# ================================================================
# React / Vite ZIP → Production DIST Builder for Google Colab
# ================================================================
#
# Does:
#   1. Shows normal Colab upload button
#   2. Uploads your React/Vite ZIP
#   3. Installs Node.js 20
#   4. Detects the actual project folder
#   5. Runs npm install
#   6. Runs npm run build
#   7. Finds the generated dist folder
#   8. Creates dist.zip
#   9. Downloads dist.zip
#
# Final result:
#   dist/
#     index.html
#     assets/
#     *.js
#     *.css
#
# The resulting DIST is for production/offline use.
# ================================================================

import os
import sys
import shutil
import zipfile
import subprocess
from pathlib import Path

from google.colab import files

# ------------------------------------------------
# Configuration
# ------------------------------------------------

WORK_DIR = Path("/content/react_build")
UPLOAD_DIR = WORK_DIR / "upload"
EXTRACT_DIR = WORK_DIR / "project"
OUTPUT_DIR = WORK_DIR / "final_dist"

# Clean previous run
if WORK_DIR.exists():
    shutil.rmtree(WORK_DIR)

UPLOAD_DIR.mkdir(parents=True)
EXTRACT_DIR.mkdir(parents=True)
OUTPUT_DIR.mkdir(parents=True)

print("=" * 70)
print(" React/Vite → DIST Builder")
print("=" * 70)
print()
print("Click the upload button below and select your React/Vite ZIP.")
print()

# ------------------------------------------------
# NORMAL COLAB UPLOAD BUTTON
# ------------------------------------------------

uploaded = files.upload()

if not uploaded:
    raise RuntimeError("No ZIP file was uploaded.")

zip_name = next(iter(uploaded.keys()))
zip_path = UPLOAD_DIR / zip_name

# The uploaded file is already in /content.
# Move it into our working directory.
source_path = Path("/content") / zip_name

if source_path.exists():
    shutil.move(str(source_path), str(zip_path))
else:
    raise RuntimeError("Uploaded ZIP could not be found.")

print()
print("=" * 70)
print("Uploaded:")
print(zip_name)
print("=" * 70)

# ------------------------------------------------
# Check ZIP
# ------------------------------------------------

if not zipfile.is_zipfile(zip_path):
    raise RuntimeError("The uploaded file is not a valid ZIP file.")

# ------------------------------------------------
# Extract
# ------------------------------------------------

print()
print("Extracting project...")

with zipfile.ZipFile(zip_path, "r") as z:
    z.extractall(EXTRACT_DIR)

print("Extraction complete.")

# ------------------------------------------------
# Find package.json
# ------------------------------------------------

package_files = list(EXTRACT_DIR.rglob("package.json"))

if not package_files:
    raise RuntimeError(
        "Could not find package.json.\n"
        "Make sure the ZIP contains the React/Vite project."
    )

# Prefer the package.json closest to the project root
package_files.sort(key=lambda p: len(p.parts))

PROJECT_DIR = package_files[0].parent

print()
print("=" * 70)
print("Project detected:")
print(PROJECT_DIR)
print("=" * 70)

# ------------------------------------------------
# Install Node.js 20
# ------------------------------------------------

print()
print("=" * 70)
print("Installing Node.js 20...")
print("=" * 70)

# Clean apt metadata first
subprocess.run(
    ["bash", "-c", "apt-get clean"],
    check=False
)

subprocess.run(
    ["bash", "-c", "rm -rf /var/lib/apt/lists/*"],
    check=False
)

subprocess.run(
    ["bash", "-c", "apt-get update"],
    check=True
)

# Install curl if necessary
subprocess.run(
    ["bash", "-c", "apt-get install -y curl ca-certificates"],
    check=True
)

# NodeSource
subprocess.run(
    [
        "bash",
        "-c",
        "curl -fsSL https://deb.nodesource.com/setup_20.x | bash -"
    ],
    check=True
)

subprocess.run(
    ["bash", "-c", "apt-get install -y nodejs"],
    check=True
)

# ------------------------------------------------
# Verify Node/npm
# ------------------------------------------------

print()
print("=" * 70)
print("Node.js version:")
print("=" * 70)

subprocess.run(["node", "--version"], check=True)

print()
print("npm version:")
subprocess.run(["npm", "--version"], check=True)

# ------------------------------------------------
# Read package.json
# ------------------------------------------------

import json

with open(PROJECT_DIR / "package.json", "r", encoding="utf-8") as f:
    package_json = json.load(f)

scripts = package_json.get("scripts", {})

print()
print("=" * 70)
print("Available npm scripts:")
print("=" * 70)

for name, command in scripts.items():
    print(f"  {name}: {command}")

# ------------------------------------------------
# Install dependencies
# ------------------------------------------------

print()
print("=" * 70)
print("Installing dependencies...")
print("=" * 70)

npm_install = subprocess.run(
    ["npm", "install"],
    cwd=str(PROJECT_DIR),
)

if npm_install.returncode != 0:
    raise RuntimeError(
        "npm install failed.\n"
        "Check the error printed above."
    )

# ------------------------------------------------
# Build project
# ------------------------------------------------

print()
print("=" * 70)
print("Building production DIST...")
print("=" * 70)

if "build" not in scripts:
    raise RuntimeError(
        "This project does not have an 'npm run build' script "
        "in package.json."
    )

build = subprocess.run(
    ["npm", "run", "build"],
    cwd=str(PROJECT_DIR),
)

if build.returncode != 0:
    raise RuntimeError(
        "npm run build failed.\n"
        "Check the build error printed above."
    )

# ------------------------------------------------
# Find generated dist folder
# ------------------------------------------------

print()
print("=" * 70)
print("Searching for generated DIST...")
print("=" * 70)

dist_candidates = []

for p in PROJECT_DIR.rglob("dist"):
    if p.is_dir():
        # Ignore node_modules
        if "node_modules" not in p.parts:
            dist_candidates.append(p)

if not dist_candidates:
    raise RuntimeError(
        "Build completed, but no dist folder was found."
    )

# Prefer project-root/dist
root_dist = PROJECT_DIR / "dist"

if root_dist.exists():
    DIST_DIR = root_dist
else:
    DIST_DIR = dist_candidates[0]

print("DIST found:")
print(DIST_DIR)

# ------------------------------------------------
# Copy DIST to clean output directory
# ------------------------------------------------

FINAL_DIST = OUTPUT_DIR / "dist"

if FINAL_DIST.exists():
    shutil.rmtree(FINAL_DIST)

shutil.copytree(DIST_DIR, FINAL_DIST)

# ------------------------------------------------
# Show generated files
# ------------------------------------------------

print()
print("=" * 70)
print("BUILD SUCCESSFUL")
print("=" * 70)

file_count = 0
total_size = 0

for file_path in FINAL_DIST.rglob("*"):
    if file_path.is_file():
        file_count += 1
        total_size += file_path.stat().st_size

print()
print(f"Files generated: {file_count}")
print(f"Size: {total_size / 1024 / 1024:.2f} MB")

print()
print("DIST contents:")
print("-" * 70)

for path in sorted(FINAL_DIST.rglob("*")):
    relative = path.relative_to(FINAL_DIST)

    if path.is_dir():
        print(f"[DIR]  {relative}")
    else:
        size = path.stat().st_size
        print(f"[FILE] {relative} ({size / 1024:.1f} KB)")

# ------------------------------------------------
# Create ZIP
# ------------------------------------------------

print()
print("=" * 70)
print("Creating dist.zip...")
print("=" * 70)

DIST_ZIP = WORK_DIR / "dist.zip"

if DIST_ZIP.exists():
    DIST_ZIP.unlink()

shutil.make_archive(
    str(DIST_ZIP.with_suffix("")),
    "zip",
    root_dir=OUTPUT_DIR,
    base_dir="dist"
)

print()
print("=" * 70)
print("DONE!")
print("=" * 70)

print()
print("Your production files are here:")
print(FINAL_DIST)

print()
print("Your downloadable ZIP is:")
print(DIST_ZIP)

print()
print("Downloading dist.zip...")

files.download(str(DIST_ZIP))

print()
print("=" * 70)
print("Finished.")
print("=" * 70)