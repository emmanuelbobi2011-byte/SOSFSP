export interface TeamMember {
  id: string;
  name: string;
  role: string;
  department: 'Academic Leadership' | 'Web & Software' | 'Junior Code & Logic' | 'STEM & Robotics';
  bio: string;
  badgeIcon: string;
  initials: string;
  skills: string[];
  focusArea: string;
  linkedin?: string;
  github?: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  tagline: string;
  iconName: string;
  category: 'Foundation' | 'Web Dev' | 'Python & Logic' | 'STEM & Hardware';
  ageGroup: string;
  description: string;
  deliverables: string[];
  technologies: string[];
  metrics: string;
}

export interface CaseStudy {
  id: string;
  title: string;
  client: string; // e.g. Student Cohort / Partner School
  category: 'Web Apps' | 'Educational Games' | 'School Tools' | 'Algorithms';
  iconName: string;
  overview: string;
  challenge: string;
  solution: string;
  results: {
    label: string;
    value: string;
  }[];
  tags: string[];
}

export interface Testimonial {
  id: string;
  quote: string;
  clientName: string;
  role: string;
  company: string; // e.g. Parent / School of Science / High School in Osun
  initials: string;
  rating: number;
  projectCategory: string;
}

export interface Milestone {
  year: string;
  title: string;
  description: string;
  highlight: string;
}

export interface CoreValue {
  iconName: string;
  title: string;
  subtitle: string;
  description: string;
  keyPillar: string;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: 'Enrollment' | 'Curriculum' | 'Schools & Venues' | 'Requirements';
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  role: string; // 'Parent', 'Student', 'School Principal / Teacher', 'Partner'
  programInterest: string;
  studentAge: string;
  message: string;
}

