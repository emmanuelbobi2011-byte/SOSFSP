import React, { useState } from 'react';
import { 
  FolderKanban, 
  ArrowUpRight, 
  CheckCircle2, 
  Code2,
  Sparkles,
  X,
  School,
  GraduationCap,
  Laptop,
  Gamepad2,
  FlaskConical,
  Building2,
  Terminal
} from 'lucide-react';
import { CASE_STUDIES } from '../data/companyData';
import { CaseStudy } from '../types';

interface PortfolioProps {
  darkMode: boolean;
  onOpenConsultation: () => void;
}

export const Portfolio: React.FC<PortfolioProps> = ({ darkMode, onOpenConsultation }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeModalStudy, setActiveModalStudy] = useState<CaseStudy | null>(null);

  const categories = ['All', 'Web Apps', 'Educational Games', 'School Tools', 'Algorithms'];

  const filteredStudies = selectedCategory === 'All'
    ? CASE_STUDIES
    : CASE_STUDIES.filter(s => s.category === selectedCategory);

  const getCaseStudyIcon = (iconName: string) => {
    switch (iconName) {
      case 'Laptop': return Laptop;
      case 'Gamepad2': return Gamepad2;
      case 'FlaskConical': return FlaskConical;
      case 'Building2': return Building2;
      case 'Terminal': return Terminal;
      default: return Code2;
    }
  };

  return (
    <section 
      id="portfolio"
      className="py-24 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <FolderKanban className="w-3.5 h-3.5" />
              <span>Young Coders in Action</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display">
              Built by Our Students in Ile-Ife.
            </h2>
            <p className={`text-base leading-relaxed ${
              darkMode ? 'text-slate-300' : 'text-slate-600'
            }`}>
              See what young minds from School of Science and partner schools build after just a few weeks of structured coding instruction and project mentoring.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-slate-800 self-start md:self-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  selectedCategory === cat
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Case Studies Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {filteredStudies.map((study) => {
            const IconComponent = getCaseStudyIcon(study.iconName);
            return (
              <div
                key={study.id}
                onClick={() => setActiveModalStudy(study)}
                className={`cursor-pointer rounded-3xl border overflow-hidden transition-all duration-300 hover:-translate-y-1.5 group flex flex-col justify-between ${
                  darkMode
                    ? 'bg-slate-900/40 border-slate-800/80 hover:border-emerald-500/50 hover:bg-slate-900/80'
                    : 'bg-white border-slate-200 hover:border-emerald-500/50 shadow-sm'
                }`}
              >
                <div>
                  {/* Visual Project Canvas */}
                  <div className="relative py-10 px-8 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800 overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
                    
                    <div className="flex items-center justify-between relative z-10 mb-6">
                      <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                        <IconComponent className="w-6 h-6" />
                      </div>
                      <span className="text-[11px] font-bold uppercase tracking-wider bg-slate-900/90 text-emerald-300 px-3 py-1 rounded-full border border-emerald-500/30">
                        {study.category}
                      </span>
                    </div>

                    <div className="relative z-10 space-y-2">
                      <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono">
                        <Terminal className="w-3.5 h-3.5" />
                        <span>Project Milestone & Code Demo</span>
                      </div>
                      <h4 className="text-lg font-bold text-white font-display">
                        {study.title}
                      </h4>
                    </div>

                    {/* Student Creator Tag */}
                    <div className="mt-6 pt-4 border-t border-slate-800/80 flex items-center justify-between relative z-10">
                      <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                        <GraduationCap className="w-4 h-4 text-emerald-400" />
                        <span>{study.client}</span>
                      </span>
                      <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:bg-emerald-500 group-hover:text-white transition-colors">
                        <ArrowUpRight className="w-4 h-4" />
                      </div>
                    </div>
                  </div>

                  {/* Content */}
                  <div className="p-8 space-y-4">
                    <p className={`text-sm leading-relaxed ${
                      darkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      {study.overview}
                    </p>

                    {/* Impact Results Bar */}
                    <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-950/80 border border-slate-800">
                      {study.results.map((res, idx) => (
                        <div key={idx} className="text-center">
                          <div className="text-lg font-black font-display text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
                            {res.value}
                          </div>
                          <div className="text-[10px] uppercase font-bold text-slate-400 mt-0.5">
                            {res.label}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Tags Footer */}
                <div className="px-8 pb-8 flex flex-wrap gap-1.5">
                  {study.tags.map((tag, idx) => (
                    <span 
                      key={idx}
                      className="text-[10px] font-mono px-2.5 py-1 rounded-full bg-slate-800/80 text-emerald-300 border border-slate-700"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

              </div>
            );
          })}
        </div>

        {/* Detailed Modal Viewer */}
        {activeModalStudy && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
            <div className={`max-w-2xl w-full rounded-3xl border p-8 max-h-[90vh] overflow-y-auto relative ${
              darkMode ? 'bg-slate-900 border-slate-800 text-white' : 'bg-white border-slate-200 text-slate-900'
            }`}>
              <button
                onClick={() => setActiveModalStudy(null)}
                className="absolute top-6 right-6 p-2 rounded-xl bg-slate-800/80 text-slate-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>

              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                Student Project • {activeModalStudy.category}
              </span>
              <h3 className="text-2xl font-bold font-display mt-2 mb-2">
                {activeModalStudy.title}
              </h3>
              <p className="text-xs text-slate-400 mb-6">
                Created by: <span className="text-emerald-400 font-semibold">{activeModalStudy.client}</span>
              </p>

              <div className="space-y-6 text-sm">
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 mb-1">
                    The Problem / Objective
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    {activeModalStudy.challenge}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 mb-1">
                    Student's Code Solution
                  </h4>
                  <p className="text-slate-300 leading-relaxed">
                    {activeModalStudy.solution}
                  </p>
                </div>

                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-teal-400 mb-2">
                    Learning Milestones & Metrics
                  </h4>
                  <div className="grid grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-950 border border-slate-800">
                    {activeModalStudy.results.map((res, i) => (
                      <div key={i} className="text-center">
                        <div className="text-xl font-black font-display text-emerald-400">{res.value}</div>
                        <div className="text-[10px] text-slate-400 font-bold uppercase">{res.label}</div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-800 flex justify-end gap-3">
                  <button
                    onClick={() => {
                      setActiveModalStudy(null);
                      onOpenConsultation();
                    }}
                    className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-emerald-500 to-teal-600"
                  >
                    Enroll Your Child to Build Projects
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

      </div>
    </section>
  );
};


