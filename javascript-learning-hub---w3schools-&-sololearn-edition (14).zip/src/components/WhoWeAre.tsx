import React, { useState } from 'react';
import { 
  Compass, 
  Target, 
  Eye, 
  Code2, 
  GraduationCap, 
  Heart, 
  Globe2, 
  Check, 
  X, 
  History, 
  ArrowRight,
  Award,
  BookOpen,
  School,
  Sparkles
} from 'lucide-react';
import { CORE_VALUES, TIMELINE_MILESTONES } from '../data/companyData';

interface WhoWeAreProps {
  darkMode: boolean;
  onOpenConsultation: () => void;
}

export const WhoWeAre: React.FC<WhoWeAreProps> = ({ darkMode, onOpenConsultation }) => {
  const [activeStoryTab, setActiveStoryTab] = useState<'mission' | 'vision' | 'dna'>('mission');

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Code2': return Code2;
      case 'GraduationCap': return GraduationCap;
      case 'Heart': return Heart;
      case 'Globe2': return Globe2;
      default: return BookOpen;
    }
  };

  return (
    <section 
      id="who-we-are"
      className={`py-24 relative transition-colors ${
        darkMode ? 'bg-slate-950/60' : 'bg-slate-50/80'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <School className="w-3.5 h-3.5" />
            <span>Our Identity & Purpose</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display">
            Who We Are & What Drives Us.
          </h2>
          <p className={`text-base sm:text-lg leading-relaxed ${
            darkMode ? 'text-slate-300' : 'text-slate-600'
          }`}>
            We are <span className="text-emerald-400 font-semibold">Mastery Class</span> — an educational coding movement originating from <span className="font-semibold text-white">School of Science</span> in Ile-Ife, Osun State, dedicated to teaching kids, teens, and youth how to write software.
          </p>
        </div>

        {/* Core Narrative / Genesis & Mission Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-20">
          
          {/* Left Block: Deep Story & Heritage */}
          <div className={`lg:col-span-6 p-8 sm:p-10 rounded-3xl border flex flex-col justify-between ${
            darkMode 
              ? 'bg-slate-900/60 border-slate-800' 
              : 'bg-white border-slate-200 shadow-sm'
          }`}>
            <div className="space-y-6">
              <div className="flex items-center gap-3 text-emerald-400 font-bold text-sm tracking-wide">
                <School className="w-5 h-5 text-emerald-400" />
                <span>The School of Science Heritage</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-extrabold font-display leading-snug">
                Nurtured in Ile-Ife, inspiring the next generation of Nigerian programmers.
              </h3>
              <p className={`leading-relaxed text-sm sm:text-base ${
                darkMode ? 'text-slate-300' : 'text-slate-600'
              }`}>
                Mastery Class was founded by passionate science and ICT educators at the renowned School of Science in Ile-Ife. We noticed that while students excelled at textbook theory, they lacked hands-on programming labs to write computer software.
              </p>
              <p className={`leading-relaxed text-sm sm:text-base ${
                darkMode ? 'text-slate-300' : 'text-slate-600'
              }`}>
                We stepped in to bridge this digital divide: transforming after-school hours and holidays into dynamic coding incubators. From visual block coding to Python and full-stack web applications, we guide young minds to build technology with confidence.
              </p>
            </div>

            {/* Quick Metrics Badges */}
            <div className="grid grid-cols-3 gap-4 pt-8 mt-6 border-t border-slate-800/80">
              <div>
                <div className="text-2xl font-bold text-emerald-400 font-display">450+</div>
                <div className="text-xs text-slate-400">Students Mentored</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-teal-400 font-display">Ages 7–18</div>
                <div className="text-xs text-slate-400">Target Learners</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-cyan-400 font-display">Ile-Ife</div>
                <div className="text-xs text-slate-400">Osun State Roots</div>
              </div>
            </div>
          </div>

          {/* Right Block: Mission / Vision / Pedagogy Interactive Tabs */}
          <div className={`lg:col-span-6 p-8 sm:p-10 rounded-3xl border flex flex-col justify-between ${
            darkMode 
              ? 'bg-slate-900/60 border-slate-800' 
              : 'bg-white border-slate-200 shadow-sm'
          }`}>
            <div>
              {/* Tab Selector */}
              <div className="flex gap-2 p-1.5 rounded-2xl bg-slate-950/80 border border-slate-800 mb-6">
                {[
                  { id: 'mission', label: 'Our Mission', icon: Target },
                  { id: 'vision', label: 'Future Ambition', icon: Eye },
                  { id: 'dna', label: 'Pedagogy DNA', icon: GraduationCap },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeStoryTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveStoryTab(tab.id as any)}
                      className={`flex-1 flex items-center justify-center gap-2 py-2.5 px-3 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Tab Content Display */}
              <div className="min-h-[220px]">
                {activeStoryTab === 'mission' && (
                  <div className="space-y-4 animate-fadeIn">
                    <h4 className="text-xl font-bold text-emerald-400 font-display">
                      Teaching every young mind in Ile-Ife & Osun to write real computer code.
                    </h4>
                    <p className={`text-sm sm:text-base leading-relaxed ${
                      darkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      Our mission is to make coding intuitive, accessible, and deeply empowering for children and teenagers. We provide hands-on training, structured mentorship, and community hackathons that turn passive digital consumers into active software creators.
                    </p>
                    <ul className="space-y-2 text-xs sm:text-sm font-semibold text-slate-300">
                      <li className="flex items-center gap-2 text-emerald-400">
                        <Check className="w-4 h-4" />
                        <span>Equip 1,000+ school pupils with practical coding fundamentals annually</span>
                      </li>
                      <li className="flex items-center gap-2 text-teal-400">
                        <Check className="w-4 h-4" />
                        <span>Bridge classroom science theory with software engineering logic</span>
                      </li>
                    </ul>
                  </div>
                )}

                {activeStoryTab === 'vision' && (
                  <div className="space-y-4 animate-fadeIn">
                    <h4 className="text-xl font-bold text-teal-400 font-display">
                      A vibrant hub of young software engineers driving Nigeria's future economy.
                    </h4>
                    <p className={`text-sm sm:text-base leading-relaxed ${
                      darkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      We envision an Osun State and a Nigeria where every young boy and girl has the opportunity to master coding before finishing secondary school. We aim to establish Mastery Class tech hubs in every district, creating a pipeline of world-class innovators.
                    </p>
                    <ul className="space-y-2 text-xs sm:text-sm font-semibold text-slate-300">
                      <li className="flex items-center gap-2 text-teal-400">
                        <Check className="w-4 h-4" />
                        <span>Scaling coding clubs to secondary schools across all 30 LGAs in Osun</span>
                      </li>
                      <li className="flex items-center gap-2 text-cyan-400">
                        <Check className="w-4 h-4" />
                        <span>Preparing young Nigerian coders for global universities & tech careers</span>
                      </li>
                    </ul>
                  </div>
                )}

                {activeStoryTab === 'dna' && (
                  <div className="space-y-4 animate-fadeIn">
                    <h4 className="text-xl font-bold text-cyan-400 font-display">
                      School of Science rigor combined with playful discovery.
                    </h4>
                    <p className={`text-sm sm:text-base leading-relaxed ${
                      darkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      We blend scientific discipline—hypothesis testing, data analysis, and mathematical logic—with interactive game design and project building. Students don't just copy code; they understand the "why" behind every syntax structure.
                    </p>
                    <ul className="space-y-2 text-xs sm:text-sm font-semibold text-slate-300">
                      <li className="flex items-center gap-2 text-emerald-400">
                        <Check className="w-4 h-4" />
                        <span>100% project-based: students build games, calculators & web apps</span>
                      </li>
                      <li className="flex items-center gap-2 text-teal-400">
                        <Check className="w-4 h-4" />
                        <span>Empathetic, patient tutoring tailored to each child's pace</span>
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-6 border-t border-slate-800/80 flex items-center justify-between">
              <span className="text-xs text-slate-400">Want to enroll your child or school?</span>
              <button 
                onClick={onOpenConsultation}
                className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1.5"
              >
                <span>Speak With Our Academic Lead</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

        </div>

        {/* Core Values 4-Card Bento Grid */}
        <div className="space-y-6 mb-24">
          <div className="text-center space-y-2">
            <h3 className="text-2xl sm:text-3xl font-extrabold font-display">
              Our Core Educational Pillars
            </h3>
            <p className="text-sm text-slate-400 max-w-xl mx-auto">
              Principles guiding every lesson plan, coding challenge, and student mentorship session.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {CORE_VALUES.map((val, idx) => {
              const Icon = getIcon(val.iconName);
              return (
                <div
                  key={idx}
                  className={`p-6 rounded-2xl border transition-all duration-300 hover:-translate-y-1 group flex flex-col justify-between ${
                    darkMode
                      ? 'bg-slate-900/50 border-slate-800 hover:border-emerald-500/50 hover:bg-slate-900/90'
                      : 'bg-white border-slate-200 hover:border-emerald-500/50 shadow-sm'
                  }`}
                >
                  <div className="space-y-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-tr from-emerald-500/20 to-teal-600/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-110 transition-transform">
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <h4 className="text-lg font-bold font-display group-hover:text-emerald-400 transition-colors">
                        {val.title}
                      </h4>
                      <p className="text-xs font-semibold text-slate-400 mt-0.5">
                        {val.subtitle}
                      </p>
                    </div>
                    <p className={`text-xs sm:text-sm leading-relaxed ${
                      darkMode ? 'text-slate-300' : 'text-slate-600'
                    }`}>
                      {val.description}
                    </p>
                  </div>

                  <div className="mt-6 pt-4 border-t border-slate-800/80">
                    <span className="inline-block text-[11px] font-bold text-emerald-400 bg-emerald-500/10 px-2.5 py-1 rounded-full border border-emerald-500/20">
                      {val.keyPillar}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Why Choose Us Comparison Matrix (Standard Rote Learning vs Mastery Class) */}
        <div className={`p-8 sm:p-12 rounded-3xl border mb-24 ${
          darkMode 
            ? 'bg-slate-900/70 border-slate-800' 
            : 'bg-white border-slate-200 shadow-md'
        }`}>
          <div className="text-center max-w-2xl mx-auto space-y-3 mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <Award className="w-3.5 h-3.5" />
              <span>The Mastery Class Advantage</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold font-display">
              Why Parents & Schools Choose Mastery Class
            </h3>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-slate-800 text-xs font-bold uppercase tracking-wider text-slate-400">
                  <th className="pb-4 pl-2">Learning Aspect</th>
                  <th className="pb-4 text-slate-500">Traditional Computer Studies</th>
                  <th className="pb-4 text-emerald-400 font-extrabold">Mastery Class Coding</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-medium">
                {[
                  {
                    aspect: 'Learning Method',
                    traditional: 'Rote memorization of textbook definitions on paper',
                    mastery: 'Hands-on coding, writing real code from day one',
                  },
                  {
                    aspect: 'Languages & Stacks',
                    traditional: 'Outdated word processing drills only',
                    mastery: 'Scratch 3.0, HTML5, CSS3, JavaScript, Python 3',
                  },
                  {
                    aspect: 'Outcome & Portfolio',
                    traditional: 'Zero tangible projects built',
                    mastery: 'Personal websites, playable games, & science tools deployed',
                  },
                  {
                    aspect: 'Instructor Mentorship',
                    traditional: 'Overcrowded classes with minimal individual guidance',
                    mastery: 'Dedicated small cohorts & personalized project coaching',
                  },
                  {
                    aspect: 'School of Science Roots',
                    traditional: 'Disconnected from scientific application',
                    mastery: 'Rooted in Ile-Ife science excellence & logic modeling',
                  },
                ].map((row, i) => (
                  <tr key={i} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-4 pl-2 font-bold text-slate-200">{row.aspect}</td>
                    <td className="py-4 text-slate-400 flex items-center gap-2">
                      <X className="w-4 h-4 text-rose-500 shrink-0" />
                      <span>{row.traditional}</span>
                    </td>
                    <td className="py-4 text-emerald-300 font-semibold">
                      <div className="flex items-center gap-2">
                        <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                        <span>{row.mastery}</span>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Milestones / Growth Timeline */}
        <div className="space-y-10">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-teal-500/10 text-teal-400 border border-teal-500/30">
              <History className="w-3.5 h-3.5" />
              <span>Milestones & Growth</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold font-display">
              Our Journey Through Time
            </h3>
            <p className="text-sm text-slate-400">
              From our humble beginnings at School of Science in 2021 to empowering hundreds across Osun State.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {TIMELINE_MILESTONES.map((m, idx) => (
              <div 
                key={idx}
                className={`p-6 rounded-2xl border relative transition-all duration-300 hover:border-emerald-500/40 ${
                  darkMode 
                    ? 'bg-slate-900/40 border-slate-800' 
                    : 'bg-white border-slate-200 shadow-sm'
                }`}
              >
                <div className="text-2xl font-black font-display text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400 mb-2">
                  {m.year}
                </div>
                <h4 className="text-base font-bold text-white mb-2">
                  {m.title}
                </h4>
                <p className="text-xs text-slate-400 leading-relaxed mb-4">
                  {m.description}
                </p>
                <div className="text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 inline-block">
                  ✓ {m.highlight}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

