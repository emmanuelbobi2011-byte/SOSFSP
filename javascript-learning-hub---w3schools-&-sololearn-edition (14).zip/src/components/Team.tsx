import React, { useState } from 'react';
import { 
  Users, 
  Linkedin, 
  Twitter, 
  Github, 
  ArrowRight,
  School,
  GraduationCap,
  BookOpen,
  Code2,
  Terminal,
  Cpu,
  HeartHandshake
} from 'lucide-react';
import { TEAM_MEMBERS } from '../data/companyData';

interface TeamProps {
  darkMode: boolean;
  onOpenConsultation: () => void;
}

export const Team: React.FC<TeamProps> = ({ darkMode, onOpenConsultation }) => {
  const [selectedDept, setSelectedDept] = useState<string>('All');
  const departments = ['All', 'Academic Leadership', 'Junior Code & Logic', 'Web & Software', 'STEM & Robotics'];

  const filteredTeam = selectedDept === 'All'
    ? TEAM_MEMBERS
    : TEAM_MEMBERS.filter(m => m.department === selectedDept);

  const getBadgeIcon = (iconName?: string) => {
    switch (iconName) {
      case 'School': return School;
      case 'GraduationCap': return GraduationCap;
      case 'Code2': return Code2;
      case 'Terminal': return Terminal;
      case 'Cpu': return Cpu;
      default: return BookOpen;
    }
  };

  return (
    <section 
      id="team"
      className={`py-24 relative transition-colors ${
        darkMode ? 'bg-slate-950/40' : 'bg-slate-50/60'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <School className="w-3.5 h-3.5" />
              <span>Instructors & Mentors</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display">
              Dedicated Mentors Guiding Young Minds.
            </h2>
            <p className={`text-base leading-relaxed ${
              darkMode ? 'text-slate-300' : 'text-slate-600'
            }`}>
              Our teachers and coding instructors are seasoned educators from School of Science and STEM alumni who specialize in making programming approachable, fun, and rigorous.
            </p>
          </div>

          {/* Department Filter Buttons */}
          <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-slate-800 self-start md:self-auto">
            {departments.map((dept) => (
              <button
                key={dept}
                onClick={() => setSelectedDept(dept)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  selectedDept === dept
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {dept}
              </button>
            ))}
          </div>
        </div>

        {/* Team Members Grid (No maker photos, clean monogram avatar design) */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredTeam.map((member) => {
            const BadgeIcon = getBadgeIcon(member.badgeIcon);
            return (
              <div
                key={member.id}
                className={`rounded-3xl border overflow-hidden transition-all duration-300 hover:-translate-y-1.5 group flex flex-col justify-between ${
                  darkMode
                    ? 'bg-slate-900/50 border-slate-800/80 hover:border-emerald-500/50 hover:bg-slate-900/90'
                    : 'bg-white border-slate-200 hover:border-emerald-500/50 shadow-sm'
                }`}
              >
                <div>
                  {/* Decorative Geometric Monogram Header (Strictly No Maker Photo) */}
                  <div className="relative py-8 px-6 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 border-b border-slate-800/80 overflow-hidden flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      {/* Monogram Badge */}
                      <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 border-2 border-emerald-500/40 text-emerald-300 font-extrabold text-xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform">
                        {member.initials || member.name.split(' ').map(n => n[0]).join('')}
                      </div>

                      <div>
                        <span className="text-[10px] font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                          {member.department}
                        </span>
                        <div className="text-xs text-slate-400 font-mono mt-1">
                          {member.role}
                        </div>
                      </div>
                    </div>

                    <div className="w-10 h-10 rounded-xl bg-slate-800/60 border border-slate-700/60 flex items-center justify-center text-teal-400">
                      <BadgeIcon className="w-5 h-5" />
                    </div>
                  </div>

                  {/* Info Section */}
                  <div className="p-6 space-y-3">
                    <div>
                      <h3 className="text-xl font-bold font-display text-white group-hover:text-emerald-400 transition-colors">
                        {member.name}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs text-emerald-400/90 font-medium mt-0.5">
                        <School className="w-3.5 h-3.5" />
                        <span>School of Science Academic Faculty</span>
                      </div>
                    </div>

                    <p className="text-xs leading-relaxed text-slate-300">
                      {member.bio}
                    </p>

                    {/* Skills / Teaching Subject Badges */}
                    <div className="flex flex-wrap gap-1.5 pt-2">
                      {member.skills.map((skill, idx) => (
                        <span 
                          key={idx}
                          className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-slate-800/80 text-emerald-300 border border-slate-700/60"
                        >
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Footer Section */}
                <div className="px-6 py-4 border-t border-slate-800/80 flex items-center justify-between">
                  <span className="text-[11px] text-slate-400 font-medium">Instructor Office: Ile-Ife</span>
                  <div className="flex items-center gap-2">
                    {member.linkedin && (
                      <a
                        href={member.linkedin}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors"
                        title="Profile"
                      >
                        <Linkedin className="w-4 h-4" />
                      </a>
                    )}
                    {member.github && (
                      <a
                        href={member.github}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors"
                        title="Code Curriculum"
                      >
                        <Github className="w-4 h-4" />
                      </a>
                    )}
                  </div>
                </div>

              </div>
            );
          })}
        </div>

        {/* Career / Volunteer Mentorship Callout */}
        <div className="mt-16 text-center space-y-4">
          <p className="text-sm text-slate-400">
            Are you a passionate software developer or science teacher in Osun State who loves mentoring kids?
          </p>
          <button
            onClick={onOpenConsultation}
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-xs font-bold text-slate-200 hover:text-white border border-slate-800 bg-slate-900/60 hover:bg-slate-800 transition-colors"
          >
            <HeartHandshake className="w-4 h-4 text-emerald-400" />
            <span>Join as a Mentor or Volunteer</span>
            <ArrowRight className="w-3.5 h-3.5 text-emerald-400" />
          </button>
        </div>

      </div>
    </section>
  );
};

