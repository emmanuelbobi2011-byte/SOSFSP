import React, { useState } from 'react';
import { 
  ArrowRight, 
  GraduationCap, 
  ShieldCheck, 
  Zap, 
  CheckCircle2, 
  Code2, 
  Terminal, 
  Blocks,
  Globe2,
  BookOpen,
  School
} from 'lucide-react';
import { COMPANY_STATS } from '../data/companyData';

interface HeroProps {
  darkMode: boolean;
  onOpenConsultation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ darkMode, onOpenConsultation }) => {
  const [activeTab, setActiveTab] = useState<'scratch' | 'web' | 'python'>('scratch');

  return (
    <section 
      id="hero"
      className="relative pt-32 pb-20 md:pt-40 md:pb-32 overflow-hidden"
    >
      {/* Background Glows */}
      <div className="absolute inset-0 pointer-events-none -z-10">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-emerald-500/10 rounded-full blur-[140px]" />
        <div className="absolute top-1/3 right-10 w-[450px] h-[450px] bg-teal-500/10 rounded-full blur-[120px]" />
        <div className="absolute -bottom-10 left-10 w-[400px] h-[400px] bg-cyan-600/10 rounded-full blur-[100px]" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          
          {/* Left Column: Core Value Proposition */}
          <div className="lg:col-span-7 space-y-8 text-center lg:text-left">
            
            {/* Pill Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-bold border tracking-wide uppercase shadow-sm backdrop-blur-md bg-emerald-500/10 text-emerald-400 border-emerald-500/30">
              <School className="w-3.5 h-3.5 text-emerald-400" />
              <span>School of Science • Ile-Ife, Osun State</span>
            </div>

            {/* Main Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight font-display leading-[1.14]">
              Teaching Young Minds <br className="hidden sm:inline" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-teal-400 to-cyan-400">
                To Build & Code the Future.
              </span>
            </h1>

            {/* Subtitle */}
            <p className={`text-base sm:text-lg max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal ${
              darkMode ? 'text-slate-300' : 'text-slate-600'
            }`}>
              Originating from the prestigious <span className="text-emerald-400 font-semibold">School of Science</span> in Ile-Ife, Osun State, <span className="font-semibold text-white">Mastery Class</span> is on a passionate mission to equip kids, teenagers, and school pupils with practical computer programming, algorithmic thinking, web development, and digital problem-solving skills.
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                id="btn-hero-consultation"
                onClick={onOpenConsultation}
                className="px-7 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-emerald-500 via-teal-600 to-cyan-600 hover:from-emerald-400 hover:via-teal-500 hover:to-cyan-500 shadow-xl shadow-emerald-500/25 hover:shadow-emerald-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 flex items-center gap-2 group"
              >
                <GraduationCap className="w-4 h-4" />
                <span>Enroll a Young Coder</span>
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                id="btn-hero-who-we-are"
                href="#who-we-are"
                className={`px-6 py-3.5 rounded-xl font-bold text-sm border transition-all duration-200 flex items-center gap-2 ${
                  darkMode
                    ? 'border-slate-800 bg-slate-900/60 hover:bg-slate-800 text-slate-200 hover:text-white'
                    : 'border-slate-300 bg-white hover:bg-slate-100 text-slate-800'
                }`}
              >
                <BookOpen className="w-4 h-4 text-emerald-400" />
                <span>Discover Our Story</span>
              </a>
            </div>

            {/* Trust Micro-Bullets */}
            <div className="pt-4 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs font-semibold">
              <div className="flex items-center gap-1.5 text-emerald-400">
                <CheckCircle2 className="w-4 h-4" />
                <span>Ages 7 to 18 Coding Tracks</span>
              </div>
              <div className="flex items-center gap-1.5 text-teal-400">
                <ShieldCheck className="w-4 h-4" />
                <span>School of Science Pedagogy</span>
              </div>
              <div className="flex items-center gap-1.5 text-cyan-400">
                <Globe2 className="w-4 h-4" />
                <span>Ile-Ife & Osun Community Focus</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Code Learning Terminal */}
          <div className="lg:col-span-5">
            <div className={`rounded-2xl border p-5 shadow-2xl backdrop-blur-xl transition-all duration-300 relative ${
              darkMode 
                ? 'bg-slate-900/80 border-slate-800 shadow-emerald-950/20' 
                : 'bg-white/95 border-slate-200 shadow-slate-200'
            }`}>
              
              {/* Card Window Controls */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-800/60">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="text-[11px] font-mono text-slate-400 ml-2 font-medium">mastery-lab://ile-ife/young-coders</span>
                </div>
                <div className="flex items-center gap-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded text-[10px] font-mono">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping mr-1" />
                  Live Lab: Active
                </div>
              </div>

              {/* Interactive Tabs */}
              <div className="flex gap-2 my-4">
                {[
                  { id: 'scratch', label: 'Junior Logic', icon: Blocks },
                  { id: 'web', label: 'Web Dev', icon: Code2 },
                  { id: 'python', label: 'Python Lab', icon: Terminal },
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id as any)}
                      className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-bold transition-all ${
                        isActive
                          ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                          : darkMode 
                            ? 'bg-slate-800/50 text-slate-400 hover:text-slate-200' 
                            : 'bg-slate-100 text-slate-600 hover:text-slate-900'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Tab Display Panel */}
              <div className="rounded-xl bg-slate-950 p-4 border border-slate-800/80 font-mono text-xs text-slate-300 space-y-3">
                {activeTab === 'scratch' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-amber-400 font-semibold">
                      <span>▸ Visual Block Algorithm (Ages 7–11)</span>
                      <span className="text-slate-500 text-[10px]">Scratch 3.0</span>
                    </div>
                    <div className="bg-slate-900/90 rounded p-2.5 space-y-1.5 text-[11px] text-slate-300 border border-slate-800">
                      <div className="text-emerald-400">when green flag clicked:</div>
                      <div className="pl-4 text-cyan-300">repeat 10:</div>
                      <div className="pl-8 text-amber-300">move (10) steps</div>
                      <div className="pl-8 text-purple-300">play sound (celebrate.wav)</div>
                      <div className="pl-4 text-teal-400">say "Hello, Ile-Ife young coder!" for 2 secs</div>
                    </div>
                    <p className="text-[11px] text-slate-400 pt-1 font-sans">
                      Building foundational spatial logic, sequence loops, and creative problem-solving.
                    </p>
                  </div>
                )}

                {activeTab === 'web' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-teal-400 font-semibold">
                      <span>▸ Real Frontend Code (Ages 12–18)</span>
                      <span className="text-emerald-400 text-[10px]">HTML5 / CSS / JS</span>
                    </div>
                    <div className="bg-slate-900/90 rounded p-2.5 space-y-1.5 text-[11px] text-slate-300 border border-slate-800">
                      <div className="text-slate-400">&lt;div class="student-card"&gt;</div>
                      <div className="pl-4 text-cyan-300">&lt;h1&gt;School of Science Innovation&lt;/h1&gt;</div>
                      <div className="pl-4 text-emerald-400">&lt;button onclick="launchProject()"&gt;Run Code&lt;/button&gt;</div>
                      <div className="text-slate-400">&lt;/div&gt;</div>
                    </div>
                    <p className="text-[11px] text-slate-400 pt-1 font-sans">
                      Students deploy genuine responsive web pages and interactive digital portfolios.
                    </p>
                  </div>
                )}

                {activeTab === 'python' && (
                  <div className="space-y-2">
                    <div className="flex items-center justify-between text-cyan-400 font-semibold">
                      <span>▸ Python Science & Math (Teens)</span>
                      <span className="text-amber-400 text-[10px]">Python 3.12</span>
                    </div>
                    <div className="bg-slate-900/90 rounded p-2.5 space-y-1.5 text-[11px] text-slate-300 border border-slate-800">
                      <div className="text-emerald-400">def calculate_gravity(mass, height):</div>
                      <div className="pl-4 text-cyan-300">g = 9.8 # School of Science Physics</div>
                      <div className="pl-4 text-amber-300">energy = mass * g * height</div>
                      <div className="pl-4 text-purple-300">return f"Potential Energy: &#123;energy&#125; Joules"</div>
                    </div>
                    <p className="text-[11px] text-slate-400 pt-1 font-sans">
                      Connecting classroom science equations with computational software automation.
                    </p>
                  </div>
                )}
              </div>

              {/* Bottom Quick Callout */}
              <div className="mt-4 pt-3 border-t border-slate-800/60 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <School className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-bold text-slate-200">School & Hub Cohorts</div>
                    <div className="text-[10px] text-slate-400">Weekend & holiday coding sessions</div>
                  </div>
                </div>
                <button
                  onClick={onOpenConsultation}
                  className="text-xs font-bold text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1"
                >
                  <span>Join Cohort</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>

            </div>
          </div>

        </div>

        {/* Impact Stats Counter Bar */}
        <div className="mt-16 pt-10 border-t border-slate-800/80">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            {COMPANY_STATS.map((stat, idx) => (
              <div 
                key={idx}
                className={`p-5 rounded-2xl border transition-all duration-300 hover:scale-[1.02] ${
                  darkMode 
                    ? 'bg-slate-900/40 border-slate-800/80 hover:border-emerald-500/40' 
                    : 'bg-white/70 border-slate-200 hover:border-emerald-500/40 shadow-sm'
                }`}
              >
                <div className="text-3xl sm:text-4xl font-black font-display text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">
                  {stat.value}
                </div>
                <div className={`text-sm font-bold mt-1 ${darkMode ? 'text-white' : 'text-slate-900'}`}>
                  {stat.label}
                </div>
                <div className="text-xs text-slate-400 mt-0.5">
                  {stat.detail}
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

