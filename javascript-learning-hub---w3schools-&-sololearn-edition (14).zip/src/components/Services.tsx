import React, { useState } from 'react';
import { 
  BookOpen, 
  Code2, 
  Terminal, 
  Blocks, 
  Cpu, 
  Lightbulb, 
  Users, 
  ArrowRight, 
  CheckCircle2, 
  Sparkles,
  GraduationCap,
  School
} from 'lucide-react';
import { SERVICES } from '../data/companyData';
import { ServiceItem } from '../types';

interface ServicesProps {
  darkMode: boolean;
  onOpenConsultation: () => void;
  onSelectService: (service: ServiceItem) => void;
}

export const Services: React.FC<ServicesProps> = ({ 
  darkMode, 
  onOpenConsultation,
  onSelectService 
}) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const categories = ['All', 'Visual & Logic', 'Web Frontend', 'Python & Math', 'STEM & Hardware', 'School Clubs'];

  const filteredServices = activeCategory === 'All' 
    ? SERVICES 
    : SERVICES.filter(s => s.category === activeCategory);

  const getServiceIcon = (iconName: string) => {
    switch (iconName) {
      case 'Blocks': return Blocks;
      case 'Code2': return Code2;
      case 'Terminal': return Terminal;
      case 'Cpu': return Cpu;
      case 'Lightbulb': return Lightbulb;
      case 'Users': return Users;
      default: return BookOpen;
    }
  };

  return (
    <section 
      id="services"
      className="py-24 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-16">
          <div className="space-y-4 max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <BookOpen className="w-3.5 h-3.5" />
              <span>Structured Coding Curriculum</span>
            </div>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display">
              Programs & Coding Tracks for Young Minds.
            </h2>
            <p className={`text-base leading-relaxed ${
              darkMode ? 'text-slate-300' : 'text-slate-600'
            }`}>
              From playful visual logic puzzles to professional Python scripts and web applications, our step-by-step curriculum is designed specifically for children, teenagers, and school pupils.
            </p>
          </div>

          {/* Category Filter Pills */}
          <div className="flex flex-wrap gap-2 p-1.5 rounded-2xl bg-slate-900/80 border border-slate-800 self-start md:self-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                  activeCategory === cat
                    ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white shadow-md'
                    : 'text-slate-400 hover:text-white hover:bg-slate-800'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredServices.map((service) => {
            const Icon = getServiceIcon(service.iconName);
            return (
              <div
                key={service.id}
                className={`p-8 rounded-3xl border flex flex-col justify-between transition-all duration-300 hover:-translate-y-1.5 group relative overflow-hidden ${
                  darkMode
                    ? 'bg-slate-900/40 border-slate-800/80 hover:border-emerald-500/40 hover:bg-slate-900/80'
                    : 'bg-white border-slate-200 hover:border-emerald-500/40 shadow-sm'
                }`}
              >
                {/* Accent Top Border Bar on Hover */}
                <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-emerald-500 to-teal-600 opacity-0 group-hover:opacity-100 transition-opacity" />

                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-emerald-500/20 to-teal-600/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30 group-hover:scale-110 transition-transform">
                      <Icon className="w-7 h-7" />
                    </div>
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400 bg-slate-800/60 px-3 py-1 rounded-full border border-slate-700/50">
                      {service.category}
                    </span>
                  </div>

                  <div>
                    <h3 className="text-xl font-bold font-display group-hover:text-emerald-400 transition-colors">
                      {service.title}
                    </h3>
                    <p className="text-xs font-semibold text-emerald-400/90 mt-1">
                      {service.tagline}
                    </p>
                  </div>

                  <p className={`text-xs sm:text-sm leading-relaxed ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {service.description}
                  </p>

                  {/* Deliverables Bullet List */}
                  <div className="space-y-2 pt-2">
                    <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      What Students Learn & Build:
                    </div>
                    <ul className="space-y-1.5">
                      {service.deliverables.map((item, idx) => (
                        <li key={idx} className="flex items-start gap-2 text-xs text-slate-300">
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                          <span>{item}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Tech Stack Badges */}
                  <div className="flex flex-wrap gap-1.5 pt-2">
                    {service.technologies.map((tech, idx) => (
                      <span 
                        key={idx}
                        className="text-[10px] font-mono font-medium px-2 py-0.5 rounded bg-slate-800 text-slate-300 border border-slate-700"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Bottom Card Footer */}
                <div className="mt-8 pt-6 border-t border-slate-800/80 flex items-center justify-between">
                  <div className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                    <GraduationCap className="w-3.5 h-3.5" />
                    <span>{service.metrics}</span>
                  </div>

                  <button
                    onClick={() => {
                      onSelectService(service);
                      onOpenConsultation();
                    }}
                    className="text-xs font-bold text-emerald-400 hover:text-emerald-300 flex items-center gap-1 group/btn"
                  >
                    <span>Enroll In Track</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover/btn:translate-x-1 transition-transform" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>

        {/* Custom School Partnership Banner */}
        <div className={`mt-16 p-8 sm:p-10 rounded-3xl border flex flex-col md:flex-row items-center justify-between gap-6 ${
          darkMode 
            ? 'bg-gradient-to-r from-slate-900 to-teal-950/40 border-slate-800' 
            : 'bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200 shadow-sm'
        }`}>
          <div className="space-y-2 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 text-emerald-400 font-bold text-xs uppercase tracking-wider">
              <School className="w-4 h-4" />
              <span>School of Science & Community Partnerships</span>
            </div>
            <h4 className="text-xl sm:text-2xl font-bold font-display text-white">
              Want to launch a Coding Club at your secondary or primary school?
            </h4>
            <p className="text-sm text-slate-400 max-w-xl">
              We partner with public and private schools across Ile-Ife and Osun State to provide curriculum, verified mentors, and after-school ICT lab instruction.
            </p>
          </div>
          <button
            onClick={onOpenConsultation}
            className="px-6 py-3.5 rounded-xl font-bold text-xs sm:text-sm text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 shadow-lg shadow-emerald-500/25 shrink-0 flex items-center gap-2"
          >
            <School className="w-4 h-4" />
            <span>Inquire for School Partnership</span>
          </button>
        </div>

      </div>
    </section>
  );
};

