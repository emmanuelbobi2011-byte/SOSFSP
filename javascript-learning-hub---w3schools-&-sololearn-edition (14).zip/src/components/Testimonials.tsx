import React from 'react';
import { 
  MessageSquareQuote, 
  Star, 
  School, 
  Sparkles, 
  CheckCircle,
  GraduationCap
} from 'lucide-react';
import { TESTIMONIALS } from '../data/companyData';

interface TestimonialsProps {
  darkMode: boolean;
}

export const Testimonials: React.FC<TestimonialsProps> = ({ darkMode }) => {
  return (
    <section 
      id="testimonials"
      className={`py-24 relative transition-colors ${
        darkMode ? 'bg-slate-950/60' : 'bg-slate-50/80'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-amber-500/10 text-amber-400 border border-amber-500/30">
            <MessageSquareQuote className="w-3.5 h-3.5" />
            <span>Community Stories</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display">
            Loved by Parents, Students & Teachers in Osun State.
          </h2>
          <p className={`text-base leading-relaxed ${
            darkMode ? 'text-slate-300' : 'text-slate-600'
          }`}>
            Read how Mastery Class has inspired young minds in Ile-Ife to discover logic, build real apps, and gain digital confidence.
          </p>
        </div>

        {/* Testimonials 3-Card Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {TESTIMONIALS.map((test) => (
            <div
              key={test.id}
              className={`p-8 rounded-3xl border flex flex-col justify-between relative transition-all duration-300 hover:-translate-y-1.5 ${
                darkMode
                  ? 'bg-slate-900/40 border-slate-800/80 hover:border-emerald-500/40 hover:bg-slate-900/70'
                  : 'bg-white border-slate-200 hover:border-emerald-500/40 shadow-sm'
              }`}
            >
              {/* Top Quote Icon & Stars */}
              <div>
                <div className="flex items-center justify-between mb-6">
                  <div className="flex items-center gap-1">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
                    ))}
                  </div>
                  <span className="text-[10px] font-mono font-semibold px-2.5 py-1 rounded-full bg-slate-800 text-emerald-300 border border-slate-700">
                    {test.projectCategory}
                  </span>
                </div>

                <p className={`text-sm leading-relaxed italic mb-8 relative ${
                  darkMode ? 'text-slate-200' : 'text-slate-700'
                }`}>
                  "{test.quote}"
                </p>
              </div>

              {/* Author Profile - Monogram Badge (No personal photos) */}
              <div className="flex items-center gap-3.5 pt-4 border-t border-slate-800/80">
                <div className="w-11 h-11 rounded-full bg-gradient-to-tr from-emerald-500/20 to-teal-500/20 text-emerald-300 border-2 border-emerald-500/40 font-bold flex items-center justify-center text-sm shadow-sm">
                  {test.clientName.split(' ').map(n => n[0]).join('')}
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white font-display">
                    {test.clientName}
                  </h4>
                  <p className="text-xs text-slate-400">
                    {test.role} • <span className="text-emerald-400">{test.company}</span>
                  </p>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* School & Hub Partnerships Bar */}
        <div className="p-8 rounded-2xl border border-slate-800/80 bg-slate-900/30 text-center space-y-4">
          <span className="text-xs uppercase tracking-widest font-bold text-slate-400">
            Educational Collaborations Across Ile-Ife & Osun State
          </span>
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-12 opacity-85 transition-all duration-300">
            {[
              'School of Science, Ile-Ife',
              'Osun Youth STEM Hub',
              'Ife Junior Coders Circle',
              'Science Teachers Association Osun',
              'Osun ICT in Schools Initiative'
            ].map((brand, i) => (
              <div key={i} className="flex items-center gap-2 font-display font-semibold text-slate-300 text-xs sm:text-sm tracking-tight">
                <School className="w-4 h-4 text-emerald-400" />
                <span>{brand}</span>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};

