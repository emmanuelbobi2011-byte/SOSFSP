import React, { useState } from 'react';
import { 
  Code2, 
  Linkedin, 
  Twitter, 
  Github, 
  ArrowUp, 
  Send, 
  CheckCircle2, 
  Heart,
  Globe2,
  Mail,
  School,
  GraduationCap
} from 'lucide-react';

interface FooterProps {
  darkMode: boolean;
  onOpenConsultation: () => void;
}

export const Footer: React.FC<FooterProps> = ({ darkMode, onOpenConsultation }) => {
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(newsletterEmail)) return;
    setSubscribed(true);
    setNewsletterEmail('');
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className={`border-t transition-colors ${
      darkMode ? 'bg-slate-950 border-slate-800/80 text-slate-400' : 'bg-slate-900 border-slate-800 text-slate-400'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-12 mb-16">
          
          {/* Brand Col */}
          <div className="lg:col-span-4 space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-600 to-cyan-600 flex items-center justify-center text-white font-bold shadow-md shadow-emerald-500/25">
                <Code2 className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl font-bold tracking-tight font-display text-white">
                  MASTERY <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">CLASS</span>
                </span>
                <span className="text-[10px] uppercase font-semibold tracking-wider text-emerald-400">
                  School of Science • Ile-Ife
                </span>
              </div>
            </div>

            <p className="text-xs leading-relaxed text-slate-400 max-w-sm">
              Empowering children, teenagers, and students across Ile-Ife and Osun State with hands-on coding skills, computational thinking, and software craftsmanship.
            </p>

            <div className="flex items-center gap-3 pt-2">
              <div className="flex items-center gap-1.5 text-xs text-slate-300 font-medium">
                <School className="w-3.5 h-3.5 text-emerald-400" />
                <span>Ile-Ife Campus, Osun State, Nigeria</span>
              </div>
            </div>
          </div>

          {/* Quick Navigation Links */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Navigation
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <a href="#who-we-are" className="hover:text-emerald-400 transition-colors">Who We Are</a>
              </li>
              <li>
                <a href="#services" className="hover:text-emerald-400 transition-colors">Courses & Tracks</a>
              </li>
              <li>
                <a href="#team" className="hover:text-emerald-400 transition-colors">Mentors Guild</a>
              </li>
              <li>
                <a href="#portfolio" className="hover:text-emerald-400 transition-colors">Student Projects</a>
              </li>
              <li>
                <a href="#testimonials" className="hover:text-emerald-400 transition-colors">Community Stories</a>
              </li>
              <li>
                <a href="#contact" className="hover:text-emerald-400 transition-colors">Admissions & Contact</a>
              </li>
            </ul>
          </div>

          {/* Core Learning Tracks */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Learning Tracks
            </h4>
            <ul className="space-y-2 text-xs">
              <li><span className="text-slate-400">Junior Code & Visual Logic (Ages 7-11)</span></li>
              <li><span className="text-slate-400">Web Design & Frontend Development</span></li>
              <li><span className="text-slate-400">Python Programming & Science Computing</span></li>
              <li><span className="text-slate-400">Full-Stack Junior Software Building</span></li>
              <li><span className="text-slate-400">STEM Electronics & Micro:bit Robotics</span></li>
              <li><span className="text-slate-400">School Coding Club Partnerships</span></li>
            </ul>
          </div>

          {/* Newsletter Subscription */}
          <div className="lg:col-span-3 space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              Parent & School Updates
            </h4>
            <p className="text-xs text-slate-400 leading-relaxed">
              Get upcoming weekend cohort schedules, holiday camp registrations, and student project spotlights.
            </p>

            {subscribed ? (
              <div className="flex items-center gap-2 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold animate-fadeIn">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>Thank you for subscribing to Mastery Class updates!</span>
              </div>
            ) : (
              <form onSubmit={handleNewsletterSubmit} className="space-y-2">
                <div className="flex gap-2">
                  <input
                    type="email"
                    required
                    placeholder="parent@gmail.com"
                    value={newsletterEmail}
                    onChange={e => setNewsletterEmail(e.target.value)}
                    className="flex-1 px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-white text-xs focus:outline-none focus:border-emerald-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-white text-xs font-bold shadow-md transition-colors flex items-center justify-center"
                  >
                    <Send className="w-3.5 h-3.5" />
                  </button>
                </div>
              </form>
            )}
          </div>

        </div>

        {/* Bottom Legal & Back to Top */}
        <div className="pt-8 border-t border-slate-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-4 text-slate-400">
            <span>© {new Date().getFullYear()} Mastery Class. School of Science, Ile-Ife, Osun State, Nigeria.</span>
          </div>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-semibold transition-colors"
          >
            <span>Back to Top</span>
            <ArrowUp className="w-3.5 h-3.5 text-emerald-400" />
          </button>
        </div>

      </div>
    </footer>
  );
};

