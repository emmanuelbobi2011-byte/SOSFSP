import React, { useState, useEffect } from 'react';
import { 
  Compass, 
  BookOpen, 
  Users, 
  FolderGit2, 
  MessageSquareQuote, 
  Send, 
  Menu, 
  X, 
  Moon, 
  Sun, 
  GraduationCap,
  Code2,
  ArrowRight
} from 'lucide-react';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  onOpenConsultation: () => void;
  activeSection: string;
}

export const Navbar: React.FC<NavbarProps> = ({ 
  darkMode, 
  setDarkMode, 
  onOpenConsultation,
  activeSection 
}) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Who We Are', href: '#who-we-are', icon: Compass, id: 'who-we-are' },
    { name: 'Courses & Tracks', href: '#services', icon: BookOpen, id: 'services' },
    { name: 'Mentors Guild', href: '#team', icon: Users, id: 'team' },
    { name: 'Student Projects', href: '#portfolio', icon: FolderGit2, id: 'portfolio' },
    { name: 'Testimonials', href: '#testimonials', icon: MessageSquareQuote, id: 'testimonials' },
    { name: 'Admissions & Contact', href: '#contact', icon: Send, id: 'contact' },
  ];

  return (
    <header 
      id="top-navbar"
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled 
          ? darkMode 
            ? 'bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80 shadow-lg shadow-black/20 py-3.5' 
            : 'bg-white/90 backdrop-blur-md border-b border-slate-200/80 shadow-md shadow-slate-900/5 py-3.5'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        {/* Brand Logo */}
        <a 
          href="#" 
          id="brand-logo-link"
          className="flex items-center gap-3 group focus:outline-none"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 via-teal-600 to-cyan-600 flex items-center justify-center text-white font-bold shadow-md shadow-emerald-500/25 group-hover:scale-105 transition-transform duration-200">
            <Code2 className="w-5 h-5 text-white" />
          </div>
          <div className="flex flex-col">
            <span className={`text-xl font-bold tracking-tight font-display transition-colors ${
              darkMode ? 'text-white group-hover:text-emerald-400' : 'text-slate-900 group-hover:text-emerald-600'
            }`}>
              MASTERY <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">CLASS</span>
            </span>
            <span className={`text-[10px] uppercase font-semibold tracking-wider ${
              darkMode ? 'text-emerald-400/90' : 'text-emerald-700'
            }`}>
              School of Science • Ile-Ife
            </span>
          </div>
        </a>

        {/* Desktop Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1.5 p-1.5 rounded-full border border-slate-800/50 bg-slate-900/40 backdrop-blur-md shadow-inner">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = activeSection === link.id;
            return (
              <a
                key={link.id}
                id={`nav-link-${link.id}`}
                href={link.href}
                className={`flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-full transition-all duration-200 ${
                  isActive
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 shadow-sm shadow-emerald-500/20'
                    : darkMode
                      ? 'text-slate-300 hover:text-white hover:bg-slate-800/60'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-200/70'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-emerald-400' : 'text-slate-400'}`} />
                <span>{link.name}</span>
              </a>
            );
          })}
        </nav>

        {/* Right CTA and Theme Toggle */}
        <div className="flex items-center gap-3">
          {/* Theme Toggle Button */}
          <button
            id="theme-toggle-btn"
            onClick={() => setDarkMode(prev => !prev)}
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle Theme"
            className={`p-2.5 rounded-xl transition-all duration-200 border ${
              darkMode
                ? 'bg-slate-900/80 hover:bg-slate-800 text-amber-400 border-slate-800 hover:border-amber-400/40 shadow-sm'
                : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300 shadow-sm'
            }`}
          >
            {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>

          {/* Enroll / Book Consultation Button */}
          <button
            id="btn-nav-consultation"
            onClick={onOpenConsultation}
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2.5 text-xs font-bold rounded-xl text-white bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 shadow-md shadow-emerald-500/25 hover:shadow-lg hover:shadow-emerald-500/40 hover:-translate-y-0.5 active:translate-y-0 transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-emerald-500/50"
          >
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Enroll Student</span>
          </button>

          {/* Mobile Menu Toggle */}
          <button
            id="mobile-menu-toggle-btn"
            onClick={() => setMobileMenuOpen(prev => !prev)}
            aria-label="Toggle navigation menu"
            className={`lg:hidden p-2.5 rounded-xl border transition-colors ${
              darkMode 
                ? 'bg-slate-900 text-slate-200 border-slate-800 hover:bg-slate-800' 
                : 'bg-slate-100 text-slate-800 border-slate-300 hover:bg-slate-200'
            }`}
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div 
          id="mobile-nav-drawer"
          className={`lg:hidden border-b transition-all duration-300 px-6 py-6 space-y-3 ${
            darkMode 
              ? 'bg-slate-950/95 border-slate-800 text-white' 
              : 'bg-white/95 border-slate-200 text-slate-900'
          }`}
        >
          <div className="grid grid-cols-1 gap-2">
            {navLinks.map((link) => {
              const Icon = link.icon;
              const isActive = activeSection === link.id;
              return (
                <a
                  key={link.id}
                  href={link.href}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all ${
                    isActive 
                      ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' 
                      : darkMode 
                        ? 'text-slate-300 hover:bg-slate-900' 
                        : 'text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  <Icon className="w-4 h-4 text-emerald-400" />
                  <span>{link.name}</span>
                  <ArrowRight className="w-4 h-4 ml-auto text-slate-500" />
                </a>
              );
            })}
          </div>

          <div className="pt-4 border-t border-slate-800/60 flex flex-col gap-3">
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenConsultation();
              }}
              className="w-full py-3 px-4 rounded-xl text-sm font-bold text-white bg-gradient-to-r from-emerald-500 to-teal-600 flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              <GraduationCap className="w-4 h-4" />
              <span>Enroll Student / Book Class</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

