import React, { useState } from 'react';
import { 
  Send, 
  Mail, 
  Phone, 
  MapPin, 
  Clock, 
  ShieldCheck, 
  CheckCircle2, 
  HelpCircle, 
  ChevronDown, 
  ChevronUp, 
  Sparkles,
  ArrowRight,
  School,
  GraduationCap,
  MessageCircle
} from 'lucide-react';
import { FAQS } from '../data/companyData';
import { ContactFormData } from '../types';

interface ContactProps {
  darkMode: boolean;
  prefilledService?: string;
}

export const Contact: React.FC<ContactProps> = ({ darkMode, prefilledService }) => {
  const [formData, setFormData] = useState<ContactFormData>({
    name: '',
    email: '',
    company: '',
    service: prefilledService || 'Junior Code, Logic & Game Building',
    budget: '₦20k - ₦35k / month',
    timeline: 'Upcoming Weekend Cohort',
    message: '',
  });

  const [expandedFaq, setExpandedFaq] = useState<string | null>('faq-1');
  const [faqCategory, setFaqCategory] = useState<string>('All');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const tracksList = [
    'Junior Code, Logic & Game Building (Ages 6-10)',
    'Web Craft: HTML, CSS & Modern Frontend (Ages 11-16)',
    'Python & Algorithmic Problem Solving (Ages 12-18)',
    'Young Hardware & Robotics Lab (Ages 10-17)',
    'Full-Stack Junior Web Bootcamp (Ages 14-18)',
    'Weekend Coding Club for Kids'
  ];

  const sessionTimings = [
    'Upcoming Weekend Cohort (Saturdays 9am - 1pm)',
    'After-School Lab (Tue & Thu 4pm - 6pm)',
    'Holiday Intensive Coding Camp',
    'Private 1-on-1 Mentorship'
  ];

  const ageBrackets = [
    'Ages 6 - 9 (Junior Explorers)',
    'Ages 10 - 13 (Middle Coders)',
    'Ages 14 - 18 (Senior Pre-University)',
    'School Group / Institution'
  ];

  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};
    if (!formData.name.trim()) newErrors.name = 'Please provide parent/guardian or student full name.';
    if (!formData.email.trim()) {
      newErrors.email = 'Please provide a valid email address or phone number.';
    }
    if (!formData.message.trim() || formData.message.trim().length < 8) {
      newErrors.message = 'Please tell us a little about the student (grade level, prior computer experience).';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSubmitted(true);
    }, 1000);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      email: '',
      company: '',
      service: 'Junior Code, Logic & Game Building',
      budget: '₦20k - ₦35k / month',
      timeline: 'Upcoming Weekend Cohort',
      message: '',
    });
    setIsSubmitted(false);
    setErrors({});
  };

  const filteredFaqs = faqCategory === 'All'
    ? FAQS
    : FAQS.filter(f => f.category === faqCategory);

  return (
    <section 
      id="contact"
      className="py-24 relative overflow-hidden"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            <GraduationCap className="w-3.5 h-3.5" />
            <span>Admissions & Inquiries</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight font-display">
            Enroll Your Child in Mastery Class.
          </h2>
          <p className={`text-base sm:text-lg leading-relaxed ${
            darkMode ? 'text-slate-300' : 'text-slate-600'
          }`}>
            Located at School of Science, Ile-Ife, Osun State. Fill out the enrollment interest form below or reach our admissions coordinator directly.
          </p>
        </div>

        {/* Main Grid: Form + Info */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-24">
          
          {/* Left Column: Enrollment Form */}
          <div className={`lg:col-span-7 p-8 sm:p-10 rounded-3xl border ${
            darkMode 
              ? 'bg-slate-900/60 border-slate-800' 
              : 'bg-white border-slate-200 shadow-md'
          }`}>
            
            {isSubmitted ? (
              <div className="text-center py-12 space-y-6 animate-fadeIn">
                <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/20">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-2xl font-bold font-display text-white">
                    Enrollment Registration Received!
                  </h3>
                  <p className="text-sm text-slate-300 max-w-md mx-auto leading-relaxed">
                    Thank you, <span className="text-emerald-400 font-bold">{formData.name}</span>! Our School of Science admissions lead in Ile-Ife will contact you at <span className="text-emerald-400 font-semibold">{formData.email}</span> within 24 hours with orientation details.
                  </p>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950/80 border border-slate-800 max-w-md mx-auto text-left text-xs space-y-2 text-slate-300">
                  <div className="text-[11px] font-bold uppercase tracking-wider text-slate-400">Enrollment Summary:</div>
                  <div><span className="text-slate-400">Selected Track:</span> {formData.service}</div>
                  <div><span className="text-slate-400">Schedule Preference:</span> {formData.timeline}</div>
                  <div><span className="text-slate-400">Student Age Bracket:</span> {formData.company || 'Not specified'}</div>
                </div>

                <button
                  onClick={resetForm}
                  className="px-6 py-2.5 rounded-xl font-bold text-xs text-white bg-slate-800 hover:bg-slate-700 transition-colors"
                >
                  Enroll Another Student
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {/* Parent / Guardian Name */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                      Parent / Guardian Name <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      id="contact-input-name"
                      placeholder="e.g. Mrs. Adeyemi or Dr. Adeleke"
                      value={formData.name}
                      onChange={e => setFormData({ ...formData, name: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-2 transition-all ${
                        errors.name 
                          ? 'border-rose-500/80 bg-rose-950/10 text-white focus:ring-rose-500/30' 
                          : darkMode 
                            ? 'bg-slate-950 border-slate-800 text-white focus:border-emerald-500 focus:ring-emerald-500/20' 
                            : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-500 focus:ring-emerald-500/20'
                      }`}
                    />
                    {errors.name && <p className="text-[11px] text-rose-400 font-medium">{errors.name}</p>}
                  </div>

                  {/* Contact Phone / Email */}
                  <div className="space-y-2">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                      Email or WhatsApp Number <span className="text-rose-400">*</span>
                    </label>
                    <input
                      type="text"
                      id="contact-input-email"
                      placeholder="e.g. 0803XXXXXXX or parent@gmail.com"
                      value={formData.email}
                      onChange={e => setFormData({ ...formData, email: e.target.value })}
                      className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-2 transition-all ${
                        errors.email 
                          ? 'border-rose-500/80 bg-rose-950/10 text-white focus:ring-rose-500/30' 
                          : darkMode 
                            ? 'bg-slate-950 border-slate-800 text-white focus:border-emerald-500 focus:ring-emerald-500/20' 
                            : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-500 focus:ring-emerald-500/20'
                      }`}
                    />
                    {errors.email && <p className="text-[11px] text-rose-400 font-medium">{errors.email}</p>}
                  </div>
                </div>

                {/* Student's Age Bracket */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    Student's Age Category
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {ageBrackets.map((bracket) => (
                      <button
                        type="button"
                        key={bracket}
                        onClick={() => setFormData({ ...formData, company: bracket })}
                        className={`py-2 px-3 rounded-xl text-xs font-medium text-left transition-all ${
                          formData.company === bracket
                            ? 'bg-emerald-600/30 text-emerald-300 border border-emerald-500'
                            : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {bracket}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Track Selection */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    Interested Coding Program
                  </label>
                  <div className="flex flex-wrap gap-2">
                    {tracksList.map((trk) => (
                      <button
                        type="button"
                        key={trk}
                        onClick={() => setFormData({ ...formData, service: trk })}
                        className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                          formData.service === trk
                            ? 'bg-emerald-500 text-white shadow-md shadow-emerald-500/25 border border-emerald-400'
                            : 'bg-slate-950 border border-slate-800 text-slate-300 hover:border-slate-700'
                        }`}
                      >
                        {trk}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Session Timing Options */}
                <div className="space-y-2">
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                    Preferred Class Schedule
                  </label>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {sessionTimings.map((opt) => (
                      <button
                        type="button"
                        key={opt}
                        onClick={() => setFormData({ ...formData, timeline: opt })}
                        className={`py-2 px-3 rounded-xl text-xs font-medium text-left transition-all ${
                          formData.timeline === opt
                            ? 'bg-teal-600/30 text-teal-300 border border-teal-500'
                            : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-white'
                        }`}
                      >
                        {opt}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Message / Background */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-300">
                      Student Name & Prior Computer Experience <span className="text-rose-400">*</span>
                    </label>
                    <span className="text-[11px] text-slate-500">{formData.message.length} / 1000 chars</span>
                  </div>
                  <textarea
                    id="contact-input-message"
                    rows={3}
                    maxLength={1000}
                    placeholder="Tell us student's name, school in Ile-Ife/Osun, grade/class, and if they have used a computer or coded before..."
                    value={formData.message}
                    onChange={e => setFormData({ ...formData, message: e.target.value })}
                    className={`w-full px-4 py-3 rounded-xl text-sm border focus:outline-none focus:ring-2 transition-all resize-none ${
                      errors.message 
                        ? 'border-rose-500/80 bg-rose-950/10 text-white focus:ring-rose-500/30' 
                        : darkMode 
                          ? 'bg-slate-950 border-slate-800 text-white focus:border-emerald-500 focus:ring-emerald-500/20' 
                          : 'bg-slate-50 border-slate-300 text-slate-900 focus:border-emerald-500 focus:ring-emerald-500/20'
                    }`}
                  />
                  {errors.message && <p className="text-[11px] text-rose-400 font-medium">{errors.message}</p>}
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  id="btn-submit-contact-form"
                  disabled={isSubmitting}
                  className="w-full py-4 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-emerald-500 via-teal-600 to-emerald-700 hover:from-emerald-400 hover:via-teal-500 hover:to-emerald-600 shadow-xl shadow-emerald-500/25 hover:shadow-emerald-500/40 disabled:opacity-60 transition-all flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <>
                      <span>Submit Student Enrollment Request</span>
                      <Send className="w-4 h-4" />
                    </>
                  )}
                </button>

                <p className="text-[11px] text-center text-slate-400">
                  🎓 Zero prior coding required. All classes are hosted in the equipped computer labs at School of Science, Ile-Ife.
                </p>

              </form>
            )}

          </div>

          {/* Right Column: Campus Location & Direct Contacts */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Direct Connect Box */}
            <div className={`p-8 rounded-3xl border space-y-6 ${
              darkMode 
                ? 'bg-slate-900/60 border-slate-800' 
                : 'bg-white border-slate-200 shadow-sm'
            }`}>
              <h3 className="text-xl font-bold font-display text-white">
                School Location & Contacts
              </h3>

              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center border border-emerald-500/20 shrink-0">
                    <MapPin className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs uppercase font-bold text-slate-400">Host Campus</div>
                    <p className="text-sm font-semibold text-white">
                      School of Science Campus<br />
                      Ile-Ife, Osun State, Nigeria
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-teal-500/10 text-teal-400 flex items-center justify-center border border-teal-500/20 shrink-0">
                    <MessageCircle className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs uppercase font-bold text-slate-400">WhatsApp / Direct Line</div>
                    <a href="tel:+2348030000000" className="text-sm font-semibold text-emerald-400 hover:underline">
                      +234 (0) 803-SCIENCE / +234 812-MASTERY
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center border border-blue-500/20 shrink-0">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs uppercase font-bold text-slate-400">Admissions Email</div>
                    <a href="mailto:admissions@masteryclass.org.ng" className="text-sm font-semibold text-white hover:text-emerald-400 transition-colors">
                      admissions@masteryclass.org.ng
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center border border-amber-500/20 shrink-0">
                    <Clock className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="text-xs uppercase font-bold text-slate-400">Lab & Counseling Hours</div>
                    <p className="text-sm font-semibold text-emerald-400">
                      Mon – Sat: 8:00 AM – 6:00 PM (WAT)
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* School of Science Heritage Badge */}
            <div className={`p-6 rounded-3xl border space-y-3 ${
              darkMode 
                ? 'bg-slate-900/40 border-slate-800' 
                : 'bg-white border-slate-200 shadow-sm'
            }`}>
              <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                <School className="w-4 h-4" />
                <span>Our Regional Focus</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Empowering the next generation of Nigerian engineers, scientists, and creators starting right from the ancient city of Ile-Ife, Osun State.
              </p>
              <div className="grid grid-cols-3 gap-2 text-center pt-2">
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-xs font-bold text-white">Ile-Ife</div>
                  <div className="text-[10px] text-emerald-400">Main Campus</div>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-xs font-bold text-white">Osogbo</div>
                  <div className="text-[10px] text-slate-400">Weekend Hub</div>
                </div>
                <div className="p-2 rounded-xl bg-slate-950 border border-slate-800">
                  <div className="text-xs font-bold text-white">Online/WAT</div>
                  <div className="text-[10px] text-slate-400">Remote Cohort</div>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* Interactive FAQ Accordion */}
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="text-center space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
              <HelpCircle className="w-3.5 h-3.5" />
              <span>Parent & Student Guide</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-extrabold font-display">
              Frequently Asked Questions
            </h3>
          </div>

          <div className="space-y-4">
            {filteredFaqs.map((faq) => {
              const isOpen = expandedFaq === faq.id;
              return (
                <div
                  key={faq.id}
                  className={`rounded-2xl border transition-all ${
                    isOpen 
                      ? 'border-emerald-500/40 bg-slate-900/90' 
                      : darkMode 
                        ? 'border-slate-800/80 bg-slate-900/40 hover:border-slate-700' 
                        : 'border-slate-200 bg-white hover:border-slate-300 shadow-sm'
                  }`}
                >
                  <button
                    onClick={() => setExpandedFaq(isOpen ? null : faq.id)}
                    className="w-full p-6 text-left flex items-center justify-between gap-4"
                  >
                    <span className="text-base font-bold font-display text-white">
                      {faq.question}
                    </span>
                    <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center shrink-0 text-emerald-400">
                      {isOpen ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-6 pb-6 pt-0 text-sm text-slate-300 leading-relaxed border-t border-slate-800/60 mt-2">
                      <div className="pt-4">{faq.answer}</div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>

      </div>
    </section>
  );
};

