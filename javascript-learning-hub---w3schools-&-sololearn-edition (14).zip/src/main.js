/**
 * Mastery Class - Vanilla JavaScript Application Logic
 * School of Science, Ile-Ife, Osun State, Nigeria
 * 
 * Easy to read and edit!
 */

document.addEventListener('DOMContentLoaded', () => {
  // Initialize Lucide Icons
  if (window.lucide) {
    window.lucide.createIcons();
  }

  /* ----------------------------------------------------
   * 1. Theme Management (Dark / Light Mode)
   * ---------------------------------------------------- */
  const themeToggleBtn = document.getElementById('theme-toggle-btn');
  const themeIconContainer = document.getElementById('theme-icon');
  
  // Check local storage or default to dark
  const currentTheme = localStorage.getItem('mastery_theme') || 'dark';
  if (currentTheme === 'light') {
    document.body.classList.add('light-mode');
    updateThemeIcon(true);
  }

  if (themeToggleBtn) {
    themeToggleBtn.addEventListener('click', () => {
      const isLight = document.body.classList.toggle('light-mode');
      localStorage.setItem('mastery_theme', isLight ? 'light' : 'dark');
      updateThemeIcon(isLight);
    });
  }

  function updateThemeIcon(isLight) {
    if (!themeIconContainer) return;
    if (isLight) {
      themeIconContainer.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-amber-500"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>`;
    } else {
      themeIconContainer.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="text-emerald-400"><path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/></svg>`;
    }
  }

  /* ----------------------------------------------------
   * 2. Mobile Menu Toggle
   * ---------------------------------------------------- */
  const mobileMenuBtn = document.getElementById('mobile-menu-btn');
  const mobileMenu = document.getElementById('mobile-menu');
  
  if (mobileMenuBtn && mobileMenu) {
    mobileMenuBtn.addEventListener('click', () => {
      mobileMenu.classList.toggle('hidden');
    });

    // Close menu when clicking on any mobile navigation link
    mobileMenu.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        mobileMenu.classList.add('hidden');
      });
    });
  }

  /* ----------------------------------------------------
   * 3. Hero Code Lab Interactive Tabs
   * ---------------------------------------------------- */
  const heroTabBtns = document.querySelectorAll('.hero-tab-btn');
  const heroTabPanels = document.querySelectorAll('.hero-tab-panel');

  heroTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetTab = btn.getAttribute('data-tab');

      // Update button styles
      heroTabBtns.forEach(b => {
        b.classList.remove('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
        b.classList.add('bg-slate-800/50', 'text-slate-400');
      });
      btn.classList.add('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
      btn.classList.remove('bg-slate-800/50', 'text-slate-400');

      // Show target panel
      heroTabPanels.forEach(panel => {
        if (panel.getAttribute('id') === `hero-panel-${targetTab}`) {
          panel.classList.remove('hidden');
        } else {
          panel.classList.add('hidden');
        }
      });
    });
  });

  /* ----------------------------------------------------
   * 4. Who We Are Story Tabs (Mission / Vision / DNA)
   * ---------------------------------------------------- */
  const storyTabBtns = document.querySelectorAll('.story-tab-btn');
  const storyPanels = document.querySelectorAll('.story-panel');

  storyTabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetStory = btn.getAttribute('data-story');

      storyTabBtns.forEach(b => {
        b.classList.remove('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
      btn.classList.remove('text-slate-400');

      storyPanels.forEach(panel => {
        if (panel.getAttribute('id') === `story-panel-${targetStory}`) {
          panel.classList.remove('hidden');
        } else {
          panel.classList.add('hidden');
        }
      });
    });
  });

  /* ----------------------------------------------------
   * 5. Course Curriculum Category Filters
   * ---------------------------------------------------- */
  const courseFilterBtns = document.querySelectorAll('.course-filter-btn');
  const courseCards = document.querySelectorAll('.course-card');

  courseFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const category = btn.getAttribute('data-category');

      courseFilterBtns.forEach(b => {
        b.classList.remove('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
      btn.classList.remove('text-slate-400');

      courseCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (category === 'All' || cardCategory === category) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  /* ----------------------------------------------------
   * 6. Mentors Guild Department Filters
   * ---------------------------------------------------- */
  const teamFilterBtns = document.querySelectorAll('.team-filter-btn');
  const teamCards = document.querySelectorAll('.team-card');

  teamFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const dept = btn.getAttribute('data-dept');

      teamFilterBtns.forEach(b => {
        b.classList.remove('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
      btn.classList.remove('text-slate-400');

      teamCards.forEach(card => {
        const cardDept = card.getAttribute('data-dept');
        if (dept === 'All' || cardDept === dept) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  /* ----------------------------------------------------
   * 7. Student Projects Portfolio Category Filters
   * ---------------------------------------------------- */
  const projectFilterBtns = document.querySelectorAll('.project-filter-btn');
  const projectCards = document.querySelectorAll('.project-card');

  projectFilterBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const category = btn.getAttribute('data-category');

      projectFilterBtns.forEach(b => {
        b.classList.remove('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
        b.classList.add('text-slate-400');
      });
      btn.classList.add('bg-gradient-to-r', 'from-emerald-500', 'to-teal-600', 'text-white', 'shadow-md');
      btn.classList.remove('text-slate-400');

      projectCards.forEach(card => {
        const cardCategory = card.getAttribute('data-category');
        if (category === 'All' || cardCategory === category) {
          card.classList.remove('hidden');
        } else {
          card.classList.add('hidden');
        }
      });
    });
  });

  /* ----------------------------------------------------
   * 8. Student Project Details Modal
   * ---------------------------------------------------- */
  const projectModal = document.getElementById('project-modal');
  const closeProjectModalBtn = document.getElementById('close-project-modal-btn');
  const modalProjectCategory = document.getElementById('modal-project-category');
  const modalProjectTitle = document.getElementById('modal-project-title');
  const modalProjectClient = document.getElementById('modal-project-client');
  const modalProjectChallenge = document.getElementById('modal-project-challenge');
  const modalProjectSolution = document.getElementById('modal-project-solution');
  const modalProjectOutcome = document.getElementById('modal-project-outcome');
  const modalProjectTags = document.getElementById('modal-project-tags');

  // Attach click to each project card
  projectCards.forEach(card => {
    card.addEventListener('click', () => {
      const title = card.getAttribute('data-title');
      const category = card.getAttribute('data-category');
      const client = card.getAttribute('data-client');
      const challenge = card.getAttribute('data-challenge');
      const solution = card.getAttribute('data-solution');
      const outcome = card.getAttribute('data-outcome');
      const tags = card.getAttribute('data-tags');

      if (modalProjectCategory) modalProjectCategory.textContent = category;
      if (modalProjectTitle) modalProjectTitle.textContent = title;
      if (modalProjectClient) modalProjectClient.textContent = client;
      if (modalProjectChallenge) modalProjectChallenge.textContent = challenge;
      if (modalProjectSolution) modalProjectSolution.textContent = solution;
      if (modalProjectOutcome) modalProjectOutcome.textContent = outcome;

      if (modalProjectTags && tags) {
        modalProjectTags.innerHTML = '';
        tags.split(',').forEach(tag => {
          const span = document.createElement('span');
          span.className = 'text-[11px] font-mono px-3 py-1 rounded-full bg-slate-800 text-emerald-300 border border-slate-700';
          span.textContent = `#${tag.trim()}`;
          modalProjectTags.appendChild(span);
        });
      }

      if (projectModal) {
        projectModal.classList.add('active');
      }
    });
  });

  if (closeProjectModalBtn && projectModal) {
    closeProjectModalBtn.addEventListener('click', () => {
      projectModal.classList.remove('active');
    });

    projectModal.addEventListener('click', (e) => {
      if (e.target === projectModal) {
        projectModal.classList.remove('active');
      }
    });
  }

  /* ----------------------------------------------------
   * 9. Consultation & Enrollment Modal
   * ---------------------------------------------------- */
  const enrollModal = document.getElementById('enroll-modal');
  const closeEnrollModalBtn = document.getElementById('close-enroll-modal-btn');
  const enrollForm = document.getElementById('enroll-modal-form');
  const enrollFormView = document.getElementById('enroll-form-view');
  const enrollSuccessView = document.getElementById('enroll-success-view');
  const modalProgramSelect = document.getElementById('modal-program-select');
  const modalSuccessDetails = document.getElementById('modal-success-details');
  const modalDoneBtn = document.getElementById('modal-done-btn');

  // Function to open enrollment modal with optional program pre-selection
  window.openEnrollModal = function(programName) {
    if (enrollModal) {
      if (modalProgramSelect && programName) {
        modalProgramSelect.value = programName;
      }
      if (enrollFormView) enrollFormView.classList.remove('hidden');
      if (enrollSuccessView) enrollSuccessView.classList.add('hidden');
      enrollModal.classList.add('active');
    }
  };

  // Open modal buttons
  document.querySelectorAll('.open-enroll-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const prog = btn.getAttribute('data-program');
      window.openEnrollModal(prog);
    });
  });

  if (closeEnrollModalBtn && enrollModal) {
    closeEnrollModalBtn.addEventListener('click', () => {
      enrollModal.classList.remove('active');
    });

    enrollModal.addEventListener('click', (e) => {
      if (e.target === enrollModal) {
        enrollModal.classList.remove('active');
      }
    });
  }

  if (modalDoneBtn && enrollModal) {
    modalDoneBtn.addEventListener('click', () => {
      enrollModal.classList.remove('active');
    });
  }

  if (enrollForm) {
    enrollForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const parentName = document.getElementById('modal-parent-name')?.value || '';
      const email = document.getElementById('modal-email')?.value || '';
      const program = modalProgramSelect?.value || 'Junior Code, Logic & Game Building';
      const schedule = document.getElementById('modal-schedule')?.value || 'Upcoming Weekend Cohort';

      if (modalSuccessDetails) {
        modalSuccessDetails.innerHTML = `
          <div><strong class="text-slate-300">Parent/Guardian:</strong> ${parentName}</div>
          <div><strong class="text-slate-300">Contact:</strong> ${email}</div>
          <div><strong class="text-slate-300">Program Track:</strong> ${program}</div>
          <div><strong class="text-slate-300">Cohort Schedule:</strong> ${schedule}</div>
        `;
      }

      if (enrollFormView) enrollFormView.classList.add('hidden');
      if (enrollSuccessView) enrollSuccessView.classList.remove('hidden');
    });
  }

  /* ----------------------------------------------------
   * 10. Main Admissions Contact Form in Section
   * ---------------------------------------------------- */
  const contactForm = document.getElementById('main-contact-form');
  const contactSuccessState = document.getElementById('contact-success-state');
  const resetContactBtn = document.getElementById('btn-reset-contact');
  const ageCategoryInput = document.getElementById('contact-age-category');
  const selectedTrackInput = document.getElementById('contact-selected-track');
  const selectedScheduleInput = document.getElementById('contact-selected-schedule');

  // Age category button selectors
  document.querySelectorAll('.age-bracket-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.age-bracket-btn').forEach(b => {
        b.classList.remove('bg-emerald-600/30', 'text-emerald-300', 'border-emerald-500');
        b.classList.add('bg-slate-950', 'border-slate-800', 'text-slate-400');
      });
      btn.classList.add('bg-emerald-600/30', 'text-emerald-300', 'border-emerald-500');
      btn.classList.remove('bg-slate-950', 'border-slate-800', 'text-slate-400');
      if (ageCategoryInput) ageCategoryInput.value = btn.getAttribute('data-value');
    });
  });

  // Track selection button selectors
  document.querySelectorAll('.track-select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.track-select-btn').forEach(b => {
        b.classList.remove('bg-emerald-500', 'text-white', 'shadow-md', 'shadow-emerald-500/25', 'border-emerald-400');
        b.classList.add('bg-slate-950', 'border-slate-800', 'text-slate-300');
      });
      btn.classList.add('bg-emerald-500', 'text-white', 'shadow-md', 'shadow-emerald-500/25', 'border-emerald-400');
      btn.classList.remove('bg-slate-950', 'border-slate-800', 'text-slate-300');
      if (selectedTrackInput) selectedTrackInput.value = btn.getAttribute('data-value');
    });
  });

  // Schedule preference button selectors
  document.querySelectorAll('.schedule-select-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.schedule-select-btn').forEach(b => {
        b.classList.remove('bg-teal-600/30', 'text-teal-300', 'border-teal-500');
        b.classList.add('bg-slate-950', 'border-slate-800', 'text-slate-400');
      });
      btn.classList.add('bg-teal-600/30', 'text-teal-300', 'border-teal-500');
      btn.classList.remove('bg-slate-950', 'border-slate-800', 'text-slate-400');
      if (selectedScheduleInput) selectedScheduleInput.value = btn.getAttribute('data-value');
    });
  });

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const parentName = document.getElementById('contact-input-name')?.value || '';
      const email = document.getElementById('contact-input-email')?.value || '';
      const ageCategory = ageCategoryInput?.value || 'Ages 6-9';
      const track = selectedTrackInput?.value || 'Junior Code, Logic & Game Building';
      const schedule = selectedScheduleInput?.value || 'Upcoming Weekend Cohort';

      const summaryDetails = document.getElementById('contact-summary-details');
      if (summaryDetails) {
        summaryDetails.innerHTML = `
          <div><strong class="text-slate-400">Parent/Student Name:</strong> ${parentName}</div>
          <div><strong class="text-slate-400">Contact Address/Phone:</strong> ${email}</div>
          <div><strong class="text-slate-400">Selected Track:</strong> ${track}</div>
          <div><strong class="text-slate-400">Age Bracket:</strong> ${ageCategory}</div>
          <div><strong class="text-slate-400">Schedule Preference:</strong> ${schedule}</div>
        `;
      }

      contactForm.classList.add('hidden');
      if (contactSuccessState) contactSuccessState.classList.remove('hidden');
    });
  }

  if (resetContactBtn) {
    resetContactBtn.addEventListener('click', () => {
      if (contactForm) {
        contactForm.reset();
        contactForm.classList.remove('hidden');
      }
      if (contactSuccessState) contactSuccessState.classList.add('hidden');
    });
  }

  /* ----------------------------------------------------
   * 11. FAQ Accordion Expand & Collapse
   * ---------------------------------------------------- */
  const faqItems = document.querySelectorAll('.faq-item');
  faqItems.forEach(item => {
    const trigger = item.querySelector('.faq-trigger');
    const content = item.querySelector('.faq-content');
    const icon = item.querySelector('.faq-icon');

    if (trigger && content) {
      trigger.addEventListener('click', () => {
        const isExpanded = !content.classList.contains('hidden');

        // Close all others
        faqItems.forEach(otherItem => {
          const otherContent = otherItem.querySelector('.faq-content');
          const otherIcon = otherItem.querySelector('.faq-icon');
          if (otherContent) otherContent.classList.add('hidden');
          if (otherIcon) otherIcon.style.transform = 'rotate(0deg)';
        });

        if (!isExpanded) {
          content.classList.remove('hidden');
          if (icon) icon.style.transform = 'rotate(180deg)';
        }
      });
    }
  });

  /* ----------------------------------------------------
   * 12. Newsletter Form in Footer
   * ---------------------------------------------------- */
  const newsletterForm = document.getElementById('newsletter-form');
  const newsletterSuccess = document.getElementById('newsletter-success');

  if (newsletterForm && newsletterSuccess) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      newsletterForm.classList.add('hidden');
      newsletterSuccess.classList.remove('hidden');
    });
  }

  /* ----------------------------------------------------
   * 13. Back to Top Smooth Button
   * ---------------------------------------------------- */
  const backToTopBtn = document.getElementById('back-to-top-btn');
  if (backToTopBtn) {
    backToTopBtn.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  // Re-run icons creation on dynamic changes
  if (window.lucide) {
    window.lucide.createIcons();
  }
});
