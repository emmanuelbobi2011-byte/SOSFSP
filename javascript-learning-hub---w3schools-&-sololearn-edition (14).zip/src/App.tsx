import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { WhoWeAre } from './components/WhoWeAre';
import { Services } from './components/Services';
import { Team } from './components/Team';
import { Portfolio } from './components/Portfolio';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Footer } from './components/Footer';
import { ConsultationModal } from './components/ConsultationModal';
import { ServiceItem } from './types';

export function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [isConsultationOpen, setIsConsultationOpen] = useState(false);
  const [selectedService, setSelectedService] = useState<ServiceItem | null>(null);
  const [activeSection, setActiveSection] = useState('hero');

  // Scroll spy to highlight active section in Navbar
  useEffect(() => {
    const sections = ['hero', 'who-we-are', 'services', 'team', 'portfolio', 'testimonials', 'contact'];
    
    const handleScroll = () => {
      const scrollY = window.scrollY;
      const windowHeight = window.innerHeight;

      for (const sectionId of sections) {
        const el = document.getElementById(sectionId);
        if (el) {
          const rect = el.getBoundingClientRect();
          if (rect.top <= windowHeight * 0.4 && rect.bottom >= windowHeight * 0.2) {
            setActiveSection(sectionId);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleOpenConsultation = () => {
    setIsConsultationOpen(true);
  };

  const handleSelectService = (service: ServiceItem) => {
    setSelectedService(service);
    setIsConsultationOpen(true);
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 font-sans ${
      darkMode ? 'bg-slate-950 text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      
      {/* Sticky Navigation Header */}
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenConsultation={handleOpenConsultation}
        activeSection={activeSection}
      />

      {/* Main Sections */}
      <main id="main-content-flow">
        {/* 1. Hero Header */}
        <Hero
          darkMode={darkMode}
          onOpenConsultation={handleOpenConsultation}
        />

        {/* 2. Who We Are (Identity, Story, Mission, Values, Comparison Matrix, Timeline) */}
        <WhoWeAre
          darkMode={darkMode}
          onOpenConsultation={handleOpenConsultation}
        />

        {/* 3. Services & Capabilities */}
        <Services
          darkMode={darkMode}
          onOpenConsultation={handleOpenConsultation}
          onSelectService={handleSelectService}
        />

        {/* 4. Leadership & Engineering Guild */}
        <Team
          darkMode={darkMode}
          onOpenConsultation={handleOpenConsultation}
        />

        {/* 5. Case Studies & Portfolio */}
        <Portfolio
          darkMode={darkMode}
          onOpenConsultation={handleOpenConsultation}
        />

        {/* 6. Client Testimonials & Trust */}
        <Testimonials
          darkMode={darkMode}
        />

        {/* 7. Interactive Contact Form & FAQ Accordion */}
        <Contact
          darkMode={darkMode}
          prefilledService={selectedService?.title}
        />
      </main>

      {/* Footer */}
      <Footer
        darkMode={darkMode}
        onOpenConsultation={handleOpenConsultation}
      />

      {/* Interactive Consultation / Strategy Call Modal */}
      <ConsultationModal
        isOpen={isConsultationOpen}
        onClose={() => {
          setIsConsultationOpen(false);
          setSelectedService(null);
        }}
        selectedService={selectedService}
        darkMode={darkMode}
      />

    </div>
  );
}

export default App;
