// SoloLearn & LeetCode style Interactive JavaScript Code Challenges
export const CODING_CHALLENGES = [
  {
    id: 'reverse-string',
    title: 'Reverse a String',
    difficulty: 'Easy',
    xp: 30,
    description: 'Write a function <code>reverseString(str)</code> that takes a string and returns it reversed.',
    starterCode: `function reverseString(str) {
  // Your code here
  return str.split("").reverse().join("");
}`,
    testCases: [
      { input: ['"hello"'], expected: '"olleh"', testCall: 'reverseString("hello")' },
      { input: ['"JavaScript"'], expected: '"tpircSavaJ"', testCall: 'reverseString("JavaScript")' },
      { input: ['"12345"'], expected: '"54321"', testCall: 'reverseString("12345")' }
    ]
  },
  {
    id: 'palindrome-check',
    title: 'Palindrome Checker',
    difficulty: 'Easy',
    xp: 35,
    description: 'Write a function <code>isPalindrome(str)</code> that checks whether a given string is a palindrome (reads same forwards and backwards, ignoring case).',
    starterCode: `function isPalindrome(str) {
  const clean = str.toLowerCase().replace(/[^a-z0-9]/g, '');
  return clean === clean.split('').reverse().join('');
}`,
    testCases: [
      { input: ['"racecar"'], expected: 'true', testCall: 'isPalindrome("racecar")' },
      { input: ['"hello"'], expected: 'false', testCall: 'isPalindrome("hello")' },
      { input: ['"A man a plan a canal Panama"'], expected: 'true', testCall: 'isPalindrome("A man a plan a canal Panama")' }
    ]
  },
  {
    id: 'two-sum',
    title: 'Two Sum Target',
    difficulty: 'Medium',
    xp: 50,
    description: 'Given an array of integers <code>nums</code> and an integer <code>target</code>, return indices of the two numbers such that they add up to <code>target</code>.',
    starterCode: `function twoSum(nums, target) {
  const map = new Map();
  for (let i = 0; i < nums.length; i++) {
    const complement = target - nums[i];
    if (map.has(complement)) {
      return [map.get(complement), i];
    }
    map.set(nums[i], i);
  }
  return [];
}`,
    testCases: [
      { input: ['[2, 7, 11, 15], 9'], expected: '[0, 1]', testCall: 'JSON.stringify(twoSum([2, 7, 11, 15], 9))' },
      { input: ['[3, 2, 4], 6'], expected: '[1, 2]', testCall: 'JSON.stringify(twoSum([3, 2, 4], 6))' }
    ]
  },
  {
    id: 'fizz-buzz',
    title: 'FizzBuzz Generator',
    difficulty: 'Easy',
    xp: 25,
    description: 'Write a function <code>fizzBuzz(n)</code> that returns an array of numbers from 1 to n. For multiples of 3, replace with "Fizz"; for multiples of 5, replace with "Buzz"; for multiples of both, "FizzBuzz".',
    starterCode: `function fizzBuzz(n) {
  const result = [];
  for (let i = 1; i <= n; i++) {
    if (i % 15 === 0) result.push("FizzBuzz");
    else if (i % 3 === 0) result.push("Fizz");
    else if (i % 5 === 0) result.push("Buzz");
    else result.push(i);
  }
  return result;
}`,
    testCases: [
      { input: ['5'], expected: '[1,2,"Fizz",4,"Buzz"]', testCall: 'JSON.stringify(fizzBuzz(5))' }
    ]
  },
  {
    id: 'flatten-array',
    title: 'Deep Array Flattener',
    difficulty: 'Medium',
    xp: 45,
    description: 'Write a function <code>flatten(arr)</code> that recursively flattens an array of arbitrarily nested arrays into a single 1D array.',
    starterCode: `function flatten(arr) {
  return arr.reduce((acc, item) => {
    return acc.concat(Array.isArray(item) ? flatten(item) : item);
  }, []);
}`,
    testCases: [
      { input: ['[1, [2, [3, [4]], 5]]'], expected: '[1,2,3,4,5]', testCall: 'JSON.stringify(flatten([1, [2, [3, [4]], 5]]))' },
      { input: ['[[["a"]], ["b"]]'], expected: '["a","b"]', testCall: 'JSON.stringify(flatten([[["a"]], ["b"]]))' }
    ]
  },
  {
    id: 'debounce-fn',
    title: 'Debounce Implementation',
    difficulty: 'Hard',
    xp: 60,
    description: 'Implement a basic <code>debounce(fn, delay)</code> function that delays invoking <code>fn</code> until after <code>delay</code> milliseconds have elapsed since the last time it was invoked.',
    starterCode: `function debounce(fn, delay) {
  let timerId;
  return function(...args) {
    clearTimeout(timerId);
    timerId = setTimeout(() => fn.apply(this, args), delay);
  };
}`,
    testCases: [
      { input: ['Function type check'], expected: '"function"', testCall: 'typeof debounce(() => {}, 100)' }
    ]
  }
];
