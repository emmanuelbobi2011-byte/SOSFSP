// Comprehensive JavaScript Exam Question Bank & SoloLearn-style Checkpoints
export const EXAM_QUESTIONS = [
  {
    id: 1,
    category: 'Basics & Syntax',
    question: 'Which of the following variable declarations is block-scoped and cannot be reassigned?',
    options: [
      'var myVar = 10;',
      'let myVar = 10;',
      'const myVar = 10;',
      'global myVar = 10;'
    ],
    answer: 2,
    explanation: 'const creates a block-scoped constant whose identifier cannot be reassigned once declared.'
  },
  {
    id: 2,
    category: 'Data Types',
    question: 'What will "5" + 3 and "5" - 3 evaluate to in JavaScript?',
    options: [
      '"53" and 2',
      '8 and 2',
      '"53" and NaN',
      '8 and NaN'
    ],
    answer: 0,
    explanation: 'The + operator performs string concatenation when one operand is a string ("53"). The - operator coerces "5" into the number 5, performing subtraction (2).'
  },
  {
    id: 3,
    category: 'Equality & Operators',
    question: 'What is the output of: console.log(null == undefined, null === undefined);',
    options: [
      'true, true',
      'true, false',
      'false, true',
      'false, false'
    ],
    answer: 1,
    explanation: 'Loose equality (==) treats null and undefined as equal (true), whereas strict equality (===) checks type and value, returning false.'
  },
  {
    id: 4,
    category: 'Functions & Scope',
    question: 'What does the following arrow function return: const fn = x => ({ val: x * 2 });',
    options: [
      'SyntaxError',
      'An object { val: 20 } when called with fn(10)',
      'undefined',
      'A block scope without a return value'
    ],
    answer: 1,
    explanation: 'Wrapping an object literal in parentheses `({ ... })` allows returning the object concisely without mistaking the braces for a function block.'
  },
  {
    id: 5,
    category: 'Closures',
    question: 'What is a closure in JavaScript?',
    options: [
      'A function that closes the browser window',
      'An inner function that retains access to outer variables even after the outer function has executed',
      'A method used to seal objects from further modification',
      'A tag used to close open HTML nodes'
    ],
    answer: 1,
    explanation: 'A closure is created when an inner function accesses variables from its lexical enclosing scope, persisting access across execution.'
  },
  {
    id: 6,
    category: 'Array Methods',
    question: 'Which method creates a new array populated with the results of calling a provided function on every element in the calling array?',
    options: [
      'forEach()',
      'map()',
      'reduce()',
      'filter()'
    ],
    answer: 1,
    explanation: 'map() transforms each element of an array and returns a newly created array of the exact same length.'
  },
  {
    id: 7,
    category: 'Array Methods',
    question: 'What does [1, 2, 3, 4].reduce((sum, num) => sum + num, 10) return?',
    options: [
      '10',
      '20',
      '24',
      '[10, 11, 12, 13]'
    ],
    answer: 1,
    explanation: 'The initial value is 10. The sum of 10 + 1 + 2 + 3 + 4 is 20.'
  },
  {
    id: 8,
    category: 'Objects & References',
    question: 'What happens when you copy an object with `const clone = { ...original };`?',
    options: [
      'A deep recursive clone of all nested objects and arrays',
      'A shallow copy where top-level primitives are copied, but nested objects remain shared by reference',
      'A frozen read-only proxy object',
      'A reference to the same memory pointer'
    ],
    answer: 1,
    explanation: 'Object spread `{ ...obj }` performs a shallow copy. Nested objects or arrays are still references to the originals.'
  },
  {
    id: 9,
    category: 'Asynchronous JS',
    question: 'What is the correct order of output for:\nconsole.log(1);\nsetTimeout(() => console.log(2), 0);\nPromise.resolve().then(() => console.log(3));\nconsole.log(4);',
    options: [
      '1, 2, 3, 4',
      '1, 4, 3, 2',
      '1, 4, 2, 3',
      '3, 2, 1, 4'
    ],
    answer: 1,
    explanation: 'Synchronous code runs first (1, 4). Microtasks like Promise.then run next (3). Macrotasks like setTimeout run last (2).'
  },
  {
    id: 10,
    category: 'Asynchronous JS',
    question: 'Which statement correctly handles an error in an async/await function?',
    options: [
      'try { await task(); } catch (err) { console.error(err); }',
      'await task().onError(err => ...)',
      'catch { await task(); }',
      'task().tryCatch()'
    ],
    answer: 0,
    explanation: 'async/await uses standard JavaScript try...catch blocks for structured asynchronous error handling.'
  },
  {
    id: 11,
    category: 'DOM & Events',
    question: 'What is event delegation in the DOM?',
    options: [
      'Delegating server requests to web workers',
      'Attaching a single event listener to a parent element to handle events on its descendants via bubbling',
      'Preventing the default browser action with e.preventDefault()',
      'Stopping script execution immediately'
    ],
    answer: 1,
    explanation: 'Event delegation leverages event bubbling by placing one listener on a common parent instead of hundreds of listeners on child nodes.'
  },
  {
    id: 12,
    category: 'Modern ES6+',
    question: 'What is the result of `const user = null; console.log(user?.address?.city ?? "Default City");`?',
    options: [
      'TypeError: Cannot read properties of null',
      '"Default City"',
      'undefined',
      'null'
    ],
    answer: 1,
    explanation: 'Optional chaining `?.` short-circuits to undefined without throwing an error, and nullish coalescing `??` provides the fallback "Default City".'
  },
  {
    id: 13,
    category: 'OOP & Classes',
    question: 'In a class derived with `class Dog extends Animal`, what MUST you call in the constructor before accessing `this`?',
    options: [
      'this.parent()',
      'super()',
      'Animal.call(this)',
      'super.init()'
    ],
    answer: 1,
    explanation: 'In derived classes, super() must be called before using this; otherwise a ReferenceError will occur.'
  },
  {
    id: 14,
    category: 'Data Structures',
    question: 'How do JavaScript Sets differ from regular Arrays?',
    options: [
      'Sets can only store numbers',
      'Sets only allow unique values and do not store duplicate elements',
      'Sets are always sorted alphabetically',
      'Sets do not have a size property'
    ],
    answer: 1,
    explanation: 'A Set is a collection of unique values where duplicate insertions are automatically ignored.'
  },
  {
    id: 15,
    category: 'Modern Features',
    question: 'How do you unpack properties `{ name: "Dev", level: 9 }` into variables `userName` and `userLevel`?',
    options: [
      'const { name: userName, level: userLevel } = user;',
      'const [userName, userLevel] = user;',
      'const { userName = name, userLevel = level } = user;',
      'const user -> { userName, userLevel };'
    ],
    answer: 0,
    explanation: 'Destructuring with renaming uses the syntax `{ propertyName: newVariableName } = object`.'
  }
];

export const CERTIFICATE_TEMPLATE = {
  title: 'Certificate of JavaScript Proficiency',
  issuer: 'W3Schools & SoloLearn Interactive JS Academy',
  validity: 'Verified Digital Credential'
};
