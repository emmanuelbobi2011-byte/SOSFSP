// JavaScript API Cheatsheet & Reference Database
export const JS_REFERENCES = [
  {
    category: 'Array Methods',
    name: 'Array.prototype.map()',
    syntax: 'arr.map((element, index, array) => { ... })',
    description: 'Creates a new array with the results of calling a provided function on every element.',
    example: 'const doubled = [1, 2, 3].map(n => n * 2); // [2, 4, 6]'
  },
  {
    category: 'Array Methods',
    name: 'Array.prototype.filter()',
    syntax: 'arr.filter((element, index) => condition)',
    description: 'Creates a shallow copy of a portion of an array containing only elements that pass the test.',
    example: 'const evens = [1, 2, 3, 4].filter(n => n % 2 === 0); // [2, 4]'
  },
  {
    category: 'Array Methods',
    name: 'Array.prototype.reduce()',
    syntax: 'arr.reduce((accumulator, currentValue) => { ... }, initialValue)',
    description: 'Executes a reducer function on each element, resulting in a single output value.',
    example: 'const total = [10, 20, 30].reduce((acc, curr) => acc + curr, 0); // 60'
  },
  {
    category: 'Array Methods',
    name: 'Array.prototype.find()',
    syntax: 'arr.find((element) => condition)',
    description: 'Returns the first element in the array that satisfies the testing function, or undefined.',
    example: 'const user = users.find(u => u.id === 42);'
  },
  {
    category: 'String Methods',
    name: 'String.prototype.includes()',
    syntax: 'str.includes(searchString, position)',
    description: 'Performs a case-sensitive search to determine whether one string may be found within another.',
    example: '"JavaScript".includes("Script"); // true'
  },
  {
    category: 'String Methods',
    name: 'String.prototype.slice()',
    syntax: 'str.slice(startIndex, endIndex)',
    description: 'Extracts a section of a string and returns it as a new string, without modifying original.',
    example: '"Frontend".slice(0, 5); // "Front"'
  },
  {
    category: 'String Methods',
    name: 'String.prototype.replace() / replaceAll()',
    syntax: 'str.replaceAll(pattern, replacement)',
    description: 'Returns a new string with all matches of a pattern replaced by a replacement.',
    example: '"cats and cats".replaceAll("cats", "dogs"); // "dogs and dogs"'
  },
  {
    category: 'Object Methods',
    name: 'Object.entries()',
    syntax: 'Object.entries(obj)',
    description: 'Returns an array of a given object\'s own enumerable string-keyed property [key, value] pairs.',
    example: 'Object.entries({ a: 1, b: 2 }); // [["a", 1], ["b", 2]]'
  },
  {
    category: 'Object Methods',
    name: 'Object.freeze()',
    syntax: 'Object.freeze(obj)',
    description: 'Freezes an object: other code cannot delete or change any properties.',
    example: 'const config = Object.freeze({ api: "https://..." });'
  },
  {
    category: 'DOM & Web APIs',
    name: 'document.querySelector()',
    syntax: 'document.querySelector(selectors)',
    description: 'Returns the first Element within the document that matches the specified selector.',
    example: 'const button = document.querySelector(".btn-submit");'
  },
  {
    category: 'DOM & Web APIs',
    name: 'EventTarget.addEventListener()',
    syntax: 'target.addEventListener(type, listener, options)',
    description: 'Sets up a function that will be called whenever the specified event is delivered to target.',
    example: 'window.addEventListener("resize", handleResize);'
  },
  {
    category: 'Async & Promises',
    name: 'Promise.all()',
    syntax: 'Promise.all(iterableOfPromises)',
    description: 'Waits for all promises to be resolved, or for any to be rejected.',
    example: 'const [users, posts] = await Promise.all([fetchUsers(), fetchPosts()]);'
  },
  {
    category: 'Async & Promises',
    name: 'Promise.allSettled()',
    syntax: 'Promise.allSettled(iterableOfPromises)',
    description: 'Returns a promise that fulfills after all given promises have either fulfilled or rejected.',
    example: 'const results = await Promise.allSettled(tasks);'
  }
];
