// Comprehensive JavaScript Mastery Curriculum
export const CATEGORIES = [
  { id: 'basics', title: '⚡ JS Basics & Setup', icon: 'zap' },
  { id: 'datatypes', title: '🗄️ Data Types & Operators', icon: 'database' },
  { id: 'control', title: '🔀 Control Flow & Loops', icon: 'git-branch' },
  { id: 'functions', title: '💻 Functions & Scope', icon: 'code' },
  { id: 'objects', title: '📦 Objects & Arrays', icon: 'box' },
  { id: 'oop', title: '🏗️ OOP & Classes', icon: 'layers' },
  { id: 'async', title: '⏱️ Asynchronous JavaScript', icon: 'clock' },
  { id: 'dom', title: '🌐 DOM & Web APIs', icon: 'layout' },
  { id: 'modern', title: '🚀 Modern ES6+ Features', icon: 'sparkles' },
  { id: 'advanced', title: '🧠 Advanced & Algorithms', icon: 'cpu' },
];

export const LESSONS = [
  // ==========================================
  // --- JAVASCRIPT TRACK ---
  // ==========================================
  {
    id: 'js-intro',
    category: 'basics',
    title: 'JavaScript Introduction',
    readTime: '4 min',
    xp: 25,
    summary: 'What is JavaScript, why is it the most popular programming language, and how does it power the web?',
    contentHtml: `
      <h2>What is JavaScript?</h2>
      <p><strong>JavaScript</strong> is the world's most popular lightweight, interpreted (or just-in-time compiled) programming language with first-class functions.</p>
      <p>While it is most well-known as the scripting language for Web pages, many non-browser environments also use it, such as <strong>Node.js</strong>, Apache CouchDB, and Adobe Acrobat.</p>

      <div class="w3-note w3-panel">
        <h4>Did You Know?</h4>
        <p>JavaScript was created in 1995 by <strong>Brendan Eich</strong> in just 10 days while working at Netscape Communications!</p>
      </div>

      <h2>The Three Pillars of the Web</h2>
      <ul>
        <li><strong>HTML</strong> defines the content and structure of web pages.</li>
        <li><strong>CSS</strong> specifies the layout, styling, and visual appearance.</li>
        <li><strong>JavaScript</strong> programs the interactive behavior, logic, and animations.</li>
      </ul>
    `,
    codeExample: `// Welcome to JavaScript!
console.log("Hello, World!");

// Math calculations
let sum = 20 + 25;
console.log("20 + 25 =", sum);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which of the following is the main purpose of JavaScript in web development?',
      options: [
        'Defining the semantic structure of a webpage',
        'Programming the behavior and interactive logic of web pages',
        'Storing web pages permanently on DNS servers',
        'Creating 3D vector graphics only'
      ],
      answer: 1,
      explanation: 'HTML provides structure, CSS provides presentation, and JavaScript handles interactive behavior and dynamic logic.'
    }
  },

  {
    id: 'html-and-js',
    category: 'basics',
    title: 'HTML & JavaScript: How They Work Together',
    readTime: '5 min',
    xp: 35,
    summary: 'Discover how HTML tags (buttons, text, inputs) act as the body, and JavaScript acts as the interactive brain.',
    contentHtml: `
      <h2>How HTML & JavaScript Connect</h2>
      <p>Think of a website like a superhero or a robot:</p>
      <ul>
        <li><strong>HTML is the Skeleton & Body:</strong> It creates the buttons (<code>&lt;button&gt;</code>), headings (<code>&lt;h1&gt;</code>), inputs (<code>&lt;input&gt;</code>), and boxes (<code>&lt;div&gt;</code>).</li>
        <li><strong>CSS is the Clothes & Style:</strong> It chooses the colors, margins, round borders, and fonts.</li>
        <li><strong>JavaScript is the Brain & Muscle:</strong> It listens for clicks, runs calculations, moves elements, and plays sounds!</li>
      </ul>

      <h2>The 3 Key Steps to Controlling HTML with JS</h2>
      
      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Step</th><th>JavaScript Code</th><th>What It Does</th></tr>
          </thead>
          <tbody>
            <tr><td><strong>1. Find Element</strong></td><td><code>const btn = document.getElementById("magic-btn");</code></td><td>Grabs the HTML button by its unique ID</td></tr>
            <tr><td><strong>2. Listen for Event</strong></td><td><code>btn.addEventListener("click", () => { ... });</code></td><td>Waits for user to click or type</td></tr>
            <tr><td><strong>3. Change HTML/Style</strong></td><td><code>btn.textContent = "Clicked!";<br>btn.style.color = "gold";</code></td><td>Updates text or CSS style dynamically</td></tr>
          </tbody>
        </table>
      </div>

      <h2>Sample HTML + JavaScript Code</h2>
      <div class="w3-code-box">
        <span class="code-badge">HTML Markup</span>
        <pre><code>&lt;!-- In your HTML file --&gt;
&lt;h1 id="title"&gt;Hello World&lt;/h1&gt;
&lt;button id="change-btn"&gt;Make Magic Happen!&lt;/button&gt;</code></pre>
      </div>

      <div class="w3-code-box">
        <span class="code-badge">JavaScript Logic</span>
        <pre><code>// In your JavaScript file
const btn = document.getElementById("change-btn");
const title = document.getElementById("title");

btn.onclick = () => {
  title.textContent = "🚀 JavaScript Changed Me!";
  title.style.color = "#10b981";
  title.style.transform = "scale(1.2)";
};</code></pre>
      </div>
    `,
    codeExample: `// 1. Finding HTML element by ID
const button = document.getElementById("magic-btn");
const heading = document.getElementById("main-heading");

// 2. Reacting to user clicks
button.onclick = () => {
  heading.textContent = "✨ JavaScript is magic!";
  heading.style.color = "#38bdf8";
  console.log("Heading text and style changed dynamically!");
};`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method in JavaScript is used to find an HTML element by its ID attribute?',
      options: [
        'document.findHTML()',
        'document.getElementById()',
        'document.searchTag()',
        'window.selectElement()'
      ],
      answer: 1,
      explanation: 'document.getElementById("idName") is the primary DOM method for selecting a single unique HTML element by its ID.'
    }
  },

  {
    id: 'js-output',
    category: 'basics',
    title: 'JavaScript Output & Console',
    readTime: '5 min',
    xp: 30,
    summary: 'Master the 4 primary ways JavaScript can display output to users and developers.',
    contentHtml: `
      <h2>JavaScript Display Possibilities</h2>
      <p>JavaScript can "display" data in different ways:</p>
      <ol>
        <li>Writing into an HTML element, using <code>innerHTML</code> or <code>textContent</code>.</li>
        <li>Writing into the HTML output stream using <code>document.write()</code> (mostly for testing).</li>
        <li>Writing into an alert box, using <code>window.alert()</code>.</li>
        <li>Writing into the browser debugging console, using <code>console.log()</code>, <code>console.error()</code>, <code>console.table()</code>.</li>
      </ol>

      <div class="w3-code-box">
        <span class="code-badge">Console Methods</span>
        <pre><code>console.log("Standard output");
console.warn("A warning message");
console.error("Critical error!");
console.table([{ name: "Alice", age: 25 }, { name: "Bob", age: 30 }]);</code></pre>
      </div>

      <div class="w3-note w3-warning">
        <h4>Important Tip</h4>
        <p>For debugging and clean development, always prefer <code>console.log()</code> and DOM modification rather than <code>window.alert()</code>, which blocks the UI thread.</p>
      </div>
    `,
    codeExample: `// Test different console outputs
console.log("1. Normal log output");
console.warn("2. Warning alert");
console.error("3. Custom error alert");

// Display tabular data easily
const users = [
  { id: 1, name: "Ada Lovelace", role: "Developer" },
  { id: 2, name: "Alan Turing", role: "Cryptanalyst" },
  { id: 3, name: "Grace Hopper", role: "Compiler Pioneer" }
];
console.table(users);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method writes directly into the browser developer console for debugging?',
      options: [
        'document.write()',
        'window.alert()',
        'console.log()',
        'print()'
      ],
      answer: 2,
      explanation: 'console.log() sends messages directly to the developer console without disrupting the user interface.'
    }
  },

  {
    id: 'js-variables',
    category: 'basics',
    title: 'JavaScript Variables: let, const & var',
    readTime: '6 min',
    xp: 35,
    summary: 'Learn the differences between let, const, and var, variable scopes, and modern best practices.',
    contentHtml: `
      <h2>Declaring Variables</h2>
      <p>In modern JavaScript (ES6+), there are three primary keywords used to declare variables:</p>
      <ul>
        <li><code>const</code> - Declares a block-scoped variable whose value <strong>cannot be reassigned</strong>. (Use by default!)</li>
        <li><code>let</code> - Declares a block-scoped variable that <strong>can be reassigned</strong>.</li>
        <li><code>var</code> - Declares a function-scoped or globally-scoped variable (legacy, avoid in modern code).</li>
      </ul>

      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Keyword</th><th>Scope</th><th>Reassignable?</th><th>Redeclarable?</th><th>Hoisting</th></tr>
          </thead>
          <tbody>
            <tr><td><code>const</code></td><td>Block</td><td>No</td><td>No</td><td>TDZ (Temporal Dead Zone)</td></tr>
            <tr><td><code>let</code></td><td>Block</td><td>Yes</td><td>No</td><td>TDZ (Temporal Dead Zone)</td></tr>
            <tr><td><code>var</code></td><td>Function</td><td>Yes</td><td>Yes</td><td>Hoisted as undefined</td></tr>
          </tbody>
        </table>
      </div>

      <div class="w3-note w3-tip">
        <h4>Best Practice Rule</h4>
        <p>Always declare variables with <code>const</code> unless you know the value will be reassigned, in which case use <code>let</code>. Never use <code>var</code> in modern code.</p>
      </div>
    `,
    codeExample: `// 1. Const cannot be reassigned
const PI = 3.14159;
console.log("PI:", PI);

// 2. Objects declared with const can still mutate properties
const student = { name: "Sarah", score: 95 };
student.score = 98; // Valid!
console.log("Updated student:", student);

// 3. Let is block-scoped and reassignable
let counter = 0;
counter += 5;
console.log("Counter:", counter);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which keyword should you use to declare a variable that will NOT be reassigned?',
      options: [
        'let',
        'const',
        'var',
        'def'
      ],
      answer: 1,
      explanation: 'const creates immutable variable bindings, ensuring that the identifier cannot be reassigned.'
    }
  },

  // --- DATA TYPES & OPERATORS ---
  {
    id: 'js-datatypes',
    category: 'datatypes',
    title: 'JavaScript Data Types',
    readTime: '5 min',
    xp: 35,
    summary: 'Understand JavaScript Primitive types vs Reference (Object) types, and the typeof operator.',
    contentHtml: `
      <h2>JavaScript has 8 Data Types</h2>
      <p>JavaScript data types are divided into two main categories:</p>

      <h3>1. Primitive Types (Stored by value)</h3>
      <ul>
        <li><code>String</code> - Text data (e.g., <code>"Hello"</code>, <code>'World'</code>)</li>
        <li><code>Number</code> - Integers and floats (e.g., <code>42</code>, <code>3.14</code>)</li>
        <li><code>BigInt</code> - Arbitrarily large integers (e.g., <code>9007199254740991n</code>)</li>
        <li><code>Boolean</code> - <code>true</code> or <code>false</code></li>
        <li><code>Undefined</code> - A variable declared without an assigned value</li>
        <li><code>Null</code> - Intentional absence of any object value</li>
        <li><code>Symbol</code> - Unique, immutable identifier</li>
      </ul>

      <h3>2. Reference Types (Stored by reference)</h3>
      <ul>
        <li><code>Object</code> - Key-value collections (e.g. <code>{ name: "John", age: 30 }</code>)</li>
        <li><code>Array</code> - Ordered lists (technically an Object subtype, e.g. <code>[1, 2, 3]</code>)</li>
        <li><code>Function</code> - Callable code blocks</li>
      </ul>

      <div class="w3-code-box">
        <span class="code-badge">The typeof Operator</span>
        <pre><code>typeof "John"         // "string"
typeof 3.14           // "number"
typeof NaN            // "number"
typeof false          // "boolean"
typeof [1, 2, 3]      // "object"
typeof { a: 1 }       // "object"
typeof null           // "object" (historic JS bug!)
typeof undefined      // "undefined"</code></pre>
      </div>
    `,
    codeExample: `// Check data types dynamically
const age = 22;
const name = "Marcus";
const isEnrolled = true;
const grades = [90, 85, 92];
const profile = { city: "New York", country: "USA" };
const unknownValue = null;

console.log("typeof age:", typeof age);
console.log("typeof name:", typeof name);
console.log("typeof isEnrolled:", typeof isEnrolled);
console.log("typeof grades:", typeof grades, "(Is Array?", Array.isArray(grades), ")");
console.log("typeof profile:", typeof profile);
console.log("typeof unknownValue:", typeof unknownValue);`,
    checkpoint: {
      type: 'mcq',
      question: 'What does the expression typeof null return in JavaScript?',
      options: [
        '"null"',
        '"undefined"',
        '"object"',
        '"number"'
      ],
      answer: 2,
      explanation: 'In JavaScript, typeof null historically returns "object" due to an original legacy implementation in the early JS engine.'
    }
  },

  {
    id: 'js-operators',
    category: 'datatypes',
    title: 'JavaScript Operators & Equality',
    readTime: '6 min',
    xp: 35,
    summary: 'Strict (===) vs Loose (==) equality, Logical operators, Nullish Coalescing (??), and Optional Chaining (?.).',
    contentHtml: `
      <h2>Comparison Operators: == vs ===</h2>
      <p>Always use strict equality <code>===</code> rather than loose equality <code>==</code>:</p>
      <ul>
        <li><code>===</code> (Strict equality): Compares both <strong>value and type</strong> without type coercion.</li>
        <li><code>==</code> (Loose equality): Converts types before comparison (coercion), causing surprising bugs!</li>
      </ul>

      <div class="w3-code-box">
        <span class="code-badge">Equality Comparison Examples</span>
        <pre><code>5 == "5"     // true  (type coerced)
5 === "5"    // false (different types: number vs string)
0 == false   // true
0 === false  // false
null == undefined  // true
null === undefined // false</code></pre>
      </div>

      <h2>Modern Logical Operators (ES2020+)</h2>
      <ul>
        <li><strong>Nullish Coalescing (<code>??</code>)</strong>: Returns the right-hand operand only if the left operand is <code>null</code> or <code>undefined</code> (unlike <code>||</code> which falls back on falsy values like <code>0</code> or <code>""</code>).</li>
        <li><strong>Optional Chaining (<code>?.</code>)</strong>: Safely access nested object properties without throwing <code>TypeError: Cannot read properties of undefined</code>.</li>
      </ul>
    `,
    codeExample: `// Test Strict vs Loose equality
console.log('5 == "5" is:', 5 == "5");
console.log('5 === "5" is:', 5 === "5");

// Modern Nullish Coalescing (??) vs OR (||)
const userScore = 0; // Valid score!
const defaultScoreOr = userScore || 100; // Bug: falls back to 100 because 0 is falsy
const defaultScoreNullish = userScore ?? 100; // Correct: preserves 0!

console.log("Using || :", defaultScoreOr);
console.log("Using ?? :", defaultScoreNullish);

// Optional Chaining (?.)
const user = { profile: { name: "Elena" } };
console.log("Safe access:", user.profile?.name);
console.log("Non-existent property:", user.address?.street); // undefined without crash`,
    checkpoint: {
      type: 'mcq',
      question: 'What is the result of 0 ?? 42 versus 0 || 42?',
      options: [
        '0 and 0',
        '0 and 42',
        '42 and 0',
        '42 and 42'
      ],
      answer: 1,
      explanation: '0 is a valid non-nullish value, so ?? returns 0. However, 0 is falsy, so || falls back to 42.'
    }
  },

  // --- CONTROL FLOW & LOOPS ---
  {
    id: 'js-conditionals',
    category: 'control',
    title: 'Conditionals: if, else & switch',
    readTime: '5 min',
    xp: 30,
    summary: 'Branching logic using if/else statements, ternary operators, and switch statements.',
    contentHtml: `
      <h2>Conditional Statements</h2>
      <p>Conditional statements allow you to perform different actions based on different conditions:</p>
      <ul>
        <li><code>if</code> - specifies a block of code to be executed if a condition is true.</li>
        <li><code>else if</code> - specifies a new condition to test if the first condition is false.</li>
        <li><code>else</code> - specifies code to execute if all previous conditions are false.</li>
        <li><code>switch</code> - selects one of many code blocks to be executed based on matching an expression.</li>
      </ul>

      <h2>The Ternary Operator</h2>
      <p>A concise one-line syntax for simple if-else expressions:</p>
      <div class="w3-code-box">
        <pre><code>const access = age >= 18 ? "Granted" : "Denied";</code></pre>
      </div>
    `,
    codeExample: `// 1. If-Else Ladder
const score = 88;
let grade;

if (score >= 90) {
  grade = "A";
} else if (score >= 80) {
  grade = "B";
} else if (score >= 70) {
  grade = "C";
} else {
  grade = "F";
}
console.log("Score:", score, "Grade:", grade);

// 2. Switch Statement
const dayNumber = 3;
let dayName;

switch (dayNumber) {
  case 1: dayName = "Monday"; break;
  case 2: dayName = "Tuesday"; break;
  case 3: dayName = "Wednesday"; break;
  case 4: dayName = "Thursday"; break;
  case 5: dayName = "Friday"; break;
  default: dayName = "Weekend";
}
console.log("Day 3 is:", dayName);`,
    checkpoint: {
      type: 'mcq',
      question: 'Why is the "break" statement important inside a switch case?',
      options: [
        'To declare new variables',
        'To stop execution from falling through to the next cases',
        'To speed up CPU clock speed',
        'It is strictly optional and has no effect'
      ],
      answer: 1,
      explanation: 'Without "break", JavaScript continues executing all subsequent cases regardless of their condition (known as fall-through).'
    }
  },

  {
    id: 'js-loops',
    category: 'control',
    title: 'Loops: for, while, for...of & for...in',
    readTime: '6 min',
    xp: 35,
    summary: 'Master standard loops, iterative control, for...of for arrays, and for...in for object keys.',
    contentHtml: `
      <h2>Types of Loops in JavaScript</h2>
      <ul>
        <li><code>for</code> - loops through a block of code a specified number of times.</li>
        <li><code>for...of</code> - loops through values of an iterable object (Arrays, Strings, Sets, Maps).</li>
        <li><code>for...in</code> - loops through enumerable properties (keys) of an Object.</li>
        <li><code>while</code> - loops through a block of code while a specified condition is true.</li>
        <li><code>do...while</code> - executes the block once before checking if the condition is true.</li>
      </ul>

      <div class="w3-note w3-tip">
        <h4>Key Distinction: for...of vs for...in</h4>
        <p>Use <strong><code>for...of</code></strong> for Array items / Iterables.</p>
        <p>Use <strong><code>for...in</code></strong> for Object keys.</p>
      </div>
    `,
    codeExample: `// 1. Standard for loop
console.log("Standard loop:");
for (let i = 1; i <= 3; i++) {
  console.log("  Count:", i);
}

// 2. for...of loop on Array (Values)
const fruits = ["Apple", "Banana", "Cherry"];
console.log("for...of values:");
for (const fruit of fruits) {
  console.log("  Fruit:", fruit);
}

// 3. for...in loop on Object (Keys)
const car = { brand: "Tesla", model: "Model 3", year: 2024 };
console.log("for...in object properties:");
for (const key in car) {
  console.log("  " + key + " -> " + car[key]);
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which loop is best suited for directly iterating through the elements of an Array in modern JavaScript?',
      options: [
        'for...in',
        'for...of',
        'goto loop',
        'switch loop'
      ],
      answer: 1,
      explanation: 'for...of iterates directly over the values of iterable collections like Arrays, Strings, and Maps.'
    }
  },

  // --- FUNCTIONS & SCOPE ---
  {
    id: 'js-functions',
    category: 'functions',
    title: 'JavaScript Functions & Arrow Syntax',
    readTime: '6 min',
    xp: 40,
    summary: 'Function declarations, expressions, arrow functions, default parameters, and rest arguments.',
    contentHtml: `
      <h2>Defining Functions</h2>
      <p>Functions are the fundamental building blocks in JavaScript. A function is a block of code designed to perform a particular task.</p>

      <h3>1. Function Declaration (Hoisted)</h3>
      <div class="w3-code-box">
        <pre><code>function add(a, b) {
  return a + b;
}</code></pre>
      </div>

      <h3>2. Arrow Function (ES6)</h3>
      <div class="w3-code-box">
        <pre><code>const add = (a, b) => a + b;</code></pre>
      </div>

      <h2>Key Differences with Arrow Functions</h2>
      <ul>
        <li>Arrow functions do not have their own <code>this</code> context; they inherit <code>this</code> from the enclosing lexical scope.</li>
        <li>Arrow functions do not have an <code>arguments</code> object.</li>
        <li>Arrow functions cannot be used as constructors (cannot use with <code>new</code>).</li>
      </ul>

      <h2>Default Parameters & Rest Parameters (<code>...</code>)</h2>
      <div class="w3-code-box">
        <pre><code>// Default parameters
function greet(name = "Guest") {
  return \`Hello, \${name}!\`;
}

// Rest parameters collect all extra arguments into an array
function sumAll(...numbers) {
  return numbers.reduce((acc, curr) => acc + curr, 0);
}</code></pre>
      </div>
    `,
    codeExample: `// 1. Arrow functions
const multiply = (x, y) => x * y;
console.log("5 * 8 =", multiply(5, 8));

// 2. Rest parameters (...args)
const calculateTotal = (...prices) => {
  return prices.reduce((total, p) => total + p, 0);
};
console.log("Total price:", calculateTotal(19.99, 5.50, 42.00, 10.00));

// 3. Higher order functions: passing functions as arguments
const applyOperation = (a, b, operation) => operation(a, b);
console.log("Higher order result:", applyOperation(10, 20, (x, y) => x + y));`,
    checkpoint: {
      type: 'mcq',
      question: 'How do Arrow Functions handle the "this" keyword compared to regular functions?',
      options: [
        'They create a new dynamic this binding on every call',
        'They lexically inherit "this" from the parent enclosing scope',
        'They permanently bind "this" to window/global',
        'They forbid any usage of properties or variables'
      ],
      answer: 1,
      explanation: 'Arrow functions do not bind their own this; they capture the this value of the enclosing execution context.'
    }
  },

  {
    id: 'js-closures',
    category: 'functions',
    title: 'Scope, Closures & Lexical Environment',
    readTime: '7 min',
    xp: 45,
    summary: 'Master one of JavaScript’s most powerful concepts: closures, lexical scope, and data privacy.',
    contentHtml: `
      <h2>What is a Closure?</h2>
      <p>A <strong>closure</strong> is the combination of a function bundled together (enclosed) with references to its surrounding state (the <strong>lexical environment</strong>).</p>
      <p>In other words, a closure gives an inner function <strong>access to an outer function's scope</strong> even after the outer function has finished executing!</p>

      <div class="w3-code-box">
        <span class="code-badge">Classic Closure Counter</span>
        <pre><code>function createCounter() {
  let count = 0; // Private variable!
  
  return {
    increment: () => ++count,
    decrement: () => --count,
    getCount: () => count
  };
}

const counter = createCounter();
counter.increment(); // 1
counter.increment(); // 2
console.log(counter.getCount()); // 2
// count is completely protected from outside tampering!</code></pre>
      </div>

      <div class="w3-note w3-tip">
        <h4>Why are Closures useful?</h4>
        <ul>
          <li><strong>Data Privacy & Encapsulation:</strong> Emulate private variables without class syntax.</li>
          <li><strong>Function Factories:</strong> Create custom functions on demand (e.g. currying).</li>
          <li><strong>Event handlers & callbacks:</strong> Retaining state across asynchronous operations.</li>
        </ul>
      </div>
    `,
    codeExample: `// Function Factory using Closure
function createMultiplier(multiplier) {
  return function(number) {
    return number * multiplier;
  };
}

const double = createMultiplier(2);
const triple = createMultiplier(3);
const timesTen = createMultiplier(10);

console.log("double(7) =", double(7));
console.log("triple(7) =", triple(7));
console.log("timesTen(7) =", timesTen(7));

// Private bank account balance
function createBankAccount(initialBalance) {
  let balance = initialBalance;
  return {
    deposit: (amount) => { balance += amount; return balance; },
    withdraw: (amount) => {
      if (amount > balance) return "Insufficient funds!";
      balance -= amount;
      return balance;
    },
    getBalance: () => balance
  };
}

const myAccount = createBankAccount(100);
myAccount.deposit(50);
console.log("Balance after deposit:", myAccount.getBalance());
console.log("Withdrawal:", myAccount.withdraw(30));
console.log("Final balance:", myAccount.getBalance());`,
    checkpoint: {
      type: 'mcq',
      question: 'What enables an inner function to remember and access variables from its outer function even after the outer function has returned?',
      options: [
        'Garbage collection',
        'A JavaScript Closure',
        'Variable Hoisting',
        'CSS Object Model'
      ],
      answer: 1,
      explanation: 'A closure preserves the outer lexical environment in memory, allowing the inner function to access its variables indefinitely.'
    }
  },

  // --- OBJECTS & ARRAYS ---
  {
    id: 'js-objects',
    category: 'objects',
    title: 'JavaScript Objects & Methods',
    readTime: '6 min',
    xp: 35,
    summary: 'Object literals, dot vs bracket notation, methods, this keyword, and static Object methods.',
    contentHtml: `
      <h2>JavaScript Objects</h2>
      <p>Objects in JavaScript are collections of key-value pairs. Values can be primitives, other objects, or functions (which are called <strong>methods</strong>).</p>

      <h2>Static Object Methods (ES6+)</h2>
      <ul>
        <li><code>Object.keys(obj)</code> - Returns an array of all keys.</li>
        <li><code>Object.values(obj)</code> - Returns an array of all values.</li>
        <li><code>Object.entries(obj)</code> - Returns an array of <code>[key, value]</code> pairs.</li>
        <li><code>Object.assign(target, source)</code> - Copies properties to a target object.</li>
        <li><code>Object.freeze(obj)</code> - Prevents modification or addition of properties.</li>
      </ul>
    `,
    codeExample: `const laptop = {
  brand: "Apple",
  model: "MacBook Pro",
  year: 2024,
  specs: {
    cpu: "M3 Max",
    ram: 36
  },
  getSummary() {
    return \`\${this.brand} \${this.model} (\${this.year}) with \${this.specs.cpu}\`;
  }
};

console.log("Summary:", laptop.getSummary());
console.log("Keys:", Object.keys(laptop));
console.log("Values:", Object.values(laptop));
console.log("Entries:", Object.entries(laptop.specs));`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method returns an array of [key, value] pairs for a given object?',
      options: [
        'Object.keys()',
        'Object.values()',
        'Object.entries()',
        'Object.freeze()'
      ],
      answer: 2,
      explanation: 'Object.entries(obj) returns an array of a given object\'s own enumerable string-keyed property [key, value] pairs.'
    }
  },

  {
    id: 'js-arrays',
    category: 'objects',
    title: 'Arrays & Array Iteration Methods',
    readTime: '8 min',
    xp: 45,
    summary: 'Master map, filter, reduce, find, some, every, flat, and immutable array transformation.',
    contentHtml: `
      <h2>Modern Array Iteration Methods</h2>
      <p>Functional array methods do not mutate the original array, making your code clean and predictable:</p>

      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Method</th><th>Purpose</th><th>Returns</th></tr>
          </thead>
          <tbody>
            <tr><td><code>map()</code></td><td>Transforms each element</td><td>New array of same length</td></tr>
            <tr><td><code>filter()</code></td><td>Selects items matching condition</td><td>New array of matching items</td></tr>
            <tr><td><code>reduce()</code></td><td>Accumulates values to a single result</td><td>Single value (number, object, etc.)</td></tr>
            <tr><td><code>find()</code></td><td>Finds first element matching condition</td><td>Element or undefined</td></tr>
            <tr><td><code>some()</code></td><td>Tests if at least one item passes</td><td>Boolean</td></tr>
            <tr><td><code>every()</code></td><td>Tests if all items pass</td><td>Boolean</td></tr>
            <tr><td><code>includes()</code></td><td>Checks if value exists in array</td><td>Boolean</td></tr>
          </tbody>
        </table>
      </div>
    `,
    codeExample: `const products = [
  { id: 1, name: "Keyboard", price: 75, category: "Tech", stock: 12 },
  { id: 2, name: "Mouse", price: 45, category: "Tech", stock: 0 },
  { id: 3, name: "Desk Mat", price: 25, category: "Office", stock: 30 },
  { id: 4, name: "Monitor", price: 320, category: "Tech", stock: 5 }
];

// 1. Filter: In-stock items only
const inStock = products.filter(item => item.stock > 0);
console.log("In-Stock count:", inStock.length);

// 2. Map: Extract formatted names
const productLabels = inStock.map(p => \`\${p.name} ($ \${p.price})\`);
console.log("Labels:", productLabels);

// 3. Reduce: Calculate total inventory value
const totalInventoryValue = products.reduce((acc, p) => acc + (p.price * p.stock), 0);
console.log("Total inventory value: $" + totalInventoryValue);

// 4. Find: First item over $100
const premiumItem = products.find(p => p.price > 100);
console.log("Premium item:", premiumItem.name);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which array method calculates a single aggregated value (like a total sum or combined object) from an array?',
      options: [
        'filter()',
        'map()',
        'reduce()',
        'forEach()'
      ],
      answer: 2,
      explanation: 'reduce() executes a user-supplied reducer callback function on each element of the array, resulting in a single output value.'
    }
  },

  // --- OOP & CLASSES ---
  {
    id: 'js-classes',
    category: 'oop',
    title: 'Object-Oriented JS & Classes',
    readTime: '7 min',
    xp: 40,
    summary: 'ES6 Classes, constructors, getters/setters, static methods, inheritance with extends and super.',
    contentHtml: `
      <h2>JavaScript Classes (ES6)</h2>
      <p>JavaScript classes are syntactic sugar over JavaScript's existing prototype-based inheritance.</p>

      <div class="w3-code-box">
        <span class="code-badge">Class Definition & Inheritance</span>
        <pre><code>class Animal {
  constructor(name) {
    this.name = name;
  }
  speak() {
    return \`\${this.name} makes a sound.\`;
  }
}

class Dog extends Animal {
  constructor(name, breed) {
    super(name); // Call parent constructor
    this.breed = breed;
  }
  speak() {
    return \`\${this.name} barks!\`;
  }
}</code></pre>
      </div>

      <h2>Private Class Fields & Static Methods</h2>
      <ul>
        <li><code>#privateField</code> - Prefix with <code>#</code> to create truly private variables inaccessible outside the class.</li>
        <li><code>static</code> - Methods attached to the class itself rather than instances (e.g. <code>Math.max()</code>).</li>
      </ul>
    `,
    codeExample: `class BankAccount {
  #balance = 0; // Private field

  constructor(owner, initialBalance = 0) {
    this.owner = owner;
    this.#balance = initialBalance;
  }

  deposit(amount) {
    if (amount <= 0) throw new Error("Deposit must be positive!");
    this.#balance += amount;
    return this.#balance;
  }

  get balance() {
    return \`$\${this.#balance.toFixed(2)}\`;
  }

  static compareAccounts(acc1, acc2) {
    return acc1.#balance - acc2.#balance;
  }
}

const account1 = new BankAccount("Alice", 500);
account1.deposit(250);
console.log("Owner:", account1.owner);
console.log("Formatted balance:", account1.balance);`,
    checkpoint: {
      type: 'mcq',
      question: 'In modern JavaScript, how do you declare a truly private class field?',
      options: [
        'private balance;',
        '#balance;',
        '_balance;',
        'protected balance;'
      ],
      answer: 1,
      explanation: 'Prefixing a property with the hash symbol # (e.g. #balance) makes it a private class field enforced by the JS engine.'
    }
  },

  // --- ASYNCHRONOUS JAVASCRIPT ---
  {
    id: 'js-async',
    category: 'async',
    title: 'Promises & Async / Await',
    readTime: '8 min',
    xp: 50,
    summary: 'Master asynchronous code: Event Loop, Promise states, async/await, and error handling with try/catch.',
    contentHtml: `
      <h2>The Asynchronous Nature of JavaScript</h2>
      <p>JavaScript is single-threaded, meaning it has one call stack. To handle long operations (like network requests or file reads) without freezing the UI, JavaScript uses the <strong>Event Loop</strong>.</p>

      <h2>Promises: 3 States</h2>
      <ul>
        <li><code>Pending</code>: Initial state, neither fulfilled nor rejected.</li>
        <li><code>Fulfilled</code>: Operation completed successfully (resolved).</li>
        <li><code>Rejected</code>: Operation failed.</li>
      </ul>

      <h2>Async / Await (The Modern Standard)</h2>
      <p><code>async/await</code> provides clean, synchronous-looking syntax for working with Promises:</p>
      <div class="w3-code-box">
        <pre><code>async function fetchData() {
  try {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('HTTP error ' + response.status);
    const data = await response.json();
    console.log(data);
  } catch (error) {
    console.error('Fetch failed:', error.message);
  }
}</code></pre>
      </div>
    `,
    codeExample: `// Simulating an asynchronous database request with a Promise
function fetchUserProfile(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (userId === 1) {
        resolve({ id: 1, username: "dev_pro", role: "admin", karma: 4200 });
      } else {
        reject(new Error("User not found"));
      }
    }, 500);
  });
}

// Consuming with async/await
async function runDemo() {
  console.log("1. Requesting user 1 data...");
  try {
    const user = await fetchUserProfile(1);
    console.log("2. Received user successfully:", user);
  } catch (err) {
    console.error("Error occurred:", err.message);
  }
  console.log("3. Done with request flow!");
}

runDemo();`,
    checkpoint: {
      type: 'mcq',
      question: 'What does a function marked with the "async" keyword always return?',
      options: [
        'A string',
        'A Promise',
        'A generator object',
        'undefined'
      ],
      answer: 1,
      explanation: 'An async function always wraps its return value in a Promise (or returns the Promise directly).'
    }
  },

  // --- DOM & WEB APIS ---
  {
    id: 'js-dom',
    category: 'dom',
    title: 'DOM Manipulation & Event Handling',
    readTime: '7 min',
    xp: 40,
    summary: 'Selecting elements, modifying attributes & CSS, listening to click/input events, and Event Delegation.',
    contentHtml: `
      <h2>What is the DOM?</h2>
      <p>The <strong>Document Object Model (DOM)</strong> is an application programming interface (API) for HTML and XML documents. It represents the page as a tree structure of nodes.</p>

      <h2>Selecting Elements</h2>
      <ul>
        <li><code>document.querySelector(selector)</code> - Returns the first matching element.</li>
        <li><code>document.querySelectorAll(selector)</code> - Returns a NodeList of all matching elements.</li>
        <li><code>document.getElementById(id)</code> - Selects element by unique ID.</li>
      </ul>

      <h2>Modifying HTML & Styles</h2>
      <div class="w3-code-box">
        <pre><code>const button = document.querySelector('#submit-btn');
button.textContent = 'Save Changes';
button.classList.add('active', 'primary');
button.style.backgroundColor = '#04AA6D';</code></pre>
      </div>

      <h2>Event Listeners</h2>
      <div class="w3-code-box">
        <pre><code>button.addEventListener('click', (event) => {
  event.preventDefault();
  console.log('Button clicked at:', event.clientX, event.clientY);
});</code></pre>
      </div>
    `,
    codeExample: `// Simulating DOM manipulation in sandbox
console.log("DOM Selection patterns:");
console.log("1. document.querySelector('.card')");
console.log("2. document.querySelectorAll('button.tab')");

// Dynamic element creation example
const elementSpec = {
  tag: "div",
  className: "alert-box success",
  text: "Profile updated successfully!"
};
console.log("Created element spec:", elementSpec);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method is recommended for selecting the first element that matches a specified CSS selector?',
      options: [
        'document.findElement()',
        'document.querySelector()',
        'document.getElementsByTag()',
        'document.searchQuery()'
      ],
      answer: 1,
      explanation: 'document.querySelector() returns the first Element within the document that matches the specified selector or group of selectors.'
    }
  },

  // --- MODERN ES6+ & WEB STORAGE ---
  {
    id: 'js-modern-features',
    category: 'modern',
    title: 'Modern ES6+ Features & Destructuring',
    readTime: '7 min',
    xp: 40,
    summary: 'Destructuring arrays & objects, Spread and Rest operators, Template Literals, and Modules.',
    contentHtml: `
      <h2>Key Modern JavaScript Additions</h2>
      
      <h3>1. Destructuring Assignment</h3>
      <div class="w3-code-box">
        <pre><code>// Object destructuring with renaming and defaults
const user = { username: 'alex', age: 28, country: 'Canada' };
const { username, age, role = 'Member' } = user;

// Array destructuring
const coords = [51.5074, -0.1278];
const [latitude, longitude] = coords;</code></pre>
      </div>

      <h3>2. Spread Operator (<code>...</code>)</h3>
      <div class="w3-code-box">
        <pre><code>// Shallow clone & merge objects
const base = { theme: 'dark', sound: true };
const custom = { ...base, sound: false, lang: 'en' };

// Combine arrays
const numbers = [...[1, 2], ...[3, 4]]; // [1, 2, 3, 4]</code></pre>
      </div>
    `,
    codeExample: `// 1. Object Destructuring
const person = { first: "Grace", last: "Hopper", field: "Computer Science" };
const { first, last, field } = person;
console.log(\`\${first} \${last} revolutionized \${field}.\`);

// 2. Spread operator cloning and merging
const defaultSettings = { theme: "light", notifications: true, volume: 80 };
const userSettings = { ...defaultSettings, theme: "dark", volume: 100 };
console.log("Merged settings:", userSettings);

// 3. Array destructuring with rest
const [firstItem, secondItem, ...remainingItems] = [10, 20, 30, 40, 50];
console.log("First:", firstItem);
console.log("Second:", secondItem);
console.log("Remaining array:", remainingItems);`,
    checkpoint: {
      type: 'mcq',
      question: 'What is the syntax used to unpack values from arrays, or properties from objects, into distinct variables?',
      options: [
        'Serialization',
        'Destructuring assignment',
        'Type Casting',
        'Prototypal Inheritance'
      ],
      answer: 1,
      explanation: 'Destructuring assignment allows unpacking values from arrays or properties from objects into distinct variables directly.'
    }
  },

  {
    id: 'js-storage',
    category: 'modern',
    title: 'Web Storage: localStorage & sessionStorage',
    readTime: '5 min',
    xp: 35,
    summary: 'Persist data locally in the browser with localStorage, JSON serialization, and storage limits.',
    contentHtml: `
      <h2>Client-Side Web Storage</h2>
      <p>Web storage allows web applications to store data locally within the user's browser:</p>
      <ul>
        <li><code>localStorage</code> - Stores data with <strong>no expiration date</strong>. The data persists even after the browser is closed and reopened.</li>
        <li><code>sessionStorage</code> - Stores data for <strong>one session</strong> only. The data is deleted when the user closes the specific browser tab.</li>
      </ul>

      <h2>Key Methods</h2>
      <div class="w3-code-box">
        <pre><code>// Store a string
localStorage.setItem('username', 'Ada');

// Store an object (must serialize with JSON.stringify)
const settings = { darkMode: true, fontSize: 16 };
localStorage.setItem('user_settings', JSON.stringify(settings));

// Retrieve and parse
const saved = JSON.parse(localStorage.getItem('user_settings'));

// Remove or clear
localStorage.removeItem('username');
localStorage.clear();</code></pre>
      </div>
    `,
    codeExample: `// Test JSON serialization & storage simulation
const userState = {
  streak: 5,
  xp: 450,
  badges: ["Fast Learner", "JS Master"],
  preferences: { sound: true }
};

// Serialize
const serialized = JSON.stringify(userState, null, 2);
console.log("Serialized JSON string:");
console.log(serialized);

// Parse back
const restored = JSON.parse(serialized);
console.log("Restored object badges:", restored.badges.join(", "));`,
    checkpoint: {
      type: 'mcq',
      question: 'How do you correctly store a JavaScript object or array in localStorage?',
      options: [
        'localStorage.setObject("key", obj)',
        'localStorage.setItem("key", JSON.stringify(obj))',
        'localStorage.save("key", obj.toString())',
        'localStorage.write("key", obj)'
      ],
      answer: 1,
      explanation: 'localStorage can only store strings, so objects and arrays must be converted to a JSON string using JSON.stringify() before saving.'
    }
  }
];
