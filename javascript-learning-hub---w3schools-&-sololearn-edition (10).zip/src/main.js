// Application Entry Point (Vanilla HTML, CSS, JS)
import './styles/main.css';
import { uiController } from './modules/ui.js';

document.addEventListener('DOMContentLoaded', () => {
  uiController.init();
});
