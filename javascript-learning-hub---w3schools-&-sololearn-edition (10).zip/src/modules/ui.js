// UI Controller & Orchestration Module
import { CATEGORIES, LESSONS } from '../data/lessons.js';
import { stateManager } from './state.js';
import { quizEngine } from './quiz.js';
import { CodeEditor } from './editor.js';
import { challengeRunner } from './challengeRunner.js';
import { referenceView } from './referenceView.js';
import { interactivePlaygrounds } from './interactivePlaygrounds.js';
import { sound } from './audio.js';

export class UIController {
  constructor() {
    this.editorInstance = null;
    this.standaloneEditorInstance = null;
    this.lastXP = stateManager.get().xp;
    this.lastLevel = stateManager.getLevel().level;
  }

  init() {
    this.applyTheme(stateManager.get().theme);
    this.renderHeaderStats();
    this.renderSidebar();
    this.bindGlobalEvents();
    this.setupScrollProgressTracker();
    this.setupView(stateManager.get().currentView);

    // Subscribe to state updates
    stateManager.subscribe(() => {
      const curState = stateManager.get();
      const curLvl = stateManager.getLevel().level;

      // Detect Level-up celebration
      if (curLvl > this.lastLevel) {
        this.triggerLevelUpCelebration(curLvl);
        this.lastLevel = curLvl;
      }

      this.renderHeaderStats();
      this.updateSidebarActiveState();
      this.updateMilestoneCard();
    });

    // Listen for custom milestone/progress celebrations from quizzes & challenges
    window.addEventListener('milestone-completed', (e) => {
      const { xp, title, desc } = e.detail || {};
      this.triggerCelebration(null, xp || 15, title || 'Milestone Reached! 🚀', desc || '');
    });
  }

  setupScrollProgressTracker() {
    const mainViewport = document.getElementById('main-viewport');
    const updateProgress = () => {
      const fill = document.getElementById('reading-progress-fill');
      if (!mainViewport || !fill) return;

      const currentView = stateManager.get().currentView;
      if (currentView !== 'learn') {
        fill.style.width = '0%';
        fill.classList.remove('reading-finished');
        return;
      }

      const maxScroll = mainViewport.scrollHeight - mainViewport.clientHeight;
      const pct = maxScroll > 10 ? Math.min(100, Math.max(0, (mainViewport.scrollTop / maxScroll) * 100)) : 100;
      fill.style.width = `${pct}%`;

      if (pct >= 95) {
        fill.classList.add('reading-finished');
      } else {
        fill.classList.remove('reading-finished');
      }
    };

    mainViewport?.addEventListener('scroll', updateProgress, { passive: true });
    window.addEventListener('resize', updateProgress, { passive: true });
  }

  bindGlobalEvents() {
    // Mobile sidebar toggle
    const toggleBtn = document.getElementById('btn-toggle-sidebar');
    const backdrop = document.getElementById('sidebar-backdrop');
    const sidebar = document.getElementById('course-sidebar');

    const toggleSidebar = () => {
      sidebar.classList.toggle('open');
      backdrop.classList.toggle('open');
    };

    toggleBtn?.addEventListener('click', toggleSidebar);
    backdrop?.addEventListener('click', toggleSidebar);

    // Brand logo click
    document.getElementById('brand-logo-link')?.addEventListener('click', (e) => {
      e.preventDefault();
      this.switchView('learn');
    });

    // Dark/Light Theme Toggle
    document.getElementById('btn-theme-toggle')?.addEventListener('click', () => {
      const current = stateManager.get().theme;
      const next = current === 'dark' ? 'light' : 'dark';
      this.applyTheme(next);
      stateManager.update({ theme: next });
    });

    // Top desktop nav tabs
    document.querySelectorAll('.nav-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.getAttribute('data-view');
        this.switchView(view);
      });
    });

    // Bottom mobile nav items
    document.querySelectorAll('.mobile-nav-item').forEach(btn => {
      btn.addEventListener('click', () => {
        const view = btn.getAttribute('data-view');
        this.switchView(view);
      });
    });

    // Sidebar search filter
    const searchInput = document.getElementById('sidebar-search-input');
    searchInput?.addEventListener('input', (e) => {
      this.filterSidebarLessons(e.target.value);
    });
  }

  applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const iconSpan = document.getElementById('theme-icon-container');
    if (iconSpan) {
      iconSpan.innerHTML = theme === 'dark' ? `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"></circle><line x1="12" y1="1" x2="12" y2="3"></line><line x1="12" y1="21" x2="12" y2="23"></line><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line><line x1="1" y1="12" x2="3" y2="12"></line><line x1="21" y1="12" x2="23" y2="12"></line><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line></svg>
      ` : `
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path></svg>
      `;
    }
  }

  renderHeaderStats() {
    const { streak, xp } = stateManager.get();
    const { level } = stateManager.getLevel();

    const streakEl = document.getElementById('stat-streak-val');
    const xpEl = document.getElementById('stat-xp-val');
    const lvlEl = document.getElementById('stat-level-val');
    const progValEl = document.getElementById('header-progress-pct');
    const progFillEl = document.getElementById('header-progress-fill');

    if (streakEl) streakEl.textContent = `${streak}d`;
    if (lvlEl) lvlEl.textContent = `Lvl ${level}`;

    // Animate XP number counter
    if (xpEl) {
      if (this.lastXP !== xp) {
        this.animateNumberCounter(xpEl, this.lastXP, xp, ' XP');
        this.lastXP = xp;
      } else {
        xpEl.textContent = `${xp} XP`;
      }
    }

    // Global course progress bar calculation
    const completed = stateManager.get().completedLessons || [];
    const total = LESSONS.length;
    const progressPct = total > 0 ? Math.round((completed.length / total) * 100) : 0;

    if (progValEl) progValEl.textContent = `${progressPct}%`;
    if (progFillEl) progFillEl.style.width = `${progressPct}%`;
  }

  animateNumberCounter(el, start, end, suffix = '') {
    const duration = 600;
    const startTime = performance.now();
    const step = (now) => {
      const progress = Math.min((now - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      const val = Math.round(start + (end - start) * ease);
      el.textContent = `${val}${suffix}`;
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    };
    requestAnimationFrame(step);
  }

  renderSidebar() {
    const container = document.getElementById('sidebar-nav-container');
    if (!container) return;

    const completed = stateManager.get().completedLessons || [];
    const activeLessonId = stateManager.get().activeLessonId;
    const totalLessons = LESSONS.length;
    const completedCount = completed.length;
    const coursePct = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;
    const levelInfo = stateManager.getLevel();

    let html = `
      <!-- Sidebar Learning Progress Dashboard Card -->
      <div class="sidebar-progress-card" id="sidebar-progress-card">
        <div class="sidebar-level-row">
          <div class="sidebar-level-badge">
            <span>Level</span>
            <span class="sidebar-level-pill" id="sidebar-lvl-badge">Lvl ${levelInfo.level}</span>
          </div>
          <div class="sidebar-xp-fraction" id="sidebar-xp-ratio">${levelInfo.currentXP} / ${levelInfo.nextLevelXP} XP</div>
        </div>
        <div class="sidebar-prog-track" title="Level Progress">
          <div class="sidebar-prog-fill" id="sidebar-lvl-fill" style="width: ${levelInfo.progressPercent}%;"></div>
        </div>
        <div class="sidebar-stats-row">
          <span>Course Completion</span>
          <span class="highlight" id="sidebar-course-ratio">${completedCount}/${totalLessons} (${coursePct}%)</span>
        </div>
      </div>
    `;

    CATEGORIES.forEach(cat => {
      const catLessons = LESSONS.filter(l => l.category === cat.id);
      if (catLessons.length === 0) return;

      const catDone = catLessons.filter(l => completed.includes(l.id)).length;
      const isCatDone = catDone === catLessons.length;
      const catPct = Math.round((catDone / catLessons.length) * 100);

      html += `
        <div class="sidebar-category-group" data-cat-id="${cat.id}">
          <div class="sidebar-cat-header-row">
            <div class="sidebar-cat-title">${cat.title}</div>
            <span class="cat-progress-badge ${isCatDone ? 'done' : ''}" id="cat-badge-${cat.id}">
              ${isCatDone ? '✓ ' : ''}${catDone}/${catLessons.length}
            </span>
          </div>
          <div class="cat-mini-track">
            <div class="cat-mini-fill" id="cat-mini-${cat.id}" style="width: ${catPct}%;"></div>
          </div>
          <div class="cat-lessons-list">
            ${catLessons.map(lesson => {
              const isDone = completed.includes(lesson.id);
              const isActive = lesson.id === activeLessonId;
              return `
                <a class="lesson-nav-link ${isActive ? 'active' : ''}" data-lesson-id="${lesson.id}">
                  <span>${lesson.title}</span>
                  ${isDone ? '<span class="lesson-check-icon">✓</span>' : ''}
                </a>
              `;
            }).join('')}
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    // Bind click events
    container.querySelectorAll('.lesson-nav-link').forEach(link => {
      link.addEventListener('click', () => {
        const id = link.getAttribute('data-lesson-id');
        this.loadLesson(id);

        // Close sidebar on mobile
        document.getElementById('course-sidebar')?.classList.remove('open');
        document.getElementById('sidebar-backdrop')?.classList.remove('open');
      });
    });
  }

  filterSidebarLessons(query) {
    const q = query.toLowerCase().trim();
    document.querySelectorAll('.lesson-nav-link').forEach(link => {
      const text = link.textContent.toLowerCase();
      const parentGroup = link.closest('.sidebar-category-group');
      const matches = !q || text.includes(q);
      link.style.display = matches ? 'flex' : 'none';
    });

    // Hide empty category titles
    document.querySelectorAll('.sidebar-category-group').forEach(group => {
      const visibleLinks = group.querySelectorAll('.lesson-nav-link:not([style*="display: none"])');
      group.style.display = visibleLinks.length > 0 ? 'block' : 'none';
    });
  }

  updateSidebarActiveState() {
    const activeLessonId = stateManager.get().activeLessonId;
    const completed = stateManager.get().completedLessons || [];
    const totalLessons = LESSONS.length;
    const completedCount = completed.length;
    const coursePct = totalLessons > 0 ? Math.round((completedCount / totalLessons) * 100) : 0;
    const levelInfo = stateManager.getLevel();

    // Update Sidebar Progress Card
    const lvlBadge = document.getElementById('sidebar-lvl-badge');
    const xpRatio = document.getElementById('sidebar-xp-ratio');
    const lvlFill = document.getElementById('sidebar-lvl-fill');
    const courseRatio = document.getElementById('sidebar-course-ratio');

    if (lvlBadge) lvlBadge.textContent = `Lvl ${levelInfo.level}`;
    if (xpRatio) xpRatio.textContent = `${levelInfo.currentXP} / ${levelInfo.nextLevelXP} XP`;
    if (lvlFill) lvlFill.style.width = `${levelInfo.progressPercent}%`;
    if (courseRatio) courseRatio.textContent = `${completedCount}/${totalLessons} (${coursePct}%)`;

    // Update Category Mini Progress Meters
    CATEGORIES.forEach(cat => {
      const catLessons = LESSONS.filter(l => l.category === cat.id);
      if (catLessons.length === 0) return;

      const catDone = catLessons.filter(l => completed.includes(l.id)).length;
      const isCatDone = catDone === catLessons.length;
      const catPct = Math.round((catDone / catLessons.length) * 100);

      const badgeEl = document.getElementById(`cat-badge-${cat.id}`);
      const miniFill = document.getElementById(`cat-mini-${cat.id}`);

      if (badgeEl) {
        badgeEl.className = `cat-progress-badge ${isCatDone ? 'done' : ''}`;
        badgeEl.textContent = `${isCatDone ? '✓ ' : ''}${catDone}/${catLessons.length}`;
      }
      if (miniFill) {
        miniFill.style.width = `${catPct}%`;
      }
    });

    // Update active nav item & checkmarks
    document.querySelectorAll('.lesson-nav-link').forEach(link => {
      const id = link.getAttribute('data-lesson-id');
      const isActive = id === activeLessonId;
      link.classList.toggle('active', isActive);

      let check = link.querySelector('.lesson-check-icon');
      if (completed.includes(id)) {
        if (!check) {
          const span = document.createElement('span');
          span.className = 'lesson-check-icon';
          span.textContent = '✓';
          link.appendChild(span);
        }
      } else if (check) {
        check.remove();
      }
    });
  }

  updateMilestoneCard() {
    const card = document.getElementById('lesson-milestone-card');
    if (!card) return;

    const activeLessonId = stateManager.get().activeLessonId;
    const completed = stateManager.get().completedLessons || [];
    const isDone = completed.includes(activeLessonId);
    const lesson = LESSONS.find(l => l.id === activeLessonId);
    if (!lesson) return;

    card.className = `lesson-milestone-card ${isDone ? 'is-completed' : ''}`;
    const statusIcon = card.querySelector('.milestone-status-icon');
    const titleEl = card.querySelector('.milestone-title');
    const descEl = card.querySelector('.milestone-subtitle');
    const btn = card.querySelector('#btn-toggle-lesson-complete');

    if (statusIcon) statusIcon.textContent = isDone ? '🎉' : '🎯';
    if (titleEl) titleEl.textContent = isDone ? 'Lesson Completed!' : 'Lesson Progress & Mastery';
    if (descEl) descEl.textContent = isDone ? 'Great job mastering this concept. Ready for the next lesson!' : 'Read through and test the concepts above to complete this lesson.';
    if (btn) {
      btn.className = `btn-toggle-milestone ${isDone ? 'done' : ''}`;
      btn.innerHTML = isDone ? '✓ Completed' : '✨ Mark Lesson as Completed';
    }
  }

  switchView(viewName) {
    stateManager.update({ currentView: viewName });
    this.setupView(viewName);
  }

  setupView(viewName) {
    // Update active nav buttons
    document.querySelectorAll('.nav-tab-btn').forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-view') === viewName);
    });
    document.querySelectorAll('.mobile-nav-item').forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-view') === viewName);
    });

    // Show/hide sidebar only on tutorial view
    const sidebar = document.getElementById('course-sidebar');
    const toggleBtn = document.getElementById('btn-toggle-sidebar');
    const mainViewport = document.getElementById('main-viewport');

    if (viewName === 'learn') {
      if (sidebar) sidebar.style.display = '';
      if (toggleBtn) toggleBtn.style.display = '';
    } else {
      if (sidebar) sidebar.style.display = 'none';
      if (toggleBtn) toggleBtn.style.display = 'none';
    }

    const contentArea = document.getElementById('main-content-view');
    if (!contentArea) return;

    if (viewName === 'learn') {
      this.loadLesson(stateManager.get().activeLessonId || 'js-intro');
    } else if (viewName === 'playground') {
      this.renderStandalonePlayground(contentArea);
    } else if (viewName === 'challenges') {
      challengeRunner.render(contentArea);
    } else if (viewName === 'exam') {
      quizEngine.initExam(contentArea);
    } else if (viewName === 'reference') {
      referenceView.render(contentArea, (sampleCode) => {
        this.switchView('playground');
        setTimeout(() => {
          if (this.standaloneEditorInstance) {
            this.standaloneEditorInstance.setCode(sampleCode);
            this.standaloneEditorInstance.executeCode();
          }
        }, 100);
      });
    }

    // Scroll top
    if (mainViewport) mainViewport.scrollTop = 0;
  }

  loadLesson(lessonId) {
    stateManager.update({ activeLessonId: lessonId, currentView: 'learn' });
    this.updateSidebarActiveState();

    const lesson = LESSONS.find(l => l.id === lessonId) || LESSONS[0];
    const contentArea = document.getElementById('main-content-view');
    if (!contentArea) return;

    const currentIndex = LESSONS.findIndex(l => l.id === lesson.id);
    const prevLesson = currentIndex > 0 ? LESSONS[currentIndex - 1] : null;
    const nextLesson = currentIndex < LESSONS.length - 1 ? LESSONS[currentIndex + 1] : null;
    const isBookmarked = stateManager.get().bookmarks.includes(lesson.id);
    const completed = stateManager.get().completedLessons || [];
    const isDone = completed.includes(lesson.id);

    // Reset reading scroll bar
    const readingBar = document.getElementById('reading-progress-fill');
    if (readingBar) {
      readingBar.style.width = '0%';
      readingBar.classList.remove('reading-finished');
    }

    contentArea.innerHTML = `
      <div class="content-inner-container">
        <!-- Top Lesson Meta -->
        <div class="lesson-meta-bar">
          <div class="meta-tags-group">
            <span class="tag-badge">${lesson.readTime}</span>
            <span class="tag-badge tag-xp">+${lesson.xp} XP</span>
          </div>
          <div class="lesson-actions-group">
            <button id="btn-bookmark-lesson" class="btn-bookmark ${isBookmarked ? 'bookmarked' : ''}">
              <svg width="15" height="15" viewBox="0 0 24 24" fill="${isBookmarked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>
              <span>${isBookmarked ? 'Saved' : 'Bookmark'}</span>
            </button>
          </div>
        </div>

        <h1 class="lesson-title">${lesson.title}</h1>
        <p class="lesson-summary-lead">${lesson.summary}</p>

        <!-- Main Article Content -->
        <article class="lesson-article-body">
          ${lesson.contentHtml}
        </article>

        <!-- Dedicated Hands-On Interactive Playground -->
        <div id="in-lesson-interactive-playground-slot"></div>

        <!-- SoloLearn Interactive Checkpoint Quiz -->
        <div class="checkpoint-container" id="in-lesson-checkpoint-container"></div>

        <!-- Interactive Milestone Progress Card -->
        <div class="lesson-milestone-card ${isDone ? 'is-completed' : ''}" id="lesson-milestone-card">
          <div class="milestone-top-row">
            <div class="milestone-title-group">
              <div class="milestone-status-icon">${isDone ? '🎉' : '🎯'}</div>
              <div>
                <h3 class="milestone-title">${isDone ? 'Lesson Completed!' : 'Lesson Progress & Mastery'}</h3>
                <p class="milestone-subtitle">${isDone ? 'Great job mastering this concept. Ready for the next lesson!' : 'Read through and test the concepts above to complete this lesson.'}</p>
              </div>
            </div>
            <div class="milestone-xp-badge">
              <span>⚡</span> <span>+${lesson.xp} XP</span>
            </div>
          </div>

          <button class="btn-toggle-milestone ${isDone ? 'done' : ''}" id="btn-toggle-lesson-complete">
            <span>${isDone ? '✓ Completed' : '✨ Mark Lesson as Completed'}</span>
          </button>
        </div>

        <!-- Bottom Lesson Navigation -->
        <div class="lesson-bottom-nav">
          ${prevLesson ? `
            <button class="btn-nav-prev" data-target="${prevLesson.id}">
              &laquo; ${prevLesson.title}
            </button>
          ` : '<div></div>'}

          ${nextLesson ? `
            <button class="btn-nav-next" data-target="${nextLesson.id}">
              Next: ${nextLesson.title} &raquo;
            </button>
          ` : `
            <button class="btn-nav-next" id="btn-goto-exam">
              Take Certification Exam &raquo;
            </button>
          `}
        </div>
      </div>
    `;

    // Mount Interactive Lesson Playground
    interactivePlaygrounds.render(
      document.getElementById('in-lesson-interactive-playground-slot'),
      lesson.id
    );

    // Mount Checkpoint
    if (lesson.checkpoint) {
      quizEngine.renderCheckpoint(
        document.getElementById('in-lesson-checkpoint-container'),
        lesson.checkpoint,
        lesson.id
      );
    }

    // Bind Bookmark
    document.getElementById('btn-bookmark-lesson')?.addEventListener('click', () => {
      stateManager.toggleBookmark(lesson.id);
      this.loadLesson(lesson.id);
    });

    // Bind Milestone Completion Toggle
    const milestoneBtn = document.getElementById('btn-toggle-lesson-complete');
    milestoneBtn?.addEventListener('click', () => {
      const isAlreadyDone = (stateManager.get().completedLessons || []).includes(lesson.id);
      if (!isAlreadyDone) {
        stateManager.completeLesson(lesson.id, lesson.xp);
        this.triggerCelebration(milestoneBtn, lesson.xp, 'Lesson Mastered! 🌟', `+${lesson.xp} XP awarded for completing "${lesson.title}"`);
      } else {
        sound.playPop();
      }
    });

    // Navigation buttons
    contentArea.querySelectorAll('.btn-nav-prev, .btn-nav-next').forEach(btn => {
      btn.addEventListener('click', () => {
        const target = btn.getAttribute('data-target');
        if (target) {
          this.loadLesson(target);
          const vp = document.getElementById('main-viewport');
          if (vp) vp.scrollTop = 0;
        }
      });
    });

    document.getElementById('btn-goto-exam')?.addEventListener('click', () => {
      this.switchView('exam');
    });
  }

  triggerCelebration(originEl, xpAmount, title = 'Milestone Reached! 🚀', desc = '') {
    sound.playSuccess();

    // 1. Spawn floating XP text from origin element or center
    const rect = originEl?.getBoundingClientRect();
    const startX = rect ? rect.left + rect.width / 2 : window.innerWidth / 2;
    const startY = rect ? rect.top : window.innerHeight / 2;

    const portal = document.getElementById('progress-celebration-portal');
    if (!portal) return;

    const xpText = document.createElement('div');
    xpText.className = 'xp-flying-text';
    xpText.textContent = `+${xpAmount} XP ⚡`;
    xpText.style.left = `${startX}px`;
    xpText.style.top = `${startY}px`;
    portal.appendChild(xpText);

    setTimeout(() => xpText.remove(), 1500);

    // 2. Spawn burst of 24 colorful confetti particles
    const colors = ['#04AA6D', '#10b981', '#38bdf8', '#f59e0b', '#ec4899', '#8b5cf6', '#ffffff'];
    for (let i = 0; i < 24; i++) {
      const particle = document.createElement('div');
      particle.className = 'confetti-particle';
      const angle = (Math.PI * 2 * i) / 24;
      const distance = 80 + Math.random() * 120;
      const tx = Math.cos(angle) * distance;
      const ty = Math.sin(angle) * distance - 40;
      const rot = Math.random() * 720 - 360;

      particle.style.left = `${startX}px`;
      particle.style.top = `${startY}px`;
      particle.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
      particle.style.setProperty('--tx', `${tx}px`);
      particle.style.setProperty('--ty', `${ty}px`);
      particle.style.setProperty('--rot', `${rot}deg`);

      portal.appendChild(particle);
      setTimeout(() => particle.remove(), 1800);
    }

    // 3. Spawn floating toast banner
    this.showToast(title, desc || `Gained +${xpAmount} XP to your learning profile.`);
  }

  triggerLevelUpCelebration(newLevel) {
    sound.playFanfare();
    this.showToast(`🎉 Level Up! You reached Level ${newLevel}!`, 'Keep up the momentum to unlock higher mastery and certification.');
  }

  showToast(title, desc) {
    const existing = document.querySelector('.progress-toast-banner');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = 'progress-toast-banner';
    toast.innerHTML = `
      <div class="toast-icon-circle">⚡</div>
      <div>
        <div class="toast-content-title">${title}</div>
        <div class="toast-content-desc">${desc}</div>
      </div>
    `;

    document.body.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('toast-fadeout');
      setTimeout(() => toast.remove(), 400);
    }, 3500);
  }

  renderStandalonePlayground(container) {
    container.innerHTML = `
      <div class="content-inner-container">
        <div style="margin-bottom: 20px;">
          <h1 style="font-size:2rem; font-weight:800; margin-bottom:8px;">Interactive JavaScript Code Playground</h1>
          <p style="color:var(--text-secondary);">Write, test, and run full-featured JavaScript with live DOM rendering and integrated debugging console.</p>
        </div>
        <div id="standalone-editor-slot"></div>
      </div>
    `;

    this.standaloneEditorInstance = new CodeEditor('standalone-editor-slot', {
      defaultCode: `// Welcome to the Full JavaScript Sandbox!
// Try writing algorithms, DOM widgets, or async fetch requests here.

function generateFibonacci(n) {
  const sequence = [0, 1];
  for (let i = 2; i < n; i++) {
    sequence.push(sequence[i - 1] + sequence[i - 2]);
  }
  return sequence;
}

console.log("Fibonacci Series (first 10):", generateFibonacci(10));

// Interactive object manipulation
const systemStats = {
  runtime: "V8 JavaScript Engine",
  timestamp: new Date().toISOString(),
  features: ["Async/Await", "ESNext Modules", "DOM Canvas API"]
};

console.table(systemStats);
`
    });
  }
}

export const uiController = new UIController();

