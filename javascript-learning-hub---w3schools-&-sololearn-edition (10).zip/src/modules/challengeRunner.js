// SoloLearn-style Coding Challenge & Automated Test Suite Runner
import { CODING_CHALLENGES } from '../data/challenges.js';
import { stateManager } from './state.js';
import { sound } from './audio.js';

export class ChallengeRunner {
  constructor() {
    this.activeChallenge = CODING_CHALLENGES[0];
  }

  render(container) {
    this.container = container;
    const completedList = stateManager.get().completedChallenges || [];

    container.innerHTML = `
      <div class="challenges-layout">
        <!-- Left Sidebar: Challenge List -->
        <div class="challenges-sidebar">
          <div class="challenges-sidebar-header">
            <h3>JavaScript Code Bites</h3>
            <span class="challenges-count">${completedList.length}/${CODING_CHALLENGES.length} Solved</span>
          </div>

          <div class="challenges-list">
            ${CODING_CHALLENGES.map(ch => {
              const isSolved = completedList.includes(ch.id);
              const isActive = this.activeChallenge.id === ch.id;
              return `
                <div class="challenge-nav-card ${isActive ? 'active' : ''} ${isSolved ? 'solved' : ''}" data-id="${ch.id}">
                  <div class="ch-nav-top">
                    <span class="ch-nav-title">${ch.title}</span>
                    ${isSolved ? '<span class="ch-solved-badge">✓</span>' : ''}
                  </div>
                  <div class="ch-nav-meta">
                    <span class="ch-diff-badge diff-${ch.difficulty.toLowerCase()}">${ch.difficulty}</span>
                    <span class="ch-xp-tag">+${ch.xp} XP</span>
                  </div>
                </div>
              `;
            }).join('')}
          </div>
        </div>

        <!-- Right Pane: Active Problem Workspace -->
        <div class="challenge-workspace" id="challenge-active-workspace">
          ${this.renderActiveProblemHtml()}
        </div>
      </div>
    `;

    this.bindEvents();
  }

  renderActiveProblemHtml() {
    const ch = this.activeChallenge;
    const isSolved = (stateManager.get().completedChallenges || []).includes(ch.id);

    return `
      <div class="ch-problem-view">
        <div class="ch-problem-header">
          <div class="ch-header-info">
            <span class="ch-diff-badge diff-${ch.difficulty.toLowerCase()}">${ch.difficulty}</span>
            <h2 class="ch-main-title">${ch.title}</h2>
          </div>
          <div class="ch-status-side">
            ${isSolved ? '<span class="ch-badge-completed">🎉 Challenge Completed</span>' : `<span class="ch-xp-reward">+${ch.xp} XP on Completion</span>`}
          </div>
        </div>

        <div class="ch-description-box">
          <p>${ch.description}</p>
        </div>

        <!-- Test cases preview -->
        <div class="ch-test-cases-preview">
          <h4>Sample Test Cases:</h4>
          <ul>
            ${ch.testCases.map(tc => `
              <li>Input: <code>${tc.input.join(', ')}</code> &rarr; Expected: <code>${tc.expected}</code></li>
            `).join('')}
          </ul>
        </div>

        <!-- Code Editor Area -->
        <div class="ch-editor-box">
          <div class="ch-editor-toolbar">
            <span>JavaScript Solution</span>
            <button id="btn-reset-ch-code" class="ch-tool-btn">Reset Code</button>
          </div>
          <textarea id="ch-code-input" class="ch-code-textarea" spellcheck="false">${this.escapeHtml(ch.starterCode)}</textarea>
        </div>

        <!-- Run & Results -->
        <div class="ch-actions-row">
          <button id="btn-run-tests" class="btn-run-tests">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <span>Run Tests & Submit</span>
          </button>
        </div>

        <!-- Test Results Output Container -->
        <div id="test-results-container" class="test-results-box" style="display: none;"></div>
      </div>
    `;
  }

  bindEvents() {
    // Select challenge from sidebar
    this.container.querySelectorAll('.challenge-nav-card').forEach(card => {
      card.addEventListener('click', () => {
        const id = card.getAttribute('data-id');
        const found = CODING_CHALLENGES.find(c => c.id === id);
        if (found) {
          this.activeChallenge = found;
          this.render(this.container);
        }
      });
    });

    // Reset code
    this.container.querySelector('#btn-reset-ch-code')?.addEventListener('click', () => {
      const textarea = this.container.querySelector('#ch-code-input');
      if (textarea) textarea.value = this.activeChallenge.starterCode;
    });

    // Run tests
    this.container.querySelector('#btn-run-tests')?.addEventListener('click', () => {
      this.runActiveChallengeTests();
    });
  }

  runActiveChallengeTests() {
    const textarea = this.container.querySelector('#ch-code-input');
    const resultsContainer = this.container.querySelector('#test-results-container');
    const userCode = textarea.value;

    resultsContainer.style.display = 'block';
    resultsContainer.innerHTML = '<div class="testing-spinner">Running test cases in sandbox...</div>';

    setTimeout(() => {
      let passedCount = 0;
      const totalTests = this.activeChallenge.testCases.length;
      const details = [];

      this.activeChallenge.testCases.forEach((tc, idx) => {
        try {
          // Construct isolated runner
          const fullScript = `
            ${userCode}
            return (${tc.testCall});
          `;
          const fn = new Function(fullScript);
          const actualVal = fn();
          const actualStr = JSON.stringify(actualVal);
          const expectedStr = tc.expected;

          // Comparison (loose / sanitized)
          const passed = String(actualStr).replace(/\s/g, '') === String(expectedStr).replace(/\s/g, '') ||
                         String(actualVal) === String(expectedStr);

          if (passed) passedCount++;

          details.push({
            index: idx + 1,
            input: tc.input.join(', '),
            expected: tc.expected,
            actual: actualStr !== undefined ? actualStr : String(actualVal),
            passed
          });
        } catch (err) {
          details.push({
            index: idx + 1,
            input: tc.input.join(', '),
            expected: tc.expected,
            actual: 'Error: ' + err.message,
            passed: false
          });
        }
      });

      const allPassed = passedCount === totalTests;

      if (allPassed) {
        sound.playSuccess();
        stateManager.completeChallenge(this.activeChallenge.id, this.activeChallenge.xp);
        window.dispatchEvent(new CustomEvent('milestone-completed', {
          detail: {
            xp: this.activeChallenge.xp,
            title: 'Challenge Conquered! 🏆',
            desc: `Earned +${this.activeChallenge.xp} XP for solving "${this.activeChallenge.title}"`
          }
        }));
      } else {
        sound.playError();
      }

      resultsContainer.innerHTML = `
        <div class="test-verdict-banner ${allPassed ? 'verdict-pass' : 'verdict-fail'}">
          <div class="verdict-title">
            ${allPassed ? '🎉 All Test Cases Passed!' : `⚠️ ${passedCount}/${totalTests} Tests Passed`}
          </div>
          <div class="verdict-sub">
            ${allPassed ? `Awarded +${this.activeChallenge.xp} XP to your profile!` : 'Some test cases failed. Check your logic and try again.'}
          </div>
        </div>

        <div class="test-cases-table">
          ${details.map(d => `
            <div class="test-row ${d.passed ? 'test-pass' : 'test-fail'}">
              <div class="test-row-header">
                <span class="test-status-tag">${d.passed ? '✓ PASSED' : '✗ FAILED'}</span>
                <span class="test-case-num">Test Case #${d.index}</span>
              </div>
              <div class="test-row-details">
                <div><strong>Input:</strong> <code>${this.escapeHtml(d.input)}</code></div>
                <div><strong>Expected:</strong> <code>${this.escapeHtml(d.expected)}</code></div>
                <div><strong>Your Output:</strong> <code class="${d.passed ? 'out-pass' : 'out-fail'}">${this.escapeHtml(d.actual)}</code></div>
              </div>
            </div>
          `).join('')}
        </div>
      `;

      // Update sidebar solved badges
      this.container.querySelectorAll('.challenge-nav-card').forEach(card => {
        if (card.getAttribute('data-id') === this.activeChallenge.id && allPassed) {
          card.classList.add('solved');
        }
      });
    }, 200);
  }

  escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
}

export const challengeRunner = new ChallengeRunner();
