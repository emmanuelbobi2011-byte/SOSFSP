// State Management & LocalStorage Persistence
const STORAGE_KEY = 'js_learning_hub_state_v1';

const DEFAULT_STATE = {
  xp: 120,
  streak: 3,
  lastActiveDate: new Date().toISOString().split('T')[0],
  completedLessons: ['js-intro'],
  completedCheckpoints: {},
  completedChallenges: [],
  examResults: null,
  userName: 'JavaScript Explorer',
  theme: 'dark',
  soundEnabled: true,
  currentView: 'learn', // 'learn' | 'playground' | 'challenges' | 'exam' | 'reference'
  activeLessonId: 'js-intro',
  bookmarks: []
};

class StateManager {
  constructor() {
    this.state = this.load();
    this.listeners = [];
    this.checkStreak();
  }

  load() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return { ...DEFAULT_STATE, ...JSON.parse(saved) };
      }
    } catch (e) {
      console.warn('Could not read state from localStorage', e);
    }
    return { ...DEFAULT_STATE };
  }

  save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(this.state));
    } catch (e) {
      console.warn('Could not write state to localStorage', e);
    }
    this.notify();
  }

  notify() {
    this.listeners.forEach(fn => fn(this.state));
  }

  subscribe(fn) {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter(l => l !== fn);
    };
  }

  get() {
    return this.state;
  }

  update(partial) {
    this.state = { ...this.state, ...partial };
    this.save();
  }

  addXP(points) {
    this.state.xp += points;
    this.save();
    return this.state.xp;
  }

  completeLesson(lessonId, xp = 20) {
    if (!this.state.completedLessons.includes(lessonId)) {
      this.state.completedLessons.push(lessonId);
      this.addXP(xp);
    }
  }

  completeCheckpoint(lessonId, score = 10) {
    if (!this.state.completedCheckpoints[lessonId]) {
      this.state.completedCheckpoints[lessonId] = true;
      this.addXP(score);
    }
  }

  completeChallenge(challengeId, xp = 30) {
    if (!this.state.completedChallenges.includes(challengeId)) {
      this.state.completedChallenges.push(challengeId);
      this.addXP(xp);
    }
  }

  saveExamResult(result) {
    this.state.examResults = result;
    if (result.passed) {
      this.addXP(150);
    }
    this.save();
  }

  toggleBookmark(lessonId) {
    if (this.state.bookmarks.includes(lessonId)) {
      this.state.bookmarks = this.state.bookmarks.filter(id => id !== lessonId);
    } else {
      this.state.bookmarks.push(lessonId);
    }
    this.save();
  }

  checkStreak() {
    const today = new Date().toISOString().split('T')[0];
    const last = this.state.lastActiveDate;
    
    if (last !== today) {
      const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
      if (last === yesterday) {
        this.state.streak += 1;
      } else {
        // missed a day, reset or start fresh
        this.state.streak = 1;
      }
      this.state.lastActiveDate = today;
      this.save();
    }
  }

  getLevel() {
    const xp = this.state.xp;
    // Level formula: Level = floor(sqrt(XP / 50)) + 1
    const level = Math.floor(Math.sqrt(xp / 40)) + 1;
    const nextLevelXP = Math.pow(level, 2) * 40;
    const prevLevelXP = Math.pow(level - 1, 2) * 40;
    const progressPercent = Math.min(100, Math.round(((xp - prevLevelXP) / (nextLevelXP - prevLevelXP)) * 100));

    return {
      level,
      progressPercent,
      currentXP: xp,
      nextLevelXP
    };
  }
}

export const stateManager = new StateManager();
