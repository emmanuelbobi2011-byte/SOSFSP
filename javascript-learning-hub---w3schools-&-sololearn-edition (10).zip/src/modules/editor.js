// Kid-Friendly, Animated, Modern Code Editor with Auto-Completion & HTML + CSS + JS Live App Studio
import { sound } from './audio.js';

export const STARTER_TEMPLATES = {
  'bob-robot': {
    title: '🤖 Bob the Animated Robot (HTML + CSS + JS)',
    mode: 'html-js',
    html: `<div class="robot-stage">
  <div id="bob" class="robot-avatar">
    <div class="robot-antenna">
      <div class="antenna-bulb" id="bob-antenna"></div>
    </div>
    <div class="robot-head">
      <div class="robot-eyes">
        <div class="eye left-eye"></div>
        <div class="eye right-eye"></div>
      </div>
      <div class="robot-mouth" id="bob-mouth">_</div>
    </div>
    <div class="robot-body">
      <div class="robot-heart" id="bob-heart">💙</div>
    </div>
  </div>
  
  <div id="bob-speech" class="speech-bubble">Hi! I am Bob the Robot! 🚀</div>
  
  <div class="button-controls">
    <button id="btn-dance" class="magic-btn btn-green">🕺 Dance</button>
    <button id="btn-speak" class="magic-btn btn-blue">💬 Talk</button>
    <button id="btn-color" class="magic-btn btn-purple">🎨 Color Shift</button>
    <button id="btn-spin" class="magic-btn btn-amber">🌀 Super Spin</button>
  </div>
</div>`,
    css: `/* Custom CSS for Robot Bob */
.robot-stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  text-align: center;
  padding: 10px;
}

.robot-avatar {
  width: 120px;
  height: 140px;
  background-color: #161b22;
  border: 3px solid #10b981;
  border-radius: 24px;
  padding: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  box-shadow: 0 0 25px rgba(16, 185, 129, 0.35);
  position: relative;
  transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.robot-avatar:hover {
  transform: scale(1.08) translateY(-4px);
  box-shadow: 0 0 35px rgba(16, 185, 129, 0.6);
}

.robot-antenna {
  width: 4px;
  height: 16px;
  background-color: #30363d;
  position: absolute;
  top: -16px;
  border-radius: 2px;
}

.antenna-bulb {
  width: 10px;
  height: 10px;
  background-color: #f59e0b;
  border-radius: 50%;
  position: absolute;
  top: -6px;
  left: -3px;
  transition: all 0.3s;
}

.antenna-glow {
  background-color: #38bdf8 !important;
  box-shadow: 0 0 15px #38bdf8 !important;
  animation: antenna-pulse 0.5s infinite alternate;
}

@keyframes antenna-pulse {
  from { transform: scale(1); }
  to { transform: scale(1.4); }
}

.robot-head {
  width: 100%;
  background-color: #0d1117;
  border-radius: 12px;
  padding: 8px;
  border: 1px solid #30363d;
}

.robot-eyes {
  display: flex;
  justify-content: space-around;
  margin-bottom: 4px;
}

.eye {
  width: 14px;
  height: 14px;
  background-color: #38bdf8;
  border-radius: 50%;
  box-shadow: 0 0 8px #38bdf8;
  animation: eye-blink 3s infinite;
}

@keyframes eye-blink {
  0%, 96%, 100% { transform: scaleY(1); }
  98% { transform: scaleY(0.1); }
}

.robot-mouth {
  font-family: monospace;
  font-weight: 900;
  color: #10b981;
  font-size: 14px;
}

.robot-heart {
  font-size: 20px;
  animation: heart-beat 1.2s infinite ease-in-out;
}

@keyframes heart-beat {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.2); }
}

.dancing {
  animation: bob-dance 0.6s infinite ease-in-out alternate;
}

@keyframes bob-dance {
  0% { transform: rotate(-8deg) translateY(0); }
  50% { transform: rotate(0) translateY(-12px); }
  100% { transform: rotate(8deg) translateY(0); }
}

.spinning {
  animation: bob-spin 0.8s cubic-bezier(0.34, 1.56, 0.64, 1);
}

@keyframes bob-spin {
  0% { transform: rotate(0deg) scale(1); }
  50% { transform: rotate(180deg) scale(1.3); }
  100% { transform: rotate(360deg) scale(1); }
}

.speech-bubble {
  background-color: #161b22;
  border: 2px solid #30363d;
  padding: 10px 18px;
  border-radius: 16px;
  font-size: 0.95rem;
  font-weight: 600;
  color: #f0f6fc;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  max-width: 320px;
  animation: bubble-pop 0.3s ease-out;
}

@keyframes bubble-pop {
  from { transform: scale(0.8); opacity: 0; }
  to { transform: scale(1); opacity: 1; }
}`,
    js: `// JavaScript brings Bob to life!
const bob = document.getElementById("bob");
const speech = document.getElementById("bob-speech");
const heart = document.getElementById("bob-heart");
const mouth = document.getElementById("bob-mouth");
const antenna = document.getElementById("bob-antenna");

// 1. Dance Button
document.getElementById("btn-dance").onclick = () => {
  bob.classList.toggle("dancing");
  speech.textContent = "Look at my cool robot moves! 🎵";
  mouth.textContent = "O";
  antenna.classList.toggle("antenna-glow");
  console.log("Bob is dancing!");
};

// 2. Speak Button
const robotQuotes = [
  "Beep Boop! I love HTML, CSS and JS! 🤖",
  "HTML is my body, CSS is my style, JS is my brain! 🧠",
  "You are an awesome coder! ⭐",
  "Let's build creative web experiences! 🎮"
];
document.getElementById("btn-speak").onclick = () => {
  const randomQuote = robotQuotes[Math.floor(Math.random() * robotQuotes.length)];
  speech.textContent = randomQuote;
  mouth.textContent = "D";
  heart.textContent = "💖";
  console.log("Bob said:", randomQuote);
};

// 3. Color Shift Button
const colors = ["#10b981", "#38bdf8", "#ec4899", "#8b5cf6", "#f59e0b", "#06b6d4"];
document.getElementById("btn-color").onclick = () => {
  const randomColor = colors[Math.floor(Math.random() * colors.length)];
  bob.style.borderColor = randomColor;
  bob.style.boxShadow = "0 0 30px " + randomColor;
  speech.textContent = "My CSS border is glowing in " + randomColor + "! ✨";
  console.log("Shifted Bob color to:", randomColor);
};

// 4. Spin Button
document.getElementById("btn-spin").onclick = () => {
  bob.classList.remove("spinning");
  void bob.offsetWidth; // Trigger reflow
  bob.classList.add("spinning");
  speech.textContent = "Whooooaaaa! Super speed! 🌀";
};`
  },

  'neon-card': {
    title: '🎨 Neon Glow Card & Animated Buttons (HTML + CSS + JS)',
    mode: 'html-js',
    html: `<div class="neon-showcase">
  <div class="cyber-card" id="card">
    <div class="card-badge">✨ CSS Master</div>
    <h2 class="card-title">Cyberpunk Studio</h2>
    <p class="card-desc">CSS gives you superpowers to create breathtaking glows, gradients, and animated buttons.</p>
    
    <div class="stats-row">
      <div class="stat-pill">⚡ 99 FPS</div>
      <div class="stat-pill">🌟 100 XP</div>
      <div class="stat-pill">🎨 4K Glow</div>
    </div>

    <div class="actions-row">
      <button id="btn-glow-cyan" class="glow-btn cyan">Cyan Glow</button>
      <button id="btn-glow-pink" class="glow-btn pink">Neon Pink</button>
      <button id="btn-glow-amber" class="glow-btn amber">Amber Fire</button>
    </div>
  </div>
</div>`,
    css: `/* Cyberpunk Neon Theme in Pure CSS */
.neon-showcase {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 16px;
  width: 100%;
}

.cyber-card {
  background: linear-gradient(145deg, #161b22, #0d1117);
  border: 2px solid #38bdf8;
  border-radius: 20px;
  padding: 24px;
  max-width: 380px;
  text-align: center;
  box-shadow: 0 0 30px rgba(56, 189, 248, 0.35);
  transition: all 0.4s cubic-bezier(0.34, 1.56, 0.64, 1);
}

.cyber-card:hover {
  transform: translateY(-6px) scale(1.02);
}

.card-badge {
  display: inline-block;
  background: rgba(56, 189, 248, 0.15);
  color: #38bdf8;
  border: 1px solid #38bdf8;
  padding: 4px 12px;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 700;
  margin-bottom: 12px;
}

.card-title {
  font-size: 1.5rem;
  font-weight: 800;
  color: #ffffff;
  margin-bottom: 8px;
  letter-spacing: -0.5px;
}

.card-desc {
  color: #8b949e;
  font-size: 0.9rem;
  line-height: 1.5;
  margin-bottom: 16px;
}

.stats-row {
  display: flex;
  justify-content: center;
  gap: 8px;
  margin-bottom: 20px;
}

.stat-pill {
  background: #21262d;
  border: 1px solid #30363d;
  color: #f0f6fc;
  padding: 6px 12px;
  border-radius: 10px;
  font-size: 0.8rem;
  font-weight: 600;
}

.actions-row {
  display: flex;
  gap: 8px;
  justify-content: center;
}

.glow-btn {
  border: none;
  padding: 8px 14px;
  border-radius: 10px;
  font-weight: 700;
  font-size: 0.85rem;
  color: #ffffff;
  cursor: pointer;
  transition: all 0.2s;
}

.glow-btn.cyan {
  background: #0284c7;
  box-shadow: 0 0 15px rgba(56, 189, 248, 0.5);
}
.glow-btn.pink {
  background: #db2777;
  box-shadow: 0 0 15px rgba(236, 72, 153, 0.5);
}
.glow-btn.amber {
  background: #d97706;
  box-shadow: 0 0 15px rgba(245, 158, 11, 0.5);
}

.glow-btn:hover {
  transform: translateY(-2px) scale(1.05);
}
.glow-btn:active {
  transform: scale(0.95);
}`,
    js: `// Dynamically change card glow colors with JS!
const card = document.getElementById("card");

document.getElementById("btn-glow-cyan").onclick = () => {
  card.style.borderColor = "#38bdf8";
  card.style.boxShadow = "0 0 40px rgba(56, 189, 248, 0.6)";
  console.log("Cyan neon activated!");
};

document.getElementById("btn-glow-pink").onclick = () => {
  card.style.borderColor = "#ec4899";
  card.style.boxShadow = "0 0 40px rgba(236, 72, 153, 0.6)";
  console.log("Pink neon activated!");
};

document.getElementById("btn-glow-amber").onclick = () => {
  card.style.borderColor = "#f59e0b";
  card.style.boxShadow = "0 0 40px rgba(245, 158, 11, 0.6)";
  console.log("Amber fire neon activated!");
};`
  },

  'flexbox-studio': {
    title: '📦 Flexbox Layout Lab (HTML + CSS)',
    mode: 'html-js',
    html: `<div class="flex-playground">
  <div class="flex-header">
    <h2>Flexbox Distribution Lab</h2>
    <p>Try editing the CSS properties in the CSS tab to see instant layout magic!</p>
  </div>
  
  <div class="flex-box-container">
    <div class="flex-box item-1">Item 1 🚀</div>
    <div class="flex-box item-2">Item 2 💎</div>
    <div class="flex-box item-3">Item 3 ⚡</div>
    <div class="flex-box item-4">Item 4 🌟</div>
  </div>
</div>`,
    css: `/* Flexbox Layout Configuration */
.flex-playground {
  width: 100%;
  max-width: 500px;
  text-align: center;
}

.flex-header h2 {
  color: #10b981;
  margin-bottom: 4px;
}
.flex-header p {
  color: #8b949e;
  font-size: 0.9rem;
  margin-bottom: 16px;
}

/* THE MAGIC FLEX CONTAINER */
.flex-box-container {
  display: flex;
  flex-direction: row;           /* row | column | row-reverse */
  justify-content: space-between;/* flex-start | center | space-between | space-evenly */
  align-items: center;           /* stretch | center | flex-start | flex-end */
  gap: 12px;
  flex-wrap: wrap;
  
  background-color: #161b22;
  border: 2px dashed #30363d;
  border-radius: 16px;
  padding: 20px;
  min-height: 180px;
}

.flex-box {
  padding: 16px 20px;
  border-radius: 12px;
  font-weight: 700;
  color: #ffffff;
  box-shadow: 0 4px 12px rgba(0,0,0,0.3);
  transition: transform 0.2s ease;
}

.flex-box:hover {
  transform: translateY(-4px) scale(1.05);
}

.item-1 { background: linear-gradient(135deg, #10b981, #059669); }
.item-2 { background: linear-gradient(135deg, #38bdf8, #0284c7); }
.item-3 { background: linear-gradient(135deg, #a855f7, #7e22ce); }
.item-4 { background: linear-gradient(135deg, #f59e0b, #d97706); }`,
    js: `console.log("Flexbox loaded! Change justify-content or flex-direction in the CSS tab to explore.");`
  },

  'magic-bulb': {
    title: '💡 Magic Light Bulb & Switch (HTML + CSS + JS)',
    mode: 'html-js',
    html: `<div class="bulb-stage" id="stage">
  <div class="lamp-fixture">
    <div class="lamp-cord"></div>
    <div id="bulb" class="bulb-glass">💡</div>
    <div id="light-rays" class="light-rays"></div>
  </div>
  
  <h2 id="room-status">The Room is Dark 🌙</h2>
  
  <button id="switch-btn" class="switch-toggle-btn">
    <span class="switch-knob"></span>
    <span id="switch-label">Flip Switch ON</span>
  </button>
</div>`,
    css: `/* Light Bulb Stage & Lighting FX */
.bulb-stage {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 16px;
  padding: 20px;
  border-radius: 16px;
  background-color: #0d1117;
  transition: all 0.5s ease;
  width: 100%;
  max-width: 400px;
}

.stage-day {
  background-color: #1e293b;
  box-shadow: 0 0 50px rgba(251, 191, 36, 0.2);
}

.bulb-glass {
  font-size: 4rem;
  filter: grayscale(100%) opacity(30%);
  transition: all 0.3s;
  position: relative;
  z-index: 2;
}

.bulb-lit {
  filter: grayscale(0%) opacity(100%) drop-shadow(0 0 35px #f59e0b) scale(1.15);
}

.light-rays {
  width: 140px;
  height: 140px;
  position: absolute;
  top: -20px;
  left: -20px;
  border-radius: 50%;
  background: radial-gradient(circle, rgba(251, 191, 36, 0.4) 0%, rgba(251, 191, 36, 0) 70%);
  opacity: 0;
  transition: all 0.3s;
  pointer-events: none;
}

.rays-active { opacity: 1; animation: rays-pulse 2s infinite ease-in-out; }
@keyframes rays-pulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.2); }
}

.switch-toggle-btn {
  background-color: #21262d;
  border: 2px solid #30363d;
  color: #f0f6fc;
  padding: 10px 20px;
  border-radius: 30px;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  gap: 10px;
  transition: all 0.2s;
}

.switch-knob {
  width: 18px;
  height: 18px;
  border-radius: 50%;
  background-color: #ef4444;
  transition: all 0.2s;
}

.switch-active {
  border-color: #10b981;
  background-color: rgba(16, 185, 129, 0.2);
}

.switch-active .switch-knob {
  background-color: #10b981;
  transform: scale(1.2);
  box-shadow: 0 0 10px #10b981;
}`,
    js: `// Interactive Light Switch Logic
const bulb = document.getElementById("bulb");
const rays = document.getElementById("light-rays");
const statusText = document.getElementById("room-status");
const switchBtn = document.getElementById("switch-btn");
const stage = document.getElementById("stage");

let isOn = false;

switchBtn.onclick = () => {
  isOn = !isOn;
  
  if (isOn) {
    bulb.classList.add("bulb-lit");
    rays.classList.add("rays-active");
    stage.classList.add("stage-day");
    statusText.textContent = "The Room is Bright! ☀️";
    switchBtn.classList.add("switch-active");
    document.getElementById("switch-label").textContent = "Flip Switch OFF";
    console.log("💡 Light bulb turned ON!");
  } else {
    bulb.classList.remove("bulb-lit");
    rays.classList.remove("rays-active");
    stage.classList.remove("stage-day");
    statusText.textContent = "The Room is Dark 🌙";
    switchBtn.classList.remove("switch-active");
    document.getElementById("switch-label").textContent = "Flip Switch ON";
    console.log("🌑 Light bulb turned OFF!");
  }
};`
  },

  'coin-clicker': {
    title: '🎮 Coin Clicker Game (HTML + CSS + JS)',
    mode: 'html-js',
    html: `<div class="clicker-game-box">
  <div class="score-board">
    <h3>Coins: <span id="coin-count" class="gold-text">0</span> 🪙</h3>
    <p>Multiplier: <span id="multiplier-display">1x</span></p>
  </div>
  
  <div class="coin-target-area">
    <div id="big-coin" class="big-coin-btn">🪙</div>
  </div>
  
  <div class="upgrades-shelf">
    <button id="btn-upgrade" class="magic-btn btn-amber">⚡ Upgrade Clicker (Cost: 10 Coins)</button>
    <button id="btn-autoclick" class="magic-btn btn-purple">🤖 Hire Mini-Bot (Cost: 25 Coins)</button>
  </div>
</div>`,
    css: `/* Coin Clicker Styling */
.clicker-game-box {
  text-align: center;
  padding: 16px;
}
.gold-text { color: #f59e0b; font-weight: 900; }

.big-coin-btn {
  font-size: 5rem;
  cursor: pointer;
  user-select: none;
  display: inline-block;
  margin: 14px 0;
  transition: transform 0.1s;
}
.big-coin-btn:hover { transform: scale(1.1); }
.big-coin-btn:active { transform: scale(0.9); }

.coin-pop { animation: pop-bounce 0.3s ease-out; }
@keyframes pop-bounce {
  0% { transform: scale(1); }
  50% { transform: scale(1.35) rotate(15deg); }
  100% { transform: scale(1); }
}

.upgrades-shelf {
  display: flex;
  flex-direction: column;
  gap: 8px;
  margin-top: 10px;
}`,
    js: `let coins = 0;
let perClick = 1;
let autoClickers = 0;

const coinCount = document.getElementById("coin-count");
const multDisplay = document.getElementById("multiplier-display");
const bigCoin = document.getElementById("big-coin");
const upgradeBtn = document.getElementById("btn-upgrade");
const autoBtn = document.getElementById("btn-autoclick");

// Click Big Coin
bigCoin.onclick = () => {
  coins += perClick;
  coinCount.textContent = coins;
  
  // Pop animation
  bigCoin.classList.remove("coin-pop");
  void bigCoin.offsetWidth;
  bigCoin.classList.add("coin-pop");
  console.log("Coin clicked! Total:", coins);
};

// Upgrade Clicker
upgradeBtn.onclick = () => {
  if (coins >= 10) {
    coins -= 10;
    perClick += 1;
    coinCount.textContent = coins;
    multDisplay.textContent = perClick + "x per click";
    console.log("Upgraded click power to:", perClick);
  } else {
    alert("You need at least 10 coins to upgrade!");
  }
};

// Auto Clicker Bot
autoBtn.onclick = () => {
  if (coins >= 25) {
    coins -= 25;
    autoClickers++;
    coinCount.textContent = coins;
    autoBtn.textContent = "🤖 Bots Active (" + autoClickers + ") - Cost: 25";
    console.log("Auto-bot hired!");
  } else {
    alert("You need 25 coins for an auto-clicker bot!");
  }
};

// Background Auto-Click Loop
setInterval(() => {
  if (autoClickers > 0) {
    coins += autoClickers;
    coinCount.textContent = coins;
  }
}, 1000);`
  },

  'pure-js-basics': {
    title: '⚡ Pure JavaScript Console Explorer',
    mode: 'pure-js',
    html: ``,
    css: ``,
    js: `// Welcome to Master JS Code Console!
console.log("🚀 Starting JavaScript Interactive Explorer...");

// 1. Working with Variables & Math
const playerName = "Alex";
let score = 100;
score += 50;

console.log("Player:", playerName);
console.log("Current Score:", score);

// 2. Arrays & Fun Transformations
const petSquad = ["🐶 Dog", "🐱 Cat", "🦜 Parrot", "🐰 Bunny"];
console.log("Squad count:", petSquad.length);

const excitedPets = petSquad.map(pet => pet + " says HI!");
console.table(excitedPets);

// 3. Functions
function giveReward(stars) {
  return "⭐".repeat(stars) + " Super Win!";
}

console.log("Reward:", giveReward(5));`
  }
};

// AUTO-COMPLETE SUGGESTIONS DATABASE (HTML, CSS & JS)
const AUTOCOMPLETE_DICTIONARY = [
  // CSS Selectors & Properties
  { text: 'display: flex;', snippet: 'display: flex;', desc: 'CSS Flexbox container', type: 'css' },
  { text: 'display: grid;', snippet: 'display: grid;', desc: 'CSS Grid container', type: 'css' },
  { text: 'justify-content: center;', snippet: 'justify-content: center;', desc: 'CSS Center horizontally', type: 'css' },
  { text: 'justify-content: space-between;', snippet: 'justify-content: space-between;', desc: 'CSS Distribute items with space between', type: 'css' },
  { text: 'align-items: center;', snippet: 'align-items: center;', desc: 'CSS Center vertically', type: 'css' },
  { text: 'gap: 16px;', snippet: 'gap: 16px;', desc: 'CSS Gutter space between items', type: 'css' },
  { text: 'border-radius: 16px;', snippet: 'border-radius: 16px;', desc: 'CSS Rounded corners', type: 'css' },
  { text: 'box-shadow: 0 0 25px rgba()', snippet: 'box-shadow: 0 0 25px rgba(56, 189, 248, 0.4);', desc: 'CSS Glowing drop shadow', type: 'css' },
  { text: 'background: linear-gradient()', snippet: 'background: linear-gradient(135deg, #10b981, #38bdf8);', desc: 'CSS Gradient background', type: 'css' },
  { text: 'transition: all 0.3s ease;', snippet: 'transition: all 0.3s cubic-bezier(0.34, 1.56, 0.64, 1);', desc: 'CSS Smooth animated transition', type: 'css' },
  { text: 'transform: scale() rotate()', snippet: 'transform: scale(1.05) translateY(-4px);', desc: 'CSS 2D transformation', type: 'css' },
  { text: '@keyframes animationName {}', snippet: '@keyframes pulse {\n  0%, 100% { transform: scale(1); }\n  50% { transform: scale(1.15); }\n}', desc: 'CSS Keyframe Animation Rule', type: 'css' },
  { text: 'animation: name 1s infinite;', snippet: 'animation: pulse 1.5s infinite ease-in-out;', desc: 'CSS Apply keyframe animation', type: 'css' },
  { text: '@media (min-width: 768px) {}', snippet: '@media (min-width: 768px) {\n  $1\n}', desc: 'CSS Responsive Media Query', type: 'css' },
  { text: 'font-family: sans-serif;', snippet: 'font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;', desc: 'CSS Font Family', type: 'css' },
  { text: 'font-weight: 700;', snippet: 'font-weight: 700;', desc: 'CSS Bold text weight', type: 'css' },
  { text: 'letter-spacing: 0.5px;', snippet: 'letter-spacing: 0.5px;', desc: 'CSS Character spacing', type: 'css' },

  // DOM & HTML Helpers
  { text: 'document.getElementById("")', snippet: 'document.getElementById("$1")', desc: 'Find HTML element by ID', type: 'dom' },
  { text: 'document.querySelector("")', snippet: 'document.querySelector("$1")', desc: 'Find first matching CSS selector', type: 'dom' },
  { text: 'document.querySelectorAll("")', snippet: 'document.querySelectorAll("$1")', desc: 'Find all matching elements', type: 'dom' },
  { text: 'addEventListener("click", () => {})', snippet: 'addEventListener("click", (event) => {\n  $1\n});', desc: 'Listen to user clicks or events', type: 'dom' },
  { text: 'element.textContent = ""', snippet: 'textContent = "$1";', desc: 'Change text inside element', type: 'dom' },
  { text: 'element.innerHTML = ""', snippet: 'innerHTML = \`$1\`;', desc: 'Change HTML content', type: 'dom' },
  { text: 'element.style.color = ""', snippet: 'style.color = "$1";', desc: 'Change text color', type: 'dom' },
  { text: 'element.style.backgroundColor = ""', snippet: 'style.backgroundColor = "$1";', desc: 'Change background color', type: 'dom' },
  { text: 'element.classList.toggle("")', snippet: 'classList.toggle("$1");', desc: 'Toggle CSS class on element', type: 'dom' },
  { text: 'element.classList.add("")', snippet: 'classList.add("$1");', desc: 'Add CSS class', type: 'dom' },
  
  // HTML Tags
  { text: '<button id="">Click</button>', snippet: '<button id="$1" class="magic-btn">Click Me</button>', desc: 'HTML Clickable Button', type: 'html' },
  { text: '<div id="" class=""></div>', snippet: '<div id="$1" class="$2">\n  $3\n</div>', desc: 'HTML Container Box', type: 'html' },
  { text: '<h1 id="">Title</h1>', snippet: '<h1 id="$1">$2</h1>', desc: 'HTML Main Heading', type: 'html' },
  { text: '<p id="">Paragraph</p>', snippet: '<p id="$1">$2</p>', desc: 'HTML Text Paragraph', type: 'html' },
  { text: '<input type="text" id="" />', snippet: '<input type="text" id="$1" placeholder="$2" />', desc: 'HTML Text Input Box', type: 'html' },
  { text: '<canvas id="" width="400" height="200"></canvas>', snippet: '<canvas id="$1" width="400" height="200"></canvas>', desc: 'HTML5 Graphics Canvas', type: 'html' },
  
  // JavaScript Statements & Methods
  { text: 'console.log()', snippet: 'console.log($1);', desc: 'Print debug message to console', type: 'js' },
  { text: 'console.table()', snippet: 'console.table($1);', desc: 'Display array/object as neat table', type: 'js' },
  { text: 'const name = value;', snippet: 'const $1 = $2;', desc: 'Declare constant variable', type: 'js' },
  { text: 'let counter = 0;', snippet: 'let $1 = $2;', desc: 'Declare reassignable variable', type: 'js' },
  { text: 'function myFunc() {}', snippet: 'function $1($2) {\n  $3\n}', desc: 'Create reusable function', type: 'js' },
  { text: 'const fn = () => {}', snippet: 'const $1 = ($2) => {\n  $3\n};', desc: 'Arrow function expression', type: 'js' },
  { text: 'if (condition) {}', snippet: 'if ($1) {\n  $2\n}', desc: 'If branch condition', type: 'js' },
  { text: 'for (let i = 0; i < 10; i++) {}', snippet: 'for (let i = 0; i < $1; i++) {\n  $2\n}', desc: 'Standard for loop', type: 'js' },
  { text: 'setTimeout(() => {}, 1000)', snippet: 'setTimeout(() => {\n  $1\n}, 1000);', desc: 'Run code after delay (ms)', type: 'js' },
  { text: 'setInterval(() => {}, 1000)', snippet: 'setInterval(() => {\n  $1\n}, 1000);', desc: 'Repeat code every X ms', type: 'js' },
  { text: 'Math.random()', snippet: 'Math.random()', desc: 'Generate random number between 0 and 1', type: 'js' },
  { text: 'Math.floor()', snippet: 'Math.floor($1)', desc: 'Round down to nearest integer', type: 'js' },
  { text: 'array.map(item => item)', snippet: 'map($1 => $2)', desc: 'Transform array items', type: 'js' },
  { text: 'array.filter(item => condition)', snippet: 'filter($1 => $2)', desc: 'Filter matching array items', type: 'js' }
];

export class CodeEditor {
  constructor(containerId, options = {}) {
    this.container = document.getElementById(containerId);
    const defaultTemplate = STARTER_TEMPLATES['bob-robot'];
    this.options = {
      defaultCode: options.defaultCode || defaultTemplate.js,
      defaultHtml: options.defaultHtml || defaultTemplate.html,
      defaultCss: options.defaultCss || defaultTemplate.css,
      mode: options.mode || 'html-js', // 'html-js' or 'pure-js'
      onRun: options.onRun || null,
      ...options
    };
    this.currentMode = this.options.mode;
    this.activeEditorTab = 'js'; // 'js' | 'css' | 'html'
    this.logs = [];
    this.activeSuggestionIndex = 0;
    this.filteredSuggestions = [];
    this.init();
  }

  init() {
    if (!this.container) return;
    this.render();
    this.bindEvents();
    // Auto execute default code on startup so the canvas shows live content right away
    setTimeout(() => {
      this.executeCode();
    }, 100);
  }

  render() {
    this.container.innerHTML = `
      <div class="kid-editor-container">
        <!-- Top Fun Toolbar -->
        <div class="kid-editor-header">
          <div class="header-left-group">
            <!-- Mode Switcher -->
            <div class="editor-mode-toggle" title="Switch between HTML+CSS+JS Live Web Studio and Pure JS Console">
              <button class="mode-btn ${this.currentMode === 'html-js' ? 'active' : ''}" id="btn-mode-htmljs">
                <span class="mode-icon">🌐</span> Web Studio (HTML + CSS + JS)
              </button>
              <button class="mode-btn ${this.currentMode === 'pure-js' ? 'active' : ''}" id="btn-mode-purejs">
                <span class="mode-icon">⚡</span> Pure JS Console
              </button>
            </div>

            <!-- Templates Select -->
            <select id="template-selector" class="kid-select-pill" title="Load fun animated template">
              <option value="">✨ Fun Templates...</option>
              <option value="bob-robot">🤖 Bob the Dancing Robot (HTML + CSS + JS)</option>
              <option value="neon-card">🎨 Neon Glow Card & Buttons (HTML + CSS + JS)</option>
              <option value="flexbox-studio">📦 Flexbox Layout Lab (HTML + CSS)</option>
              <option value="magic-bulb">💡 Magic Light Bulb (HTML + CSS + JS)</option>
              <option value="coin-clicker">🎮 Coin Clicker Game (HTML + CSS + JS)</option>
              <option value="pure-js-basics">⚡ Pure JS Console Explorer</option>
            </select>
          </div>

          <div class="header-right-group">
            <button id="btn-auto-trigger" class="kid-icon-btn btn-purple" title="Show Auto-Complete Suggestions (Ctrl+Space)">
              <span class="btn-sparkle">✨</span> Auto-Complete
            </button>
            <button id="btn-format" class="kid-icon-btn" title="Clean & Format Code">
              <span>🧹 Format</span>
            </button>
            <button id="btn-copy" class="kid-icon-btn" title="Copy Code">
              <span>📋 Copy</span>
            </button>
            <button id="btn-clear-code" class="kid-icon-btn" title="Reset Code">
              <span>🗑️ Clear</span>
            </button>
            <button id="btn-run-code" class="kid-run-btn" title="Run Code (Ctrl + Enter)">
              <span class="run-icon">▶</span>
              <span class="run-text">RUN CODE</span>
              <span class="run-pulse"></span>
            </button>
          </div>
        </div>

        <!-- Touch/Quick Autocomplete Toolbar -->
        <div class="quick-autocomplete-bar" id="quick-keys-bar">
          <span class="quick-chip-label">Quick Snippets:</span>
          <div class="quick-chips-scroll" id="quick-chips-container">
            <button type="button" class="kid-key-chip chip-css" data-insert="display: flex; justify-content: center; align-items: center;">flex-center</button>
            <button type="button" class="kid-key-chip chip-css" data-insert="background: linear-gradient(135deg, #10b981, #38bdf8);">gradient</button>
            <button type="button" class="kid-key-chip chip-css" data-insert="box-shadow: 0 0 25px rgba(56, 189, 248, 0.5);">glow-shadow</button>
            <button type="button" class="kid-key-chip chip-css" data-insert="border-radius: 16px;">border-radius</button>
            <button type="button" class="kid-key-chip chip-html" data-insert="<button id='' class='magic-btn'>Click</button>">&lt;button&gt;</button>
            <button type="button" class="kid-key-chip chip-html" data-insert="<div id='' class=''></div>">&lt;div&gt;</button>
            <button type="button" class="kid-key-chip" data-insert="document.getElementById('')">getElementById()</button>
            <button type="button" class="kid-key-chip" data-insert="addEventListener('click', () => {})">on('click')</button>
            <button type="button" class="kid-key-chip" data-insert="console.log()">log()</button>
            <button type="button" class="kid-key-chip" data-insert="const ">const</button>
            <button type="button" class="kid-key-chip" data-insert="let ">let</button>
            <button type="button" class="kid-key-chip" data-insert="=>">=&gt;</button>
            <button type="button" class="kid-key-chip" data-insert="{}">{ }</button>
            <button type="button" class="kid-key-chip" data-insert="()">( )</button>
          </div>
        </div>

        <!-- Main Workspace Split -->
        <div class="kid-workspace-split">
          <!-- LEFT SIDE: Code Input Section -->
          <div class="kid-code-side">
            <!-- Tabs for HTML vs CSS vs JS editing when in Web App mode -->
            <div class="code-tab-switch-bar ${this.currentMode === 'pure-js' ? 'hidden' : ''}" id="code-tabs-bar">
              <button class="code-tab-btn active" id="tab-btn-js" data-editor="js">
                <span class="tab-badge badge-js">JS</span> JavaScript (Logic)
              </button>
              <button class="code-tab-btn" id="tab-btn-css" data-editor="css">
                <span class="tab-badge badge-css">CSS</span> CSS (Style & Visuals)
              </button>
              <button class="code-tab-btn" id="tab-btn-html" data-editor="html">
                <span class="tab-badge badge-html">&lt;/&gt;</span> HTML (Elements)
              </button>
            </div>

            <!-- Editor Wrapper with Line Numbers & Floating Autocomplete -->
            <div class="editor-pane-wrapper">
              <!-- JS Textarea Pane -->
              <div class="textarea-pane active" id="pane-js">
                <div class="line-numbers" id="js-line-numbers">1</div>
                <textarea id="js-code-textarea" class="kid-code-textarea" spellcheck="false" placeholder="// Write JavaScript code here...">${this.escapeHtml(this.options.defaultCode)}</textarea>
              </div>

              <!-- CSS Textarea Pane -->
              <div class="textarea-pane" id="pane-css">
                <div class="line-numbers" id="css-line-numbers">1</div>
                <textarea id="css-code-textarea" class="kid-code-textarea css-theme" spellcheck="false" placeholder="/* Write CSS styles here... */">${this.escapeHtml(this.options.defaultCss)}</textarea>
              </div>

              <!-- HTML Textarea Pane -->
              <div class="textarea-pane" id="pane-html">
                <div class="line-numbers" id="html-line-numbers">1</div>
                <textarea id="html-code-textarea" class="kid-code-textarea html-theme" spellcheck="false" placeholder="<!-- Write HTML elements here like <button id='btn'>Click</button> -->">${this.escapeHtml(this.options.defaultHtml)}</textarea>
              </div>

              <!-- Floating Autocomplete Suggestion Dropdown -->
              <div class="autocomplete-floating-menu" id="autocomplete-popup" style="display: none;">
                <div class="autocomplete-header">
                  <span>Suggestions (Tab or Enter to Insert)</span>
                  <span class="esc-hint">Esc to Close</span>
                </div>
                <div class="autocomplete-list" id="autocomplete-items"></div>
              </div>
            </div>
          </div>

          <!-- RIGHT SIDE: Live Output / Preview & Console -->
          <div class="kid-output-side">
            <div class="output-topbar">
              <div class="output-tab-pills">
                <button class="out-tab-pill active" id="pill-preview" data-view="preview">
                  <span class="live-dot"></span> Live Interactive App
                </button>
                <button class="out-tab-pill" id="pill-console" data-view="console">
                  <span class="console-icon">💻</span> Console Logs (<span id="log-counter">0</span>)
                </button>
              </div>
              <button id="btn-clear-terminal" class="mini-clear-btn" title="Clear console">Clear</button>
            </div>

            <!-- Preview Canvas Pane -->
            <div class="output-view-pane active" id="view-preview">
              <iframe id="kid-preview-frame" sandbox="allow-scripts allow-same-origin allow-modals" class="kid-preview-iframe" title="Interactive Web App Preview"></iframe>
            </div>

            <!-- Console Terminal Pane -->
            <div class="output-view-pane" id="view-console">
              <div class="kid-terminal" id="kid-terminal-output">
                <div class="terminal-welcome">Click <strong>▶ RUN CODE</strong> to run and see console messages!</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    `;

    this.updateLineNumbers('js');
    this.updateLineNumbers('css');
    this.updateLineNumbers('html');
  }

  bindEvents() {
    const jsTextarea = this.container.querySelector('#js-code-textarea');
    const cssTextarea = this.container.querySelector('#css-code-textarea');
    const htmlTextarea = this.container.querySelector('#html-code-textarea');
    const runBtn = this.container.querySelector('#btn-run-code');
    const clearTerminalBtn = this.container.querySelector('#btn-clear-terminal');
    const formatBtn = this.container.querySelector('#btn-format');
    const copyBtn = this.container.querySelector('#btn-copy');
    const clearCodeBtn = this.container.querySelector('#btn-clear-code');
    const templateSelect = this.container.querySelector('#template-selector');
    const quickChips = this.container.querySelectorAll('.kid-key-chip');
    const autoTriggerBtn = this.container.querySelector('#btn-auto-trigger');

    // Mode Toggle Buttons
    this.container.querySelector('#btn-mode-htmljs')?.addEventListener('click', () => {
      this.setMode('html-js');
      sound.playClick();
    });
    this.container.querySelector('#btn-mode-purejs')?.addEventListener('click', () => {
      this.setMode('pure-js');
      sound.playClick();
    });

    // Editor Tab Switch (JS vs CSS vs HTML)
    this.container.querySelector('#tab-btn-js')?.addEventListener('click', () => {
      this.switchEditorTab('js');
      sound.playClick();
    });
    this.container.querySelector('#tab-btn-css')?.addEventListener('click', () => {
      this.switchEditorTab('css');
      sound.playClick();
    });
    this.container.querySelector('#tab-btn-html')?.addEventListener('click', () => {
      this.switchEditorTab('html');
      sound.playClick();
    });

    // Output Tabs (Preview vs Console)
    this.container.querySelector('#pill-preview')?.addEventListener('click', () => {
      this.switchOutputTab('preview');
      sound.playClick();
    });
    this.container.querySelector('#pill-console')?.addEventListener('click', () => {
      this.switchOutputTab('console');
      sound.playClick();
    });

    // Run Code with Animation & Sound
    runBtn?.addEventListener('click', () => {
      this.executeCode();
      sound.playSuccess();
      runBtn.classList.add('btn-bounce');
      setTimeout(() => runBtn.classList.remove('btn-bounce'), 400);
    });

    // Clear Terminal
    clearTerminalBtn?.addEventListener('click', () => {
      this.logs = [];
      const term = this.container.querySelector('#kid-terminal-output');
      term.innerHTML = '<div class="terminal-welcome">[Console Cleared]</div>';
      this.container.querySelector('#log-counter').textContent = '0';
      sound.playClick();
    });

    // Format Code
    formatBtn?.addEventListener('click', () => {
      const activeTextarea = this.getActiveTextarea();
      if (activeTextarea) {
        activeTextarea.value = this.cleanFormat(activeTextarea.value);
        this.updateLineNumbers(this.activeEditorTab);
        sound.playClick();
      }
    });

    // Copy Code
    copyBtn?.addEventListener('click', () => {
      const activeTextarea = this.getActiveTextarea();
      if (activeTextarea) {
        navigator.clipboard.writeText(activeTextarea.value).then(() => {
          const span = copyBtn.querySelector('span');
          const orig = span.textContent;
          span.textContent = '✅ Copied!';
          sound.playSparkle();
          setTimeout(() => { span.textContent = orig; }, 1500);
        });
      }
    });

    // Clear Code
    clearCodeBtn?.addEventListener('click', () => {
      if (confirm('Clear the current code box?')) {
        const activeTextarea = this.getActiveTextarea();
        if (activeTextarea) {
          activeTextarea.value = '';
          this.updateLineNumbers(this.activeEditorTab);
          sound.playClick();
        }
      }
    });

    // Template Selector
    templateSelect?.addEventListener('change', (e) => {
      const key = e.target.value;
      if (STARTER_TEMPLATES[key]) {
        const t = STARTER_TEMPLATES[key];
        if (t.mode === 'pure-js') {
          this.setMode('pure-js');
          jsTextarea.value = t.js;
          if (cssTextarea) cssTextarea.value = '';
          if (htmlTextarea) htmlTextarea.value = '';
        } else {
          this.setMode('html-js');
          jsTextarea.value = t.js;
          if (cssTextarea) cssTextarea.value = t.css || '';
          if (htmlTextarea) htmlTextarea.value = t.html || '';
        }
        this.updateLineNumbers('js');
        this.updateLineNumbers('css');
        this.updateLineNumbers('html');
        this.executeCode();
        sound.playSparkle();
      }
    });

    // Quick Chips Insertion
    quickChips.forEach(chip => {
      chip.addEventListener('click', () => {
        const text = chip.getAttribute('data-insert');
        this.insertSnippetAtCursor(text);
        sound.playPop();
      });
    });

    // Auto-Complete Manual Trigger Button
    autoTriggerBtn?.addEventListener('click', () => {
      const activeTextarea = this.getActiveTextarea();
      if (activeTextarea) {
        this.showAutocompletePopup(activeTextarea, true);
        sound.playSparkle();
      }
    });

    // Handle Textarea Typing, Auto-Brackets, Shortcuts, and Autocomplete
    [jsTextarea, cssTextarea, htmlTextarea].forEach(textarea => {
      if (!textarea) return;

      textarea.addEventListener('keydown', (e) => this.handleTextareaKeydown(e, textarea));
      textarea.addEventListener('input', () => {
        let targetType = 'js';
        if (textarea.id.includes('css')) targetType = 'css';
        else if (textarea.id.includes('html')) targetType = 'html';

        this.updateLineNumbers(targetType);
        this.handleAutocompleteTyping(textarea);
      });
      textarea.addEventListener('scroll', () => {
        let targetType = 'js';
        if (textarea.id.includes('css')) targetType = 'css';
        else if (textarea.id.includes('html')) targetType = 'html';

        const lineNumbers = this.container.querySelector(`#${targetType}-line-numbers`);
        if (lineNumbers) lineNumbers.scrollTop = textarea.scrollTop;
      });
    });

    // Close autocomplete on click outside
    document.addEventListener('click', (e) => {
      const popup = this.container.querySelector('#autocomplete-popup');
      if (popup && !popup.contains(e.target) && e.target !== autoTriggerBtn) {
        popup.style.display = 'none';
      }
    });
  }

  getActiveTextarea() {
    if (this.activeEditorTab === 'js') return this.container.querySelector('#js-code-textarea');
    if (this.activeEditorTab === 'css') return this.container.querySelector('#css-code-textarea');
    return this.container.querySelector('#html-code-textarea');
  }

  setMode(mode) {
    this.currentMode = mode;
    const modeHtmlBtn = this.container.querySelector('#btn-mode-htmljs');
    const modePureBtn = this.container.querySelector('#btn-mode-purejs');
    const codeTabsBar = this.container.querySelector('#code-tabs-bar');

    if (mode === 'pure-js') {
      modeHtmlBtn?.classList.remove('active');
      modePureBtn?.classList.add('active');
      codeTabsBar?.classList.add('hidden');
      this.switchEditorTab('js');
      this.switchOutputTab('console');
    } else {
      modeHtmlBtn?.classList.add('active');
      modePureBtn?.classList.remove('active');
      codeTabsBar?.classList.remove('hidden');
      this.switchOutputTab('preview');
    }
  }

  switchEditorTab(tab) {
    this.activeEditorTab = tab;
    const btnJs = this.container.querySelector('#tab-btn-js');
    const btnCss = this.container.querySelector('#tab-btn-css');
    const btnHtml = this.container.querySelector('#tab-btn-html');
    const paneJs = this.container.querySelector('#pane-js');
    const paneCss = this.container.querySelector('#pane-css');
    const paneHtml = this.container.querySelector('#pane-html');

    btnJs?.classList.toggle('active', tab === 'js');
    btnCss?.classList.toggle('active', tab === 'css');
    btnHtml?.classList.toggle('active', tab === 'html');

    paneJs?.classList.toggle('active', tab === 'js');
    paneCss?.classList.toggle('active', tab === 'css');
    paneHtml?.classList.toggle('active', tab === 'html');
  }

  switchOutputTab(view) {
    const pillPrev = this.container.querySelector('#pill-preview');
    const pillCons = this.container.querySelector('#pill-console');
    const viewPrev = this.container.querySelector('#view-preview');
    const viewCons = this.container.querySelector('#view-console');

    if (view === 'preview') {
      pillPrev?.classList.add('active');
      pillCons?.classList.remove('active');
      viewPrev?.classList.add('active');
      viewCons?.classList.remove('active');
    } else {
      pillPrev?.classList.remove('active');
      pillCons?.classList.add('active');
      viewPrev?.classList.remove('active');
      viewCons?.classList.add('active');
    }
  }

  updateLineNumbers(type) {
    const textarea = this.container.querySelector(`#${type}-code-textarea`);
    const lineNumbers = this.container.querySelector(`#${type}-line-numbers`);
    if (!textarea || !lineNumbers) return;

    const lines = textarea.value.split('\n').length;
    let html = '';
    for (let i = 1; i <= Math.max(lines, 1); i++) {
      html += `<div>${i}</div>`;
    }
    lineNumbers.innerHTML = html;
  }

  handleTextareaKeydown(e, textarea) {
    const popup = this.container.querySelector('#autocomplete-popup');
    const isPopupOpen = popup && popup.style.display !== 'none';

    // 1. Run Shortcut: Ctrl+Enter / Cmd+Enter
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
      e.preventDefault();
      this.executeCode();
      sound.playSuccess();
      return;
    }

    // 2. Autocomplete Navigation with Arrow Keys & Enter/Tab
    if (isPopupOpen) {
      if (e.key === 'ArrowDown') {
        e.preventDefault();
        this.activeSuggestionIndex = (this.activeSuggestionIndex + 1) % this.filteredSuggestions.length;
        this.renderSuggestionItems();
        return;
      }
      if (e.key === 'ArrowUp') {
        e.preventDefault();
        this.activeSuggestionIndex = (this.activeSuggestionIndex - 1 + this.filteredSuggestions.length) % this.filteredSuggestions.length;
        this.renderSuggestionItems();
        return;
      }
      if (e.key === 'Enter' || e.key === 'Tab') {
        e.preventDefault();
        if (this.filteredSuggestions[this.activeSuggestionIndex]) {
          this.applySuggestion(this.filteredSuggestions[this.activeSuggestionIndex], textarea);
        }
        return;
      }
      if (e.key === 'Escape') {
        popup.style.display = 'none';
        return;
      }
    }

    // 3. Tab Indentation
    if (e.key === 'Tab') {
      e.preventDefault();
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      textarea.value = textarea.value.substring(0, start) + '  ' + textarea.value.substring(end);
      textarea.selectionStart = textarea.selectionEnd = start + 2;
      this.updateLineNumbers(this.activeEditorTab);
      return;
    }

    // 4. Auto-Closing Pairs
    const pairs = {
      '(': ')',
      '{': '}',
      '[': ']',
      '"': '"',
      "'": "'",
      '`': '`'
    };

    if (pairs[e.key]) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const closing = pairs[e.key];

      e.preventDefault();
      textarea.value = textarea.value.substring(0, start) + e.key + closing + textarea.value.substring(end);
      textarea.selectionStart = textarea.selectionEnd = start + 1;
      this.updateLineNumbers(this.activeEditorTab);
    }
  }

  handleAutocompleteTyping(textarea) {
    const cursorPos = textarea.selectionStart;
    const textBefore = textarea.value.substring(0, cursorPos);
    const words = textBefore.split(/[\s\(\)\{\}\[\]\.,;><="']+/);
    const lastWord = words[words.length - 1] || '';

    if (lastWord.length >= 2) {
      this.showAutocompletePopup(textarea, false, lastWord);
    } else {
      const popup = this.container.querySelector('#autocomplete-popup');
      if (popup) popup.style.display = 'none';
    }
  }

  showAutocompletePopup(textarea, forceAll = false, query = '') {
    const popup = this.container.querySelector('#autocomplete-popup');
    if (!popup) return;

    const lower = query.toLowerCase();
    this.filteredSuggestions = AUTOCOMPLETE_DICTIONARY.filter(item => {
      if (forceAll) return true;
      return item.text.toLowerCase().includes(lower) || item.desc.toLowerCase().includes(lower);
    }).slice(0, 7);

    if (this.filteredSuggestions.length === 0) {
      popup.style.display = 'none';
      return;
    }

    this.activeSuggestionIndex = 0;
    this.renderSuggestionItems();
    popup.style.display = 'block';
  }

  renderSuggestionItems() {
    const itemsContainer = this.container.querySelector('#autocomplete-items');
    if (!itemsContainer) return;

    itemsContainer.innerHTML = this.filteredSuggestions.map((item, idx) => `
      <div class="autocomplete-item ${idx === this.activeSuggestionIndex ? 'active' : ''}" data-idx="${idx}">
        <div class="item-left">
          <span class="item-badge badge-${item.type}">${item.type.toUpperCase()}</span>
          <span class="item-text">${this.escapeHtml(item.text)}</span>
        </div>
        <span class="item-desc">${this.escapeHtml(item.desc)}</span>
      </div>
    `).join('');

    itemsContainer.querySelectorAll('.autocomplete-item').forEach(el => {
      el.addEventListener('click', () => {
        const idx = parseInt(el.getAttribute('data-idx'), 10);
        const activeTextarea = this.getActiveTextarea();
        if (activeTextarea) {
          this.applySuggestion(this.filteredSuggestions[idx], activeTextarea);
        }
      });
    });
  }

  applySuggestion(item, textarea) {
    const popup = this.container.querySelector('#autocomplete-popup');
    if (popup) popup.style.display = 'none';

    const start = textarea.selectionStart;
    const textBefore = textarea.value.substring(0, start);
    const words = textBefore.split(/[\s\(\)\{\}\[\]\.,;><="']+/);
    const lastWord = words[words.length - 1] || '';

    const replaceStart = start - lastWord.length;
    const snippetClean = item.snippet.replace(/\$\d/g, '');

    textarea.value = textarea.value.substring(0, replaceStart) + snippetClean + textarea.value.substring(start);
    textarea.focus();
    textarea.selectionStart = textarea.selectionEnd = replaceStart + snippetClean.length;
    this.updateLineNumbers(this.activeEditorTab);
    sound.playSparkle();
  }

  insertSnippetAtCursor(snippetText) {
    const textarea = this.getActiveTextarea();
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    textarea.value = textarea.value.substring(0, start) + snippetText + textarea.value.substring(end);
    textarea.focus();

    if (snippetText.includes("''") || snippetText.includes('""') || snippetText.includes('()') || snippetText.includes('{}')) {
      textarea.selectionStart = textarea.selectionEnd = start + snippetText.length - 1;
    } else {
      textarea.selectionStart = textarea.selectionEnd = start + snippetText.length;
    }
    this.updateLineNumbers(this.activeEditorTab);
  }

  cleanFormat(code) {
    return code.split('\n').map(l => l.trimEnd()).join('\n');
  }

  executeCode() {
    const jsTextarea = this.container.querySelector('#js-code-textarea');
    const cssTextarea = this.container.querySelector('#css-code-textarea');
    const htmlTextarea = this.container.querySelector('#html-code-textarea');
    const terminal = this.container.querySelector('#kid-terminal-output');
    const previewFrame = this.container.querySelector('#kid-preview-frame');

    const jsCode = jsTextarea ? jsTextarea.value : '';
    const cssCode = (this.currentMode === 'html-js' && cssTextarea) ? cssTextarea.value : '';
    const htmlCode = (this.currentMode === 'html-js' && htmlTextarea) ? htmlTextarea.value : '';

    this.logs = [];
    if (terminal) terminal.innerHTML = '';

    // Generate Sandboxed HTML Document with CSS + HTML + Live Logger
    const sandboxDoc = `
      <!DOCTYPE html>
      <html lang="en">
        <head>
          <meta charset="UTF-8">
          <style>
            * { box-sizing: border-box; margin: 0; padding: 0; }
            body {
              font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
              background-color: #0d1117;
              color: #f0f6fc;
              padding: 16px;
              min-height: 100vh;
              display: flex;
              flex-direction: column;
              align-items: center;
              justify-content: center;
            }

            /* Fun Button Base Styles */
            .magic-btn {
              background: linear-gradient(135deg, #10b981, #059669);
              color: #ffffff;
              border: none;
              padding: 10px 18px;
              border-radius: 10px;
              font-size: 0.95rem;
              font-weight: 700;
              cursor: pointer;
              box-shadow: 0 4px 14px rgba(16, 185, 129, 0.4);
              transition: all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
              display: inline-flex;
              align-items: center;
              gap: 6px;
              user-select: none;
            }
            .magic-btn:hover {
              transform: translateY(-2px) scale(1.04);
              box-shadow: 0 6px 20px rgba(16, 185, 129, 0.6);
            }
            .magic-btn:active {
              transform: scale(0.95);
            }
            .magic-btn.btn-green { background: linear-gradient(135deg, #10b981, #059669); box-shadow: 0 4px 14px rgba(16, 185, 129, 0.4); }
            .magic-btn.btn-blue { background: linear-gradient(135deg, #38bdf8, #0284c7); box-shadow: 0 4px 14px rgba(56, 189, 248, 0.4); }
            .magic-btn.btn-purple { background: linear-gradient(135deg, #a855f7, #7e22ce); box-shadow: 0 4px 14px rgba(168, 85, 247, 0.4); }
            .magic-btn.btn-amber { background: linear-gradient(135deg, #f59e0b, #d97706); box-shadow: 0 4px 14px rgba(245, 158, 11, 0.4); }
            .magic-btn.btn-secondary { background: #21262d; border: 1px solid #30363d; color: #c9d1d9; box-shadow: none; }

            .button-controls {
              display: flex;
              flex-wrap: wrap;
              gap: 8px;
              justify-content: center;
              margin-top: 6px;
            }

            /* User Defined Custom CSS */
            ${cssCode}
          </style>
        </head>
        <body>
          <div id="app-root">
            ${htmlCode}
          </div>

          <script>
            (function() {
              const post = (type, args) => {
                window.parent.postMessage({ type: 'KID_CONSOLE', logType: type, args }, '*');
              };

              const customConsole = {
                log: (...args) => post('log', args.map(formatArg)),
                warn: (...args) => post('warn', args.map(formatArg)),
                error: (...args) => post('error', args.map(formatArg)),
                info: (...args) => post('info', args.map(formatArg)),
                table: (data) => post('table', [formatArg(data)])
              };

              function formatArg(arg) {
                try {
                  if (arg === null) return { type: 'null', value: 'null' };
                  if (arg === undefined) return { type: 'undefined', value: 'undefined' };
                  if (typeof arg === 'function') return { type: 'function', value: arg.toString() };
                  if (typeof arg === 'object') {
                    return { type: 'object', value: JSON.stringify(arg, null, 2) };
                  }
                  return { type: typeof arg, value: String(arg) };
                } catch(e) {
                  return { type: 'string', value: String(arg) };
                }
              }

              window.addEventListener('message', (event) => {
                if (event.data?.type === 'RUN_USER_CODE') {
                  try {
                    const runFn = new Function('console', event.data.code);
                    const result = runFn(customConsole);
                    if (result !== undefined) {
                      post('return', [formatArg(result)]);
                    }
                  } catch (err) {
                    post('error', [{ type: 'error', value: err.name + ': ' + err.message }]);
                  }
                }
              });
            })();
          <\/script>
        </body>
      </html>
    `;

    if (previewFrame) {
      previewFrame.srcdoc = sandboxDoc;

      const messageHandler = (e) => {
        if (e.data?.type === 'KID_CONSOLE') {
          this.appendTerminalLog(e.data.logType, e.data.args);
        }
      };

      window.removeEventListener('message', this._currentKidMsgHandler);
      this._currentKidMsgHandler = messageHandler;
      window.addEventListener('message', messageHandler);

      previewFrame.onload = () => {
        previewFrame.contentWindow.postMessage({ type: 'RUN_USER_CODE', code: jsCode }, '*');
      };
    }

    if (this.options.onRun) {
      this.options.onRun(jsCode);
    }
  }

  appendTerminalLog(type, args) {
    const terminal = this.container.querySelector('#kid-terminal-output');
    const logCounter = this.container.querySelector('#log-counter');
    if (!terminal) return;

    this.logs.push({ type, args, time: new Date().toLocaleTimeString() });
    if (logCounter) logCounter.textContent = this.logs.length;

    const logRow = document.createElement('div');
    logRow.className = `term-row term-${type}`;

    let icon = 'ℹ️';
    if (type === 'warn') icon = '⚠️';
    if (type === 'error') icon = '❌';
    if (type === 'return') icon = '↩️';
    if (type === 'table') icon = '📊';

    let contentHtml = '';
    if (type === 'table') {
      try {
        const raw = JSON.parse(args[0].value);
        if (Array.isArray(raw)) {
          const keys = Object.keys(raw[0] || {});
          contentHtml = `
            <table class="term-table">
              <thead><tr><th>#</th>${keys.map(k => `<th>${this.escapeHtml(k)}</th>`).join('')}</tr></thead>
              <tbody>
                ${raw.map((row, i) => `<tr><td>${i}</td>${keys.map(k => `<td>${this.escapeHtml(String(row[k] ?? ''))}</td>`).join('')}</tr>`).join('')}
              </tbody>
            </table>
          `;
        }
      } catch(e) {
        contentHtml = args.map(a => `<span class="val-${a.type}">${this.escapeHtml(a.value)}</span>`).join(' ');
      }
    } else {
      contentHtml = args.map(a => `<span class="val-${a.type}">${this.escapeHtml(a.value)}</span>`).join(' ');
    }

    logRow.innerHTML = `<span class="term-icon">${icon}</span> <div class="term-content">${contentHtml}</div>`;
    terminal.appendChild(logRow);
    terminal.scrollTop = terminal.scrollHeight;
  }

  setCode(code) {
    const textarea = this.container?.querySelector('#js-code-textarea');
    if (textarea) {
      textarea.value = code;
      this.updateLineNumbers('js');
    }
  }

  getCode() {
    const textarea = this.container?.querySelector('#js-code-textarea');
    return textarea ? textarea.value : '';
  }

  escapeHtml(str) {
    if (!str) return '';
    return str
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }
}
