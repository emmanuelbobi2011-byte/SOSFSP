// Interactive Playgrounds Engine for Every Lesson (HTML, CSS & JavaScript)
import { sound } from './audio.js';

export class InteractivePlaygrounds {
  render(container, lessonId) {
    if (!container) return;

    const renderers = {
      // --- HTML TRACK PLAYGROUNDS ---
      'html-intro': this.renderHtmlIntroPlayground.bind(this),
      'html-text': this.renderHtmlTextPlayground.bind(this),
      'html-links': this.renderHtmlLinksPlayground.bind(this),
      'html-images': this.renderHtmlImagesPlayground.bind(this),
      'html-audio-video': this.renderHtmlMediaPlayground.bind(this),
      'html-lists': this.renderHtmlListsPlayground.bind(this),
      'html-tables': this.renderHtmlTablesPlayground.bind(this),
      'html-containers': this.renderHtmlContainersPlayground.bind(this),
      'html-forms': this.renderHtmlFormsPlayground.bind(this),

      // --- CSS TRACK PLAYGROUNDS ---
      'css-intro': this.renderCssIntroPlayground.bind(this),
      'css-colors': this.renderCssColorsPlayground.bind(this),
      'css-typography': this.renderCssTypographyPlayground.bind(this),
      'css-boxmodel': this.renderCssBoxModelPlayground.bind(this),
      'css-borders': this.renderCssBordersPlayground.bind(this),
      'css-flexbox': this.renderCssFlexboxPlayground.bind(this),
      'css-grid': this.renderCssGridPlayground.bind(this),
      'css-transitions': this.renderCssTransitionsPlayground.bind(this),
      'css-keyframes': this.renderCssKeyframesPlayground.bind(this),
      'css-responsive': this.renderCssResponsivePlayground.bind(this),

      // --- JS TRACK PLAYGROUNDS ---
      'js-intro': this.renderIntroPlayground.bind(this),
      'html-and-js': this.renderHtmlAndJsPlayground.bind(this),
      'js-output': this.renderOutputPlayground.bind(this),
      'js-variables': this.renderVariablesPlayground.bind(this),
      'js-datatypes': this.renderDataTypesPlayground.bind(this),
      'js-operators': this.renderOperatorsPlayground.bind(this),
      'js-conditionals': this.renderConditionalsPlayground.bind(this),
      'js-loops': this.renderLoopsPlayground.bind(this),
      'js-functions': this.renderFunctionsPlayground.bind(this),
      'js-closures': this.renderClosuresPlayground.bind(this),
      'js-objects': this.renderObjectsPlayground.bind(this),
      'js-arrays': this.renderArraysPlayground.bind(this),
      'js-classes': this.renderClassesPlayground.bind(this),
      'js-async': this.renderAsyncPlayground.bind(this),
      'js-dom': this.renderDomPlayground.bind(this),
      'js-modern-features': this.renderModernPlayground.bind(this),
      'js-storage': this.renderStoragePlayground.bind(this)
    };

    const renderer = renderers[lessonId] || this.renderDefaultPlayground.bind(this);
    renderer(container);
  }

  createPlaygroundFrame(title, description, innerHtml) {
    return `
      <div class="interactive-playground-card">
        <div class="playground-card-header">
          <div class="playground-title-group">
            <span class="playground-pulse-dot"></span>
            <h3 class="playground-title">${title}</h3>
          </div>
          <span class="playground-badge">Live Interactive Sandbox</span>
        </div>
        <p class="playground-desc">${description}</p>
        <div class="playground-widget-body">
          ${innerHtml}
        </div>
      </div>
    `;
  }

  // ==========================================
  // --- HTML TRACK PLAYGROUNDS (Simple & Visual) ---
  // ==========================================

  // 1. HTML INTRO & TAG BUILDER STUDIO
  renderHtmlIntroPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📄 Simple HTML Tag Builder',
      'Pick any HTML tag below, type your own custom message, and see how HTML elements wrap text with opening & closing tags!',
      `
        <div class="html-builder-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. Choose a Tag:</label>
              <div class="selector-pills-row" id="tag-picker-row">
                <button class="html-tag-pill active" data-tag="h1">&lt;h1&gt; Main Title</button>
                <button class="html-tag-pill" data-tag="h2">&lt;h2&gt; Sub-title</button>
                <button class="html-tag-pill" data-tag="p">&lt;p&gt; Paragraph</button>
                <button class="html-tag-pill" data-tag="button">&lt;button&gt; Button</button>
                <button class="html-tag-pill" data-tag="mark">&lt;mark&gt; Highlight</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Type Your Content:</label>
              <input type="text" class="simple-text-input" id="html-intro-input" value="Hello, World! 🚀" placeholder="Enter text here...">
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Live Webpage Output:</div>
            <div class="html-live-stage" id="html-intro-stage">
              <!-- Live rendered element will appear here -->
            </div>

            <div class="html-code-box">
              <div class="css-code-header">Generated HTML Code:</div>
              <pre><code id="html-intro-code">&lt;h1&gt;Hello, World! 🚀&lt;/h1&gt;</code></pre>
            </div>
          </div>
        </div>
      `
    );

    let activeTag = 'h1';
    const input = container.querySelector('#html-intro-input');
    const stage = container.querySelector('#html-intro-stage');
    const code = container.querySelector('#html-intro-code');
    const tagBtns = container.querySelectorAll('.html-tag-pill');

    const update = () => {
      const text = input.value || 'Hello!';
      let innerEl = '';
      if (activeTag === 'h1') {
        innerEl = `<h1 style="color: #f0f6fc; margin: 0; font-size: 1.8rem; font-weight: 800;">${text}</h1>`;
      } else if (activeTag === 'h2') {
        innerEl = `<h2 style="color: #f97316; margin: 0; font-size: 1.4rem; font-weight: 700;">${text}</h2>`;
      } else if (activeTag === 'p') {
        innerEl = `<p style="color: #c9d1d9; margin: 0; font-size: 1rem; line-height: 1.5;">${text}</p>`;
      } else if (activeTag === 'button') {
        innerEl = `<button style="background: #f97316; color: white; border: none; padding: 10px 20px; border-radius: 8px; font-weight: bold; cursor: pointer; box-shadow: 0 4px 12px rgba(249,115,22,0.4);">${text}</button>`;
      } else if (activeTag === 'mark') {
        innerEl = `<p style="font-size: 1.1rem; color: #f0f6fc; margin: 0;"><mark style="background: #fef08a; color: #1e293b; padding: 2px 8px; border-radius: 4px; font-weight: bold;">${text}</mark></p>`;
      }

      stage.innerHTML = innerEl;
      code.textContent = `<${activeTag}>${text}</${activeTag}>`;
    };

    tagBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        tagBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeTag = btn.getAttribute('data-tag');
        update();
      });
    });

    input.addEventListener('input', update);
    update();
  }

  // 2. HTML HEADINGS & TEXT STYLER
  renderHtmlTextPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📝 Headings & Formatting Styler',
      'Experiment with heading sizes and simple formatting tags (Bold, Italic, Underline, Highlight).',
      `
        <div class="html-text-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. Heading Level:</label>
              <div class="selector-pills-row">
                <button class="html-tag-pill active" data-level="h1">&lt;h1&gt;</button>
                <button class="html-tag-pill" data-level="h2">&lt;h2&gt;</button>
                <button class="html-tag-pill" data-level="h3">&lt;h3&gt;</button>
                <button class="html-tag-pill" data-level="p">&lt;p&gt;</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Text Formatting Toggles:</label>
              <div class="selector-pills-row">
                <button class="html-toggle-chip" id="fmt-bold" data-fmt="b"><b>&lt;b&gt; Bold</b></button>
                <button class="html-toggle-chip" id="fmt-italic" data-fmt="i"><i>&lt;i&gt; Italic</i></button>
                <button class="html-toggle-chip" id="fmt-underline" data-fmt="u"><u>&lt;u&gt; Underline</u></button>
                <button class="html-toggle-chip" id="fmt-mark" data-fmt="mark"><mark style="background:#fef08a; padding:1px 4px; border-radius:2px; color:#1e293b;">&lt;mark&gt;</mark></button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">3. Edit Text:</label>
              <input type="text" class="simple-text-input" id="html-text-input" value="The Amazing Web Explorer" placeholder="Enter headline...">
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Live Output:</div>
            <div class="html-live-stage" id="html-text-stage">
              <!-- Rendered Text -->
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Markup:</div>
              <pre><code id="html-text-code">&lt;h1&gt;The Amazing Web Explorer&lt;/h1&gt;</code></pre>
            </div>
          </div>
        </div>
      `
    );

    let currentLevel = 'h1';
    const formatting = { b: false, i: false, u: false, mark: false };

    const input = container.querySelector('#html-text-input');
    const stage = container.querySelector('#html-text-stage');
    const code = container.querySelector('#html-text-code');

    const update = () => {
      let text = input.value || 'Sample Text';
      let wrapped = text;

      if (formatting.mark) wrapped = `<mark>${wrapped}</mark>`;
      if (formatting.u) wrapped = `<u>${wrapped}</u>`;
      if (formatting.i) wrapped = `<i>${wrapped}</i>`;
      if (formatting.b) wrapped = `<b>${wrapped}</b>`;

      const fullHtml = `<${currentLevel}>${wrapped}</${currentLevel}>`;
      stage.innerHTML = fullHtml;
      code.textContent = fullHtml;
    };

    container.querySelectorAll('.html-tag-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('.html-tag-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentLevel = btn.getAttribute('data-level');
        update();
      });
    });

    ['bold', 'italic', 'underline', 'mark'].forEach(type => {
      const key = type === 'bold' ? 'b' : (type === 'italic' ? 'i' : (type === 'underline' ? 'u' : 'mark'));
      const btn = container.querySelector(`#fmt-${type}`);
      btn?.addEventListener('click', () => {
        sound.play('click');
        formatting[key] = !formatting[key];
        btn.classList.toggle('active', formatting[key]);
        update();
      });
    });

    input.addEventListener('input', update);
    update();
  }

  // 3. HTML LINKS & BUTTONS
  renderHtmlLinksPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🔗 Hyperlinks & Clickable Buttons',
      'Create clickable links (&lt;a href="..."&gt;) and action buttons (&lt;button&gt;). Test clicking them directly in the live stage!',
      `
        <div class="html-links-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. Element Type:</label>
              <div class="selector-pills-row">
                <button class="html-tag-pill active" id="btn-mode-link">🌐 Hyperlink (&lt;a&gt;)</button>
                <button class="html-tag-pill" id="btn-mode-btn">🔘 Action Button (&lt;button&gt;)</button>
              </div>
            </div>

            <div class="control-subgroup" id="link-controls">
              <label class="control-label">2. Website Destination:</label>
              <div class="selector-pills-row" style="margin-bottom: 8px;">
                <button class="preset-pill active" data-href="https://wikipedia.org">Wikipedia</button>
                <button class="preset-pill" data-href="https://google.com">Google</button>
                <button class="preset-pill" data-href="https://github.com">GitHub</button>
              </div>
              <label style="color:#c9d1d9; font-size:0.85rem; display:flex; align-items:center; gap:6px; cursor:pointer;">
                <input type="checkbox" id="link-target-blank" checked> Open in new tab (<code>target="_blank"</code>)
              </label>
            </div>

            <div class="control-subgroup">
              <label class="control-label">3. Label Text:</label>
              <input type="text" class="simple-text-input" id="link-text-input" value="Explore Wikipedia 🚀">
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Interactive Stage (Click to Test):</div>
            <div class="html-live-stage" id="link-live-stage">
              <!-- Live element -->
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Code:</div>
              <pre><code id="link-code-output"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let isLink = true;
    let href = 'https://wikipedia.org';
    const textInput = container.querySelector('#link-text-input');
    const targetCheck = container.querySelector('#link-target-blank');
    const stage = container.querySelector('#link-live-stage');
    const code = container.querySelector('#link-code-output');

    const update = () => {
      const text = textInput.value || 'Click here';
      if (isLink) {
        const isBlank = targetCheck.checked;
        const targetAttr = isBlank ? ' target="_blank" rel="noopener noreferrer"' : '';
        stage.innerHTML = `
          <a href="${href}" ${targetAttr} style="color: #38bdf8; text-decoration: underline; font-size: 1.15rem; font-weight: 700; display: inline-flex; align-items: center; gap: 6px;">
            ${text} ↗
          </a>
        `;
        code.textContent = `<a href="${href}"${isBlank ? ' target="_blank"' : ''}>${text}</a>`;
      } else {
        stage.innerHTML = `
          <button id="interactive-live-btn" style="background: #10b981; color: white; border: none; padding: 12px 24px; border-radius: 10px; font-weight: 800; font-size: 1.05rem; cursor: pointer; box-shadow: 0 4px 14px rgba(16,185,129,0.4); transition: transform 0.1s;">
            ${text}
          </button>
        `;
        code.textContent = `<button onclick="alert('Button clicked! 🎉')">\n  ${text}\n</button>`;

        stage.querySelector('#interactive-live-btn')?.addEventListener('click', () => {
          sound.play('celebration');
          stage.querySelector('#interactive-live-btn').style.transform = 'scale(0.95)';
          setTimeout(() => {
            if (stage.querySelector('#interactive-live-btn')) {
              stage.querySelector('#interactive-live-btn').style.transform = 'scale(1)';
            }
          }, 150);
        });
      }
    };

    container.querySelector('#btn-mode-link').addEventListener('click', () => {
      sound.play('click');
      isLink = true;
      container.querySelector('#btn-mode-link').classList.add('active');
      container.querySelector('#btn-mode-btn').classList.remove('active');
      container.querySelector('#link-controls').style.display = 'block';
      update();
    });

    container.querySelector('#btn-mode-btn').addEventListener('click', () => {
      sound.play('click');
      isLink = false;
      container.querySelector('#btn-mode-btn').classList.add('active');
      container.querySelector('#btn-mode-link').classList.remove('active');
      container.querySelector('#link-controls').style.display = 'none';
      update();
    });

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        href = btn.getAttribute('data-href');
        update();
      });
    });

    textInput.addEventListener('input', update);
    targetCheck.addEventListener('change', update);
    update();
  }

  // 4. HTML IMAGES & PHOTOS
  renderHtmlImagesPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🖼️ Simple Image (&lt;img&gt;) Studio',
      'See how the self-closing &lt;img&gt; tag works with src (image link), alt (description), and width sizing!',
      `
        <div class="html-media-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. Choose Photo Subject:</label>
              <div class="selector-pills-row">
                <button class="preset-pill active" data-pic="code">💻 Code Editor</button>
                <button class="preset-pill" data-pic="nature">🌄 Mountain</button>
                <button class="preset-pill" data-pic="rocket">🚀 Rocket</button>
                <button class="preset-pill" data-pic="art">🎨 Design</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Width (Pixels): <span id="img-width-val">160px</span></label>
              <input type="range" class="kid-slider" id="img-width-slider" min="80" max="260" value="160">
            </div>

            <div class="control-subgroup">
              <label class="control-label">3. Alt Description:</label>
              <input type="text" class="simple-text-input" id="img-alt-input" value="Clean code on laptop screen">
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Live Image Render:</div>
            <div class="html-live-stage" id="img-live-stage">
              <!-- Live img will render here -->
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Image Tag:</div>
              <pre><code id="img-code-output"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    const pictures = {
      code: { src: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=300', alt: 'Clean code on laptop screen' },
      nature: { src: 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=300', alt: 'Scenic mountain range at sunset' },
      rocket: { src: 'https://images.unsplash.com/photo-1517976487507-5b3b4a45057b?w=300', alt: 'A rocket soaring into space' },
      art: { src: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?w=300', alt: 'Modern abstract colorful artwork' }
    };

    let currentPic = 'code';
    const slider = container.querySelector('#img-width-slider');
    const widthVal = container.querySelector('#img-width-val');
    const altInput = container.querySelector('#img-alt-input');
    const stage = container.querySelector('#img-live-stage');
    const code = container.querySelector('#img-code-output');

    const update = () => {
      const width = slider.value;
      widthVal.textContent = `${width}px`;
      const alt = altInput.value || pictures[currentPic].alt;
      const src = pictures[currentPic].src;

      stage.innerHTML = `
        <img src="${src}" alt="${alt}" width="${width}" style="border-radius: 12px; border: 2px solid #30363d; box-shadow: 0 6px 16px rgba(0,0,0,0.4); max-width: 100%;">
      `;

      code.textContent = `<img src="${src}"\n     alt="${alt}"\n     width="${width}">`;
    };

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentPic = btn.getAttribute('data-pic');
        altInput.value = pictures[currentPic].alt;
        update();
      });
    });

    slider.addEventListener('input', update);
    altInput.addEventListener('input', update);
    update();
  }

  // 5. HTML AUDIO & MEDIA PLAYGROUND
  renderHtmlMediaPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🎵 Audio (&lt;audio&gt;) Player Lab',
      'Learn how the &lt;audio controls&gt; element embeds sound with native player controls.',
      `
        <div class="html-media-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. Choose Sound Effect:</label>
              <div class="selector-pills-row">
                <button class="preset-pill active" data-sfx="celebration">🎉 Fanfare</button>
                <button class="preset-pill" data-sfx="bell">🔔 Victory Bell</button>
                <button class="preset-pill" data-sfx="zap">⚡ Laser Zap</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Audio Attributes:</label>
              <label style="color:#c9d1d9; font-size:0.85rem; display:flex; align-items:center; gap:6px; margin-bottom: 6px;">
                <input type="checkbox" id="media-controls-check" checked> <code>controls</code> (Play/Pause buttons)
              </label>
              <label style="color:#c9d1d9; font-size:0.85rem; display:flex; align-items:center; gap:6px;">
                <input type="checkbox" id="media-loop-check"> <code>loop</code> (Repeat continuously)
              </label>
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Interactive Audio Player:</div>
            <div class="html-live-stage" id="audio-stage">
              <div style="background: #161b22; border: 1px solid #30363d; border-radius: 12px; padding: 14px 20px; display: flex; align-items: center; gap: 14px; width: 100%; max-width: 280px;">
                <button id="media-play-btn" style="width: 44px; height: 44px; border-radius: 50%; background: #10b981; border: none; color: white; font-size: 1.2rem; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(16,185,129,0.4);">
                  ▶
                </button>
                <div style="flex: 1;">
                  <div style="color: #f0f6fc; font-weight: 800; font-size: 0.9rem;" id="media-title">victory_fanfare.mp3</div>
                  <div style="color: #8b949e; font-size: 0.75rem;">HTML5 Audio Element</div>
                </div>
              </div>
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Audio Code:</div>
              <pre><code id="audio-code-output"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let activeSfx = 'celebration';
    const sfxNames = {
      celebration: 'victory_fanfare.mp3',
      bell: 'school_bell.mp3',
      zap: 'laser_zap.mp3'
    };

    const playBtn = container.querySelector('#media-play-btn');
    const titleEl = container.querySelector('#media-title');
    const controlsCheck = container.querySelector('#media-controls-check');
    const loopCheck = container.querySelector('#media-loop-check');
    const code = container.querySelector('#audio-code-output');

    const update = () => {
      const fileName = sfxNames[activeSfx];
      titleEl.textContent = fileName;
      const hasControls = controlsCheck.checked ? ' controls' : '';
      const hasLoop = loopCheck.checked ? ' loop' : '';

      code.textContent = `<audio${hasControls}${hasLoop} src="${fileName}">\n  Your browser does not support audio.\n</audio>`;
    };

    playBtn.addEventListener('click', () => {
      sound.play(activeSfx);
      playBtn.textContent = '🔊';
      setTimeout(() => { playBtn.textContent = '▶'; }, 800);
    });

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeSfx = btn.getAttribute('data-sfx');
        update();
      });
    });

    controlsCheck.addEventListener('change', update);
    loopCheck.addEventListener('change', update);
    update();
  }

  // 6. HTML LISTS CREATOR
  renderHtmlListsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📋 Bulleted (&lt;ul&gt;) & Numbered (&lt;ol&gt;) Lists',
      'Create lists with bullet points or numbered steps. Add items and watch clean HTML list items generate instantly.',
      `
        <div class="html-lists-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. List Container Type:</label>
              <div class="selector-pills-row">
                <button class="html-tag-pill active" id="list-ul-btn">&lt;ul&gt; Bulleted List</button>
                <button class="html-tag-pill" id="list-ol-btn">&lt;ol&gt; Numbered List</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Add New List Item (&lt;li&gt;):</label>
              <div style="display:flex; gap: 8px;">
                <input type="text" class="simple-text-input" id="list-item-input" value="🍇 Purple Grapes" placeholder="Type list item...">
                <button id="add-item-btn" style="background: #10b981; color: white; border: none; padding: 8px 14px; border-radius: 8px; font-weight: bold; cursor: pointer; white-space: nowrap;">
                  + Add
                </button>
              </div>
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Live List Render:</div>
            <div class="html-live-stage" id="list-live-stage" style="align-items: flex-start;">
              <!-- Rendered list -->
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Markup:</div>
              <pre><code id="list-code-output"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let isOrdered = false;
    let items = ['🍎 Crisp Red Apple', '🍌 Golden Banana', '🍇 Sweet Grapes'];

    const stage = container.querySelector('#list-live-stage');
    const code = container.querySelector('#list-code-output');
    const input = container.querySelector('#list-item-input');

    const update = () => {
      const tag = isOrdered ? 'ol' : 'ul';
      const itemsHtml = items.map(item => `<li>${item}</li>`).join('\n  ');
      
      stage.innerHTML = `
        <${tag} class="simple-list-rendered">
          ${items.map(item => `<li>${item}</li>`).join('')}
        </${tag}>
      `;

      code.textContent = `<${tag}>\n  ${itemsHtml}\n</${tag}>`;
    };

    container.querySelector('#list-ul-btn').addEventListener('click', () => {
      sound.play('click');
      isOrdered = false;
      container.querySelector('#list-ul-btn').classList.add('active');
      container.querySelector('#list-ol-btn').classList.remove('active');
      update();
    });

    container.querySelector('#list-ol-btn').addEventListener('click', () => {
      sound.play('click');
      isOrdered = true;
      container.querySelector('#list-ol-btn').classList.add('active');
      container.querySelector('#list-ul-btn').classList.remove('active');
      update();
    });

    container.querySelector('#add-item-btn').addEventListener('click', () => {
      if (input.value.trim()) {
        sound.play('celebration');
        items.push(input.value.trim());
        input.value = '';
        update();
      }
    });

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        container.querySelector('#add-item-btn').click();
      }
    });

    update();
  }

  // 7. HTML TABLES GENERATOR
  renderHtmlTablesPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📊 Simple Table (&lt;table&gt;) Builder',
      'See how table rows (&lt;tr&gt;), headers (&lt;th&gt;), and data cells (&lt;td&gt;) build clean information grids.',
      `
        <div class="html-tables-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">1. Table Template Preset:</label>
              <div class="selector-pills-row">
                <button class="preset-pill active" data-preset="scores">🏆 High Scores</button>
                <button class="preset-pill" data-preset="heroes">🦸 Superheroes</button>
                <button class="preset-pill" data-preset="pets">🐶 Pet Roster</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Table Settings:</label>
              <label style="color:#c9d1d9; font-size:0.85rem; display:flex; align-items:center; gap:6px;">
                <input type="checkbox" id="table-border-check" checked> Include <code>border="1"</code>
              </label>
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Live Table Render:</div>
            <div class="html-live-stage" id="table-live-stage">
              <!-- Live Table -->
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Table Code:</div>
              <pre><code id="table-code-output"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    const tablesData = {
      scores: {
        headers: ['Player', 'Game', 'Score'],
        rows: [
          ['Alex', 'Space Quest', '9,850'],
          ['Maya', 'Cyber Runner', '12,400']
        ]
      },
      heroes: {
        headers: ['Hero', 'Power', 'City'],
        rows: [
          ['Flash', 'Super Speed', 'Central City'],
          ['Batman', 'High Tech', 'Gotham']
        ]
      },
      pets: {
        headers: ['Pet Name', 'Species', 'Age'],
        rows: [
          ['Biscuit', 'Golden Dog', '3 yrs'],
          ['Milo', 'Tabby Cat', '2 yrs']
        ]
      }
    };

    let currentPreset = 'scores';
    const borderCheck = container.querySelector('#table-border-check');
    const stage = container.querySelector('#table-live-stage');
    const code = container.querySelector('#table-code-output');

    const update = () => {
      const data = tablesData[currentPreset];
      const hasBorder = borderCheck.checked;
      const borderAttr = hasBorder ? ' border="1"' : '';

      const ths = data.headers.map(h => `<th>${h}</th>`).join('');
      const trs = data.rows.map(r => `<tr>${r.map(c => `<td>${c}</td>`).join('')}</tr>`).join('');

      stage.innerHTML = `
        <table class="simple-styled-table"${borderAttr}>
          <thead><tr>${ths}</tr></thead>
          <tbody>${trs}</tbody>
        </table>
      `;

      const codeHeader = `  <tr>\n    ${data.headers.map(h => `<th>${h}</th>`).join('\n    ')}\n  </tr>`;
      const codeRows = data.rows.map(r => `  <tr>\n    ${r.map(c => `<td>${c}</td>`).join('\n    ')}\n  </tr>`).join('\n');

      code.textContent = `<table${borderAttr}>\n${codeHeader}\n${codeRows}\n</table>`;
    };

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentPreset = btn.getAttribute('data-preset');
        update();
      });
    });

    borderCheck.addEventListener('change', update);
    update();
  }

  // 8. HTML CONTAINERS & SEMANTIC LEGO BLOCKS
  renderHtmlContainersPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🧱 Semantic Webpage Blocks (&lt;header&gt;, &lt;main&gt;, &lt;footer&gt;)',
      'Click any block in the webpage layout below to see how semantic tags organize a real site.',
      `
        <div class="html-blocks-grid">
          <div class="html-controls-col">
            <div class="control-subgroup">
              <label class="control-label">Click a Webpage Block:</label>
              <div class="selector-pills-row">
                <button class="preset-pill active" data-block="header">&lt;header&gt;</button>
                <button class="preset-pill" data-block="nav">&lt;nav&gt;</button>
                <button class="preset-pill" data-block="main">&lt;main&gt;</button>
                <button class="preset-pill" data-block="footer">&lt;footer&gt;</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Block Explanation:</label>
              <div id="block-info-text" style="color: #c9d1d9; font-size: 0.88rem; line-height: 1.5;">
                <strong>&lt;header&gt;</strong>: The top area containing your site title, logo, or banner.
              </div>
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Visual Webpage Layout:</div>
            <div style="background: #0d1117; border: 2px dashed #30363d; border-radius: 12px; padding: 14px;">
              <div class="lego-block-item lego-header" id="lego-el-header">&lt;header&gt; Site Title & Logo &lt;/header&gt;</div>
              <div class="lego-block-item lego-nav" id="lego-el-nav">&lt;nav&gt; Home | About | Contact &lt;/nav&gt;</div>
              <div class="lego-block-item lego-main" id="lego-el-main">&lt;main&gt; Primary Article & Story Content &lt;/main&gt;</div>
              <div class="lego-block-item lego-footer" id="lego-el-footer">&lt;footer&gt; © 2026 Copyright Info &lt;/footer&gt;</div>
            </div>

            <div class="html-code-box" style="margin-top: 12px;">
              <div class="css-code-header">Semantic Structure:</div>
              <pre><code>&lt;header&gt;...&lt;/header&gt;
&lt;nav&gt;...&lt;/nav&gt;
&lt;main&gt;...&lt;/main&gt;
&lt;footer&gt;...&lt;/footer&gt;</code></pre>
            </div>
          </div>
        </div>
      `
    );

    const blockDescriptions = {
      header: '<strong>&lt;header&gt;</strong>: The top area containing your website brand logo and main banner.',
      nav: '<strong>&lt;nav&gt;</strong>: Holds navigation links to guide visitors around your site.',
      main: '<strong>&lt;main&gt;</strong>: The central, primary content of the webpage (articles, games, stories).',
      footer: '<strong>&lt;footer&gt;</strong>: The bottom section containing copyright details and author links.'
    };

    const infoText = container.querySelector('#block-info-text');

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const block = btn.getAttribute('data-block');
        infoText.innerHTML = blockDescriptions[block];

        // Animate selected block
        const targetEl = container.querySelector(`#lego-el-${block}`);
        if (targetEl) {
          targetEl.style.transform = 'scale(1.05)';
          setTimeout(() => { targetEl.style.transform = 'scale(1)'; }, 200);
        }
      });
    });
  }

  // 9. HTML FORMS & INPUTS PLAYGROUND
  renderHtmlFormsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📝 Interactive Form (&lt;form&gt;) Sandbox',
      'Test different &lt;input&gt; types (text, color picker, slider range, checkbox). Everything reacts live on screen!',
      `
        <div class="html-forms-grid">
          <div class="html-controls-col">
            <div class="sample-form-box">
              <div class="sample-form-row">
                <label>1. Text Box (&lt;input type="text"&gt;):</label>
                <input type="text" class="simple-text-input" id="form-name-input" value="Captain Code">
              </div>

              <div class="sample-form-row">
                <label>2. Color Picker (&lt;input type="color"&gt;):</label>
                <input type="color" id="form-color-input" value="#10b981" style="width: 100%; height: 36px; border: none; border-radius: 6px; cursor: pointer;">
              </div>

              <div class="sample-form-row">
                <label>3. Range Slider (&lt;input type="range"&gt;): <span id="form-range-val">80%</span></label>
                <input type="range" class="kid-slider" id="form-range-input" min="10" max="100" value="80">
              </div>

              <div class="sample-form-row">
                <label style="display:flex; align-items:center; gap:6px; cursor:pointer; color:#f0f6fc; margin-top:4px;">
                  <input type="checkbox" id="form-shield-check" checked> 4. Checkbox: Enable Magic Shield 🛡️
                </label>
              </div>

              <button id="form-submit-btn" style="background:#f97316; color:white; border:none; padding:10px; border-radius:8px; font-weight:800; cursor:pointer; margin-top:6px; box-shadow:0 4px 12px rgba(249,115,22,0.4);">
                🚀 Submit Form
              </button>
            </div>
          </div>

          <div class="html-preview-col">
            <div class="html-stage-label">Live Character Card:</div>
            <div class="html-live-stage" id="form-character-stage">
              <div id="character-card-box" style="background: #161b22; border: 2px solid #10b981; border-radius: 12px; padding: 16px; text-align: center; width: 100%; max-width: 220px; transition: all 0.2s;">
                <div style="font-size: 2.2rem;" id="hero-avatar">🧙‍♂️</div>
                <div style="color: #ffffff; font-weight: 800; font-size: 1.1rem; margin: 4px 0;" id="hero-name-display">Captain Code</div>
                <div style="color: #10b981; font-size: 0.8rem; font-weight: 700;" id="hero-power-display">Power: 80% • Shield Active</div>
              </div>
            </div>

            <div class="html-code-box">
              <div class="css-code-header">HTML Form Code:</div>
              <pre><code id="form-code-output"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    const nameInput = container.querySelector('#form-name-input');
    const colorInput = container.querySelector('#form-color-input');
    const rangeInput = container.querySelector('#form-range-input');
    const rangeVal = container.querySelector('#form-range-val');
    const shieldCheck = container.querySelector('#form-shield-check');
    const cardBox = container.querySelector('#character-card-box');
    const nameDisplay = container.querySelector('#hero-name-display');
    const powerDisplay = container.querySelector('#hero-power-display');
    const submitBtn = container.querySelector('#form-submit-btn');
    const code = container.querySelector('#form-code-output');

    const update = () => {
      const name = nameInput.value || 'Player 1';
      const color = colorInput.value;
      const power = rangeInput.value;
      const hasShield = shieldCheck.checked;

      rangeVal.textContent = `${power}%`;
      nameDisplay.textContent = name;
      cardBox.style.borderColor = color;
      powerDisplay.style.color = color;
      powerDisplay.textContent = `Power: ${power}% • ${hasShield ? 'Shield 🛡️' : 'No Shield'}`;

      code.textContent = `<form>\n  <input type="text" value="${name}">\n  <input type="color" value="${color}">\n  <input type="range" value="${power}">\n  <input type="checkbox"${hasShield ? ' checked' : ''}>\n  <button type="submit">Submit</button>\n</form>`;
    };

    submitBtn.addEventListener('click', () => {
      sound.play('celebration');
      cardBox.style.transform = 'scale(1.1)';
      setTimeout(() => { cardBox.style.transform = 'scale(1)'; }, 200);
    });

    nameInput.addEventListener('input', update);
    colorInput.addEventListener('input', update);
    rangeInput.addEventListener('input', update);
    shieldCheck.addEventListener('change', update);
    update();
  }

  // ==========================================
  // --- CSS TRACK PLAYGROUNDS ---
  // ==========================================

  // 1. CSS INTRO & SELECTOR STUDIO
  renderCssIntroPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🎨 Live CSS Selector & Property Lab',
      'Test how element, class, and ID selectors target HTML elements. Tweak properties below and watch the live CSS rule generate in real-time!',
      `
        <div class="css-intro-lab-grid">
          <!-- Controls Panel -->
          <div class="css-controls-column">
            <div class="control-subgroup">
              <label class="control-label">1. Choose Selector Target:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" id="sel-btn" data-target="btn">button (Tag)</button>
                <button class="selector-pill" id="sel-badge" data-target="badge">.magic-badge (Class)</button>
                <button class="selector-pill" id="sel-card" data-target="card">#hero-card (ID)</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Background Color:</label>
              <div class="color-palette-row">
                <button class="color-dot-btn active" style="background:#10b981;" data-color="#10b981"></button>
                <button class="color-dot-btn" style="background:#38bdf8;" data-color="#38bdf8"></button>
                <button class="color-dot-btn" style="background:#ec4899;" data-color="#ec4899"></button>
                <button class="color-dot-btn" style="background:#8b5cf6;" data-color="#8b5cf6"></button>
                <button class="color-dot-btn" style="background:#f59e0b;" data-color="#f59e0b"></button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">3. Padding (Inner space): <span id="css-pad-val">12px 24px</span></label>
              <input type="range" id="slider-css-padding" min="6" max="32" value="16" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">4. Border Radius: <span id="css-radius-val">12px</span></label>
              <input type="range" id="slider-css-radius" min="0" max="30" value="12" class="kid-slider" />
            </div>
          </div>

          <!-- Live Preview & CSS Output -->
          <div class="css-preview-column">
            <div class="css-live-stage" id="css-intro-stage">
              <div class="stage-sample-item" id="sample-target">
                <span class="sample-icon">✨</span>
                <span class="sample-text" id="sample-label">Interactive Target</span>
              </div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">Generated CSS:</div>
              <pre><code id="generated-css-code">/* Select a property to see CSS */</code></pre>
            </div>
          </div>
        </div>
      `
    );

    let currentTarget = 'btn';
    let currentColor = '#10b981';
    let currentPadding = 16;
    let currentRadius = 12;

    const sample = container.querySelector('#sample-target');
    const sampleLabel = container.querySelector('#sample-label');
    const codeDisplay = container.querySelector('#generated-css-code');
    const padVal = container.querySelector('#css-pad-val');
    const radVal = container.querySelector('#css-radius-val');

    const updateCss = () => {
      let selectorName = 'button';
      if (currentTarget === 'badge') selectorName = '.magic-badge';
      if (currentTarget === 'card') selectorName = '#hero-card';

      sample.style.backgroundColor = currentColor;
      sample.style.padding = `${currentPadding}px ${currentPadding * 1.5}px`;
      sample.style.borderRadius = `${currentRadius}px`;
      sample.style.color = '#ffffff';
      sample.style.boxShadow = `0 4px 16px ${currentColor}66`;

      padVal.textContent = `${currentPadding}px ${Math.round(currentPadding * 1.5)}px`;
      radVal.textContent = `${currentRadius}px`;

      codeDisplay.textContent = `${selectorName} {\n  background-color: ${currentColor};\n  padding: ${currentPadding}px ${Math.round(currentPadding * 1.5)}px;\n  border-radius: ${currentRadius}px;\n  color: #ffffff;\n  box-shadow: 0 4px 16px ${currentColor}66;\n}`;
    };

    container.querySelectorAll('.selector-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.selector-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentTarget = btn.getAttribute('data-target');
        if (currentTarget === 'btn') sampleLabel.textContent = '<button> Click Me</button>';
        if (currentTarget === 'badge') sampleLabel.textContent = '<span class="magic-badge">NEW</span>';
        if (currentTarget === 'card') sampleLabel.textContent = '<div id="hero-card">Featured Card</div>';
        updateCss();
        sound.playClick();
      });
    });

    container.querySelectorAll('.color-dot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.color-dot-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentColor = btn.getAttribute('data-color');
        updateCss();
        sound.playPop();
      });
    });

    container.querySelector('#slider-css-padding')?.addEventListener('input', (e) => {
      currentPadding = parseInt(e.target.value, 10);
      updateCss();
    });

    container.querySelector('#slider-css-radius')?.addEventListener('input', (e) => {
      currentRadius = parseInt(e.target.value, 10);
      updateCss();
    });

    updateCss();
  }

  // 2. CSS COLORS & GRADIENT STUDIO
  renderCssColorsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🌈 CSS Color & Gradient Designer',
      'Create high-contrast Linear Gradients, Radial Glows, and transparent RGBA alpha channels with real-time CSS export.',
      `
        <div class="css-color-studio-grid">
          <div class="studio-controls-pane">
            <div class="control-subgroup">
              <label class="control-label">Gradient Type:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" id="btn-grad-linear">Linear Gradient</button>
                <button class="selector-pill" id="btn-grad-radial">Radial Glow</button>
                <button class="selector-pill" id="btn-grad-rgba">RGBA Alpha Opacity</button>
              </div>
            </div>

            <div class="control-subgroup" id="angle-control-box">
              <label class="control-label">Gradient Angle: <span id="grad-angle-text">135 deg</span></label>
              <input type="range" id="slider-grad-angle" min="0" max="360" value="135" class="kid-slider" />
            </div>

            <div class="control-subgroup" id="alpha-control-box" style="display:none;">
              <label class="control-label">Alpha Transparency: <span id="alpha-val-text">0.75</span></label>
              <input type="range" id="slider-alpha" min="0.1" max="1" step="0.05" value="0.75" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Color Presets:</label>
              <div class="color-preset-pills">
                <button class="preset-pill active" data-c1="#10b981" data-c2="#06b6d4">Emerald & Cyan</button>
                <button class="preset-pill" data-c1="#38bdf8" data-c2="#a855f7">Sky Blue & Violet</button>
                <button class="preset-pill" data-c1="#ec4899" data-c2="#f59e0b">Flamingo & Gold</button>
                <button class="preset-pill" data-c1="#8b5cf6" data-c2="#ef4444">Purple & Crimson</button>
              </div>
            </div>
          </div>

          <div class="studio-preview-pane">
            <div class="gradient-preview-orb" id="gradient-display-orb">
              <div class="orb-inner-content">
                <span class="orb-icon">🎨</span>
                <span class="orb-title">CSS Master</span>
              </div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Background Rule:</div>
              <pre><code id="grad-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let mode = 'linear';
    let angle = 135;
    let alpha = 0.75;
    let color1 = '#10b981';
    let color2 = '#06b6d4';

    const orb = container.querySelector('#gradient-display-orb');
    const cssCode = container.querySelector('#grad-css-code');
    const angleText = container.querySelector('#grad-angle-text');
    const alphaText = container.querySelector('#alpha-val-text');
    const angleBox = container.querySelector('#angle-control-box');
    const alphaBox = container.querySelector('#alpha-control-box');

    const updateGradient = () => {
      let bgStyle = '';
      if (mode === 'linear') {
        bgStyle = `linear-gradient(${angle}deg, ${color1}, ${color2})`;
        cssCode.textContent = `.gradient-card {\n  background: linear-gradient(${angle}deg, ${color1}, ${color2});\n}`;
      } else if (mode === 'radial') {
        bgStyle = `radial-gradient(circle, ${color1} 0%, ${color2} 100%)`;
        cssCode.textContent = `.radial-card {\n  background: radial-gradient(circle, ${color1} 0%, ${color2} 100%);\n}`;
      } else {
        bgStyle = `rgba(16, 185, 129, ${alpha})`;
        cssCode.textContent = `.translucent-card {\n  background-color: rgba(16, 185, 129, ${alpha});\n  backdrop-filter: blur(12px);\n}`;
      }

      orb.style.background = bgStyle;
      orb.style.boxShadow = `0 10px 30px ${color1}55`;
    };

    container.querySelector('#btn-grad-linear')?.addEventListener('click', (e) => {
      mode = 'linear';
      container.querySelectorAll('.selector-pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      angleBox.style.display = 'block';
      alphaBox.style.display = 'none';
      updateGradient();
      sound.playClick();
    });

    container.querySelector('#btn-grad-radial')?.addEventListener('click', (e) => {
      mode = 'radial';
      container.querySelectorAll('.selector-pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      angleBox.style.display = 'none';
      alphaBox.style.display = 'none';
      updateGradient();
      sound.playClick();
    });

    container.querySelector('#btn-grad-rgba')?.addEventListener('click', (e) => {
      mode = 'rgba';
      container.querySelectorAll('.selector-pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      angleBox.style.display = 'none';
      alphaBox.style.display = 'block';
      updateGradient();
      sound.playClick();
    });

    container.querySelector('#slider-grad-angle')?.addEventListener('input', (e) => {
      angle = e.target.value;
      angleText.textContent = `${angle} deg`;
      updateGradient();
    });

    container.querySelector('#slider-alpha')?.addEventListener('input', (e) => {
      alpha = e.target.value;
      alphaText.textContent = alpha;
      updateGradient();
    });

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        color1 = btn.getAttribute('data-c1');
        color2 = btn.getAttribute('data-c2');
        updateGradient();
        sound.playPop();
      });
    });

    updateGradient();
  }

  // 3. CSS TYPOGRAPHY LAB
  renderCssTypographyPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '✍️ CSS Typography & Font Studio',
      'Experiment with font families, font weights, letter spacing, line height, and neon text-shadow effects.',
      `
        <div class="css-typography-grid">
          <div class="typo-controls">
            <div class="control-subgroup">
              <label class="control-label">Font Family:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-font="sans-serif">Sans-Serif (Modern)</button>
                <button class="selector-pill" data-font="monospace">Monospace (Code)</button>
                <button class="selector-pill" data-font="serif">Serif (Editorial)</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Font Size: <span id="typo-size-label">28px</span></label>
              <input type="range" id="slider-typo-size" min="18" max="48" value="28" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Font Weight: <span id="typo-weight-label">700 (Bold)</span></label>
              <input type="range" id="slider-typo-weight" min="300" max="900" step="100" value="700" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Letter Spacing: <span id="typo-space-label">0px</span></label>
              <input type="range" id="slider-typo-spacing" min="-2" max="8" step="1" value="0" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Glow Shadow:</label>
              <button class="btn-play-action btn-blue" id="btn-toggle-glow">✨ Toggle Neon Text-Shadow</button>
            </div>
          </div>

          <div class="typo-preview-side">
            <div class="typo-stage-card">
              <h2 id="typo-preview-text">The Quick Brown Fox Jumps Over The Lazy Dog</h2>
              <p class="typo-sub-text">CSS typography creates readability and distinct character across modern web interfaces.</p>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Typography Rules:</div>
              <pre><code id="typo-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let font = 'sans-serif';
    let size = 28;
    let weight = 700;
    let spacing = 0;
    let hasGlow = false;

    const preview = container.querySelector('#typo-preview-text');
    const cssCode = container.querySelector('#typo-css-code');
    const sizeLabel = container.querySelector('#typo-size-label');
    const weightLabel = container.querySelector('#typo-weight-label');
    const spaceLabel = container.querySelector('#typo-space-label');

    const updateTypo = () => {
      preview.style.fontFamily = font;
      preview.style.fontSize = `${size}px`;
      preview.style.fontWeight = weight;
      preview.style.letterSpacing = `${spacing}px`;
      preview.style.textShadow = hasGlow ? '0 0 20px #38bdf8, 0 0 40px #38bdf8' : 'none';

      sizeLabel.textContent = `${size}px`;
      weightLabel.textContent = `${weight}`;
      spaceLabel.textContent = `${spacing}px`;

      cssCode.textContent = `.hero-text {\n  font-family: ${font};\n  font-size: ${size}px;\n  font-weight: ${weight};\n  letter-spacing: ${spacing}px;\n  ${hasGlow ? 'text-shadow: 0 0 20px #38bdf8;' : '/* No text-shadow */'}\n}`;
    };

    container.querySelectorAll('.selector-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.selector-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        font = btn.getAttribute('data-font');
        updateTypo();
        sound.playClick();
      });
    });

    container.querySelector('#slider-typo-size')?.addEventListener('input', (e) => {
      size = e.target.value;
      updateTypo();
    });

    container.querySelector('#slider-typo-weight')?.addEventListener('input', (e) => {
      weight = e.target.value;
      updateTypo();
    });

    container.querySelector('#slider-typo-spacing')?.addEventListener('input', (e) => {
      spacing = e.target.value;
      updateTypo();
    });

    container.querySelector('#btn-toggle-glow')?.addEventListener('click', () => {
      hasGlow = !hasGlow;
      updateTypo();
      sound.playSparkle();
    });

    updateTypo();
  }

  // 4. CSS BOX MODEL 4-LAYER VISUALIZER
  renderCssBoxModelPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📦 Interactive 4-Layer Box Model Studio',
      'Visualize the 4 concentric layers of every HTML element: Margin (orange), Border (yellow), Padding (green), and Content (blue).',
      `
        <div class="box-model-lab-layout">
          <div class="box-model-controls">
            <div class="control-subgroup">
              <label class="control-label margin-label">🟠 Margin (Outer space): <span id="val-margin">20px</span></label>
              <input type="range" id="slider-margin" min="0" max="40" value="20" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label border-label">🟡 Border (The wall): <span id="val-border">4px</span></label>
              <input type="range" id="slider-border" min="0" max="16" value="4" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label padding-label">🟢 Padding (Inner space): <span id="val-padding">24px</span></label>
              <input type="range" id="slider-padding" min="4" max="48" value="24" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label content-label">🔵 Content Width: <span id="val-width">160px</span></label>
              <input type="range" id="slider-width" min="100" max="240" value="160" class="kid-slider" />
            </div>
          </div>

          <div class="box-model-diagram-side">
            <!-- 4 Concentric Layers -->
            <div class="bm-layer-margin" id="layer-margin">
              <span class="bm-tag tag-margin">MARGIN</span>
              
              <div class="bm-layer-border" id="layer-border">
                <span class="bm-tag tag-border">BORDER</span>
                
                <div class="bm-layer-padding" id="layer-padding">
                  <span class="bm-tag tag-padding">PADDING</span>
                  
                  <div class="bm-layer-content" id="layer-content">
                    <span class="bm-tag tag-content">CONTENT</span>
                    <div class="bm-content-dim" id="content-dim-text">160 x 60</div>
                  </div>
                </div>
              </div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Box Model Code:</div>
              <pre><code id="bm-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let margin = 20;
    let border = 4;
    let padding = 24;
    let width = 160;

    const layerMargin = container.querySelector('#layer-margin');
    const layerBorder = container.querySelector('#layer-border');
    const layerPadding = container.querySelector('#layer-padding');
    const layerContent = container.querySelector('#layer-content');
    const dimText = container.querySelector('#content-dim-text');
    const cssCode = container.querySelector('#bm-css-code');

    const updateBox = () => {
      layerMargin.style.padding = `${margin}px`;
      layerBorder.style.padding = `${border}px`;
      layerPadding.style.padding = `${padding}px`;
      layerContent.style.width = `${width}px`;

      container.querySelector('#val-margin').textContent = `${margin}px`;
      container.querySelector('#val-border').textContent = `${border}px`;
      container.querySelector('#val-padding').textContent = `${padding}px`;
      container.querySelector('#val-width').textContent = `${width}px`;

      dimText.textContent = `${width}px × 60px`;

      cssCode.textContent = `.box-element {\n  box-sizing: border-box;\n  width: ${width}px;\n  padding: ${padding}px;\n  border: ${border}px solid #f59e0b;\n  margin: ${margin}px;\n}`;
    };

    container.querySelector('#slider-margin')?.addEventListener('input', (e) => {
      margin = parseInt(e.target.value, 10);
      updateBox();
    });

    container.querySelector('#slider-border')?.addEventListener('input', (e) => {
      border = parseInt(e.target.value, 10);
      updateBox();
    });

    container.querySelector('#slider-padding')?.addEventListener('input', (e) => {
      padding = parseInt(e.target.value, 10);
      updateBox();
    });

    container.querySelector('#slider-width')?.addEventListener('input', (e) => {
      width = parseInt(e.target.value, 10);
      updateBox();
    });

    updateBox();
  }

  // 5. CSS BORDERS & GLOW SHADOWS
  renderCssBordersPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '✨ Borders, Pill Shapes & Neon Glow Studio',
      'Morph corner curves into pills or circles with border-radius, and layer vibrant multi-color glow shadows.',
      `
        <div class="css-borders-grid">
          <div class="borders-controls">
            <div class="control-subgroup">
              <label class="control-label">Corner Radius: <span id="border-rad-text">20px</span></label>
              <input type="range" id="slider-radius" min="0" max="60" value="20" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Border Style:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-style="solid">Solid</button>
                <button class="selector-pill" data-style="dashed">Dashed</button>
                <button class="selector-pill" data-style="double">Double</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Neon Glow Colors:</label>
              <div class="color-preset-pills">
                <button class="preset-pill active" data-glow="#10b981">Emerald Matrix</button>
                <button class="preset-pill" data-glow="#38bdf8">Cyan Laser</button>
                <button class="preset-pill" data-glow="#ec4899">Pink Cyber</button>
                <button class="preset-pill" data-glow="#f59e0b">Golden Solar</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Glow Blur Spread: <span id="glow-blur-text">25px</span></label>
              <input type="range" id="slider-glow-blur" min="5" max="60" value="25" class="kid-slider" />
            </div>
          </div>

          <div class="borders-preview-side">
            <div class="neon-target-box" id="neon-box">
              <div class="neon-badge-pill">CYBER UI</div>
              <h3>Borders & Glows</h3>
              <p>Craft futuristic web cards</p>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Border & Box-Shadow Code:</div>
              <pre><code id="border-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let radius = 20;
    let bStyle = 'solid';
    let glowColor = '#10b981';
    let glowBlur = 25;

    const neonBox = container.querySelector('#neon-box');
    const cssCode = container.querySelector('#border-css-code');
    const radText = container.querySelector('#border-rad-text');
    const blurText = container.querySelector('#glow-blur-text');

    const updateBorder = () => {
      neonBox.style.borderRadius = `${radius}px`;
      neonBox.style.border = `2px ${bStyle} ${glowColor}`;
      neonBox.style.boxShadow = `0 4px 12px rgba(0,0,0,0.5), 0 0 ${glowBlur}px ${glowColor}88, 0 0 ${glowBlur * 2}px ${glowColor}33`;

      radText.textContent = `${radius}px`;
      blurText.textContent = `${glowBlur}px`;

      cssCode.textContent = `.neon-card {\n  border: 2px ${bStyle} ${glowColor};\n  border-radius: ${radius}px;\n  box-shadow:\n    0 4px 12px rgba(0, 0, 0, 0.5),\n    0 0 ${glowBlur}px ${glowColor}88;\n}`;
    };

    container.querySelector('#slider-radius')?.addEventListener('input', (e) => {
      radius = e.target.value;
      updateBorder();
    });

    container.querySelector('#slider-glow-blur')?.addEventListener('input', (e) => {
      glowBlur = e.target.value;
      updateBorder();
    });

    container.querySelectorAll('.selector-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.selector-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        bStyle = btn.getAttribute('data-style');
        updateBorder();
        sound.playClick();
      });
    });

    container.querySelectorAll('.preset-pill').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.preset-pill').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        glowColor = btn.getAttribute('data-glow');
        updateBorder();
        sound.playPop();
      });
    });

    updateBorder();
  }

  // 6. CSS FLEXBOX MASTER LAB
  renderCssFlexboxPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📐 Flexbox Interactive Director',
      'Toggle flex-direction, justify-content, align-items, and gap in real-time to watch items flow effortlessly across the stage.',
      `
        <div class="css-flexbox-grid">
          <div class="flexbox-controls">
            <div class="control-subgroup">
              <label class="control-label">flex-direction:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-dir="row">row</button>
                <button class="selector-pill" data-dir="column">column</button>
                <button class="selector-pill" data-dir="row-reverse">row-reverse</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">justify-content (Main Axis):</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-jc="center">center</button>
                <button class="selector-pill" data-jc="space-between">space-between</button>
                <button class="selector-pill" data-jc="flex-start">flex-start</button>
                <button class="selector-pill" data-jc="space-evenly">space-evenly</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">align-items (Cross Axis):</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-ai="center">center</button>
                <button class="selector-pill" data-ai="flex-start">flex-start</button>
                <button class="selector-pill" data-ai="flex-end">flex-end</button>
                <button class="selector-pill" data-ai="stretch">stretch</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">gap: <span id="flex-gap-val">12px</span></label>
              <input type="range" id="slider-flex-gap" min="0" max="32" value="12" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <button class="btn-play-action btn-green" id="btn-add-flex-item">➕ Add Flex Item</button>
              <button class="btn-play-action btn-secondary" id="btn-remove-flex-item">➖ Remove Item</button>
            </div>
          </div>

          <div class="flexbox-preview-side">
            <div class="flex-stage-container" id="flex-stage">
              <div class="flex-toy-item f-item-1">1 🚀</div>
              <div class="flex-toy-item f-item-2">2 💎</div>
              <div class="flex-toy-item f-item-3">3 ⚡</div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Flex Container Code:</div>
              <pre><code id="flex-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let fDir = 'row';
    let jc = 'center';
    let ai = 'center';
    let gap = 12;
    let itemCount = 3;

    const stage = container.querySelector('#flex-stage');
    const cssCode = container.querySelector('#flex-css-code');
    const gapVal = container.querySelector('#flex-gap-val');

    const updateFlex = () => {
      stage.style.flexDirection = fDir;
      stage.style.justifyContent = jc;
      stage.style.alignItems = ai;
      stage.style.gap = `${gap}px`;

      gapVal.textContent = `${gap}px`;

      cssCode.textContent = `.flex-container {\n  display: flex;\n  flex-direction: ${fDir};\n  justify-content: ${jc};\n  align-items: ${ai};\n  gap: ${gap}px;\n}`;
    };

    container.querySelectorAll('[data-dir]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-dir]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        fDir = btn.getAttribute('data-dir');
        updateFlex();
        sound.playClick();
      });
    });

    container.querySelectorAll('[data-jc]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-jc]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        jc = btn.getAttribute('data-jc');
        updateFlex();
        sound.playClick();
      });
    });

    container.querySelectorAll('[data-ai]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-ai]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        ai = btn.getAttribute('data-ai');
        updateFlex();
        sound.playClick();
      });
    });

    container.querySelector('#slider-flex-gap')?.addEventListener('input', (e) => {
      gap = e.target.value;
      updateFlex();
    });

    container.querySelector('#btn-add-flex-item')?.addEventListener('click', () => {
      if (itemCount < 6) {
        itemCount++;
        const item = document.createElement('div');
        item.className = `flex-toy-item f-item-${itemCount % 4 + 1}`;
        item.textContent = `${itemCount} 🌟`;
        stage.appendChild(item);
        sound.playPop();
      }
    });

    container.querySelector('#btn-remove-flex-item')?.addEventListener('click', () => {
      if (itemCount > 1) {
        stage.removeChild(stage.lastElementChild);
        itemCount--;
        sound.playClick();
      }
    });

    updateFlex();
  }

  // 7. CSS GRID LAB
  renderCssGridPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🔲 CSS Grid Builder & Responsive Auto-Fit',
      'Build modern 2-dimensional layouts. Tweak column counts and gutter gaps to observe perfect responsive reflow.',
      `
        <div class="css-grid-lab-grid">
          <div class="grid-controls">
            <div class="control-subgroup">
              <label class="control-label">Grid Layout Preset:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-preset="repeat(3, 1fr)">3 Equal Columns</button>
                <button class="selector-pill" data-preset="2fr 1fr">Bento (2fr 1fr)</button>
                <button class="selector-pill" data-preset="repeat(auto-fit, minmax(120px, 1fr))">Auto-Fit Responsive</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Grid Gap: <span id="grid-gap-val">16px</span></label>
              <input type="range" id="slider-grid-gap" min="4" max="32" value="16" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <button class="btn-play-action btn-blue" id="btn-shuffle-grid">🎲 Shuffle Card Sizes</button>
            </div>
          </div>

          <div class="grid-preview-side">
            <div class="grid-stage-container" id="grid-stage">
              <div class="grid-card-item g-card-1">Card 1</div>
              <div class="grid-card-item g-card-2">Card 2</div>
              <div class="grid-card-item g-card-3">Card 3</div>
              <div class="grid-card-item g-card-4">Card 4</div>
              <div class="grid-card-item g-card-5">Card 5</div>
              <div class="grid-card-item g-card-6">Card 6</div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Grid Rules:</div>
              <pre><code id="grid-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let preset = 'repeat(3, 1fr)';
    let gap = 16;

    const stage = container.querySelector('#grid-stage');
    const cssCode = container.querySelector('#grid-css-code');
    const gapVal = container.querySelector('#grid-gap-val');

    const updateGrid = () => {
      stage.style.gridTemplateColumns = preset;
      stage.style.gap = `${gap}px`;
      gapVal.textContent = `${gap}px`;

      cssCode.textContent = `.grid-gallery {\n  display: grid;\n  grid-template-columns: ${preset};\n  gap: ${gap}px;\n}`;
    };

    container.querySelectorAll('[data-preset]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-preset]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        preset = btn.getAttribute('data-preset');
        updateGrid();
        sound.playClick();
      });
    });

    container.querySelector('#slider-grid-gap')?.addEventListener('input', (e) => {
      gap = e.target.value;
      updateGrid();
    });

    container.querySelector('#btn-shuffle-grid')?.addEventListener('click', () => {
      container.querySelectorAll('.grid-card-item').forEach(card => {
        const h = 70 + Math.floor(Math.random() * 50);
        card.style.minHeight = `${h}px`;
      });
      sound.playSparkle();
    });

    updateGrid();
  }

  // 8. CSS TRANSITIONS & HOVER MAGIC
  renderCssTransitionsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '✨ Transitions, Hover Magic & 2D Transforms',
      'Experience how cubic-bezier easing curves, scaling, and rotations turn static buttons into tactile interactive controls.',
      `
        <div class="css-trans-grid">
          <div class="trans-controls">
            <div class="control-subgroup">
              <label class="control-label">Hover Animation Style:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-fx="bounce">Bouncy Pop (Scale + Float)</button>
                <button class="selector-pill" data-fx="tilt">3D Tilt & Glow</button>
                <button class="selector-pill" data-fx="rotate">Super Spin (360°)</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Transition Speed: <span id="trans-speed-val">0.3s</span></label>
              <input type="range" id="slider-trans-speed" min="0.1" max="1.5" step="0.1" value="0.3" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Hover or Click the Button:</label>
              <p class="kid-hint-text">Move your cursor over the button on the right to test the hover transition!</p>
            </div>
          </div>

          <div class="trans-preview-side">
            <div class="trans-stage-area">
              <button class="trans-interactive-btn fx-bounce" id="demo-hover-btn">
                <span class="btn-icon">🚀</span>
                <span>Hover Me!</span>
              </button>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Transition & Hover Rules:</div>
              <pre><code id="trans-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let fx = 'bounce';
    let speed = 0.3;

    const btn = container.querySelector('#demo-hover-btn');
    const cssCode = container.querySelector('#trans-css-code');
    const speedVal = container.querySelector('#trans-speed-val');

    const updateTrans = () => {
      btn.className = `trans-interactive-btn fx-${fx}`;
      btn.style.transition = `all ${speed}s cubic-bezier(0.34, 1.56, 0.64, 1)`;
      speedVal.textContent = `${speed}s`;

      let hoverTransform = 'transform: translateY(-8px) scale(1.1);';
      if (fx === 'tilt') hoverTransform = 'transform: rotate(10deg) scale(1.08);';
      if (fx === 'rotate') hoverTransform = 'transform: rotate(360deg) scale(1.1);';

      cssCode.textContent = `.magic-button {\n  transition: all ${speed}s cubic-bezier(0.34, 1.56, 0.64, 1);\n}\n\n.magic-button:hover {\n  ${hoverTransform}\n  box-shadow: 0 12px 28px rgba(16, 185, 129, 0.5);\n}`;
    };

    container.querySelectorAll('[data-fx]').forEach(b => {
      b.addEventListener('click', () => {
        container.querySelectorAll('[data-fx]').forEach(el => el.classList.remove('active'));
        b.classList.add('active');
        fx = b.getAttribute('data-fx');
        updateTrans();
        sound.playPop();
      });
    });

    container.querySelector('#slider-trans-speed')?.addEventListener('input', (e) => {
      speed = e.target.value;
      updateTrans();
    });

    btn.addEventListener('click', () => {
      sound.playSuccess();
    });

    updateTrans();
  }

  // 9. CSS KEYFRAME ANIMATIONS THEATER
  renderCssKeyframesPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🎬 Keyframe Animations Motion Theater',
      'CSS @keyframes run continuous cinematic animations. Choose a UI component below, adjust speed, and pause or reverse the loop!',
      `
        <div class="css-anim-theater-grid">
          <div class="theater-controls">
            <div class="control-subgroup">
              <label class="control-label">Select UI Animation Component:</label>
              <div class="selector-pills-row">
                <button class="selector-pill active" data-actor="badge">🌟 Pulsing Badge</button>
                <button class="selector-pill" data-actor="spinner">⏳ Spinner Loader</button>
                <button class="selector-pill" data-actor="button">🚀 Bouncing Button</button>
                <button class="selector-pill" data-actor="bell">🔔 Shaking Alert</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">Animation Duration: <span id="anim-speed-text">0.8s</span></label>
              <input type="range" id="slider-anim-duration" min="0.2" max="3.0" step="0.1" value="0.8" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Playback Controls:</label>
              <div class="selector-pills-row">
                <button class="btn-play-action" id="btn-toggle-play">⏸️ Pause</button>
                <button class="btn-play-action btn-purple" id="btn-toggle-dir">🔄 Reverse</button>
              </div>
            </div>
          </div>

          <div class="theater-stage-side">
            <div class="theater-stage" id="theater-stage">
              <!-- Actor Container -->
              <div class="theater-actor anim-badge" id="theater-actor">
                <div class="actor-emoji" id="actor-emoji">🌟</div>
                <div class="actor-label" id="actor-label">Pulsing Badge</div>
              </div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS @keyframes Animation Code:</div>
              <pre><code id="keyframes-css-code"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    let actor = 'badge';
    let duration = 0.8;
    let isPaused = false;
    let isReversed = false;

    const actorEl = container.querySelector('#theater-actor');
    const actorEmoji = container.querySelector('#actor-emoji');
    const actorLabel = container.querySelector('#actor-label');
    const cssCode = container.querySelector('#keyframes-css-code');
    const durationText = container.querySelector('#anim-speed-text');
    const playBtn = container.querySelector('#btn-toggle-play');

    const updateActor = () => {
      actorEl.className = `theater-actor anim-${actor}`;
      actorEl.style.animationDuration = `${duration}s`;
      actorEl.style.animationPlayState = isPaused ? 'paused' : 'running';
      actorEl.style.animationDirection = isReversed ? 'reverse' : 'normal';

      durationText.textContent = `${duration}s`;

      if (actor === 'badge') {
        actorEmoji.textContent = '🌟';
        actorLabel.textContent = 'Pulsing Badge';
        cssCode.textContent = `@keyframes badge-pulse {\n  0%, 100% { transform: scale(1); filter: drop-shadow(0 0 8px #f59e0b); }\n  50% { transform: scale(1.18); filter: drop-shadow(0 0 24px #f59e0b); }\n}\n\n.glowing-badge {\n  animation: badge-pulse ${duration}s infinite ease-in-out;\n}`;
      } else if (actor === 'spinner') {
        actorEmoji.textContent = '⏳';
        actorLabel.textContent = 'Spinning Loader';
        cssCode.textContent = `@keyframes spin-loader {\n  0% { transform: rotate(0deg); }\n  100% { transform: rotate(360deg); }\n}\n\n.loading-spinner {\n  animation: spin-loader ${duration}s infinite linear;\n}`;
      } else if (actor === 'button') {
        actorEmoji.textContent = '🚀';
        actorLabel.textContent = 'Bouncing Button';
        cssCode.textContent = `@keyframes bounce-float {\n  0%, 100% { transform: translateY(0); }\n  50% { transform: translateY(-16px) scale(1.05); }\n}\n\n.bouncy-btn {\n  animation: bounce-float ${duration}s infinite ease-in-out;\n}`;
      } else {
        actorEmoji.textContent = '🔔';
        actorLabel.textContent = 'Shaking Alert Bell';
        cssCode.textContent = `@keyframes bell-shake {\n  0%, 100% { transform: rotate(0); }\n  25% { transform: rotate(18deg); }\n  75% { transform: rotate(-18deg); }\n}\n\n.notification-bell {\n  animation: bell-shake ${duration}s infinite ease-in-out;\n}`;
      }
    };

    container.querySelectorAll('[data-actor]').forEach(b => {
      b.addEventListener('click', () => {
        container.querySelectorAll('[data-actor]').forEach(el => el.classList.remove('active'));
        b.classList.add('active');
        actor = b.getAttribute('data-actor');
        updateActor();
        sound.playSparkle();
      });
    });

    container.querySelector('#slider-anim-duration')?.addEventListener('input', (e) => {
      duration = e.target.value;
      updateActor();
    });

    playBtn?.addEventListener('click', () => {
      isPaused = !isPaused;
      playBtn.textContent = isPaused ? '▶️ Play' : '⏸️ Pause';
      updateActor();
      sound.playClick();
    });

    container.querySelector('#btn-toggle-dir')?.addEventListener('click', () => {
      isReversed = !isReversed;
      updateActor();
      sound.playPop();
    });

    updateActor();
  }

  // 10. CSS RESPONSIVE & MEDIA QUERY SIMULATOR
  renderCssResponsivePlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📱 Responsive Viewport & Media Query Simulator',
      'Test how layout transforms dynamically between Mobile (375px), Tablet (600px), and Desktop (100%) screen sizes with CSS Media Queries.',
      `
        <div class="css-resp-simulator-grid">
          <div class="resp-controls">
            <div class="control-subgroup">
              <label class="control-label">Simulated Device Screen:</label>
              <div class="selector-pills-row">
                <button class="selector-pill" data-width="340px">📱 Mobile (340px)</button>
                <button class="selector-pill" data-width="520px">📟 Tablet (520px)</button>
                <button class="selector-pill active" data-width="100%">💻 Desktop (100%)</button>
              </div>
            </div>

            <div class="control-subgroup">
              <div class="active-query-badge" id="media-query-indicator">
                <span>Active Mode: Desktop Layout (@media min-width: 600px)</span>
              </div>
            </div>
          </div>

          <div class="resp-viewport-pane">
            <!-- Simulated Browser Screen Wrapper -->
            <div class="simulated-device-window" id="device-window" style="width: 100%;">
              <div class="simulated-browser-bar">
                <span class="browser-dot dot-red"></span>
                <span class="browser-dot dot-yellow"></span>
                <span class="browser-dot dot-green"></span>
                <span class="browser-url">https://masterjscode.app/responsive</span>
              </div>

              <div class="simulated-web-page" id="simulated-page">
                <header class="sim-nav">
                  <span class="sim-brand">🚀 Web App</span>
                  <div class="sim-links">
                    <span>Home</span>
                    <span>Lessons</span>
                    <span>Profile</span>
                  </div>
                </header>

                <div class="sim-content-body">
                  <div class="sim-main-card">
                    <h3>Responsive Hero Section</h3>
                    <p>On small screens, columns stack vertically. On desktops, they align horizontally!</p>
                  </div>
                  <div class="sim-side-card">
                    <h4>Sidebar Widget</h4>
                    <p>⚡ 100 XP Earned</p>
                  </div>
                </div>
              </div>
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">CSS Responsive Media Query:</div>
              <pre><code id="resp-css-code">/* Default Mobile-First Styles */
.sim-content-body {
  display: flex;
  flex-direction: column;
}

/* Tablet & Desktop Layout */
@media (min-width: 500px) {
  .sim-content-body {
    flex-direction: row;
    gap: 16px;
  }
}</code></pre>
            </div>
          </div>
        </div>
      `
    );

    const deviceWindow = container.querySelector('#device-window');
    const page = container.querySelector('#simulated-page');
    const indicator = container.querySelector('#media-query-indicator');

    container.querySelectorAll('[data-width]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-width]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const targetWidth = btn.getAttribute('data-width');
        deviceWindow.style.width = targetWidth;

        if (targetWidth === '340px') {
          page.classList.add('is-mobile');
          indicator.innerHTML = '<span>Active: 📱 Mobile Layout (Default stacked view)</span>';
        } else if (targetWidth === '520px') {
          page.classList.remove('is-mobile');
          indicator.innerHTML = '<span>Active: 📟 Tablet View (@media min-width: 500px)</span>';
        } else {
          page.classList.remove('is-mobile');
          indicator.innerHTML = '<span>Active: 💻 Desktop Full View (@media min-width: 768px)</span>';
        }
        sound.playClick();
      });
    });
  }

  // ==========================================
  // --- JAVASCRIPT TRACK PLAYGROUNDS ---
  // ==========================================

  // 1. JS INTRO PLAYGROUND
  renderIntroPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '⚡ JavaScript Action & Logic Live Engine',
      'JavaScript powers the interactive behavior of websites. Choose an action below to see real JavaScript expressions execute, compute values, and update the UI in real-time!',
      `
        <div class="intro-playground-grid">
          <!-- Control Panel -->
          <div class="mini-widget-box">
            <div class="widget-subtitle">1. Choose a JavaScript Concept to Execute</div>
            
            <div class="selector-pills-row" style="margin-bottom: 14px;">
              <button class="html-tag-pill active" data-js-action="math">🧮 Math Calculation</button>
              <button class="html-tag-pill" data-js-action="string">💬 Dynamic String</button>
              <button class="html-tag-pill" data-js-action="toggle">🔄 Boolean State</button>
              <button class="html-tag-pill" data-js-action="theme">🎨 Style Mutation</button>
            </div>

            <div id="js-intro-inputs-panel">
              <!-- Dynamic inputs inserted here -->
            </div>

            <div style="margin-top: 14px;">
              <button class="btn-play-action btn-green" id="btn-run-js-intro" style="width: 100%; justify-content: center;">
                ▶ Execute JavaScript (runCode())
              </button>
            </div>
          </div>

          <!-- Live Result Stage -->
          <div class="mini-widget-box">
            <div class="widget-subtitle">2. Live Execution Output & DOM Result</div>
            
            <div class="html-live-stage" id="js-intro-live-stage" style="min-height: 120px; background: #090d16;">
              <!-- Live result will render here -->
            </div>

            <div class="html-code-box" style="margin-top: 10px;">
              <div class="css-code-header">Executed JavaScript Code:</div>
              <pre><code id="js-intro-code-view"></code></pre>
            </div>

            <div class="console-output-box" style="margin-top: 10px; background: #030712; border: 1px solid #1f2937; border-radius: 8px; padding: 10px; font-family: 'Fira Code', monospace; font-size: 0.82rem; color: #34d399;">
              <span style="color: #6b7280;">// console.log output:</span>
              <div id="js-intro-console-log" style="margin-top: 4px;">Ready to execute code...</div>
            </div>
          </div>
        </div>
      `
    );

    let activeConcept = 'math';
    const inputsPanel = container.querySelector('#js-intro-inputs-panel');
    const stage = container.querySelector('#js-intro-live-stage');
    const codeView = container.querySelector('#js-intro-code-view');
    const consoleLog = container.querySelector('#js-intro-console-log');
    const runBtn = container.querySelector('#btn-run-js-intro');

    let numA = 25;
    let numB = 15;
    let userName = 'Alex';
    let isStatusOnline = true;
    let activeColor = '#10b981';

    const renderInputs = () => {
      if (activeConcept === 'math') {
        inputsPanel.innerHTML = `
          <div style="display: flex; gap: 10px; align-items: center;">
            <div style="flex: 1;">
              <label class="control-label" style="font-size: 0.75rem;">Number A:</label>
              <input type="number" id="input-num-a" value="${numA}" class="kid-input" style="width:100%; padding:6px 10px;" />
            </div>
            <span style="color: #f59e0b; font-weight: 900; font-size: 1.2rem; margin-top: 14px;">+</span>
            <div style="flex: 1;">
              <label class="control-label" style="font-size: 0.75rem;">Number B:</label>
              <input type="number" id="input-num-b" value="${numB}" class="kid-input" style="width:100%; padding:6px 10px;" />
            </div>
          </div>
        `;
        inputsPanel.querySelector('#input-num-a')?.addEventListener('input', (e) => {
          numA = parseFloat(e.target.value) || 0;
        });
        inputsPanel.querySelector('#input-num-b')?.addEventListener('input', (e) => {
          numB = parseFloat(e.target.value) || 0;
        });
      } else if (activeConcept === 'string') {
        inputsPanel.innerHTML = `
          <div>
            <label class="control-label" style="font-size: 0.75rem;">User Name (String):</label>
            <input type="text" id="input-username" value="${userName}" class="kid-input" style="width:100%; padding:6px 10px;" />
          </div>
        `;
        inputsPanel.querySelector('#input-username')?.addEventListener('input', (e) => {
          userName = e.target.value || 'User';
        });
      } else if (activeConcept === 'toggle') {
        inputsPanel.innerHTML = `
          <div>
            <label class="control-label" style="font-size: 0.75rem;">Current Boolean State:</label>
            <div style="color: #93c5fd; font-family: monospace; font-size: 0.9rem; padding: 6px 0;">
              let isOnline = <strong>${isStatusOnline}</strong>;
            </div>
          </div>
        `;
      } else {
        inputsPanel.innerHTML = `
          <div>
            <label class="control-label" style="font-size: 0.75rem;">Pick Accent Color:</label>
            <div class="selector-pills-row">
              <button class="preset-pill ${activeColor === '#10b981' ? 'active' : ''}" data-col="#10b981">Emerald</button>
              <button class="preset-pill ${activeColor === '#38bdf8' ? 'active' : ''}" data-col="#38bdf8">Sky Blue</button>
              <button class="preset-pill ${activeColor === '#a855f7' ? 'active' : ''}" data-col="#a855f7">Purple</button>
              <button class="preset-pill ${activeColor === '#f59e0b' ? 'active' : ''}" data-col="#f59e0b">Amber</button>
            </div>
          </div>
        `;
        inputsPanel.querySelectorAll('[data-col]').forEach(btn => {
          btn.addEventListener('click', () => {
            activeColor = btn.getAttribute('data-col');
            inputsPanel.querySelectorAll('[data-col]').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
          });
        });
      }
    };

    const executeCode = () => {
      sound.play('click');
      if (activeConcept === 'math') {
        const sum = numA + numB;
        stage.innerHTML = `
          <div style="text-align: center;">
            <div style="font-size: 0.8rem; color: #94a3b8; font-weight: 700;">CALCULATED SUM</div>
            <div style="font-size: 2.2rem; font-weight: 900; color: #10b981; font-family: 'Fira Code', monospace; margin: 4px 0;">
              ${numA} + ${numB} = ${sum}
            </div>
            <div style="font-size: 0.82rem; color: #cbd5e1;">JavaScript calculated the numeric addition instantly!</div>
          </div>
        `;
        codeView.textContent = `let numA = ${numA};\nlet numB = ${numB};\nlet sum = numA + numB;\n\nconsole.log("Calculated Sum:", sum); // Output: ${sum}`;
        consoleLog.textContent = `> Calculated Sum: ${sum}`;
      } else if (activeConcept === 'string') {
        const timeStr = new Date().toLocaleTimeString();
        const greeting = `Hello, ${userName}! Welcome to JavaScript.`;
        stage.innerHTML = `
          <div style="text-align: center;">
            <div style="font-size: 1.3rem; font-weight: 800; color: #38bdf8;">👋 ${greeting}</div>
            <div style="font-size: 0.8rem; color: #94a3b8; margin-top: 6px;">Generated at: ${timeStr}</div>
          </div>
        `;
        codeView.textContent = `let userName = "${userName}";\nlet greeting = "Hello, " + userName + "! Welcome to JavaScript.";\n\nconsole.log(greeting);`;
        consoleLog.textContent = `> "${greeting}"`;
      } else if (activeConcept === 'toggle') {
        isStatusOnline = !isStatusOnline;
        renderInputs();
        const statusColor = isStatusOnline ? '#10b981' : '#64748b';
        const statusText = isStatusOnline ? 'ONLINE & READY' : 'OFFLINE (IDLE)';
        stage.innerHTML = `
          <div style="display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.05); padding: 12px 20px; border-radius: 10px; border: 1px solid #334155;">
            <div style="width: 14px; height: 14px; border-radius: 50%; background: ${statusColor}; box-shadow: 0 0 10px ${statusColor};"></div>
            <div>
              <div style="font-weight: 800; font-size: 1rem; color: #f8fafc;">User Status: ${statusText}</div>
              <div style="font-size: 0.75rem; color: #94a3b8;">isOnline = ${isStatusOnline}</div>
            </div>
          </div>
        `;
        codeView.textContent = `let isOnline = ${!isStatusOnline};\nisOnline = !isOnline; // Flipped value to: ${isStatusOnline}\n\nif (isOnline) {\n  statusBadge.style.background = "#10b981";\n} else {\n  statusBadge.style.background = "#64748b";\n}`;
        consoleLog.textContent = `> isOnline is now: ${isStatusOnline}`;
      } else {
        stage.innerHTML = `
          <div style="background: ${activeColor}22; border: 2px solid ${activeColor}; padding: 16px 24px; border-radius: 12px; text-align: center; box-shadow: 0 0 20px ${activeColor}44;">
            <div style="color: ${activeColor}; font-weight: 900; font-size: 1.1rem;">Dynamic Style Mutation</div>
            <div style="color: #f1f5f9; font-size: 0.85rem; margin-top: 4px;">Accent color updated to: <code>${activeColor}</code></div>
          </div>
        `;
        codeView.textContent = `let card = document.querySelector("#preview-card");\ncard.style.borderColor = "${activeColor}";\ncard.style.boxShadow = "0 0 20px ${activeColor}44";\n\nconsole.log("Updated style color to ${activeColor}");`;
        consoleLog.textContent = `> Style color applied: "${activeColor}"`;
      }
    };

    container.querySelectorAll('[data-js-action]').forEach(btn => {
      btn.addEventListener('click', () => {
        sound.play('click');
        container.querySelectorAll('[data-js-action]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        activeConcept = btn.getAttribute('data-js-action');
        renderInputs();
        executeCode();
      });
    });

    runBtn?.addEventListener('click', () => {
      executeCode();
    });

    renderInputs();
    executeCode();
  }

  // 2. HTML AND JS SYNERGY PLAYGROUND
  renderHtmlAndJsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🌐 HTML Elements + JavaScript DOM Live Sandbox',
      'See exactly how JavaScript controls HTML tags in real-time. Type text, change styles, and trigger DOM mutations!',
      `
        <div class="html-js-sandbox-grid">
          <!-- Control Panel -->
          <div class="sandbox-input-panel">
            <div class="control-subgroup">
              <label class="control-label">1. Edit HTML Heading Text:</label>
              <div class="input-with-action">
                <input type="text" id="dom-text-input" value="Super Cool Heading" class="kid-input" placeholder="Type new text..." />
                <button class="btn-play-action" id="btn-update-text">title.textContent = val</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">2. Change Button Style Dynamically:</label>
              <div class="color-palette-row">
                <button class="color-dot-btn active" style="background:#10b981;" data-bg="#10b981" title="Emerald"></button>
                <button class="color-dot-btn" style="background:#38bdf8;" data-bg="#38bdf8" title="Sky Blue"></button>
                <button class="color-dot-btn" style="background:#ec4899;" data-bg="#ec4899" title="Pink"></button>
                <button class="color-dot-btn" style="background:#8b5cf6;" data-bg="#8b5cf6" title="Purple"></button>
                <button class="color-dot-btn" style="background:#f59e0b;" data-bg="#f59e0b" title="Amber"></button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">3. Add New HTML Elements Dynamically:</label>
              <button class="btn-play-action btn-purple" id="btn-add-badge">➕ document.createElement("span")</button>
            </div>
          </div>

          <!-- Live HTML Target View -->
          <div class="sandbox-stage-panel">
            <div class="dom-preview-card" id="dom-target-card">
              <h2 id="live-dom-heading" class="live-heading">Super Cool Heading</h2>
              <p class="live-desc">This HTML is rendered live inside the DOM container.</p>
              
              <div class="badges-shelf" id="badges-shelf">
                <span class="live-badge">🚀 Initial Tag</span>
              </div>

              <div class="actions-shelf">
                <button id="live-dom-button" class="live-interactive-btn">Interactive HTML Button</button>
              </div>
            </div>

            <!-- Code Explanation Box -->
            <div class="dom-code-peek">
              <div class="code-peek-title">DOM Method Executed:</div>
              <pre><code id="dom-action-code">// Click any button above to see JavaScript DOM code!</code></pre>
            </div>
          </div>
        </div>
      `
    );

    const input = container.querySelector('#dom-text-input');
    const heading = container.querySelector('#live-dom-heading');
    const button = container.querySelector('#live-dom-button');
    const shelf = container.querySelector('#badges-shelf');
    const codePeek = container.querySelector('#dom-action-code');

    container.querySelector('#btn-update-text')?.addEventListener('click', () => {
      heading.textContent = input.value || 'Awesome Heading';
      codePeek.textContent = `const heading = document.getElementById("live-dom-heading");\nheading.textContent = "${input.value}";`;
      sound.playClick();
    });

    container.querySelectorAll('.color-dot-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        const bg = btn.getAttribute('data-bg');
        button.style.backgroundColor = bg;
        button.style.boxShadow = `0 4px 15px ${bg}88`;
        codePeek.textContent = `const btn = document.getElementById("live-dom-button");\nbtn.style.backgroundColor = "${bg}";\nbtn.style.boxShadow = "0 4px 15px ${bg}88";`;
        sound.playPop();
      });
    });

    let badgeCount = 1;
    container.querySelector('#btn-add-badge')?.addEventListener('click', () => {
      badgeCount++;
      const newBadge = document.createElement('span');
      newBadge.className = 'live-badge badge-pop';
      newBadge.textContent = `✨ Badge #${badgeCount}`;
      shelf.appendChild(newBadge);
      codePeek.textContent = `const badge = document.createElement("span");\nbadge.className = "live-badge";\nbadge.textContent = "✨ Badge #${badgeCount}";\ndocument.getElementById("badges-shelf").appendChild(badge);`;
      sound.playSparkle();
    });

    button.addEventListener('click', () => {
      button.classList.add('btn-bounce');
      setTimeout(() => button.classList.remove('btn-bounce'), 300);
      codePeek.textContent = `button.addEventListener("click", () => {\n  console.log("HTML Button was clicked by user!");\n});`;
      sound.playSuccess();
    });
  }

  // 3. OUTPUT & CONSOLE PLAYGROUND
  renderOutputPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '💻 JavaScript Output Studio',
      'Test the 4 ways JavaScript displays data: console.log(), console.table(), DOM innerHTML, and live notifications.',
      `
        <div class="playground-grid-split">
          <div class="playground-col">
            <label class="playground-control-label">Pick an Output Method:</label>
            <div class="playground-btn-row">
              <button class="btn-play-action" id="btn-out-log">console.log("Hello")</button>
              <button class="btn-play-action btn-blue" id="btn-out-table">console.table(users)</button>
              <button class="btn-play-action btn-purple" id="btn-out-dom">document.write()</button>
              <button class="btn-play-action btn-warning" id="btn-out-warn">console.warn()</button>
            </div>
            <div class="playground-input-group">
              <label class="playground-control-label">Custom Message:</label>
              <input type="text" id="custom-log-input" class="kid-input" placeholder="Type a message..." value="Hello from JavaScript!" />
            </div>
          </div>

          <div class="playground-col">
            <label class="playground-control-label">Output Monitor:</label>
            <div class="mini-console-monitor" id="out-monitor">
              <div class="console-line-row">Output will stream here in real-time...</div>
            </div>
          </div>
        </div>
      `
    );

    const monitor = container.querySelector('#out-monitor');
    const input = container.querySelector('#custom-log-input');

    const logToMonitor = (text, type = 'log') => {
      const line = document.createElement('div');
      line.className = `console-line-row line-${type}`;
      line.innerHTML = `<span class="time-stamp">${new Date().toLocaleTimeString()}</span> ${text}`;
      monitor.appendChild(line);
      monitor.scrollTop = monitor.scrollHeight;
    };

    container.querySelector('#btn-out-log')?.addEventListener('click', () => {
      logToMonitor(`[LOG]: ${input.value}`, 'log');
      sound.playPop();
    });

    container.querySelector('#btn-out-warn')?.addEventListener('click', () => {
      logToMonitor(`⚠️ [WARN]: Watch out! Memory threshold reached.`, 'warn');
      sound.playClick();
    });

    container.querySelector('#btn-out-table')?.addEventListener('click', () => {
      logToMonitor(`📊 [TABLE]: Users Table: Alex (Lv 12), Mia (Lv 15), Sam (Lv 9)`, 'table');
      sound.playSparkle();
    });

    container.querySelector('#btn-out-dom')?.addEventListener('click', () => {
      logToMonitor(`🌐 [DOM]: Updated innerHTML of #app container.`, 'dom');
      sound.playSuccess();
    });
  }

  // 4. VARIABLES PLAYGROUND
  renderVariablesPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🏷️ Variables & Memory Inspector',
      'See how let, const, and var store values in memory. Try reassigning variables and observe error handling in real-time.',
      `
        <div class="variables-playground-layout">
          <div class="memory-boxes-grid">
            <div class="memory-card" id="mem-const">
              <div class="mem-badge const-badge">const</div>
              <div class="mem-var-name">APP_NAME</div>
              <div class="mem-value-box" id="val-const">"Master JS"</div>
              <button class="mini-mutate-btn" id="btn-mutate-const" title="Try reassigning const">Try Change</button>
            </div>

            <div class="memory-card" id="mem-let">
              <div class="mem-badge let-badge">let</div>
              <div class="mem-var-name">score</div>
              <div class="mem-value-box" id="val-let">100</div>
              <div class="mem-actions">
                <button class="mini-mutate-btn" id="btn-add-score">+ 50</button>
                <button class="mini-mutate-btn" id="btn-sub-score">- 25</button>
              </div>
            </div>

            <div class="memory-card" id="mem-flag">
              <div class="mem-badge let-badge">let</div>
              <div class="mem-var-name">isOnline</div>
              <div class="mem-value-box" id="val-flag">true</div>
              <button class="mini-mutate-btn" id="btn-toggle-flag">Toggle</button>
            </div>
          </div>

          <div class="variable-log-panel" id="var-log-panel">
            <div class="var-log-title">Variable Operation Log:</div>
            <div class="var-log-feed" id="var-feed">Ready to inspect variables!</div>
          </div>
        </div>
      `
    );

    let score = 100;
    let isOnline = true;
    const scoreVal = container.querySelector('#val-let');
    const flagVal = container.querySelector('#val-flag');
    const feed = container.querySelector('#var-feed');

    const logVar = (msg, isErr = false) => {
      feed.innerHTML = `<span class="${isErr ? 'err-text' : 'ok-text'}">${msg}</span>`;
      if (isErr) sound.playClick();
      else sound.playSuccess();
    };

    container.querySelector('#btn-mutate-const')?.addEventListener('click', () => {
      logVar(`❌ TypeError: Assignment to constant variable APP_NAME is forbidden!`, true);
    });

    container.querySelector('#btn-add-score')?.addEventListener('click', () => {
      score += 50;
      scoreVal.textContent = score;
      logVar(`✅ score = ${score}; (Memory updated successfully)`);
    });

    container.querySelector('#btn-sub-score')?.addEventListener('click', () => {
      score = Math.max(0, score - 25);
      scoreVal.textContent = score;
      logVar(`✅ score = ${score}; (Memory updated successfully)`);
    });

    container.querySelector('#btn-toggle-flag')?.addEventListener('click', () => {
      isOnline = !isOnline;
      flagVal.textContent = String(isOnline);
      logVar(`✅ isOnline = ${isOnline}; (Boolean flag flipped)`);
    });
  }

  // 5. DATA TYPES & TYPEOF INSPECTOR
  renderDataTypesPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🔬 typeof & Primitive Types Inspector',
      'JavaScript has 7 primitive data types plus Objects. Click each type below to see its value, type, and memory footprint.',
      `
        <div class="datatypes-grid">
          <div class="type-buttons-shelf">
            <button class="type-pill-btn active" data-val='"JavaScript"' data-type="string">String</button>
            <button class="type-pill-btn" data-val="2025" data-type="number">Number</button>
            <button class="type-pill-btn" data-val="true" data-type="boolean">Boolean</button>
            <button class="type-pill-btn" data-val="null" data-type="object">null</button>
            <button class="type-pill-btn" data-val="undefined" data-type="undefined">undefined</button>
            <button class="type-pill-btn" data-val='{ id: 1, name: "Alex" }' data-type="object">Object</button>
            <button class="type-pill-btn" data-val='[10, 20, 30]' data-type="object">Array</button>
          </div>

          <div class="type-inspector-card" id="type-inspector-card">
            <div class="inspector-header">
              <span class="inspector-badge" id="insp-type-badge">string</span>
              <span class="inspector-fn">typeof value === <strong id="insp-type-res">"string"</strong></span>
            </div>
            <div class="inspector-body">
              <div class="insp-val-display" id="insp-val-display">"JavaScript"</div>
            </div>
          </div>
        </div>
      `
    );

    const badge = container.querySelector('#insp-type-badge');
    const res = container.querySelector('#insp-type-res');
    const valDisplay = container.querySelector('#insp-val-display');

    container.querySelectorAll('.type-pill-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.type-pill-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const val = btn.getAttribute('data-val');
        const type = btn.getAttribute('data-type');

        badge.textContent = type;
        res.textContent = `"${type}"`;
        valDisplay.textContent = val;
        sound.playPop();
      });
    });
  }

  // 6. OPERATORS PLAYGROUND
  renderOperatorsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🧮 Interactive Operator Calculator',
      'Test arithmetic, strict comparison (=== vs ==), logical operators (&&, ||), and ternary conditionals.',
      `
        <div class="operators-grid-layout">
          <div class="op-input-col">
            <label class="control-label">Operand A:</label>
            <input type="number" id="op-val-a" class="kid-input" value="10" />
            
            <label class="control-label" style="margin-top: 10px;">Operand B:</label>
            <input type="number" id="op-val-b" class="kid-input" value="5" />
          </div>

          <div class="op-actions-col">
            <div class="op-button-matrix">
              <button class="op-calc-btn active" data-op="+">A + B</button>
              <button class="op-calc-btn" data-op="-">A - B</button>
              <button class="op-calc-btn" data-op="*">A * B</button>
              <button class="op-calc-btn" data-op="/">A / B</button>
              <button class="op-calc-btn" data-op="%">A % B</button>
              <button class="op-calc-btn" data-op="===">A === B</button>
              <button class="op-calc-btn" data-op=">">A &gt; B</button>
            </div>
          </div>

          <div class="op-result-col">
            <div class="calc-result-box">
              <div class="res-equation" id="res-equation">10 + 5</div>
              <div class="res-number" id="res-number">15</div>
            </div>
          </div>
        </div>
      `
    );

    const inputA = container.querySelector('#op-val-a');
    const inputB = container.querySelector('#op-val-b');
    const eq = container.querySelector('#res-equation');
    const num = container.querySelector('#res-number');

    let currentOp = '+';

    const recalculate = () => {
      const a = Number(inputA.value) || 0;
      const b = Number(inputB.value) || 0;
      let ans = 0;

      if (currentOp === '+') ans = a + b;
      if (currentOp === '-') ans = a - b;
      if (currentOp === '*') ans = a * b;
      if (currentOp === '/') ans = b !== 0 ? (a / b).toFixed(2) : 'Infinity';
      if (currentOp === '%') ans = b !== 0 ? a % b : 'NaN';
      if (currentOp === '===') ans = (a === b).toString();
      if (currentOp === '>') ans = (a > b).toString();

      eq.textContent = `${a} ${currentOp} ${b}`;
      num.textContent = ans;
    };

    container.querySelectorAll('.op-calc-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('.op-calc-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentOp = btn.getAttribute('data-op');
        recalculate();
        sound.playPop();
      });
    });

    inputA.addEventListener('input', recalculate);
    inputB.addEventListener('input', recalculate);
  }

  // 7. CONDITIONALS PLAYGROUND
  renderConditionalsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🚦 Decision Logic: Traffic Light Controller',
      'Test if/else if/else and switch statements with an interactive traffic light system.',
      `
        <div class="conditionals-grid-layout">
          <div class="traffic-light-fixture">
            <div class="traffic-lamp lamp-red" id="lamp-red"></div>
            <div class="traffic-lamp lamp-yellow" id="lamp-yellow"></div>
            <div class="traffic-lamp lamp-green" id="lamp-green"></div>
          </div>

          <div class="traffic-controls">
            <label class="control-label">Set Traffic Signal:</label>
            <div class="selector-pills-row">
              <button class="selector-pill active" id="btn-sig-green">signal = "green"</button>
              <button class="selector-pill" id="btn-sig-yellow">signal = "yellow"</button>
              <button class="selector-pill" id="btn-sig-red">signal = "red"</button>
            </div>

            <div class="logic-decision-box" id="logic-decision-box">
              <div class="decision-title">Executed Branch:</div>
              <pre><code id="decision-code">if (signal === "green") {
  car.drive(); // ✅ Green Light!
}</code></pre>
            </div>
          </div>
        </div>
      `
    );

    const lampRed = container.querySelector('#lamp-red');
    const lampYellow = container.querySelector('#lamp-yellow');
    const lampGreen = container.querySelector('#lamp-green');
    const code = container.querySelector('#decision-code');

    const setSignal = (sig) => {
      lampRed.classList.toggle('lamp-lit', sig === 'red');
      lampYellow.classList.toggle('lamp-lit', sig === 'yellow');
      lampGreen.classList.toggle('lamp-lit', sig === 'green');

      if (sig === 'green') {
        code.textContent = `if (signal === "green") {\n  car.drive(); // 🟢 Green Light - Safe to drive!\n}`;
      } else if (sig === 'yellow') {
        code.textContent = `else if (signal === "yellow") {\n  car.slowDown(); // 🟡 Caution - Prepare to stop!\n}`;
      } else {
        code.textContent = `else {\n  car.stop(); // 🔴 Red Light - Full Stop!\n}`;
      }
      sound.playClick();
    };

    container.querySelector('#btn-sig-green')?.addEventListener('click', (e) => {
      container.querySelectorAll('.selector-pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      setSignal('green');
    });

    container.querySelector('#btn-sig-yellow')?.addEventListener('click', (e) => {
      container.querySelectorAll('.selector-pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      setSignal('yellow');
    });

    container.querySelector('#btn-sig-red')?.addEventListener('click', (e) => {
      container.querySelectorAll('.selector-pill').forEach(p => p.classList.remove('active'));
      e.target.classList.add('active');
      setSignal('red');
    });

    setSignal('green');
  }

  // 8. LOOPS PLAYGROUND
  renderLoopsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🔁 Loop Engine & Visual Step Iterator',
      'Step through for and while loops visually. Watch loop indices increment and elements spawn step-by-step.',
      `
        <div class="loops-playground-grid">
          <div class="loop-controls-pane">
            <div class="control-subgroup">
              <label class="control-label">Loop Iterations: <span id="loop-count-text">5</span></label>
              <input type="range" id="slider-loop-count" min="1" max="10" value="5" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <button class="btn-play-action btn-green" id="btn-run-loop">▶️ Run Loop</button>
              <button class="btn-play-action btn-purple" id="btn-step-loop">⏭️ Step Once</button>
            </div>
          </div>

          <div class="loop-stage-pane">
            <div class="loop-spawn-shelf" id="loop-spawn-shelf">
              <!-- Spawned Items appear here -->
            </div>

            <div class="generated-css-box">
              <div class="css-code-header">Loop Code:</div>
              <pre><code id="loop-code-display">for (let i = 0; i &lt; 5; i++) {
  spawnItem(i);
}</code></pre>
            </div>
          </div>
        </div>
      `
    );

    let maxLoops = 5;
    let currentStep = 0;
    const shelf = container.querySelector('#loop-spawn-shelf');
    const codeDisplay = container.querySelector('#loop-code-display');
    const countText = container.querySelector('#loop-count-text');

    const updateLoopView = () => {
      shelf.innerHTML = '';
      for (let i = 0; i < currentStep; i++) {
        const item = document.createElement('div');
        item.className = 'loop-toy-box pop-in';
        item.textContent = `📦 i = ${i}`;
        shelf.appendChild(item);
      }
    };

    container.querySelector('#slider-loop-count')?.addEventListener('input', (e) => {
      maxLoops = parseInt(e.target.value, 10);
      countText.textContent = maxLoops;
      codeDisplay.textContent = `for (let i = 0; i < ${maxLoops}; i++) {\n  spawnItem(i);\n}`;
      currentStep = 0;
      updateLoopView();
    });

    container.querySelector('#btn-run-loop')?.addEventListener('click', () => {
      currentStep = maxLoops;
      updateLoopView();
      sound.playSuccess();
    });

    container.querySelector('#btn-step-loop')?.addEventListener('click', () => {
      if (currentStep < maxLoops) {
        currentStep++;
        updateLoopView();
        sound.playPop();
      } else {
        currentStep = 0;
        updateLoopView();
      }
    });
  }

  // 9. FUNCTIONS PLAYGROUND
  renderFunctionsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '⚙️ Function Machine: Input & Output',
      'A function takes arguments (Inputs), processes them, and returns a Result (Output).',
      `
        <div class="function-machine-grid">
          <div class="machine-input-side">
            <label class="control-label">Argument A (base):</label>
            <input type="number" id="fn-arg-a" class="kid-input" value="4" />

            <label class="control-label" style="margin-top:8px;">Argument B (multiplier):</label>
            <input type="number" id="fn-arg-b" class="kid-input" value="3" />
            
            <button class="btn-play-action btn-green" id="btn-call-fn" style="margin-top:12px;">calculate(a, b)</button>
          </div>

          <div class="machine-diagram-side">
            <div class="machine-core-box">
              <div class="machine-title">function calculate(a, b)</div>
              <div class="machine-formula">return (a * b) + 10;</div>
            </div>

            <div class="machine-return-box">
              <span class="ret-label">Return Value:</span>
              <span class="ret-val" id="fn-return-val">22</span>
            </div>
          </div>
        </div>
      `
    );

    const argA = container.querySelector('#fn-arg-a');
    const argB = container.querySelector('#fn-arg-b');
    const retVal = container.querySelector('#fn-return-val');

    container.querySelector('#btn-call-fn')?.addEventListener('click', () => {
      const a = Number(argA.value) || 0;
      const b = Number(argB.value) || 0;
      const result = (a * b) + 10;
      retVal.textContent = result;
      sound.playSuccess();
    });
  }

  // 10. CLOSURES PLAYGROUND
  renderClosuresPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🔒 Closure Bank Account: Private Scope',
      'Closures allow inner functions to retain access to variables in outer functions even after the outer function has finished execution.',
      `
        <div class="closure-grid">
          <div class="closure-controls">
            <div class="bank-vault-card">
              <div class="vault-label">Private Variable (balance)</div>
              <div class="vault-amount">$<span id="vault-balance">100</span></div>
            </div>

            <div class="closure-actions">
              <button class="btn-play-action btn-green" id="btn-deposit">deposit(50)</button>
              <button class="btn-play-action btn-warning" id="btn-withdraw">withdraw(25)</button>
            </div>
          </div>

          <div class="closure-code-side">
            <div class="generated-css-box">
              <div class="css-code-header">Closure JavaScript Code:</div>
              <pre><code>function createAccount(initial) {
  let balance = initial; // 🔒 Private variable!

  return {
    deposit: (amt) => balance += amt,
    withdraw: (amt) => balance -= amt,
    getBalance: () => balance
  };
}</code></pre>
            </div>
          </div>
        </div>
      `
    );

    let balance = 100;
    const balanceText = container.querySelector('#vault-balance');

    container.querySelector('#btn-deposit')?.addEventListener('click', () => {
      balance += 50;
      balanceText.textContent = balance;
      sound.playSuccess();
    });

    container.querySelector('#btn-withdraw')?.addEventListener('click', () => {
      balance = Math.max(0, balance - 25);
      balanceText.textContent = balance;
      sound.playClick();
    });
  }

  // 11. OBJECTS PLAYGROUND
  renderObjectsPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📦 JavaScript Object Inspector & Property Mutator',
      'Objects group related data into key-value properties. Mutate properties in real-time and see how the object state updates in memory.',
      `
        <div class="objects-playground-grid">
          <div class="obj-controls">
            <div class="control-subgroup">
              <label class="control-label">User Profile Name:</label>
              <input type="text" id="obj-user-name" class="kid-input" value="Alex Coder" />
            </div>

            <div class="control-subgroup">
              <label class="control-label">Developer Role:</label>
              <div class="selector-pills-row" id="role-picker-row">
                <button class="selector-pill active" data-role="Frontend Dev">Frontend Dev</button>
                <button class="selector-pill" data-role="Fullstack">Fullstack</button>
                <button class="selector-pill" data-role="UI Engineer">UI Engineer</button>
              </div>
            </div>

            <div class="control-subgroup">
              <label class="control-label">XP Level: <span id="obj-lvl-text">15</span></label>
              <input type="range" id="slider-obj-lvl" min="1" max="50" value="15" class="kid-slider" />
            </div>

            <div class="control-subgroup">
              <button class="btn-play-action btn-purple" id="btn-add-skill">➕ Add Skill (skills.push())</button>
            </div>
          </div>

          <div class="obj-preview-side">
            <div class="generated-css-box">
              <div class="css-code-header">Object in Memory (JSON.stringify(userProfile)):</div>
              <pre><code id="obj-json-display"></code></pre>
            </div>
          </div>
        </div>
      `
    );

    const nameInput = container.querySelector('#obj-user-name');
    const lvlSlider = container.querySelector('#slider-obj-lvl');
    const lvlText = container.querySelector('#obj-lvl-text');
    const jsonDisplay = container.querySelector('#obj-json-display');

    let currentRole = 'Frontend Dev';
    let skills = ['JavaScript', 'HTML5', 'CSS3'];

    const updateObj = () => {
      const userProfile = {
        name: nameInput.value || 'Anonymous',
        role: currentRole,
        level: parseInt(lvlSlider.value, 10),
        isActive: true,
        skills: skills
      };
      lvlText.textContent = lvlSlider.value;
      jsonDisplay.textContent = JSON.stringify(userProfile, null, 2);
    };

    nameInput.addEventListener('input', updateObj);
    lvlSlider.addEventListener('input', updateObj);

    container.querySelectorAll('[data-role]').forEach(btn => {
      btn.addEventListener('click', () => {
        container.querySelectorAll('[data-role]').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentRole = btn.getAttribute('data-role');
        updateObj();
        sound.playPop();
      });
    });

    container.querySelector('#btn-add-skill')?.addEventListener('click', () => {
      const availableSkills = ['TypeScript', 'React', 'Node.js', 'TailwindCSS', 'GraphQL', 'Next.js'];
      const nextSkill = availableSkills.find(s => !skills.includes(s));
      if (nextSkill) {
        skills.push(nextSkill);
        updateObj();
        sound.playSparkle();
      }
    });

    updateObj();
  }

  // 12. ARRAYS PLAYGROUND
  renderArraysPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '📚 Array Methods: push, pop, shift, unshift & map',
      'Arrays are ordered lists. Test mutating and higher-order array methods visually.',
      `
        <div class="arrays-playground-grid">
          <div class="arr-controls">
            <button class="btn-play-action btn-green" id="btn-arr-push">push("🌟")</button>
            <button class="btn-play-action btn-warning" id="btn-arr-pop">pop()</button>
            <button class="btn-play-action btn-blue" id="btn-arr-unshift">unshift("💎")</button>
            <button class="btn-play-action btn-purple" id="btn-arr-shift">shift()</button>
          </div>

          <div class="arr-display-shelf" id="arr-shelf"></div>
        </div>
      `
    );

    let items = ['🍎', '🍌', '🍇'];
    const shelf = container.querySelector('#arr-shelf');

    const updateArr = () => {
      shelf.innerHTML = items.map((it, idx) => `
        <div class="arr-item-box pop-in">
          <span class="arr-idx">[${idx}]</span>
          <span class="arr-val">${it}</span>
        </div>
      `).join('');
    };

    container.querySelector('#btn-arr-push')?.addEventListener('click', () => {
      items.push('🌟');
      updateArr();
      sound.playPop();
    });

    container.querySelector('#btn-arr-pop')?.addEventListener('click', () => {
      items.pop();
      updateArr();
      sound.playClick();
    });

    container.querySelector('#btn-arr-unshift')?.addEventListener('click', () => {
      items.unshift('💎');
      updateArr();
      sound.playPop();
    });

    container.querySelector('#btn-arr-shift')?.addEventListener('click', () => {
      items.shift();
      updateArr();
      sound.playClick();
    });

    updateArr();
  }

  // 13. CLASSES & OOP PLAYGROUND
  renderClassesPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🏗️ Object-Oriented Programming (Classes & Inheritance)',
      'Classes act as blueprints for creating structured objects. Instantiate instances from the base class and subclass with methods!',
      `
        <div class="classes-playground-grid">
          <div class="class-controls">
            <button class="btn-play-action btn-green" id="btn-spawn-user">
              ➕ new UserAccount("Alice", "Standard")
            </button>
            <button class="btn-play-action btn-purple" id="btn-spawn-admin">
              👑 new AdminAccount("David", ["deploy", "manage"])
            </button>
          </div>

          <div class="hero-roster-shelf" id="classes-instance-shelf">
            <!-- Instantiated objects will appear here -->
          </div>
        </div>
      `
    );

    const shelf = container.querySelector('#classes-instance-shelf');

    const addInstanceCard = (name, role, tag, permissions) => {
      const card = document.createElement('div');
      card.className = 'hero-character-card pop-in';
      card.style.background = '#161b22';
      card.style.border = tag.includes('Admin') ? '1px solid #a855f7' : '1px solid #10b981';
      card.innerHTML = `
        <div class="hero-type-tag" style="background: ${tag.includes('Admin') ? '#a855f7' : '#10b981'}; color: white;">
          ${tag}
        </div>
        <h4 style="color: #f0f6fc; margin: 6px 0 2px;">${name}</h4>
        <p style="color: #8b949e; font-size: 0.82rem;">Role: <strong style="color:#c9d1d9;">${role}</strong></p>
        <p style="color: #8b949e; font-size: 0.78rem;">Permissions: <code>${permissions}</code></p>
      `;
      shelf.appendChild(card);
      sound.playSuccess();
    };

    container.querySelector('#btn-spawn-user')?.addEventListener('click', () => {
      addInstanceCard('Alice', 'Standard Member', 'class UserAccount', 'read:courses');
    });

    container.querySelector('#btn-spawn-admin')?.addEventListener('click', () => {
      addInstanceCard('David', 'Platform Admin', 'class AdminAccount extends UserAccount', 'read, write, deploy');
    });
  }

  // 14. ASYNC / PROMISES PLAYGROUND
  renderAsyncPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '⏱️ Asynchronous JavaScript & Promises',
      'Experience async/await and fake API fetching with loading spinners and error handling.',
      `
        <div class="async-grid">
          <button class="btn-play-action btn-green" id="btn-fetch-data">⚡ fetch("/api/user")</button>
          <div class="async-status-card" id="async-card">
            <span id="async-status-text">Click to trigger async network request</span>
          </div>
        </div>
      `
    );

    const card = container.querySelector('#async-card');
    const text = container.querySelector('#async-status-text');

    container.querySelector('#btn-fetch-data')?.addEventListener('click', () => {
      text.textContent = '⏳ Loading data from server... (Pending)';
      card.classList.add('loading-pulse');
      sound.playClick();

      setTimeout(() => {
        card.classList.remove('loading-pulse');
        text.textContent = '✅ Success 200 OK: { id: 101, username: "dev_coder" }';
        sound.playSuccess();
      }, 1200);
    });
  }

  // 15. DOM MANIPULATION PLAYGROUND
  renderDomPlayground(container) {
    this.renderHtmlAndJsPlayground(container);
  }

  // 16. MODERN ES6+ PLAYGROUND
  renderModernPlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '🚀 Modern ES6+ Features (Destructuring, Spread, Optional Chaining)',
      'Explore the elegant modern syntax that speeds up JavaScript development.',
      `
        <div class="modern-grid">
          <div class="modern-buttons">
            <button class="btn-play-action btn-purple" id="btn-spread">...spreadArray</button>
            <button class="btn-play-action btn-blue" id="btn-destruct">{ name, age } = user</button>
          </div>
          <div class="generated-css-box">
            <pre><code id="modern-code-result">// Click a modern syntax feature above</code></pre>
          </div>
        </div>
      `
    );

    const code = container.querySelector('#modern-code-result');

    container.querySelector('#btn-spread')?.addEventListener('click', () => {
      code.textContent = `const arr1 = [1, 2];\nconst arr2 = [3, 4];\nconst combined = [...arr1, ...arr2]; // [1, 2, 3, 4]`;
      sound.playPop();
    });

    container.querySelector('#btn-destruct')?.addEventListener('click', () => {
      code.textContent = `const user = { name: "Alice", age: 25, role: "Dev" };\nconst { name, role } = user;\nconsole.log(name, role); // "Alice", "Dev"`;
      sound.playSparkle();
    });
  }

  // 17. STORAGE PLAYGROUND
  renderStoragePlayground(container) {
    container.innerHTML = this.createPlaygroundFrame(
      '💾 localStorage & Client-Side Persistence',
      'Save, read, and delete persistent key-value data directly in the browser.',
      `
        <div class="storage-grid">
          <div class="storage-inputs">
            <input type="text" id="storage-key" class="kid-input" placeholder="Key (e.g. username)" value="player_rank" />
            <input type="text" id="storage-val" class="kid-input" placeholder="Value" value="Diamond ⭐" />
            <div class="storage-btns">
              <button class="btn-play-action btn-green" id="btn-save-store">localStorage.setItem()</button>
              <button class="btn-play-action btn-warning" id="btn-clear-store">localStorage.clear()</button>
            </div>
          </div>
          <div class="storage-shelf" id="storage-shelf">
            <div class="store-row"><strong>player_rank:</strong> "Diamond ⭐"</div>
          </div>
        </div>
      `
    );

    const kInput = container.querySelector('#storage-key');
    const vInput = container.querySelector('#storage-val');
    const shelf = container.querySelector('#storage-shelf');

    container.querySelector('#btn-save-store')?.addEventListener('click', () => {
      shelf.innerHTML = `<div class="store-row"><strong>${kInput.value}:</strong> "${vInput.value}"</div>`;
      sound.playSuccess();
    });

    container.querySelector('#btn-clear-store')?.addEventListener('click', () => {
      shelf.innerHTML = '<div class="store-row empty-text">[Storage Cleared]</div>';
      sound.playClick();
    });
  }

  // DEFAULT FALLBACK PLAYGROUND
  renderDefaultPlayground(container) {
    this.renderIntroPlayground(container);
  }
}

export const interactivePlaygrounds = new InteractivePlaygrounds();
