// Searchable JavaScript Reference & Cheatsheet Module
import { JS_REFERENCES } from '../data/reference.js';

export class ReferenceView {
  constructor() {
    this.searchQuery = '';
    this.selectedCategory = 'All';
  }

  render(container, onTryCode) {
    this.container = container;
    this.onTryCode = onTryCode;

    const categories = ['All', 'Array Methods', 'String Methods', 'Object Methods', 'DOM & Web APIs', 'Async & Promises'];

    container.innerHTML = `
      <div class="reference-wrapper">
        <div class="reference-header">
          <h1>JavaScript Reference & Cheatsheet</h1>
          <p>Quick lookup for core JavaScript methods, modern browser APIs, syntax guides, and examples.</p>

          <!-- Search & Filter Controls -->
          <div class="ref-controls-row">
            <div class="ref-search-box">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <input type="text" id="ref-search-input" placeholder="Search methods, syntax, e.g. 'map', 'slice', 'Promise'..." value="${this.escapeHtml(this.searchQuery)}" />
            </div>

            <div class="ref-category-pills">
              ${categories.map(cat => `
                <button class="cat-pill ${this.selectedCategory === cat ? 'active' : ''}" data-cat="${cat}">
                  ${cat}
                </button>
              `).join('')}
            </div>
          </div>
        </div>

        <!-- Reference Items Grid / List -->
        <div class="ref-items-list" id="ref-items-container">
          ${this.renderItemsHtml()}
        </div>
      </div>
    `;

    this.bindEvents();
  }

  renderItemsHtml() {
    const query = this.searchQuery.toLowerCase().trim();
    const filtered = JS_REFERENCES.filter(item => {
      const matchCat = this.selectedCategory === 'All' || item.category === this.selectedCategory;
      const matchQuery = !query ||
        item.name.toLowerCase().includes(query) ||
        item.description.toLowerCase().includes(query) ||
        item.syntax.toLowerCase().includes(query);
      return matchCat && matchQuery;
    });

    if (filtered.length === 0) {
      return `
        <div class="no-results-box">
          <p>No JavaScript references found matching "${this.escapeHtml(this.searchQuery)}".</p>
        </div>
      `;
    }

    return filtered.map(item => `
      <div class="ref-card">
        <div class="ref-card-header">
          <div class="ref-title-group">
            <span class="ref-cat-tag">${item.category}</span>
            <h3 class="ref-name">${this.escapeHtml(item.name)}</h3>
          </div>
          <button class="btn-try-ref" data-example="${this.escapeHtml(item.example)}">
            Try in Editor &raquo;
          </button>
        </div>

        <p class="ref-desc">${item.description}</p>

        <div class="ref-syntax-box">
          <span class="ref-syntax-label">Syntax:</span>
          <code>${this.escapeHtml(item.syntax)}</code>
        </div>

        <div class="ref-example-box">
          <span class="ref-example-label">Example:</span>
          <pre><code>${this.escapeHtml(item.example)}</code></pre>
        </div>
      </div>
    `).join('');
  }

  bindEvents() {
    const searchInput = this.container.querySelector('#ref-search-input');
    const pills = this.container.querySelectorAll('.cat-pill');
    const itemsContainer = this.container.querySelector('#ref-items-container');

    searchInput?.addEventListener('input', (e) => {
      this.searchQuery = e.target.value;
      itemsContainer.innerHTML = this.renderItemsHtml();
      this.bindCardEvents();
    });

    pills.forEach(pill => {
      pill.addEventListener('click', () => {
        pills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');
        this.selectedCategory = pill.getAttribute('data-cat');
        itemsContainer.innerHTML = this.renderItemsHtml();
        this.bindCardEvents();
      });
    });

    this.bindCardEvents();
  }

  bindCardEvents() {
    this.container.querySelectorAll('.btn-try-ref').forEach(btn => {
      btn.addEventListener('click', () => {
        const code = btn.getAttribute('data-example');
        if (this.onTryCode && code) {
          this.onTryCode(code);
        }
      });
    });
  }

  escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
}

export const referenceView = new ReferenceView();
