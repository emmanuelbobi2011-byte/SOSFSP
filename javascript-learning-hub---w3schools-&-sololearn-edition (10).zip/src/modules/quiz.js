// Comprehensive JavaScript Exam & SoloLearn-style Quiz Engine
import { EXAM_QUESTIONS, CERTIFICATE_TEMPLATE } from '../data/quizzes.js';
import { stateManager } from './state.js';
import { sound } from './audio.js';

export class QuizEngine {
  constructor() {
    this.currentQuestionIndex = 0;
    this.userAnswers = {};
    this.timerInterval = null;
    this.timeRemaining = 20 * 60; // 20 minutes in seconds
    this.isSubmitted = false;
  }

  // --- In-Lesson Checkpoint Quiz (SoloLearn UX) ---
  renderCheckpoint(container, checkpoint, lessonId) {
    if (!container || !checkpoint) return;

    const isCompleted = stateManager.get().completedCheckpoints[lessonId];

    container.innerHTML = `
      <div class="checkpoint-card ${isCompleted ? 'completed' : ''}">
        <div class="checkpoint-header">
          <div class="checkpoint-badge">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
            <span>SoloLearn Checkpoint Quiz</span>
          </div>
          <span class="checkpoint-xp">+15 XP</span>
        </div>

        <h3 class="checkpoint-question">${checkpoint.question}</h3>

        <div class="checkpoint-options">
          ${checkpoint.options.map((opt, idx) => `
            <button class="option-btn" data-index="${idx}">
              <span class="option-letter">${String.fromCharCode(65 + idx)}</span>
              <span class="option-text">${opt}</span>
            </button>
          `).join('')}
        </div>

        <div class="checkpoint-feedback" style="display: none;"></div>
      </div>
    `;

    const buttons = container.querySelectorAll('.option-btn');
    const feedback = container.querySelector('.checkpoint-feedback');

    buttons.forEach(btn => {
      btn.addEventListener('click', () => {
        const selectedIdx = parseInt(btn.getAttribute('data-index'), 10);
        const isCorrect = selectedIdx === checkpoint.answer;

        buttons.forEach((b, i) => {
          b.disabled = true;
          if (i === checkpoint.answer) {
            b.classList.add('correct');
          } else if (i === selectedIdx && !isCorrect) {
            b.classList.add('wrong');
          }
        });

        feedback.style.display = 'block';
        if (isCorrect) {
          sound.playSuccess();
          stateManager.completeCheckpoint(lessonId, 15);
          stateManager.completeLesson(lessonId);
          window.dispatchEvent(new CustomEvent('milestone-completed', {
            detail: {
              xp: 15,
              title: 'Checkpoint Solved! 🎯',
              desc: 'Earned +15 XP for concept checkpoint mastery.'
            }
          }));
          feedback.className = 'checkpoint-feedback success';
          feedback.innerHTML = `
            <div class="feedback-title">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"></polyline></svg>
              <span>Great Job! Correct Answer (+15 XP)</span>
            </div>
            <p>${checkpoint.explanation}</p>
          `;
        } else {
          sound.playError();
          feedback.className = 'checkpoint-feedback error';
          feedback.innerHTML = `
            <div class="feedback-title">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
              <span>Not quite right</span>
            </div>
            <p>${checkpoint.explanation}</p>
            <button class="retry-btn">Try Again</button>
          `;

          const retryBtn = feedback.querySelector('.retry-btn');
          retryBtn.addEventListener('click', () => {
            this.renderCheckpoint(container, checkpoint, lessonId);
          });
        }
      });
    });
  }

  // --- Comprehensive Certification Exam Module ---
  initExam(container) {
    this.container = container;
    this.currentQuestionIndex = 0;
    this.userAnswers = {};
    this.isSubmitted = false;
    this.timeRemaining = 20 * 60;
    this.renderExamIntro();
  }

  renderExamIntro() {
    const previousResult = stateManager.get().examResults;
    const totalQuestions = EXAM_QUESTIONS.length;

    this.container.innerHTML = `
      <div class="exam-intro-card">
        <div class="exam-header-banner">
          <div class="exam-badge-tag">Official Certification</div>
          <h1 class="exam-title">JavaScript Master Proficiency Exam</h1>
          <p class="exam-subtitle">Test your full-stack JavaScript fundamentals, modern ES6+ features, asynchronous paradigms, and DOM knowledge to earn your verified credential.</p>
        </div>

        <div class="exam-specs-grid">
          <div class="spec-card">
            <div class="spec-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            </div>
            <div class="spec-info">
              <span class="spec-label">Time Limit</span>
              <span class="spec-value">20 Minutes</span>
            </div>
          </div>

          <div class="spec-card">
            <div class="spec-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
            </div>
            <div class="spec-info">
              <span class="spec-label">Total Questions</span>
              <span class="spec-value">${totalQuestions} Questions</span>
            </div>
          </div>

          <div class="spec-card">
            <div class="spec-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"></polygon></svg>
            </div>
            <div class="spec-info">
              <span class="spec-label">Passing Grade</span>
              <span class="spec-value">70% or Higher</span>
            </div>
          </div>

          <div class="spec-card">
            <div class="spec-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>
            </div>
            <div class="spec-info">
              <span class="spec-label">Reward</span>
              <span class="spec-value">+150 XP & Certificate</span>
            </div>
          </div>
        </div>

        ${previousResult ? `
          <div class="previous-result-box ${previousResult.passed ? 'passed' : 'failed'}">
            <div class="prev-badge">${previousResult.passed ? 'Passed Previous Attempt' : 'Previous Attempt'}</div>
            <div class="prev-details">
              <span>Score: <strong>${previousResult.score}/${previousResult.total} (${previousResult.percentage}%)</strong></span>
              <span>Grade: <strong>${previousResult.grade}</strong></span>
              <span>Date: ${previousResult.date}</span>
            </div>
            ${previousResult.passed ? `<button id="btn-view-prev-cert" class="btn-cert-mini">View Saved Certificate</button>` : ''}
          </div>
        ` : ''}

        <div class="exam-rules-box">
          <h3>Exam Guidelines</h3>
          <ul>
            <li>You can navigate back and forth between questions before submitting.</li>
            <li>Each question has only one correct answer.</li>
            <li>The timer counts down automatically. Upon reaching 00:00, the exam auto-submits.</li>
            <li>Upon passing, an official verifiable certificate will be generated in your name!</li>
          </ul>
        </div>

        <div class="exam-start-actions">
          <button id="btn-start-exam" class="btn-start-exam">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
            <span>Start JavaScript Exam Now</span>
          </button>
        </div>
      </div>
    `;

    this.container.querySelector('#btn-start-exam')?.addEventListener('click', () => {
      this.startExamSession();
    });

    this.container.querySelector('#btn-view-prev-cert')?.addEventListener('click', () => {
      const res = stateManager.get().examResults;
      if (res) this.renderCertificate(res);
    });
  }

  startExamSession() {
    this.userAnswers = {};
    this.currentQuestionIndex = 0;
    this.isSubmitted = false;
    this.timeRemaining = 20 * 60;
    this.renderExamInterface();
    this.startTimer();
  }

  startTimer() {
    clearInterval(this.timerInterval);
    this.timerInterval = setInterval(() => {
      this.timeRemaining--;
      this.updateTimerDisplay();

      if (this.timeRemaining <= 0) {
        clearInterval(this.timerInterval);
        alert('Time is up! Submitting your exam automatically.');
        this.submitExam();
      }
    }, 1000);
  }

  updateTimerDisplay() {
    const timerElem = this.container.querySelector('#exam-timer-display');
    if (!timerElem) return;

    const mins = Math.floor(this.timeRemaining / 60);
    const secs = this.timeRemaining % 60;
    const formatted = `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    timerElem.textContent = formatted;

    if (this.timeRemaining < 120) {
      timerElem.classList.add('timer-warning');
    }
  }

  renderExamInterface() {
    const total = EXAM_QUESTIONS.length;
    const currentQ = EXAM_QUESTIONS[this.currentQuestionIndex];
    const answeredCount = Object.keys(this.userAnswers).length;
    const progressPercent = Math.round(((this.currentQuestionIndex + 1) / total) * 100);

    this.container.innerHTML = `
      <div class="exam-active-container">
        <!-- Top Exam Header -->
        <div class="exam-status-bar">
          <div class="exam-status-title">
            <span class="exam-indicator-dot"></span>
            <span>JS Certification Exam</span>
          </div>

          <div class="exam-timer-wrapper">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
            <span id="exam-timer-display" class="timer-digits">20:00</span>
          </div>

          <div class="exam-progress-stats">
            <span>Answered: <strong>${answeredCount}/${total}</strong></span>
          </div>
        </div>

        <!-- Progress bar -->
        <div class="exam-progress-track">
          <div class="exam-progress-fill" style="width: ${progressPercent}%;"></div>
        </div>

        <!-- Questions Navigation Grid (SoloLearn style quick jump) -->
        <div class="questions-quick-nav">
          ${EXAM_QUESTIONS.map((q, idx) => {
            const isAnswered = this.userAnswers[idx] !== undefined;
            const isCurrent = idx === this.currentQuestionIndex;
            return `
              <button class="nav-q-btn ${isCurrent ? 'active' : ''} ${isAnswered ? 'answered' : ''}" data-idx="${idx}">
                ${idx + 1}
              </button>
            `;
          }).join('')}
        </div>

        <!-- Current Question Display Card -->
        <div class="exam-question-card">
          <div class="q-meta-row">
            <span class="q-category-tag">${currentQ.category}</span>
            <span class="q-number-tag">Question ${this.currentQuestionIndex + 1} of ${total}</span>
          </div>

          <h2 class="q-text">${currentQ.question}</h2>

          <div class="exam-options-list">
            ${currentQ.options.map((opt, oIdx) => {
              const isSelected = this.userAnswers[this.currentQuestionIndex] === oIdx;
              return `
                <label class="exam-option-label ${isSelected ? 'selected' : ''}">
                  <input type="radio" name="exam-option" value="${oIdx}" ${isSelected ? 'checked' : ''} />
                  <span class="radio-custom"></span>
                  <span class="exam-opt-text">${this.escapeHtml(opt)}</span>
                </label>
              `;
            }).join('')}
          </div>

          <!-- Bottom Navigation Controls -->
          <div class="exam-bottom-controls">
            <button id="btn-prev-q" class="exam-nav-btn" ${this.currentQuestionIndex === 0 ? 'disabled' : ''}>
              &laquo; Previous
            </button>

            <div class="nav-center-actions">
              ${this.currentQuestionIndex === total - 1 ? `
                <button id="btn-submit-exam" class="btn-submit-exam-finish">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                  <span>Submit Exam for Certification</span>
                </button>
              ` : `
                <button id="btn-next-q" class="exam-nav-btn primary">
                  Next Question &raquo;
                </button>
              `}
            </div>

            <button id="btn-submit-early" class="btn-submit-early" title="Submit exam early">
              Finish Early
            </button>
          </div>
        </div>
      </div>
    `;

    this.updateTimerDisplay();
    this.bindExamEvents();
  }

  bindExamEvents() {
    // Quick question jump
    this.container.querySelectorAll('.nav-q-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        this.currentQuestionIndex = parseInt(btn.getAttribute('data-idx'), 10);
        this.renderExamInterface();
      });
    });

    // Radio option selection
    this.container.querySelectorAll('input[name="exam-option"]').forEach(radio => {
      radio.addEventListener('change', (e) => {
        this.userAnswers[this.currentQuestionIndex] = parseInt(e.target.value, 10);
        this.renderExamInterface();
      });
    });

    // Next / Prev
    this.container.querySelector('#btn-prev-q')?.addEventListener('click', () => {
      if (this.currentQuestionIndex > 0) {
        this.currentQuestionIndex--;
        this.renderExamInterface();
      }
    });

    this.container.querySelector('#btn-next-q')?.addEventListener('click', () => {
      if (this.currentQuestionIndex < EXAM_QUESTIONS.length - 1) {
        this.currentQuestionIndex++;
        this.renderExamInterface();
      }
    });

    // Submit
    this.container.querySelector('#btn-submit-exam')?.addEventListener('click', () => {
      this.confirmSubmit();
    });

    this.container.querySelector('#btn-submit-early')?.addEventListener('click', () => {
      this.confirmSubmit();
    });
  }

  confirmSubmit() {
    const total = EXAM_QUESTIONS.length;
    const answered = Object.keys(this.userAnswers).length;
    const unanswered = total - answered;

    let msg = 'Are you sure you want to submit your exam?';
    if (unanswered > 0) {
      msg = `You still have ${unanswered} unanswered question(s). Submit now anyway?`;
    }

    if (confirm(msg)) {
      clearInterval(this.timerInterval);
      this.submitExam();
    }
  }

  submitExam() {
    let score = 0;
    const total = EXAM_QUESTIONS.length;
    const breakdown = [];

    EXAM_QUESTIONS.forEach((q, idx) => {
      const userAns = this.userAnswers[idx];
      const isCorrect = userAns === q.answer;
      if (isCorrect) score++;

      breakdown.push({
        questionId: q.id,
        category: q.category,
        question: q.question,
        options: q.options,
        userAnswer: userAns,
        correctAnswer: q.answer,
        isCorrect,
        explanation: q.explanation
      });
    });

    const percentage = Math.round((score / total) * 100);
    const passed = percentage >= 70;

    let grade = 'Fail';
    if (percentage >= 90) grade = 'Distinction (A+)';
    else if (percentage >= 80) grade = 'Merit (A)';
    else if (percentage >= 70) grade = 'Pass (B)';

    const result = {
      score,
      total,
      percentage,
      passed,
      grade,
      date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' }),
      certId: `JS-CERT-${Math.floor(10000 + Math.random() * 90000)}-${new Date().getFullYear()}`,
      breakdown
    };

    stateManager.saveExamResult(result);
    if (passed) {
      sound.playFanfare();
    } else {
      sound.playError();
    }

    this.renderExamScore(result);
  }

  renderExamScore(result) {
    this.container.innerHTML = `
      <div class="exam-result-card ${result.passed ? 'result-passed' : 'result-failed'}">
        <div class="result-hero">
          <div class="result-icon-badge">
            ${result.passed ? `
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#04AA6D" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><polyline points="16 10 10 16 7 13"></polyline></svg>
            ` : `
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2.5"><circle cx="12" cy="12" r="10"></circle><line x1="15" y1="9" x2="9" y2="15"></line><line x1="9" y1="9" x2="15" y2="15"></line></svg>
            `}
          </div>

          <h1 class="result-status-title">
            ${result.passed ? '🎉 Congratulations! You Passed!' : 'Exam Needs Improvement'}
          </h1>
          <p class="result-status-sub">
            ${result.passed 
              ? 'You have successfully proven mastery of core and advanced JavaScript concepts.' 
              : 'You scored below the 70% passing threshold. Review the questions below and try again!'}
          </p>
        </div>

        <div class="result-stats-row">
          <div class="r-stat">
            <span class="r-label">Final Score</span>
            <span class="r-val">${result.score} / ${result.total}</span>
          </div>
          <div class="r-stat">
            <span class="r-label">Percentage</span>
            <span class="r-val ${result.passed ? 'text-green' : 'text-red'}">${result.percentage}%</span>
          </div>
          <div class="r-stat">
            <span class="r-label">Grade</span>
            <span class="r-val">${result.grade}</span>
          </div>
          <div class="r-stat">
            <span class="r-label">XP Awarded</span>
            <span class="r-val text-amber">+${result.passed ? '150 XP' : '20 XP'}</span>
          </div>
        </div>

        ${result.passed ? `
          <div class="cert-callout-action">
            <div class="cert-prompt-box">
              <label for="learner-name-input">Name on Certificate:</label>
              <div class="name-input-group">
                <input type="text" id="learner-name-input" class="learner-name-field" value="${this.escapeHtml(stateManager.get().userName)}" placeholder="Enter your full name..." />
                <button id="btn-generate-cert" class="btn-cert-generate">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                  <span>View Official Certificate</span>
                </button>
              </div>
            </div>
          </div>
        ` : ''}

        <div class="exam-review-section">
          <h3>Question-by-Question Detailed Review</h3>
          <div class="review-list">
            ${result.breakdown.map((item, idx) => `
              <div class="review-item ${item.isCorrect ? 'rev-correct' : 'rev-wrong'}">
                <div class="rev-header">
                  <span class="rev-num">Question ${idx + 1} (${item.category})</span>
                  <span class="rev-verdict">${item.isCorrect ? '✓ Correct' : '✗ Incorrect'}</span>
                </div>
                <div class="rev-question">${item.question}</div>
                <div class="rev-choices">
                  <div class="rev-choice user-choice ${item.isCorrect ? 'is-correct' : 'is-wrong'}">
                    <strong>Your Answer:</strong> ${item.userAnswer !== undefined ? this.escapeHtml(item.options[item.userAnswer]) : '<em>No answer selected</em>'}
                  </div>
                  ${!item.isCorrect ? `
                    <div class="rev-choice correct-choice">
                      <strong>Correct Answer:</strong> ${this.escapeHtml(item.options[item.correctAnswer])}
                    </div>
                  ` : ''}
                </div>
                <div class="rev-explanation">
                  <strong>Explanation:</strong> ${item.explanation}
                </div>
              </div>
            `).join('')}
          </div>
        </div>

        <div class="result-footer-actions">
          <button id="btn-retake-exam" class="btn-retake">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6"></path><path d="M1 20v-6h6"></path><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"></path></svg>
            <span>Retake Exam</span>
          </button>
        </div>
      </div>
    `;

    this.container.querySelector('#btn-retake-exam')?.addEventListener('click', () => {
      this.initExam(this.container);
    });

    this.container.querySelector('#btn-generate-cert')?.addEventListener('click', () => {
      const nameInput = this.container.querySelector('#learner-name-input');
      if (nameInput && nameInput.value.trim()) {
        stateManager.update({ userName: nameInput.value.trim() });
      }
      this.renderCertificate(result);
    });
  }

  renderCertificate(result) {
    const userName = stateManager.get().userName || 'Dedicated Developer';

    this.container.innerHTML = `
      <div class="cert-view-wrapper">
        <div class="cert-toolbar no-print">
          <button id="btn-back-results" class="cert-tool-btn">
            &larr; Back to Exam
          </button>
          <div class="cert-tool-actions">
            <button id="btn-print-cert" class="btn-print-action">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
              <span>Print / Download PDF</span>
            </button>
          </div>
        </div>

        <!-- Luxury Verified Digital Certificate Frame -->
        <div class="certificate-paper" id="certificate-print-area">
          <div class="cert-border-outer">
            <div class="cert-border-inner">
              
              <!-- Header Logos & Seal -->
              <div class="cert-top-branding">
                <div class="cert-logo-mark">
                  <div class="js-square-badge">JS</div>
                  <div class="academy-name">
                    <span class="brand-part1">Master JS</span> &bull; <span class="brand-part2">Code</span>
                    <div class="sub-brand">Interactive JavaScript Academy</div>
                  </div>
                </div>
                <div class="cert-badge-ribbon">VERIFIED</div>
              </div>

              <!-- Certificate Title -->
              <div class="cert-heading-group">
                <div class="cert-small-title">CERTIFICATE OF MASTERY & ACHIEVEMENT</div>
                <h1 class="cert-recipient-name">${this.escapeHtml(userName)}</h1>
                <div class="cert-divider-line"></div>
                <p class="cert-statement">
                  Has successfully completed all curriculum requirements, interactive problem-solving challenges, and passed the official examination with <strong>${result.grade} (${result.percentage}%)</strong> demonstrating professional proficiency in:
                </p>
                <div class="cert-skills-pills">
                  <span>Core JS Syntax</span>
                  <span>ES6+ Features</span>
                  <span>Async / Await</span>
                  <span>DOM & Web APIs</span>
                  <span>OOP & Closures</span>
                  <span>Functional Arrays</span>
                </div>
              </div>

              <!-- Signatures & Verification Meta -->
              <div class="cert-footer-meta">
                <div class="cert-sig-block">
                  <div class="sig-line">Brendan Eich / W3 Academy Board</div>
                  <div class="sig-title">Curriculum Director</div>
                </div>

                <div class="cert-seal-emboss">
                  <div class="seal-circle">
                    <div class="seal-inner">
                      <span class="seal-text">OFFICIAL</span>
                      <span class="seal-year">${new Date().getFullYear()}</span>
                    </div>
                  </div>
                </div>

                <div class="cert-id-block">
                  <div class="cert-id-label">Credential ID:</div>
                  <div class="cert-id-value">${result.certId}</div>
                  <div class="cert-date-issue">Issued on: ${result.date}</div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    `;

    this.container.querySelector('#btn-back-results')?.addEventListener('click', () => {
      this.renderExamScore(result);
    });

    this.container.querySelector('#btn-print-cert')?.addEventListener('click', () => {
      window.print();
    });
  }

  escapeHtml(str) {
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
}

export const quizEngine = new QuizEngine();
