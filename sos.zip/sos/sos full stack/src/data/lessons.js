// Comprehensive Web Development Course Syllabus (HTML, CSS & JavaScript)
export const CATEGORIES = [
  // --- HTML TRACK (Building the Web) ---
  { id: 'html-basics', title: '📄 HTML Basics & Tags', icon: 'file-text' },
  { id: 'html-media', title: '🖼️ Links, Images & Media', icon: 'image' },
  { id: 'html-structures', title: '📋 Lists, Tables & Blocks', icon: 'list' },
  { id: 'html-forms', title: '📝 Forms, Inputs & Buttons', icon: 'edit' },

  // --- CSS TRACK (Styling the Web) ---
  { id: 'css-basics', title: '🎨 CSS Basics & Selectors', icon: 'palette' },
  { id: 'css-boxmodel', title: '📦 CSS Box Model, Colors & Borders', icon: 'box' },
  { id: 'css-layout', title: '📐 Modern Layouts (Flexbox & Grid)', icon: 'layout' },
  { id: 'css-animations', title: '✨ CSS Animations & Responsive Design', icon: 'sparkles' },

  // --- JAVASCRIPT TRACK (Interactivity & Logic) ---
  { id: 'basics', title: '⚡ JS Basics & HTML Synergy', icon: 'zap' },
  { id: 'datatypes', title: '🗄️ Data Types & Operators', icon: 'database' },
  { id: 'control', title: '🔀 Control Flow & Loops', icon: 'git-branch' },
  { id: 'functions', title: '💻 Functions & Scope', icon: 'code' },
  { id: 'objects', title: '📦 Objects & Arrays', icon: 'box' },
  { id: 'oop', title: '🏗️ OOP & Classes', icon: 'layers' },
  { id: 'async', title: '⏱️ Asynchronous JavaScript', icon: 'clock' },
  { id: 'dom', title: '🌐 DOM & Web APIs', icon: 'layout' },
  { id: 'modern', title: '🚀 Modern ES6+ Features', icon: 'sparkles' },
  { id: 'advanced', title: '🧠 Advanced & Algorithms', icon: 'cpu' },
];

export const LESSONS = [
  // ==========================================
  // --- HTML TRACK: BASICS & TAGS ---
  // ==========================================
  {
    id: 'html-intro',
    category: 'html-basics',
    title: 'HTML Introduction & Simple Tags',
    readTime: '3 min',
    xp: 25,
    summary: 'Learn what HTML is and how simple opening and closing tags build every website on the internet.',
    contentHtml: `
      <h2>What is HTML?</h2>
      <p><strong>HTML</strong> stands for <em>HyperText Markup Language</em>. It is the skeleton of every website. Just like LEGO blocks, you put tags together to build pages!</p>

      <h2>How Tags Work (Opening & Closing)</h2>
      <p>Most HTML elements have an <strong>opening tag</strong> and a <strong>closing tag</strong> with content in the middle:</p>

      <div class="w3-code-box">
        <span class="code-badge">Simple Tag Rule</span>
        <pre><code>&lt;tagname&gt;Your text or content goes here&lt;/tagname&gt;

&lt;!-- Example 1: A big heading --&gt;
&lt;h1&gt;Welcome to My Website!&lt;/h1&gt;

&lt;!-- Example 2: A paragraph of text --&gt;
&lt;p&gt;HTML is fun, simple, and easy to learn.&lt;/p&gt;

&lt;!-- Example 3: A clickable button --&gt;
&lt;button&gt;Click Me!&lt;/button&gt;</code></pre>
      </div>

      <h2>The Webpage Skeleton</h2>
      <p>Every standard webpage has 3 simple parts:</p>
      <ul>
        <li><code>&lt;html&gt;</code>: The container for the whole page.</li>
        <li><code>&lt;head&gt;</code>: Holds page information (like the title shown in browser tab).</li>
        <li><code>&lt;body&gt;</code>: Holds everything you see on screen (headings, text, buttons, pictures).</li>
      </ul>
    `,
    codeExample: `<!-- Your very first simple HTML webpage -->
<h1>👋 Hello, World!</h1>
<p>I am building my very first webpage with HTML!</p>
<button>🚀 Launch Adventure</button>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which tag correctly closes a paragraph tag in HTML?',
      options: [
        '</p>',
        '<close p>',
        '<end p>',
        '<p/>'
      ],
      answer: 0,
      explanation: 'Closing tags in HTML always start with a forward slash before the tag name, like </p>, </h1>, or </button>.'
    }
  },

  {
    id: 'html-text',
    category: 'html-basics',
    title: 'Headings, Paragraphs & Text Styling',
    readTime: '3 min',
    xp: 25,
    summary: 'Organize your text with headings (h1 to h6), paragraphs, bold text, italics, and highlighter pens.',
    contentHtml: `
      <h2>Headings: From H1 to H6</h2>
      <p>HTML gives you 6 levels of headings. <code>&lt;h1&gt;</code> is the biggest main title, and <code>&lt;h6&gt;</code> is the smallest subtitle:</p>

      <div class="w3-code-box">
        <span class="code-badge">Heading Levels</span>
        <pre><code>&lt;h1&gt;Level 1: Giant Main Title&lt;/h1&gt;
&lt;h2&gt;Level 2: Major Section Heading&lt;/h2&gt;
&lt;h3&gt;Level 3: Sub-topic Heading&lt;/h3&gt;
&lt;p&gt;Regular paragraph of normal reading text.&lt;/p&gt;</code></pre>
      </div>

      <h2>Simple Text Formatting Tags</h2>
      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Tag</th><th>What it does</th><th>Example Code</th></tr>
          </thead>
          <tbody>
            <tr><td><code>&lt;b&gt;</code> or <code>&lt;strong&gt;</code></td><td>Makes text <strong>Bold</strong></td><td><code>&lt;b&gt;Super Fast&lt;/b&gt;</code></td></tr>
            <tr><td><code>&lt;i&gt;</code> or <code>&lt;em&gt;</code></td><td>Makes text <em>Italic</em></td><td><code>&lt;i&gt;Important Note&lt;/i&gt;</code></td></tr>
            <tr><td><code>&lt;mark&gt;</code></td><td><mark>Highlights</mark> text in yellow</td><td><code>&lt;mark&gt;Key Point&lt;/mark&gt;</code></td></tr>
            <tr><td><code>&lt;u&gt;</code></td><td><u>Underlines</u> text</td><td><code>&lt;u&gt;Check this&lt;/u&gt;</code></td></tr>
          </tbody>
        </table>
      </div>
    `,
    codeExample: `<h1>🏰 The Magic Castle</h1>
<h2>Chapter 1: The Secret Gate</h2>
<p>Deep in the forest, Alex found a <b>golden key</b> and an <i>ancient map</i>.</p>
<p>Remember: <mark>Never enter without a flashlight!</mark></p>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which heading tag produces the largest main title on a webpage?',
      options: [
        '<h6>',
        '<h3>',
        '<h1>',
        '<header>'
      ],
      answer: 2,
      explanation: '<h1> is the highest level heading and renders the largest, most prominent title.'
    }
  },

  // ==========================================
  // --- HTML TRACK: MEDIA & LINKS ---
  // ==========================================
  {
    id: 'html-links',
    category: 'html-media',
    title: 'Hyperlinks & Clickable Buttons',
    readTime: '3 min',
    xp: 30,
    summary: 'Connect pages across the world using simple <a> link tags and interactive buttons.',
    contentHtml: `
      <h2>The Hyperlink Tag (&lt;a&gt;)</h2>
      <p>The <code>&lt;a&gt;</code> tag stands for <strong>Anchor</strong>. It creates a clickable link to another webpage or website.</p>
      <p>The <code>href</code> attribute tells the browser where to go when clicked:</p>

      <div class="w3-code-box">
        <span class="code-badge">Link Syntax</span>
        <pre><code>&lt;!-- Basic Link --&gt;
&lt;a href="https://google.com"&gt;Visit Google&lt;/a&gt;

&lt;!-- Open in a New Browser Tab --&gt;
&lt;a href="https://wikipedia.org" target="_blank"&gt;Open Wikipedia in New Tab&lt;/a&gt;</code></pre>
      </div>

      <h2>Clickable Buttons (&lt;button&gt;)</h2>
      <p>Use <code>&lt;button&gt;</code> when you want the user to trigger an action (like sending a message, playing a sound, or submitting a quiz):</p>
      
      <div class="w3-code-box">
        <span class="code-badge">Button Example</span>
        <pre><code>&lt;button onclick="alert('Hello from HTML!')"&gt;
  ✨ Click Me!
&lt;/button&gt;</code></pre>
      </div>
    `,
    codeExample: `<h2>🔗 Useful Links & Actions</h2>
<p>Check out our favorite search engine:</p>
<a href="https://google.com" target="_blank">🌐 Open Google</a>

<br><br>
<button onclick="alert('You clicked the magic button! 🎉')">
  🎁 Open Surprise
</button>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which attribute tells the link <a> which website URL to open?',
      options: [
        'src',
        'href',
        'link',
        'url'
      ],
      answer: 1,
      explanation: 'href (Hypertext REFerence) specifies the URL destination for the <a> tag.'
    }
  },

  {
    id: 'html-images',
    category: 'html-media',
    title: 'Images & Photos (<img>)',
    readTime: '3 min',
    xp: 30,
    summary: 'Display images, photos, and icons on your page using the self-closing <img> tag and alt descriptions.',
    contentHtml: `
      <h2>How to Add Images with &lt;img&gt;</h2>
      <p>The <code>&lt;img&gt;</code> tag is a <strong>self-closing tag</strong> (it does not need a closing <code>&lt;/img&gt;</code> tag).</p>

      <h2>The Two Essential Attributes</h2>
      <ul>
        <li><code>src</code>: The <strong>Source</strong> URL or path to the picture file.</li>
        <li><code>alt</code>: The <strong>Alternative text</strong> description (read by screen readers for accessibility, and displayed if the photo cannot load).</li>
        <li><code>width</code> and <code>height</code>: Sets the picture dimensions in pixels.</li>
      </ul>

      <div class="w3-code-box">
        <span class="code-badge">Image Tag Syntax</span>
        <pre><code>&lt;img src="https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=300" 
     alt="A cute glowing robot" 
     width="240"&gt;</code></pre>
      </div>
    `,
    codeExample: `<h2>🤖 Meet Robot Bob!</h2>
<img src="https://images.unsplash.com/photo-1485827404703-89b55fcc595e?w=300" 
     alt="A friendly smart white robot" 
     width="220" 
     style="border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.3);">

<p>Bob loves helping kids learn HTML!</p>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which attribute is required to provide the link or file location of an image?',
      options: [
        'href',
        'src',
        'file',
        'pic'
      ],
      answer: 1,
      explanation: 'src (source) is the attribute that tells the browser where to find the image file.'
    }
  },

  {
    id: 'html-audio-video',
    category: 'html-media',
    title: 'Audio & Video Players',
    readTime: '3 min',
    xp: 30,
    summary: 'Embed audio tracks, sound effects, and video players directly into your webpage with simple controls.',
    contentHtml: `
      <h2>The &lt;audio&gt; Tag</h2>
      <p>Use the <code>&lt;audio&gt;</code> tag with the <code>controls</code> attribute to display play, pause, and volume buttons:</p>

      <div class="w3-code-box">
        <span class="code-badge">Audio Tag</span>
        <pre><code>&lt;audio controls src="https://actions.google.com/sounds/v1/cartoon/pop.ogg"&gt;
  Your browser does not support audio.
&lt;/audio&gt;</code></pre>
      </div>

      <h2>The &lt;video&gt; Tag</h2>
      <p>Similarly, <code>&lt;video controls width="320"&gt;</code> creates an interactive video player:</p>

      <div class="w3-code-box">
        <span class="code-badge">Video Tag</span>
        <pre><code>&lt;video controls width="320" src="movie.mp4"&gt;
  Your browser does not support video.
&lt;/video&gt;</code></pre>
      </div>
    `,
    codeExample: `<h2>🎵 Sound Effect Center</h2>
<p>Click play on the audio player below:</p>
<audio controls src="https://actions.google.com/sounds/v1/cartoon/pop.ogg">
  Your browser does not support the audio element.
</audio>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which attribute gives the user play, pause, and volume buttons on audio/video elements?',
      options: [
        'controls',
        'buttons',
        'media',
        'play'
      ],
      answer: 0,
      explanation: 'The controls attribute tells the browser to render standard play/pause/volume controls.'
    }
  },

  // ==========================================
  // --- HTML TRACK: STRUCTURES & BLOCKS ---
  // ==========================================
  {
    id: 'html-lists',
    category: 'html-structures',
    title: 'Bulleted & Numbered Lists',
    readTime: '3 min',
    xp: 25,
    summary: 'Create clean bullet-point lists with <ul> and numbered step-by-step lists with <ol>.',
    contentHtml: `
      <h2>Two Types of HTML Lists</h2>
      <p>HTML has two simple list containers:</p>
      <ul>
        <li><code>&lt;ul&gt;</code>: <strong>Unordered List</strong> (bullet points ⚪)</li>
        <li><code>&lt;ol&gt;</code>: <strong>Ordered List</strong> (numbered 1, 2, 3...)</li>
      </ul>

      <h2>The List Item (&lt;li&gt;)</h2>
      <p>Inside both list types, each individual entry is wrapped in <code>&lt;li&gt;</code> (List Item):</p>

      <div class="w3-code-box">
        <span class="code-badge">List Code Examples</span>
        <pre><code>&lt;!-- Unordered Bullet List --&gt;
&lt;ul&gt;
  &lt;li&gt;🍎 Crisp Red Apples&lt;/li&gt;
  &lt;li&gt;🍌 Sweet Bananas&lt;/li&gt;
  &lt;li&gt;🍇 Fresh Grapes&lt;/li&gt;
&lt;/ul&gt;

&lt;!-- Ordered Numbered Steps --&gt;
&lt;ol&gt;
  &lt;li&gt;Turn on computer&lt;/li&gt;
  &lt;li&gt;Open code editor&lt;/li&gt;
  &lt;li&gt;Write awesome HTML!&lt;/li&gt;
&lt;/ol&gt;</code></pre>
      </div>
    `,
    codeExample: `<h2>🚀 Space Mission Checklist</h2>
<ol>
  <li>Check rocket fuel ⛽</li>
  <li>Put on space helmet 👨‍🚀</li>
  <li>Blast off to Mars! 🛸</li>
</ol>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which tag is used for each individual item inside a list?',
      options: [
        '<ul>',
        '<ol>',
        '<li>',
        '<item>'
      ],
      answer: 2,
      explanation: '<li> stands for List Item and represents an item inside either <ul> or <ol>.'
    }
  },

  {
    id: 'html-tables',
    category: 'html-structures',
    title: 'Simple Data Tables',
    readTime: '4 min',
    xp: 30,
    summary: 'Organize data neatly into clean rows and columns using <table>, <tr>, <th>, and <td>.',
    contentHtml: `
      <h2>Table Anatomy</h2>
      <p>HTML tables use 4 simple tags to build a grid of information:</p>
      <ul>
        <li><code>&lt;table&gt;</code>: The table container.</li>
        <li><code>&lt;tr&gt;</code>: <strong>Table Row</strong> (horizontal line).</li>
        <li><code>&lt;th&gt;</code>: <strong>Table Header</strong> (bold title cell).</li>
        <li><code>&lt;td&gt;</code>: <strong>Table Data</strong> (regular data cell).</li>
      </ul>

      <div class="w3-code-box">
        <span class="code-badge">Table Code</span>
        <pre><code>&lt;table border="1"&gt;
  &lt;tr&gt;
    &lt;th&gt;Hero Name&lt;/th&gt;
    &lt;th&gt;Superpower&lt;/th&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td&gt;Flash&lt;/td&gt;
    &lt;td&gt;Super Speed&lt;/td&gt;
  &lt;/tr&gt;
  &lt;tr&gt;
    &lt;td&gt;Superman&lt;/td&gt;
    &lt;td&gt;Flight&lt;/td&gt;
  &lt;/tr&gt;
&lt;/table&gt;</code></pre>
      </div>
    `,
    codeExample: `<h2>🏆 Video Game High Scores</h2>
<table border="1" cellpadding="8" style="border-collapse: collapse; width: 100%;">
  <tr style="background: #161b22; color: #10b981;">
    <th>Player</th>
    <th>Game</th>
    <th>Score</th>
  </tr>
  <tr>
    <td>Alex</td>
    <td>Space Quest</td>
    <td>9,850</td>
  </tr>
  <tr>
    <td>Maya</td>
    <td>Cyber Runner</td>
    <td>12,400</td>
  </tr>
</table>`,
    checkpoint: {
      type: 'mcq',
      question: 'What does <tr> stand for in an HTML table?',
      options: [
        'Table Record',
        'Table Row',
        'Table Right',
        'Table Real'
      ],
      answer: 1,
      explanation: '<tr> stands for Table Row and defines a horizontal row of cells in a table.'
    }
  },

  {
    id: 'html-containers',
    category: 'html-structures',
    title: 'Divs & Semantic Web Blocks',
    readTime: '3 min',
    xp: 25,
    summary: 'Group elements together with <div> containers and meaningful semantic tags like <header>, <main>, and <footer>.',
    contentHtml: `
      <h2>The &lt;div&gt; Box Container</h2>
      <p>A <code>&lt;div&gt;</code> (division) is a generic box that groups HTML elements together so you can style or position them as a unit.</p>

      <h2>Semantic Tags (Meaningful Blocks)</h2>
      <p>Modern HTML uses clear named containers that describe their purpose:</p>
      <ul>
        <li><code>&lt;header&gt;</code>: Top banner with logo and title.</li>
        <li><code>&lt;nav&gt;</code>: Navigation menu links.</li>
        <li><code>&lt;main&gt;</code>: The primary content of the webpage.</li>
        <li><code>&lt;footer&gt;</code>: The bottom copyright and links section.</li>
      </ul>
    `,
    codeExample: `<!-- Clean Semantic Webpage Layout -->
<header style="background: #21262d; padding: 12px; border-radius: 8px;">
  <h1>🌟 My Cool Website</h1>
</header>

<main style="padding: 16px 0;">
  <p>Welcome to our simple, fast homepage!</p>
</main>

<footer style="color: #8b949e; border-top: 1px solid #30363d; padding-top: 8px;">
  <small>© 2026 Web Explorers Club</small>
</footer>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which semantic tag is best suited for the bottom area containing copyright information?',
      options: [
        '<bottom>',
        '<end>',
        '<footer>',
        '<base>'
      ],
      answer: 2,
      explanation: '<footer> is the semantic HTML tag representing the bottom footer area of a webpage or section.'
    }
  },

  // ==========================================
  // --- HTML TRACK: FORMS & INPUTS ---
  // ==========================================
  {
    id: 'html-forms',
    category: 'html-forms',
    title: 'Forms, Text Boxes & Inputs',
    readTime: '4 min',
    xp: 35,
    summary: 'Collect text, colors, numbers, and checkbox choices from users using interactive <input> fields and forms.',
    contentHtml: `
      <h2>The &lt;form&gt; and &lt;input&gt; Tags</h2>
      <p>HTML forms let visitors send information to your website. The <code>&lt;input&gt;</code> tag changes its appearance based on the <code>type</code> attribute!</p>

      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Input Type</th><th>What it looks like</th><th>Code</th></tr>
          </thead>
          <tbody>
            <tr><td><code>type="text"</code></td><td>A simple text box</td><td><code>&lt;input type="text" placeholder="Your name"&gt;</code></td></tr>
            <tr><td><code>type="color"</code></td><td>A color picker popup</td><td><code>&lt;input type="color" value="#10b981"&gt;</code></td></tr>
            <tr><td><code>type="range"</code></td><td>A sliding slider lever</td><td><code>&lt;input type="range" min="1" max="100"&gt;</code></td></tr>
            <tr><td><code>type="checkbox"</code></td><td>A toggle check square</td><td><code>&lt;input type="checkbox"&gt; Agree</code></td></tr>
          </tbody>
        </table>
      </div>
    `,
    codeExample: `<!-- Interactive Player Creation Form -->
<form onsubmit="event.preventDefault(); alert('Hero created! 🎮');">
  <label>Hero Name:</label><br>
  <input type="text" placeholder="e.g. Captain Code" required style="padding: 6px; border-radius: 6px; margin: 6px 0;"><br>

  <label>Favorite Cape Color:</label><br>
  <input type="color" value="#10b981" style="margin: 6px 0;"><br>

  <label><input type="checkbox" checked> Ready for Adventure</label><br><br>

  <button type="submit" style="background: #10b981; color: white; padding: 8px 16px; border: none; border-radius: 8px; font-weight: bold; cursor: pointer;">
    🚀 Create Hero
  </button>
</form>`,
    checkpoint: {
      type: 'mcq',
      question: 'Which input type displays a color picker widget on screen?',
      options: [
        '<input type="color">',
        '<input type="rgb">',
        '<input type="palette">',
        '<input type="paint">'
      ],
      answer: 0,
      explanation: '<input type="color"> creates a native color picker that lets the user choose any color.'
    }
  },

  // ==========================================
  // --- CSS TRACK: BASICS & SELECTORS ---
  // ==========================================
  {
    id: 'css-intro',
    category: 'css-basics',
    title: 'CSS Introduction & Syntax',
    readTime: '4 min',
    xp: 30,
    summary: 'Learn what CSS (Cascading Style Sheets) is, how syntax rules work (Selectors, Properties, Values), and how to style HTML.',
    contentHtml: `
      <h2>What is CSS?</h2>
      <p><strong>CSS (Cascading Style Sheets)</strong> is the styling language used to describe the presentation and visual design of a document written in HTML.</p>
      <p>While HTML gives web pages structure (like headings, buttons, and paragraphs), CSS gives them beauty—colors, margins, fonts, gradients, and layouts!</p>

      <h2>The Anatomy of a CSS Rule</h2>
      <p>A CSS rule consists of a <strong>Selector</strong> and a <strong>Declaration Block</strong>:</p>

      <div class="w3-code-box">
        <span class="code-badge">CSS Syntax Diagram</span>
        <pre><code>/* Selector { Property: Value; } */
h1 {
  color: #10b981;        /* Property: Value; */
  font-size: 32px;       /* Property: Value; */
  text-align: center;    /* Property: Value; */
}</code></pre>
      </div>

      <h2>The 3 Main CSS Selectors</h2>
      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Selector Type</th><th>Syntax</th><th>Example</th><th>What it Targets</th></tr>
          </thead>
          <tbody>
            <tr><td><strong>Element Selector</strong></td><td><code>tagname</code></td><td><code>button { ... }</code></td><td>Targets ALL <code>&lt;button&gt;</code> tags on the page</td></tr>
            <tr><td><strong>Class Selector</strong></td><td><code>.classname</code></td><td><code>.magic-card { ... }</code></td><td>Targets elements with <code>class="magic-card"</code></td></tr>
            <tr><td><strong>ID Selector</strong></td><td><code>#idname</code></td><td><code>#hero-title { ... }</code></td><td>Targets single unique element with <code>id="hero-title"</code></td></tr>
          </tbody>
        </table>
      </div>

      <h2>How to Link CSS to HTML</h2>
      <p>You can add CSS to HTML in 3 ways:</p>
      <ul>
        <li><strong>External CSS:</strong> Inside a separate <code>style.css</code> file linked with <code>&lt;link rel="stylesheet" href="style.css"&gt;</code> (Recommended best practice).</li>
        <li><strong>Internal CSS:</strong> Inside a <code>&lt;style&gt;</code> tag in the HTML <code>&lt;head&gt;</code>.</li>
        <li><strong>Inline CSS:</strong> Directly on an HTML tag via <code>style="color: red;"</code>.</li>
      </ul>
    `,
    codeExample: `/* Welcome to CSS! Let's style a cool button */
button.magic-btn {
  background-color: #10b981;
  color: #ffffff;
  padding: 12px 24px;
  border: 2px solid #059669;
  border-radius: 12px;
  font-size: 16px;
  font-weight: bold;
  cursor: pointer;
  box-shadow: 0 4px 14px rgba(16, 185, 129, 0.4);
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which CSS selector is used to target an element with class="super-btn"?',
      options: [
        '#super-btn',
        '.super-btn',
        '*super-btn',
        'super-btn()'
      ],
      answer: 1,
      explanation: 'In CSS, classes are selected with a period (dot) prefix: .super-btn. IDs use # and elements use the tag name directly.'
    }
  },

  {
    id: 'css-colors',
    category: 'css-basics',
    title: 'CSS Colors, Gradients & Backgrounds',
    readTime: '5 min',
    xp: 35,
    summary: 'Master Color formats (Hex, RGB, HSL, RGBA), Linear Gradients, Radial Gradients, and backdrop filters.',
    contentHtml: `
      <h2>Ways to Define Colors in CSS</h2>
      <p>CSS provides multiple formats to specify exact colors:</p>
      <ul>
        <li><strong>Color Names:</strong> <code>red</code>, <code>royalblue</code>, <code>gold</code>, <code>rebeccapurple</code></li>
        <li><strong>HEX Codes:</strong> <code>#10b981</code> (Emerald), <code>#38bdf8</code> (Sky Blue), <code>#ffffff</code> (White)</li>
        <li><strong>RGB / RGBA:</strong> <code>rgb(16, 185, 129)</code> or with opacity <code>rgba(16, 185, 129, 0.5)</code></li>
        <li><strong>HSL / HSLA:</strong> <code>hsl(160, 84%, 39%)</code> (Hue, Saturation, Lightness, Alpha)</li>
      </ul>

      <h2>Linear & Radial Gradients</h2>
      <p>Gradients create smooth transitions between two or more colors without using images!</p>

      <div class="w3-code-box">
        <span class="code-badge">Linear Gradient</span>
        <pre><code>.card-gradient {
  /* Gradient at 135-degree angle from emerald to cyan */
  background: linear-gradient(135deg, #10b981 0%, #06b6d4 100%);
}</code></pre>
      </div>

      <div class="w3-code-box">
        <span class="code-badge">Radial Gradient</span>
        <pre><code>.glowing-orb {
  /* Radial glow expanding from center */
  background: radial-gradient(circle, #f59e0b 0%, #0d1117 75%);
}</code></pre>
      </div>
    `,
    codeExample: `/* Gradient Background Card */
.neon-box {
  background: linear-gradient(135deg, #38bdf8, #a855f7);
  color: #ffffff;
  padding: 20px;
  border-radius: 16px;
  box-shadow: 0 10px 25px rgba(168, 85, 247, 0.35);
}`,
    checkpoint: {
      type: 'mcq',
      question: 'What does the "A" in RGBA(0, 0, 0, 0.5) stand for?',
      options: [
        'Angle (rotation)',
        'Alpha (opacity / transparency)',
        'Absorption (darkness)',
        'Aspect Ratio'
      ],
      answer: 1,
      explanation: 'Alpha specifies the opacity level of the color, ranging from 0 (completely transparent) to 1 (fully opaque).'
    }
  },

  {
    id: 'css-typography',
    category: 'css-basics',
    title: 'Typography & Text Styling',
    readTime: '4 min',
    xp: 30,
    summary: 'Style headings and text with font-family, font-weight, line-height, letter-spacing, and text-shadow.',
    contentHtml: `
      <h2>CSS Text Properties</h2>
      <p>Typography sets the tone and readability of your whole application.</p>
      
      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Property</th><th>Example Values</th><th>Description</th></tr>
          </thead>
          <tbody>
            <tr><td><code>font-family</code></td><td><code>'Inter', sans-serif</code></td><td>Specifies the font typeface</td></tr>
            <tr><td><code>font-size</code></td><td><code>16px</code>, <code>1.25rem</code>, <code>2vw</code></td><td>Controls the size of text</td></tr>
            <tr><td><code>font-weight</code></td><td><code>400</code> (Normal), <code>700</code> (Bold), <code>900</code></td><td>Thickness of letter glyphs</td></tr>
            <tr><td><code>line-height</code></td><td><code>1.5</code>, <code>1.7</code></td><td>Vertical space between lines of text</td></tr>
            <tr><td><code>letter-spacing</code></td><td><code>0.5px</code>, <code>1px</code></td><td>Horizontal spacing between letters</td></tr>
            <tr><td><code>text-shadow</code></td><td><code>0 2px 8px rgba(0,0,0,0.5)</code></td><td>Adds a drop shadow behind text</td></tr>
          </tbody>
        </table>
      </div>
    `,
    codeExample: `/* Modern Hero Typography */
.hero-heading {
  font-family: 'Poppins', sans-serif;
  font-size: 2.5rem;
  font-weight: 800;
  line-height: 1.2;
  letter-spacing: -0.5px;
  color: #ffffff;
  text-shadow: 0 0 20px rgba(56, 189, 248, 0.5);
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which property controls the vertical spacing between lines in a text block?',
      options: [
        'letter-spacing',
        'word-spacing',
        'line-height',
        'text-indent'
      ],
      answer: 2,
      explanation: 'line-height specifies the distance between lines of text, ensuring optimal readability.'
    }
  },

  // ==========================================
  // --- CSS TRACK: BOX MODEL & BORDERS ---
  // ==========================================
  {
    id: 'css-boxmodel',
    category: 'css-boxmodel',
    title: 'The CSS Box Model Masterclass',
    readTime: '6 min',
    xp: 40,
    summary: 'Understand the fundamental 4 layers of every HTML element: Content, Padding, Border, and Margin.',
    contentHtml: `
      <h2>The 4 Layers of Every Box</h2>
      <p>In CSS, every HTML element is treated as a rectangular box. The CSS Box Model describes how these 4 concentric layers interact:</p>

      <ul>
        <li><strong>1. Content (Center):</strong> The actual text, image, or video inside the element.</li>
        <li><strong>2. Padding (Inner cushion):</strong> Transparent space clearing the area <em>inside</em> the border around the content.</li>
        <li><strong>3. Border (The wall):</strong> A border that wraps around the padding and content.</li>
        <li><strong>4. Margin (Outer cushion):</strong> Transparent space clearing the area <em>outside</em> the border, pushing sibling elements away.</li>
      </ul>

      <h2>The Magic of <code>box-sizing: border-box</code></h2>
      <p>By default in older CSS (<code>content-box</code>), adding padding or borders increased the element's total width. With modern <code>box-sizing: border-box</code>, the padding and border are included <strong>inside</strong> the width you set!</p>

      <div class="w3-code-box">
        <span class="code-badge">Universal Box-Sizing Reset</span>
        <pre><code>/* Add this to top of every stylesheet! */
* {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}</code></pre>
      </div>
    `,
    codeExample: `/* Complete Box Model Styling */
.featured-card {
  width: 300px;
  
  /* Content styling */
  background-color: #161b22;
  color: #f0f6fc;
  
  /* Inner spacing (Padding) */
  padding: 24px;
  
  /* The Wall (Border) */
  border: 2px solid #30363d;
  border-radius: 16px;
  
  /* Outer spacing (Margin) */
  margin: 20px auto;
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which Box Model layer creates space OUTSIDE the border, pushing away surrounding elements?',
      options: [
        'Padding',
        'Border',
        'Margin',
        'Outline'
      ],
      answer: 2,
      explanation: 'Margin creates empty space outside the border. Padding creates empty space inside the border.'
    }
  },

  {
    id: 'css-borders',
    category: 'css-boxmodel',
    title: 'Borders, Rounded Corners & Glow Shadows',
    readTime: '4 min',
    xp: 35,
    summary: 'Craft futuristic UI components with border-radius, outline offsets, and multi-layered box-shadow glows.',
    contentHtml: `
      <h2>Border Radius for Rounded Buttons & Circles</h2>
      <p>Use <code>border-radius</code> to curve corners into smooth pills or perfect circular avatars:</p>
      <ul>
        <li><code>border-radius: 12px;</code> &rarr; Smooth curved card</li>
        <li><code>border-radius: 9999px;</code> &rarr; Oval pill button</li>
        <li><code>border-radius: 50%;</code> on a square width/height &rarr; Perfect Circle</li>
      </ul>

      <h2>The Power of <code>box-shadow</code></h2>
      <p>Syntax: <code>box-shadow: [offset-x] [offset-y] [blur-radius] [spread-radius] [color];</code></p>
      <div class="w3-code-box">
        <span class="code-badge">Multi-layer Neon Glow</span>
        <pre><code>.neon-glow-card {
  border: 2px solid #10b981;
  border-radius: 16px;
  box-shadow: 
    0 4px 12px rgba(0, 0, 0, 0.5),
    0 0 25px rgba(16, 185, 129, 0.4),
    0 0 50px rgba(16, 185, 129, 0.2);
}</code></pre>
      </div>
    `,
    codeExample: `/* Glowing Cyberpunk Button */
.cyber-btn {
  background-color: #090c10;
  color: #38bdf8;
  border: 2px solid #38bdf8;
  border-radius: 20px;
  padding: 10px 24px;
  font-weight: 800;
  box-shadow: 0 0 20px rgba(56, 189, 248, 0.4);
  cursor: pointer;
}`,
    checkpoint: {
      type: 'mcq',
      question: 'How do you turn an element with equal width and height into a perfect circle in CSS?',
      options: [
        'border-radius: 50%',
        'shape-circle: true',
        'border-round: 100px',
        'clip-path: oval()'
      ],
      answer: 0,
      explanation: 'Setting border-radius: 50% on an element with equal width and height renders a mathematically perfect circle.'
    }
  },

  // ==========================================
  // --- CSS TRACK: LAYOUT (FLEXBOX & GRID) ---
  // ==========================================
  {
    id: 'css-flexbox',
    category: 'css-layout',
    title: 'Flexbox Superpowers (Row, Align & Justify)',
    readTime: '6 min',
    xp: 45,
    summary: 'Learn CSS Flexible Box Layout to effortlessly align, distribute, and center items horizontally and vertically.',
    contentHtml: `
      <h2>Why Flexbox?</h2>
      <p>Before Flexbox, centering a box vertically in CSS was notoriously tricky. With Flexbox, it takes just 3 lines!</p>

      <div class="w3-code-box">
        <span class="code-badge">The Legendary Perfect Centering</span>
        <pre><code>.center-everything {
  display: flex;
  justify-content: center; /* Centers horizontally along main axis */
  align-items: center;     /* Centers vertically along cross axis */
}</code></pre>
      </div>

      <h2>Key Flexbox Container Properties</h2>
      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Property</th><th>Common Values</th><th>What it Does</th></tr>
          </thead>
          <tbody>
            <tr><td><code>display</code></td><td><code>flex</code>, <code>inline-flex</code></td><td>Activates flexbox context</td></tr>
            <tr><td><code>flex-direction</code></td><td><code>row</code>, <code>column</code>, <code>row-reverse</code></td><td>Sets primary axis direction</td></tr>
            <tr><td><code>justify-content</code></td><td><code>flex-start</code>, <code>center</code>, <code>space-between</code>, <code>space-around</code>, <code>space-evenly</code></td><td>Aligns items along Main Axis</td></tr>
            <tr><td><code>align-items</code></td><td><code>stretch</code>, <code>center</code>, <code>flex-start</code>, <code>flex-end</code></td><td>Aligns items along Cross Axis</td></tr>
            <tr><td><code>gap</code></td><td><code>8px</code>, <code>16px</code>, <code>24px</code></td><td>Sets spacing between flex children without extra margins!</td></tr>
            <tr><td><code>flex-wrap</code></td><td><code>nowrap</code>, <code>wrap</code></td><td>Wraps items onto new lines if space runs out</td></tr>
          </tbody>
        </table>
      </div>
    `,
    codeExample: `/* Responsive Navigation Bar with Flexbox */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 12px 24px;
  background-color: #161b22;
  gap: 16px;
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which flexbox property creates equal spacing between flex child items without needing margins?',
      options: [
        'gap',
        'spacer',
        'item-margin',
        'flex-space'
      ],
      answer: 0,
      explanation: 'The modern CSS gap property sets explicit gutter space between flex or grid items.'
    }
  },

  {
    id: 'css-grid',
    category: 'css-layout',
    title: 'CSS Grid Mastery (Columns & Rows)',
    readTime: '6 min',
    xp: 45,
    summary: 'Build 2-dimensional layouts, dashboard bento boxes, and responsive card galleries using CSS Grid.',
    contentHtml: `
      <h2>Flexbox vs CSS Grid</h2>
      <ul>
        <li><strong>Flexbox:</strong> 1-Dimensional (Ideal for rows OR columns, toolbars, navbars).</li>
        <li><strong>CSS Grid:</strong> 2-Dimensional (Controls both Rows AND Columns simultaneously—ideal for page layouts, galleries, and dashboards).</li>
      </ul>

      <h2>The Responsive Auto-Fit Grid</h2>
      <p>You can create a fully responsive card grid that automatically wraps cards without needing a single media query!</p>

      <div class="w3-code-box">
        <span class="code-badge">Modern Responsive Grid</span>
        <pre><code>.card-grid {
  display: grid;
  /* Automatically fill columns, minimum 240px each, expand to 1 fraction */
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: 20px;
}</code></pre>
      </div>
    `,
    codeExample: `/* 3-Column Dashboard Bento Grid */
.bento-grid {
  display: grid;
  grid-template-columns: 2fr 1fr;
  grid-template-rows: auto auto;
  gap: 16px;
}`,
    checkpoint: {
      type: 'mcq',
      question: 'What does "1fr" represent in CSS Grid?',
      options: [
        '1 Frame rate per second',
        '1 Fraction of available free space in the grid container',
        '1 Fixed rem unit',
        '1 Font resolution'
      ],
      answer: 1,
      explanation: 'The fr unit represents a fraction of the leftover free space in the grid container.'
    }
  },

  // ==========================================
  // --- CSS TRACK: ANIMATIONS & RESPONSIVE ---
  // ==========================================
  {
    id: 'css-transitions',
    category: 'css-animations',
    title: 'CSS Transitions, Hover Magic & Transforms',
    readTime: '5 min',
    xp: 35,
    summary: 'Bring UI buttons and cards to life with smooth hover states, 2D transforms (scale, rotate, translate), and bezier curves.',
    contentHtml: `
      <h2>CSS Transitions</h2>
      <p>Transitions let you smoothly interpolate property changes over time when a user hovers or clicks:</p>
      
      <div class="w3-code-box">
        <span class="code-badge">Hover Transition</span>
        <pre><code>.interactive-card {
  background-color: #161b22;
  transition: transform 0.3s cubic-bezier(0.34, 1.56, 0.64, 1), box-shadow 0.3s ease;
}

.interactive-card:hover {
  transform: translateY(-8px) scale(1.03);
  box-shadow: 0 16px 32px rgba(16, 185, 129, 0.3);
}</code></pre>
      </div>

      <h2>2D Transforms</h2>
      <ul>
        <li><code>transform: scale(1.1);</code> &rarr; Magnifies element by 10%</li>
        <li><code>transform: rotate(15deg);</code> &rarr; Tilts element by 15 degrees</li>
        <li><code>transform: translateY(-5px);</code> &rarr; Floats element upward</li>
      </ul>
    `,
    codeExample: `/* Bouncy Button with Hover Effect */
.bouncy-btn {
  background: #10b981;
  color: #fff;
  padding: 12px 24px;
  border-radius: 12px;
  border: none;
  font-weight: 700;
  cursor: pointer;
  transition: all 0.2s cubic-bezier(0.34, 1.56, 0.64, 1);
}
.bouncy-btn:hover {
  transform: translateY(-3px) scale(1.05);
  box-shadow: 0 8px 20px rgba(16, 185, 129, 0.5);
}
.bouncy-btn:active {
  transform: scale(0.95);
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which CSS pseudo-class is used to apply styles when the mouse cursor rests over an element?',
      options: [
        ':hover',
        ':focus',
        ':active',
        ':visited'
      ],
      answer: 0,
      explanation: ':hover triggers when the mouse pointer is over the element.'
    }
  },

  {
    id: 'css-keyframes',
    category: 'css-animations',
    title: 'CSS Keyframe Animations (@keyframes)',
    readTime: '6 min',
    xp: 40,
    summary: 'Build continuous spinning badges, bouncing robots, and pulsing glowing orbs using pure CSS @keyframes.',
    contentHtml: `
      <h2>The @keyframes Rule</h2>
      <p>While transitions only animate from Point A to Point B on hover/click, <code>@keyframes</code> animations can run continuously on their own through multiple steps!</p>

      <div class="w3-code-box">
        <span class="code-badge">Keyframe Definition</span>
        <pre><code>/* Define animation steps */
@keyframes bob-dancing {
  0%   { transform: rotate(-6deg) translateY(0); }
  50%  { transform: rotate(0deg) translateY(-10px); }
  100% { transform: rotate(6deg) translateY(0); }
}

/* Attach animation to element */
.robot-bob {
  animation: bob-dancing 0.6s infinite alternate ease-in-out;
}</code></pre>
      </div>

      <h2>Animation Shorthand Properties</h2>
      <p><code>animation: [name] [duration] [timing-function] [delay] [iteration-count] [direction];</code></p>
    `,
    codeExample: `/* Infinite Neon Pulse */
@keyframes neon-pulse {
  0%, 100% {
    box-shadow: 0 0 10px #38bdf8;
    transform: scale(1);
  }
  50% {
    box-shadow: 0 0 30px #38bdf8;
    transform: scale(1.08);
  }
}

.glowing-badge {
  display: inline-block;
  padding: 8px 16px;
  background: #090c10;
  color: #38bdf8;
  border: 2px solid #38bdf8;
  border-radius: 20px;
  animation: neon-pulse 1.5s infinite ease-in-out;
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which CSS property value makes a keyframe animation loop forever without stopping?',
      options: [
        'animation-iteration-count: infinite',
        'animation-repeat: always',
        'animation-loop: true',
        'animation-play: forever'
      ],
      answer: 0,
      explanation: 'animation-iteration-count: infinite directs the browser to repeat the animation continuously.'
    }
  },

  {
    id: 'css-responsive',
    category: 'css-animations',
    title: 'Responsive Design & Media Queries',
    readTime: '5 min',
    xp: 35,
    summary: 'Make your web applications look stunning on smartphones, tablets, laptops, and 4K displays with media queries.',
    contentHtml: `
      <h2>Mobile-First Responsive Design</h2>
      <p>Today, more than 60% of all web traffic comes from mobile phones. <strong>Media queries</strong> allow CSS to adapt styles based on screen width, height, or orientation.</p>

      <div class="w3-code-box">
        <span class="code-badge">Media Query Example</span>
        <pre><code>/* Default styles (Mobile First) */
.content-layout {
  display: flex;
  flex-direction: column;
  padding: 12px;
}

/* Tablet & Desktop (Screens 768px wide or greater) */
@media (min-width: 768px) {
  .content-layout {
    flex-direction: row;
    padding: 32px;
    gap: 24px;
  }
}</code></pre>
      </div>
    `,
    codeExample: `/* Responsive Split View */
.split-view {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

@media (min-width: 768px) {
  .split-view {
    flex-direction: row;
  }
}`,
    checkpoint: {
      type: 'mcq',
      question: 'What is the standard CSS at-rule used to apply styles conditionally based on viewport width?',
      options: [
        '@media',
        '@viewport',
        '@screen',
        '@device'
      ],
      answer: 0,
      explanation: '@media queries allow you to specify CSS rules that apply only when certain media conditions (like min-width or max-width) are met.'
    }
  },

  // ==========================================
  // --- JAVASCRIPT TRACK ---
  // ==========================================
  {
    id: 'js-intro',
    category: 'basics',
    title: 'JavaScript Introduction',
    readTime: '4 min',
    xp: 25,
    summary: 'What is JavaScript, why is it the most popular programming language, and how does it power the web?',
    contentHtml: `
      <h2>What is JavaScript?</h2>
      <p><strong>JavaScript</strong> is the world's most popular lightweight, interpreted (or just-in-time compiled) programming language with first-class functions.</p>
      <p>While it is most well-known as the scripting language for Web pages, many non-browser environments also use it, such as <strong>Node.js</strong>, Apache CouchDB, and Adobe Acrobat.</p>

      <div class="w3-note w3-panel">
        <h4>Did You Know?</h4>
        <p>JavaScript was created in 1995 by <strong>Brendan Eich</strong> in just 10 days while working at Netscape Communications!</p>
      </div>

      <h2>The Three Pillars of the Web</h2>
      <ul>
        <li><strong>HTML</strong> defines the content and structure of web pages.</li>
        <li><strong>CSS</strong> specifies the layout, styling, and visual appearance.</li>
        <li><strong>JavaScript</strong> programs the interactive behavior, logic, and animations.</li>
      </ul>
    `,
    codeExample: `// Welcome to JavaScript!
console.log("Hello, World!");

// Math calculations
let sum = 20 + 25;
console.log("20 + 25 =", sum);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which of the following is the main purpose of JavaScript in web development?',
      options: [
        'Defining the semantic structure of a webpage',
        'Programming the behavior and interactive logic of web pages',
        'Storing web pages permanently on DNS servers',
        'Creating 3D vector graphics only'
      ],
      answer: 1,
      explanation: 'HTML provides structure, CSS provides presentation, and JavaScript handles interactive behavior and dynamic logic.'
    }
  },

  {
    id: 'html-and-js',
    category: 'basics',
    title: 'HTML & JavaScript: How They Work Together',
    readTime: '5 min',
    xp: 35,
    summary: 'Discover how HTML tags (buttons, text, inputs) act as the body, and JavaScript acts as the interactive brain.',
    contentHtml: `
      <h2>How HTML & JavaScript Connect</h2>
      <p>Think of a website like a superhero or a robot:</p>
      <ul>
        <li><strong>HTML is the Skeleton & Body:</strong> It creates the buttons (<code>&lt;button&gt;</code>), headings (<code>&lt;h1&gt;</code>), inputs (<code>&lt;input&gt;</code>), and boxes (<code>&lt;div&gt;</code>).</li>
        <li><strong>CSS is the Clothes & Style:</strong> It chooses the colors, margins, round borders, and fonts.</li>
        <li><strong>JavaScript is the Brain & Muscle:</strong> It listens for clicks, runs calculations, moves elements, and plays sounds!</li>
      </ul>

      <h2>The 3 Key Steps to Controlling HTML with JS</h2>
      
      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Step</th><th>JavaScript Code</th><th>What It Does</th></tr>
          </thead>
          <tbody>
            <tr><td><strong>1. Find Element</strong></td><td><code>const btn = document.getElementById("magic-btn");</code></td><td>Grabs the HTML button by its unique ID</td></tr>
            <tr><td><strong>2. Listen for Event</strong></td><td><code>btn.addEventListener("click", () => { ... });</code></td><td>Waits for user to click or type</td></tr>
            <tr><td><strong>3. Change HTML/Style</strong></td><td><code>btn.textContent = "Clicked!";<br>btn.style.color = "gold";</code></td><td>Updates text or CSS style dynamically</td></tr>
          </tbody>
        </table>
      </div>

      <h2>Sample HTML + JavaScript Code</h2>
      <div class="w3-code-box">
        <span class="code-badge">HTML Markup</span>
        <pre><code>&lt;!-- In your HTML file --&gt;
&lt;h1 id="title"&gt;Hello World&lt;/h1&gt;
&lt;button id="change-btn"&gt;Make Magic Happen!&lt;/button&gt;</code></pre>
      </div>

      <div class="w3-code-box">
        <span class="code-badge">JavaScript Logic</span>
        <pre><code>// In your JavaScript file
const btn = document.getElementById("change-btn");
const title = document.getElementById("title");

btn.onclick = () => {
  title.textContent = "🚀 JavaScript Changed Me!";
  title.style.color = "#10b981";
  title.style.transform = "scale(1.2)";
};</code></pre>
      </div>
    `,
    codeExample: `// 1. Finding HTML element by ID
const button = document.getElementById("magic-btn");
const heading = document.getElementById("main-heading");

// 2. Reacting to user clicks
button.onclick = () => {
  heading.textContent = "✨ JavaScript is magic!";
  heading.style.color = "#38bdf8";
  console.log("Heading text and style changed dynamically!");
};`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method in JavaScript is used to find an HTML element by its ID attribute?',
      options: [
        'document.findHTML()',
        'document.getElementById()',
        'document.searchTag()',
        'window.selectElement()'
      ],
      answer: 1,
      explanation: 'document.getElementById("idName") is the primary DOM method for selecting a single unique HTML element by its ID.'
    }
  },

  {
    id: 'js-output',
    category: 'basics',
    title: 'JavaScript Output & Console',
    readTime: '5 min',
    xp: 30,
    summary: 'Master the 4 primary ways JavaScript can display output to users and developers.',
    contentHtml: `
      <h2>JavaScript Display Possibilities</h2>
      <p>JavaScript can "display" data in different ways:</p>
      <ol>
        <li>Writing into an HTML element, using <code>innerHTML</code> or <code>textContent</code>.</li>
        <li>Writing into the HTML output stream using <code>document.write()</code> (mostly for testing).</li>
        <li>Writing into an alert box, using <code>window.alert()</code>.</li>
        <li>Writing into the browser debugging console, using <code>console.log()</code>, <code>console.error()</code>, <code>console.table()</code>.</li>
      </ol>

      <div class="w3-code-box">
        <span class="code-badge">Console Methods</span>
        <pre><code>console.log("Standard output");
console.warn("A warning message");
console.error("Critical error!");
console.table([{ name: "Alice", age: 25 }, { name: "Bob", age: 30 }]);</code></pre>
      </div>

      <div class="w3-note w3-warning">
        <h4>Important Tip</h4>
        <p>For debugging and clean development, always prefer <code>console.log()</code> and DOM modification rather than <code>window.alert()</code>, which blocks the UI thread.</p>
      </div>
    `,
    codeExample: `// Test different console outputs
console.log("1. Normal log output");
console.warn("2. Warning alert");
console.error("3. Custom error alert");

// Display tabular data easily
const users = [
  { id: 1, name: "Ada Lovelace", role: "Developer" },
  { id: 2, name: "Alan Turing", role: "Cryptanalyst" },
  { id: 3, name: "Grace Hopper", role: "Compiler Pioneer" }
];
console.table(users);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method writes directly into the browser developer console for debugging?',
      options: [
        'document.write()',
        'window.alert()',
        'console.log()',
        'print()'
      ],
      answer: 2,
      explanation: 'console.log() sends messages directly to the developer console without disrupting the user interface.'
    }
  },

  {
    id: 'js-variables',
    category: 'basics',
    title: 'JavaScript Variables: let, const & var',
    readTime: '6 min',
    xp: 35,
    summary: 'Learn the differences between let, const, and var, variable scopes, and modern best practices.',
    contentHtml: `
      <h2>Declaring Variables</h2>
      <p>In modern JavaScript (ES6+), there are three primary keywords used to declare variables:</p>
      <ul>
        <li><code>const</code> - Declares a block-scoped variable whose value <strong>cannot be reassigned</strong>. (Use by default!)</li>
        <li><code>let</code> - Declares a block-scoped variable that <strong>can be reassigned</strong>.</li>
        <li><code>var</code> - Declares a function-scoped or globally-scoped variable (legacy, avoid in modern code).</li>
      </ul>

      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Keyword</th><th>Scope</th><th>Reassignable?</th><th>Redeclarable?</th><th>Hoisting</th></tr>
          </thead>
          <tbody>
            <tr><td><code>const</code></td><td>Block</td><td>No</td><td>No</td><td>TDZ (Temporal Dead Zone)</td></tr>
            <tr><td><code>let</code></td><td>Block</td><td>Yes</td><td>No</td><td>TDZ (Temporal Dead Zone)</td></tr>
            <tr><td><code>var</code></td><td>Function</td><td>Yes</td><td>Yes</td><td>Hoisted as undefined</td></tr>
          </tbody>
        </table>
      </div>

      <div class="w3-note w3-tip">
        <h4>Best Practice Rule</h4>
        <p>Always declare variables with <code>const</code> unless you know the value will be reassigned, in which case use <code>let</code>. Never use <code>var</code> in modern code.</p>
      </div>
    `,
    codeExample: `// 1. Const cannot be reassigned
const PI = 3.14159;
console.log("PI:", PI);

// 2. Objects declared with const can still mutate properties
const student = { name: "Sarah", score: 95 };
student.score = 98; // Valid!
console.log("Updated student:", student);

// 3. Let is block-scoped and reassignable
let counter = 0;
counter += 5;
console.log("Counter:", counter);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which keyword should you use to declare a variable that will NOT be reassigned?',
      options: [
        'let',
        'const',
        'var',
        'def'
      ],
      answer: 1,
      explanation: 'const creates immutable variable bindings, ensuring that the identifier cannot be reassigned.'
    }
  },

  // --- DATA TYPES & OPERATORS ---
  {
    id: 'js-datatypes',
    category: 'datatypes',
    title: 'JavaScript Data Types',
    readTime: '5 min',
    xp: 35,
    summary: 'Understand JavaScript Primitive types vs Reference (Object) types, and the typeof operator.',
    contentHtml: `
      <h2>JavaScript has 8 Data Types</h2>
      <p>JavaScript data types are divided into two main categories:</p>

      <h3>1. Primitive Types (Stored by value)</h3>
      <ul>
        <li><code>String</code> - Text data (e.g., <code>"Hello"</code>, <code>'World'</code>)</li>
        <li><code>Number</code> - Integers and floats (e.g., <code>42</code>, <code>3.14</code>)</li>
        <li><code>BigInt</code> - Arbitrarily large integers (e.g., <code>9007199254740991n</code>)</li>
        <li><code>Boolean</code> - <code>true</code> or <code>false</code></li>
        <li><code>Undefined</code> - A variable declared without an assigned value</li>
        <li><code>Null</code> - Intentional absence of any object value</li>
        <li><code>Symbol</code> - Unique, immutable identifier</li>
      </ul>

      <h3>2. Reference Types (Stored by reference)</h3>
      <ul>
        <li><code>Object</code> - Key-value collections (e.g. <code>{ name: "John", age: 30 }</code>)</li>
        <li><code>Array</code> - Ordered lists (technically an Object subtype, e.g. <code>[1, 2, 3]</code>)</li>
        <li><code>Function</code> - Callable code blocks</li>
      </ul>

      <div class="w3-code-box">
        <span class="code-badge">The typeof Operator</span>
        <pre><code>typeof "John"         // "string"
typeof 3.14           // "number"
typeof NaN            // "number"
typeof false          // "boolean"
typeof [1, 2, 3]      // "object"
typeof { a: 1 }       // "object"
typeof null           // "object" (historic JS bug!)
typeof undefined      // "undefined"</code></pre>
      </div>
    `,
    codeExample: `// Check data types dynamically
const age = 22;
const name = "Marcus";
const isEnrolled = true;
const grades = [90, 85, 92];
const profile = { city: "New York", country: "USA" };
const unknownValue = null;

console.log("typeof age:", typeof age);
console.log("typeof name:", typeof name);
console.log("typeof isEnrolled:", typeof isEnrolled);
console.log("typeof grades:", typeof grades, "(Is Array?", Array.isArray(grades), ")");
console.log("typeof profile:", typeof profile);
console.log("typeof unknownValue:", typeof unknownValue);`,
    checkpoint: {
      type: 'mcq',
      question: 'What does the expression typeof null return in JavaScript?',
      options: [
        '"null"',
        '"undefined"',
        '"object"',
        '"number"'
      ],
      answer: 2,
      explanation: 'In JavaScript, typeof null historically returns "object" due to an original legacy implementation in the early JS engine.'
    }
  },

  {
    id: 'js-operators',
    category: 'datatypes',
    title: 'JavaScript Operators & Equality',
    readTime: '6 min',
    xp: 35,
    summary: 'Strict (===) vs Loose (==) equality, Logical operators, Nullish Coalescing (??), and Optional Chaining (?.).',
    contentHtml: `
      <h2>Comparison Operators: == vs ===</h2>
      <p>Always use strict equality <code>===</code> rather than loose equality <code>==</code>:</p>
      <ul>
        <li><code>===</code> (Strict equality): Compares both <strong>value and type</strong> without type coercion.</li>
        <li><code>==</code> (Loose equality): Converts types before comparison (coercion), causing surprising bugs!</li>
      </ul>

      <div class="w3-code-box">
        <span class="code-badge">Equality Comparison Examples</span>
        <pre><code>5 == "5"     // true  (type coerced)
5 === "5"    // false (different types: number vs string)
0 == false   // true
0 === false  // false
null == undefined  // true
null === undefined // false</code></pre>
      </div>

      <h2>Modern Logical Operators (ES2020+)</h2>
      <ul>
        <li><strong>Nullish Coalescing (<code>??</code>)</strong>: Returns the right-hand operand only if the left operand is <code>null</code> or <code>undefined</code> (unlike <code>||</code> which falls back on falsy values like <code>0</code> or <code>""</code>).</li>
        <li><strong>Optional Chaining (<code>?.</code>)</strong>: Safely access nested object properties without throwing <code>TypeError: Cannot read properties of undefined</code>.</li>
      </ul>
    `,
    codeExample: `// Test Strict vs Loose equality
console.log('5 == "5" is:', 5 == "5");
console.log('5 === "5" is:', 5 === "5");

// Modern Nullish Coalescing (??) vs OR (||)
const userScore = 0; // Valid score!
const defaultScoreOr = userScore || 100; // Bug: falls back to 100 because 0 is falsy
const defaultScoreNullish = userScore ?? 100; // Correct: preserves 0!

console.log("Using || :", defaultScoreOr);
console.log("Using ?? :", defaultScoreNullish);

// Optional Chaining (?.)
const user = { profile: { name: "Elena" } };
console.log("Safe access:", user.profile?.name);
console.log("Non-existent property:", user.address?.street); // undefined without crash`,
    checkpoint: {
      type: 'mcq',
      question: 'What is the result of 0 ?? 42 versus 0 || 42?',
      options: [
        '0 and 0',
        '0 and 42',
        '42 and 0',
        '42 and 42'
      ],
      answer: 1,
      explanation: '0 is a valid non-nullish value, so ?? returns 0. However, 0 is falsy, so || falls back to 42.'
    }
  },

  // --- CONTROL FLOW & LOOPS ---
  {
    id: 'js-conditionals',
    category: 'control',
    title: 'Conditionals: if, else & switch',
    readTime: '5 min',
    xp: 30,
    summary: 'Branching logic using if/else statements, ternary operators, and switch statements.',
    contentHtml: `
      <h2>Conditional Statements</h2>
      <p>Conditional statements allow you to perform different actions based on different conditions:</p>
      <ul>
        <li><code>if</code> - specifies a block of code to be executed if a condition is true.</li>
        <li><code>else if</code> - specifies a new condition to test if the first condition is false.</li>
        <li><code>else</code> - specifies code to execute if all previous conditions are false.</li>
        <li><code>switch</code> - selects one of many code blocks to be executed based on matching an expression.</li>
      </ul>

      <h2>The Ternary Operator</h2>
      <p>A concise one-line syntax for simple if-else expressions:</p>
      <div class="w3-code-box">
        <pre><code>const access = age >= 18 ? "Granted" : "Denied";</code></pre>
      </div>
    `,
    codeExample: `// 1. If-Else Ladder
const score = 88;
let grade;

if (score >= 90) {
  grade = "A";
} else if (score >= 80) {
  grade = "B";
} else if (score >= 70) {
  grade = "C";
} else {
  grade = "F";
}
console.log("Score:", score, "Grade:", grade);

// 2. Switch Statement
const dayNumber = 3;
let dayName;

switch (dayNumber) {
  case 1: dayName = "Monday"; break;
  case 2: dayName = "Tuesday"; break;
  case 3: dayName = "Wednesday"; break;
  case 4: dayName = "Thursday"; break;
  case 5: dayName = "Friday"; break;
  default: dayName = "Weekend";
}
console.log("Day 3 is:", dayName);`,
    checkpoint: {
      type: 'mcq',
      question: 'Why is the "break" statement important inside a switch case?',
      options: [
        'To declare new variables',
        'To stop execution from falling through to the next cases',
        'To speed up CPU clock speed',
        'It is strictly optional and has no effect'
      ],
      answer: 1,
      explanation: 'Without "break", JavaScript continues executing all subsequent cases regardless of their condition (known as fall-through).'
    }
  },

  {
    id: 'js-loops',
    category: 'control',
    title: 'Loops: for, while, for...of & for...in',
    readTime: '6 min',
    xp: 35,
    summary: 'Master standard loops, iterative control, for...of for arrays, and for...in for object keys.',
    contentHtml: `
      <h2>Types of Loops in JavaScript</h2>
      <ul>
        <li><code>for</code> - loops through a block of code a specified number of times.</li>
        <li><code>for...of</code> - loops through values of an iterable object (Arrays, Strings, Sets, Maps).</li>
        <li><code>for...in</code> - loops through enumerable properties (keys) of an Object.</li>
        <li><code>while</code> - loops through a block of code while a specified condition is true.</li>
        <li><code>do...while</code> - executes the block once before checking if the condition is true.</li>
      </ul>

      <div class="w3-note w3-tip">
        <h4>Key Distinction: for...of vs for...in</h4>
        <p>Use <strong><code>for...of</code></strong> for Array items / Iterables.</p>
        <p>Use <strong><code>for...in</code></strong> for Object keys.</p>
      </div>
    `,
    codeExample: `// 1. Standard for loop
console.log("Standard loop:");
for (let i = 1; i <= 3; i++) {
  console.log("  Count:", i);
}

// 2. for...of loop on Array (Values)
const fruits = ["Apple", "Banana", "Cherry"];
console.log("for...of values:");
for (const fruit of fruits) {
  console.log("  Fruit:", fruit);
}

// 3. for...in loop on Object (Keys)
const car = { brand: "Tesla", model: "Model 3", year: 2024 };
console.log("for...in object properties:");
for (const key in car) {
  console.log("  " + key + " -> " + car[key]);
}`,
    checkpoint: {
      type: 'mcq',
      question: 'Which loop is best suited for directly iterating through the elements of an Array in modern JavaScript?',
      options: [
        'for...in',
        'for...of',
        'goto loop',
        'switch loop'
      ],
      answer: 1,
      explanation: 'for...of iterates directly over the values of iterable collections like Arrays, Strings, and Maps.'
    }
  },

  // --- FUNCTIONS & SCOPE ---
  {
    id: 'js-functions',
    category: 'functions',
    title: 'JavaScript Functions & Arrow Syntax',
    readTime: '6 min',
    xp: 40,
    summary: 'Function declarations, expressions, arrow functions, default parameters, and rest arguments.',
    contentHtml: `
      <h2>Defining Functions</h2>
      <p>Functions are the fundamental building blocks in JavaScript. A function is a block of code designed to perform a particular task.</p>

      <h3>1. Function Declaration (Hoisted)</h3>
      <div class="w3-code-box">
        <pre><code>function add(a, b) {
  return a + b;
}</code></pre>
      </div>

      <h3>2. Arrow Function (ES6)</h3>
      <div class="w3-code-box">
        <pre><code>const add = (a, b) => a + b;</code></pre>
      </div>

      <h2>Key Differences with Arrow Functions</h2>
      <ul>
        <li>Arrow functions do not have their own <code>this</code> context; they inherit <code>this</code> from the enclosing lexical scope.</li>
        <li>Arrow functions do not have an <code>arguments</code> object.</li>
        <li>Arrow functions cannot be used as constructors (cannot use with <code>new</code>).</li>
      </ul>

      <h2>Default Parameters & Rest Parameters (<code>...</code>)</h2>
      <div class="w3-code-box">
        <pre><code>// Default parameters
function greet(name = "Guest") {
  return \`Hello, \${name}!\`;
}

// Rest parameters collect all extra arguments into an array
function sumAll(...numbers) {
  return numbers.reduce((acc, curr) => acc + curr, 0);
}</code></pre>
      </div>
    `,
    codeExample: `// 1. Arrow functions
const multiply = (x, y) => x * y;
console.log("5 * 8 =", multiply(5, 8));

// 2. Rest parameters (...args)
const calculateTotal = (...prices) => {
  return prices.reduce((total, p) => total + p, 0);
};
console.log("Total price:", calculateTotal(19.99, 5.50, 42.00, 10.00));

// 3. Higher order functions: passing functions as arguments
const applyOperation = (a, b, operation) => operation(a, b);
console.log("Higher order result:", applyOperation(10, 20, (x, y) => x + y));`,
    checkpoint: {
      type: 'mcq',
      question: 'How do Arrow Functions handle the "this" keyword compared to regular functions?',
      options: [
        'They create a new dynamic this binding on every call',
        'They lexically inherit "this" from the parent enclosing scope',
        'They permanently bind "this" to window/global',
        'They forbid any usage of properties or variables'
      ],
      answer: 1,
      explanation: 'Arrow functions do not bind their own this; they capture the this value of the enclosing execution context.'
    }
  },

  {
    id: 'js-closures',
    category: 'functions',
    title: 'Scope, Closures & Lexical Environment',
    readTime: '7 min',
    xp: 45,
    summary: 'Master one of JavaScript’s most powerful concepts: closures, lexical scope, and data privacy.',
    contentHtml: `
      <h2>What is a Closure?</h2>
      <p>A <strong>closure</strong> is the combination of a function bundled together (enclosed) with references to its surrounding state (the <strong>lexical environment</strong>).</p>
      <p>In other words, a closure gives an inner function <strong>access to an outer function's scope</strong> even after the outer function has finished executing!</p>

      <div class="w3-code-box">
        <span class="code-badge">Classic Closure Counter</span>
        <pre><code>function createCounter() {
  let count = 0; // Private variable!
  
  return {
    increment: () => ++count,
    decrement: () => --count,
    getCount: () => count
  };
}

const counter = createCounter();
counter.increment(); // 1
counter.increment(); // 2
console.log(counter.getCount()); // 2
// count is completely protected from outside tampering!</code></pre>
      </div>

      <div class="w3-note w3-tip">
        <h4>Why are Closures useful?</h4>
        <ul>
          <li><strong>Data Privacy & Encapsulation:</strong> Emulate private variables without class syntax.</li>
          <li><strong>Function Factories:</strong> Create custom functions on demand (e.g. currying).</li>
          <li><strong>Event handlers & callbacks:</strong> Retaining state across asynchronous operations.</li>
        </ul>
      </div>
    `,
    codeExample: `// Function Factory using Closure
function createMultiplier(multiplier) {
  return function(number) {
    return number * multiplier;
  };
}

const double = createMultiplier(2);
const triple = createMultiplier(3);
const timesTen = createMultiplier(10);

console.log("double(7) =", double(7));
console.log("triple(7) =", triple(7));
console.log("timesTen(7) =", timesTen(7));

// Private bank account balance
function createBankAccount(initialBalance) {
  let balance = initialBalance;
  return {
    deposit: (amount) => { balance += amount; return balance; },
    withdraw: (amount) => {
      if (amount > balance) return "Insufficient funds!";
      balance -= amount;
      return balance;
    },
    getBalance: () => balance
  };
}

const myAccount = createBankAccount(100);
myAccount.deposit(50);
console.log("Balance after deposit:", myAccount.getBalance());
console.log("Withdrawal:", myAccount.withdraw(30));
console.log("Final balance:", myAccount.getBalance());`,
    checkpoint: {
      type: 'mcq',
      question: 'What enables an inner function to remember and access variables from its outer function even after the outer function has returned?',
      options: [
        'Garbage collection',
        'A JavaScript Closure',
        'Variable Hoisting',
        'CSS Object Model'
      ],
      answer: 1,
      explanation: 'A closure preserves the outer lexical environment in memory, allowing the inner function to access its variables indefinitely.'
    }
  },

  // --- OBJECTS & ARRAYS ---
  {
    id: 'js-objects',
    category: 'objects',
    title: 'JavaScript Objects & Methods',
    readTime: '6 min',
    xp: 35,
    summary: 'Object literals, dot vs bracket notation, methods, this keyword, and static Object methods.',
    contentHtml: `
      <h2>JavaScript Objects</h2>
      <p>Objects in JavaScript are collections of key-value pairs. Values can be primitives, other objects, or functions (which are called <strong>methods</strong>).</p>

      <h2>Static Object Methods (ES6+)</h2>
      <ul>
        <li><code>Object.keys(obj)</code> - Returns an array of all keys.</li>
        <li><code>Object.values(obj)</code> - Returns an array of all values.</li>
        <li><code>Object.entries(obj)</code> - Returns an array of <code>[key, value]</code> pairs.</li>
        <li><code>Object.assign(target, source)</code> - Copies properties to a target object.</li>
        <li><code>Object.freeze(obj)</code> - Prevents modification or addition of properties.</li>
      </ul>
    `,
    codeExample: `const laptop = {
  brand: "Apple",
  model: "MacBook Pro",
  year: 2024,
  specs: {
    cpu: "M3 Max",
    ram: 36
  },
  getSummary() {
    return \`\${this.brand} \${this.model} (\${this.year}) with \${this.specs.cpu}\`;
  }
};

console.log("Summary:", laptop.getSummary());
console.log("Keys:", Object.keys(laptop));
console.log("Values:", Object.values(laptop));
console.log("Entries:", Object.entries(laptop.specs));`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method returns an array of [key, value] pairs for a given object?',
      options: [
        'Object.keys()',
        'Object.values()',
        'Object.entries()',
        'Object.freeze()'
      ],
      answer: 2,
      explanation: 'Object.entries(obj) returns an array of a given object\'s own enumerable string-keyed property [key, value] pairs.'
    }
  },

  {
    id: 'js-arrays',
    category: 'objects',
    title: 'Arrays & Array Iteration Methods',
    readTime: '8 min',
    xp: 45,
    summary: 'Master map, filter, reduce, find, some, every, flat, and immutable array transformation.',
    contentHtml: `
      <h2>Modern Array Iteration Methods</h2>
      <p>Functional array methods do not mutate the original array, making your code clean and predictable:</p>

      <div class="w3-table-responsive">
        <table class="w3-table">
          <thead>
            <tr><th>Method</th><th>Purpose</th><th>Returns</th></tr>
          </thead>
          <tbody>
            <tr><td><code>map()</code></td><td>Transforms each element</td><td>New array of same length</td></tr>
            <tr><td><code>filter()</code></td><td>Selects items matching condition</td><td>New array of matching items</td></tr>
            <tr><td><code>reduce()</code></td><td>Accumulates values to a single result</td><td>Single value (number, object, etc.)</td></tr>
            <tr><td><code>find()</code></td><td>Finds first element matching condition</td><td>Element or undefined</td></tr>
            <tr><td><code>some()</code></td><td>Tests if at least one item passes</td><td>Boolean</td></tr>
            <tr><td><code>every()</code></td><td>Tests if all items pass</td><td>Boolean</td></tr>
            <tr><td><code>includes()</code></td><td>Checks if value exists in array</td><td>Boolean</td></tr>
          </tbody>
        </table>
      </div>
    `,
    codeExample: `const products = [
  { id: 1, name: "Keyboard", price: 75, category: "Tech", stock: 12 },
  { id: 2, name: "Mouse", price: 45, category: "Tech", stock: 0 },
  { id: 3, name: "Desk Mat", price: 25, category: "Office", stock: 30 },
  { id: 4, name: "Monitor", price: 320, category: "Tech", stock: 5 }
];

// 1. Filter: In-stock items only
const inStock = products.filter(item => item.stock > 0);
console.log("In-Stock count:", inStock.length);

// 2. Map: Extract formatted names
const productLabels = inStock.map(p => \`\${p.name} ($ \${p.price})\`);
console.log("Labels:", productLabels);

// 3. Reduce: Calculate total inventory value
const totalInventoryValue = products.reduce((acc, p) => acc + (p.price * p.stock), 0);
console.log("Total inventory value: $" + totalInventoryValue);

// 4. Find: First item over $100
const premiumItem = products.find(p => p.price > 100);
console.log("Premium item:", premiumItem.name);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which array method calculates a single aggregated value (like a total sum or combined object) from an array?',
      options: [
        'filter()',
        'map()',
        'reduce()',
        'forEach()'
      ],
      answer: 2,
      explanation: 'reduce() executes a user-supplied reducer callback function on each element of the array, resulting in a single output value.'
    }
  },

  // --- OOP & CLASSES ---
  {
    id: 'js-classes',
    category: 'oop',
    title: 'Object-Oriented JS & Classes',
    readTime: '7 min',
    xp: 40,
    summary: 'ES6 Classes, constructors, getters/setters, static methods, inheritance with extends and super.',
    contentHtml: `
      <h2>JavaScript Classes (ES6)</h2>
      <p>JavaScript classes are syntactic sugar over JavaScript's existing prototype-based inheritance.</p>

      <div class="w3-code-box">
        <span class="code-badge">Class Definition & Inheritance</span>
        <pre><code>class Animal {
  constructor(name) {
    this.name = name;
  }
  speak() {
    return \`\${this.name} makes a sound.\`;
  }
}

class Dog extends Animal {
  constructor(name, breed) {
    super(name); // Call parent constructor
    this.breed = breed;
  }
  speak() {
    return \`\${this.name} barks!\`;
  }
}</code></pre>
      </div>

      <h2>Private Class Fields & Static Methods</h2>
      <ul>
        <li><code>#privateField</code> - Prefix with <code>#</code> to create truly private variables inaccessible outside the class.</li>
        <li><code>static</code> - Methods attached to the class itself rather than instances (e.g. <code>Math.max()</code>).</li>
      </ul>
    `,
    codeExample: `class BankAccount {
  #balance = 0; // Private field

  constructor(owner, initialBalance = 0) {
    this.owner = owner;
    this.#balance = initialBalance;
  }

  deposit(amount) {
    if (amount <= 0) throw new Error("Deposit must be positive!");
    this.#balance += amount;
    return this.#balance;
  }

  get balance() {
    return \`$\${this.#balance.toFixed(2)}\`;
  }

  static compareAccounts(acc1, acc2) {
    return acc1.#balance - acc2.#balance;
  }
}

const account1 = new BankAccount("Alice", 500);
account1.deposit(250);
console.log("Owner:", account1.owner);
console.log("Formatted balance:", account1.balance);`,
    checkpoint: {
      type: 'mcq',
      question: 'In modern JavaScript, how do you declare a truly private class field?',
      options: [
        'private balance;',
        '#balance;',
        '_balance;',
        'protected balance;'
      ],
      answer: 1,
      explanation: 'Prefixing a property with the hash symbol # (e.g. #balance) makes it a private class field enforced by the JS engine.'
    }
  },

  // --- ASYNCHRONOUS JAVASCRIPT ---
  {
    id: 'js-async',
    category: 'async',
    title: 'Promises & Async / Await',
    readTime: '8 min',
    xp: 50,
    summary: 'Master asynchronous code: Event Loop, Promise states, async/await, and error handling with try/catch.',
    contentHtml: `
      <h2>The Asynchronous Nature of JavaScript</h2>
      <p>JavaScript is single-threaded, meaning it has one call stack. To handle long operations (like network requests or file reads) without freezing the UI, JavaScript uses the <strong>Event Loop</strong>.</p>

      <h2>Promises: 3 States</h2>
      <ul>
        <li><code>Pending</code>: Initial state, neither fulfilled nor rejected.</li>
        <li><code>Fulfilled</code>: Operation completed successfully (resolved).</li>
        <li><code>Rejected</code>: Operation failed.</li>
      </ul>

      <h2>Async / Await (The Modern Standard)</h2>
      <p><code>async/await</code> provides clean, synchronous-looking syntax for working with Promises:</p>
      <div class="w3-code-box">
        <pre><code>async function fetchData() {
  try {
    const response = await fetch('https://api.example.com/data');
    if (!response.ok) throw new Error('HTTP error ' + response.status);
    const data = await response.json();
    console.log(data);
  } catch (error) {
    console.error('Fetch failed:', error.message);
  }
}</code></pre>
      </div>
    `,
    codeExample: `// Simulating an asynchronous database request with a Promise
function fetchUserProfile(userId) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (userId === 1) {
        resolve({ id: 1, username: "dev_pro", role: "admin", karma: 4200 });
      } else {
        reject(new Error("User not found"));
      }
    }, 500);
  });
}

// Consuming with async/await
async function runDemo() {
  console.log("1. Requesting user 1 data...");
  try {
    const user = await fetchUserProfile(1);
    console.log("2. Received user successfully:", user);
  } catch (err) {
    console.error("Error occurred:", err.message);
  }
  console.log("3. Done with request flow!");
}

runDemo();`,
    checkpoint: {
      type: 'mcq',
      question: 'What does a function marked with the "async" keyword always return?',
      options: [
        'A string',
        'A Promise',
        'A generator object',
        'undefined'
      ],
      answer: 1,
      explanation: 'An async function always wraps its return value in a Promise (or returns the Promise directly).'
    }
  },

  // --- DOM & WEB APIS ---
  {
    id: 'js-dom',
    category: 'dom',
    title: 'DOM Manipulation & Event Handling',
    readTime: '7 min',
    xp: 40,
    summary: 'Selecting elements, modifying attributes & CSS, listening to click/input events, and Event Delegation.',
    contentHtml: `
      <h2>What is the DOM?</h2>
      <p>The <strong>Document Object Model (DOM)</strong> is an application programming interface (API) for HTML and XML documents. It represents the page as a tree structure of nodes.</p>

      <h2>Selecting Elements</h2>
      <ul>
        <li><code>document.querySelector(selector)</code> - Returns the first matching element.</li>
        <li><code>document.querySelectorAll(selector)</code> - Returns a NodeList of all matching elements.</li>
        <li><code>document.getElementById(id)</code> - Selects element by unique ID.</li>
      </ul>

      <h2>Modifying HTML & Styles</h2>
      <div class="w3-code-box">
        <pre><code>const button = document.querySelector('#submit-btn');
button.textContent = 'Save Changes';
button.classList.add('active', 'primary');
button.style.backgroundColor = '#04AA6D';</code></pre>
      </div>

      <h2>Event Listeners</h2>
      <div class="w3-code-box">
        <pre><code>button.addEventListener('click', (event) => {
  event.preventDefault();
  console.log('Button clicked at:', event.clientX, event.clientY);
});</code></pre>
      </div>
    `,
    codeExample: `// Simulating DOM manipulation in sandbox
console.log("DOM Selection patterns:");
console.log("1. document.querySelector('.card')");
console.log("2. document.querySelectorAll('button.tab')");

// Dynamic element creation example
const elementSpec = {
  tag: "div",
  className: "alert-box success",
  text: "Profile updated successfully!"
};
console.log("Created element spec:", elementSpec);`,
    checkpoint: {
      type: 'mcq',
      question: 'Which method is recommended for selecting the first element that matches a specified CSS selector?',
      options: [
        'document.findElement()',
        'document.querySelector()',
        'document.getElementsByTag()',
        'document.searchQuery()'
      ],
      answer: 1,
      explanation: 'document.querySelector() returns the first Element within the document that matches the specified selector or group of selectors.'
    }
  },

  // --- MODERN ES6+ & WEB STORAGE ---
  {
    id: 'js-modern-features',
    category: 'modern',
    title: 'Modern ES6+ Features & Destructuring',
    readTime: '7 min',
    xp: 40,
    summary: 'Destructuring arrays & objects, Spread and Rest operators, Template Literals, and Modules.',
    contentHtml: `
      <h2>Key Modern JavaScript Additions</h2>
      
      <h3>1. Destructuring Assignment</h3>
      <div class="w3-code-box">
        <pre><code>// Object destructuring with renaming and defaults
const user = { username: 'alex', age: 28, country: 'Canada' };
const { username, age, role = 'Member' } = user;

// Array destructuring
const coords = [51.5074, -0.1278];
const [latitude, longitude] = coords;</code></pre>
      </div>

      <h3>2. Spread Operator (<code>...</code>)</h3>
      <div class="w3-code-box">
        <pre><code>// Shallow clone & merge objects
const base = { theme: 'dark', sound: true };
const custom = { ...base, sound: false, lang: 'en' };

// Combine arrays
const numbers = [...[1, 2], ...[3, 4]]; // [1, 2, 3, 4]</code></pre>
      </div>
    `,
    codeExample: `// 1. Object Destructuring
const person = { first: "Grace", last: "Hopper", field: "Computer Science" };
const { first, last, field } = person;
console.log(\`\${first} \${last} revolutionized \${field}.\`);

// 2. Spread operator cloning and merging
const defaultSettings = { theme: "light", notifications: true, volume: 80 };
const userSettings = { ...defaultSettings, theme: "dark", volume: 100 };
console.log("Merged settings:", userSettings);

// 3. Array destructuring with rest
const [firstItem, secondItem, ...remainingItems] = [10, 20, 30, 40, 50];
console.log("First:", firstItem);
console.log("Second:", secondItem);
console.log("Remaining array:", remainingItems);`,
    checkpoint: {
      type: 'mcq',
      question: 'What is the syntax used to unpack values from arrays, or properties from objects, into distinct variables?',
      options: [
        'Serialization',
        'Destructuring assignment',
        'Type Casting',
        'Prototypal Inheritance'
      ],
      answer: 1,
      explanation: 'Destructuring assignment allows unpacking values from arrays or properties from objects into distinct variables directly.'
    }
  },

  {
    id: 'js-storage',
    category: 'modern',
    title: 'Web Storage: localStorage & sessionStorage',
    readTime: '5 min',
    xp: 35,
    summary: 'Persist data locally in the browser with localStorage, JSON serialization, and storage limits.',
    contentHtml: `
      <h2>Client-Side Web Storage</h2>
      <p>Web storage allows web applications to store data locally within the user's browser:</p>
      <ul>
        <li><code>localStorage</code> - Stores data with <strong>no expiration date</strong>. The data persists even after the browser is closed and reopened.</li>
        <li><code>sessionStorage</code> - Stores data for <strong>one session</strong> only. The data is deleted when the user closes the specific browser tab.</li>
      </ul>

      <h2>Key Methods</h2>
      <div class="w3-code-box">
        <pre><code>// Store a string
localStorage.setItem('username', 'Ada');

// Store an object (must serialize with JSON.stringify)
const settings = { darkMode: true, fontSize: 16 };
localStorage.setItem('user_settings', JSON.stringify(settings));

// Retrieve and parse
const saved = JSON.parse(localStorage.getItem('user_settings'));

// Remove or clear
localStorage.removeItem('username');
localStorage.clear();</code></pre>
      </div>
    `,
    codeExample: `// Test JSON serialization & storage simulation
const userState = {
  streak: 5,
  xp: 450,
  badges: ["Fast Learner", "JS Master"],
  preferences: { sound: true }
};

// Serialize
const serialized = JSON.stringify(userState, null, 2);
console.log("Serialized JSON string:");
console.log(serialized);

// Parse back
const restored = JSON.parse(serialized);
console.log("Restored object badges:", restored.badges.join(", "));`,
    checkpoint: {
      type: 'mcq',
      question: 'How do you correctly store a JavaScript object or array in localStorage?',
      options: [
        'localStorage.setObject("key", obj)',
        'localStorage.setItem("key", JSON.stringify(obj))',
        'localStorage.save("key", obj.toString())',
        'localStorage.write("key", obj)'
      ],
      answer: 1,
      explanation: 'localStorage can only store strings, so objects and arrays must be converted to a JSON string using JSON.stringify() before saving.'
    }
  }
];
