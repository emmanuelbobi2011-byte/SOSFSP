(function (global) {
  var modules = {};

  // ===== VALIDATE =====
  var v = {
    required: function (x) { return x != null && String(x).trim() !== ''; },
    email: function (x) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(x); },
    phone: function (x) { return /^[+]?[\d\s\-()]{7,}$/.test(x); },
    url: function (x) { return /^https?:\/\/.+/.test(x); },
    number: function (x) { return !isNaN(parseFloat(x)) && isFinite(x); },
    integer: function (x) { return /^-?\d+$/.test(x); },
    min: function (x, n) { return parseFloat(x) >= n; },
    max: function (x, n) { return parseFloat(x) <= n; },
    minLen: function (x, n) { return String(x).length >= n; },
    maxLen: function (x, n) { return String(x).length <= n; },
    match: function (x, o) { return x === o; },
    card: function (x) {
      var s = String(x).replace(/\s+/g, '');
      if (!/^\d{13,19}$/.test(s)) return false;
      var sum = 0, alt = false;
      for (var i = s.length - 1; i >= 0; i--) {
        var n = parseInt(s[i], 10);
        if (alt) { n *= 2; if (n > 9) n -= 9; }
        sum += n; alt = !alt;
      }
      return sum % 10 === 0;
    },
    password: function (x, s) {
      s = s || 2;
      var score = 0;
      if (x.length >= 8) score++;
      if (/[a-z]/.test(x) && /[A-Z]/.test(x)) score++;
      if (/\d/.test(x)) score++;
      if (/[^A-Za-z0-9]/.test(x)) score++;
      return score >= s;
    }
  };
  modules.validators = v;
  modules.validate = function (value, rules) {
    if (!Array.isArray(rules)) rules = [rules];
    for (var i = 0; i < rules.length; i++) {
      var r = rules[i];
      if (typeof r === 'string') {
        var p = r.split(':');
        if (!v[p[0]](value, p[1])) return false;
      } else if (typeof r === 'function') {
        if (!r(value)) return false;
      }
    }
    return true;
  };

  // ===== QRCODE =====
  function qrMatrix(text, size) {
    size = size || 21;
    var data = [];
    for (var i = 0; i < text.length; i++) {
      var c = text.charCodeAt(i);
      var bits = c.toString(2).padStart(8, '0');
      for (var j = 0; j < 8; j++) data.push(bits[j] === '1' ? 1 : 0);
    }
    var m = [];
    for (var r = 0; r < size; r++) {
      m[r] = [];
      for (var col = 0; col < size; col++) m[r][col] = 0;
    }
    function finder(top, left) {
      for (var y = 0; y < 7; y++) for (var x = 0; x < 7; x++) {
        var e = (y === 0 || y === 6 || x === 0 || x === 6);
        var c2 = (y >= 2 && y <= 4 && x >= 2 && x <= 4);
        m[top + y][left + x] = (e || c2) ? 1 : 0;
      }
    }
    finder(0, 0); finder(0, size - 7); finder(size - 7, 0);
    for (var k = 8; k < size - 8; k++) {
      m[6][k] = k % 2 === 0 ? 1 : 0;
      m[k][6] = k % 2 === 0 ? 1 : 0;
    }
    var di = 0;
    for (var rr = size - 1; rr >= 0; rr -= 2) {
      if (rr === 6) rr--;
      for (var cc = 0; cc < size; cc++) {
        for (var xx = 0; xx < 2; xx++) {
          var y2 = cc, x2 = rr - xx;
          var res = (y2 < 9 && x2 < 9) || (y2 < 9 && x2 > size - 9) || (y2 > size - 9 && x2 < 9) || y2 === 6 || x2 === 6;
          if (!res && m[y2][x2] === 0) {
            m[y2][x2] = di < data.length ? data[di++] : (Math.random() > 0.5 ? 1 : 0);
          }
        }
      }
    }
    return m;
  }

  modules.qrcode = function (text, opts) {
    opts = opts || {};
    var px = opts.size || 200;
    var m = qrMatrix(text, 21);
    var cell = px / m.length;
    var wrap = create('div');
    wrap.style = 'inline-block bg-white p-3 rounded-2xl';
    var el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('viewBox', '0 0 ' + px + ' ' + px);
    el.setAttribute('width', px);
    el.setAttribute('height', px);
    for (var r = 0; r < m.length; r++) for (var c = 0; c < m[r].length; c++) {
      if (m[r][c]) {
        var rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
        rect.setAttribute('x', c * cell);
        rect.setAttribute('y', r * cell);
        rect.setAttribute('width', cell);
        rect.setAttribute('height', cell);
        rect.setAttribute('fill', opts.color || '#000');
        el.appendChild(rect);
      }
    }
    wrap.el.appendChild(el);
    return wrap;
  };

  // ===== DATEPICKER =====
  function pad2(n) { return String(n).padStart(2, '0'); }
  function ymd(y, m, d) { return y + '-' + pad2(m + 1) + '-' + pad2(d); }

  modules.datePicker = function (opts) {
    opts = opts || {};
    var today = new Date();
    var view = { y: today.getFullYear(), m: today.getMonth() };
    var selected = opts.value ? new Date(opts.value) : null;
    var _onChange = opts.onChange || function () {};

    var wrap = create('div');
    wrap.style = 'bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm w-full max-w-xs';

    var header = create('div');
    header.style = 'flex flex-row items-center justify-between mb-3';
    var prev = iconBtn('chevronLeft', 'text-gray-600 dark:text-gray-300');
    var next = iconBtn('chevronRight', 'text-gray-600 dark:text-gray-300');
    var title = create('div', '');
    title.style = 'text-base font-bold text-gray-900 dark:text-white';
    header.push(prev, title, next);
    wrap.push(header);

    var grid = create('div');
    grid.style = 'grid grid-cols-7 gap-1';
    wrap.push(grid);

    var footer = create('div');
    footer.style = 'flex flex-row gap-2 mt-3';
    var todayBtn = create('button', 'Today');
    todayBtn.style = 'flex-1 p-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200';
    var clearBtn = create('button', 'Clear');
    clearBtn.style = 'flex-1 p-2 text-sm rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200';
    footer.push(todayBtn, clearBtn);
    wrap.push(footer);

    function paint() {
      title.text = new Date(view.y, view.m, 1).toLocaleString('en', { month: 'long', year: 'numeric' });
      grid.clear();
      ['S','M','T','W','T','F','S'].forEach(function (d) {
        var c = create('div', d);
        c.style = 'text-center text-xs font-bold text-gray-400 py-1';
        grid.push(c);
      });
      var first = new Date(view.y, view.m, 1).getDay();
      var days = new Date(view.y, view.m + 1, 0).getDate();
      for (var i = 0; i < first; i++) grid.push(create('div', ''));
      for (var d = 1; d <= days; d++) {
        (function (day) {
          var isSel = selected && selected.getFullYear() === view.y && selected.getMonth() === view.m && selected.getDate() === day;
          var isT = today.getFullYear() === view.y && today.getMonth() === view.m && today.getDate() === day;
          var cell = create('button', String(day));
          cell.style = 'h-9 rounded-lg text-sm font-medium transition ' +
            (isSel ? 'bg-blue-600 text-white'
             : isT ? 'bg-blue-50 text-blue-600 dark:bg-blue-900/40 dark:text-blue-300'
             : 'text-gray-700 dark:text-gray-200');
          cell.onClick = function () {
            selected = new Date(view.y, view.m, day);
            paint();
            _onChange(ymd(view.y, view.m, day), selected);
            vibrate(15);
          };
          grid.push(cell);
        })(d);
      }
    }

    prev.onClick = function () { view.m--; if (view.m < 0) { view.m = 11; view.y--; } paint(); };
    next.onClick = function () { view.m++; if (view.m > 11) { view.m = 0; view.y++; } paint(); };
    todayBtn.onClick = function () {
      selected = new Date();
      view.y = selected.getFullYear();
      view.m = selected.getMonth();
      paint();
      _onChange(ymd(view.y, view.m, selected.getDate()), selected);
    };
    clearBtn.onClick = function () { selected = null; paint(); _onChange('', null); };

    paint();
    wrap.get = function () { return selected ? ymd(selected.getFullYear(), selected.getMonth(), selected.getDate()) : ''; };
    return wrap;
  };

  modules.openDatePicker = function (opts) {
    opts = opts || {};
    var result = opts.value || '';
    var picker = modules.datePicker({
      value: opts.value,
      onChange: function (x) { result = x; }
    });
    return modal({
      title: opts.title || 'Pick a date',
      body: picker,
      buttons: [
        { label: 'Cancel' },
        { label: 'OK', primary: true, onClick: function () { if (opts.onChange) opts.onChange(result); } }
      ]
    });
  };

  // ===== FORM =====
  modules.form = function (fields, onSubmit) {
    var wrap = create('div');
    wrap.style = 'flex flex-col gap-4';
    var values = {}, inputs = {}, errors = {};

    Object.keys(fields).forEach(function (name) {
      var f = fields[name];
      var group = create('div');
      group.style = 'flex flex-col gap-1.5';

      if (f.label) {
        var lbl = create('label', f.label + (f.required ? ' *' : ''));
        lbl.style = 'text-sm font-medium text-gray-700 dark:text-gray-300';
        group.push(lbl);
      }

      var input;
      if (f.type === 'date') {
        input = create('div');
        input.style = 'cursor-pointer';
        var display = create('div', f.value || 'Pick a date');
        display.style = 'w-full p-3 rounded-xl border border-gray-200 bg-white dark:bg-gray-800 dark:text-white';
        input.push(display);
        values[name] = f.value || '';
        input.onClick = function () {
          modules.openDatePicker({
            title: f.label || 'Pick a date',
            value: values[name],
            onChange: function (val) {
              values[name] = val;
              display.text = val || 'Pick a date';
              validateField(name);
            }
          });
        };
      } else if (f.type === 'select') {
        input = create('select');
        input.style = 'w-full p-3 rounded-xl border border-gray-200 outline-none bg-white dark:bg-gray-800 dark:text-white';
        (f.options || []).forEach(function (o) {
          var val = typeof o === 'string' ? o : o.value;
          var lab = typeof o === 'string' ? o : o.label;
          var opt = document.createElement('option');
          opt.value = val; opt.textContent = lab;
          input.el.appendChild(opt);
        });
        values[name] = f.value || (f.options && f.options[0] ? (typeof f.options[0] === 'string' ? f.options[0] : f.options[0].value) : '');
        input.el.value = values[name];
      } else if (f.type === 'textarea') {
        input = create('textarea');
        input.style = 'w-full p-3 rounded-xl border border-gray-200 outline-none bg-white dark:bg-gray-800 dark:text-white resize-none';
        input.el.rows = f.rows || 3;
        if (f.placeholder) input.placeholder = f.placeholder;
        values[name] = f.value || '';
      } else {
        input = create('input');
        input.el.type = f.type || 'text';
        input.style = 'w-full p-3 rounded-xl border border-gray-200 outline-none bg-white dark:bg-gray-800 dark:text-white';
        if (f.placeholder) input.placeholder = f.placeholder;
        values[name] = f.value || '';
      }

      if (input.on) {
        input.on('input', function () { values[name] = input.value; validateField(name); });
        input.on('change', function () { values[name] = input.value; validateField(name); });
      }

      inputs[name] = input;
      group.push(input);
      var err = create('div', '');
      err.style = 'text-xs text-red-500 min-h-[14px]';
      errors[name] = err;
      group.push(err);
      wrap.push(group);
    });

    function validateField(name) {
      var f = fields[name], val = values[name], err = '';
      if (f.required && (!val || String(val).trim() === '')) err = 'Required';
      else if (val && f.rules) { if (!modules.validate(val, f.rules)) err = f.message || 'Invalid'; }
      else if (val && f.validate) {
        var r = f.validate(val);
        if (typeof r === 'string') err = r;
        else if (r === false) err = 'Invalid';
      }
      errors[name].text = err;
      var inp = inputs[name];
      if (inp && inp.style && f.type !== 'date') {
        inp.style = 'w-full p-3 rounded-xl border outline-none bg-white dark:bg-gray-800 dark:text-white ' +
          (err ? 'border-red-400' : 'border-gray-200');
      }
      return !err;
    }

    function validateAll() {
      var ok = true;
      Object.keys(fields).forEach(function (n) { if (!validateField(n)) ok = false; });
      return ok;
    }

    var submit = create('button', 'Submit');
    submit.style = 'w-full bg-blue-600 text-white p-4 rounded-xl font-bold mt-2';
    submit.onClick = function () {
      if (!validateAll()) { toast('Please fix the errors', 'error'); return; }
      if (onSubmit) onSubmit(values);
    };
    wrap.push(submit);

    wrap.get = function () { return values; };
    wrap.reset = function () {
      Object.keys(fields).forEach(function (n) {
        values[n] = '';
        if (inputs[n] && inputs[n].el && 'value' in inputs[n].el) inputs[n].el.value = '';
        errors[n].text = '';
      });
      return wrap;
    };
    wrap.validate = validateAll;
    return wrap;
  };

  // ===== MARKDOWN =====
  function mdToHtml(text) {
    text = String(text).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    text = text.replace(/```([\s\S]*?)```/g, function (_, c) {
      return '<pre style="background:#0d1117;color:#e6edf3;padding:12px;border-radius:8px;overflow:auto;font-family:ui-monospace,monospace;font-size:13px">' + c.trim() + '</pre>';
    });
    text = text.replace(/`([^`]+)`/g, '<code style="background:#f3f4f6;padding:2px 6px;border-radius:4px;font-family:ui-monospace,monospace">$1</code>');
    text = text.replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/(^|[^*])\*([^*]+)\*/g, '$1<em>$2</em>');
    text = text.replace(/\[([^\]]+)\]\(([^)]+)\)/g, '<a href="$2" style="color:#3b82f6;text-decoration:underline">$1</a>');
    text = text.replace(/^###### (.*$)/gm, '<h6 style="font-size:.875rem;font-weight:700;margin:1em 0 .5em">$1</h6>');
    text = text.replace(/^##### (.*$)/gm, '<h5 style="font-size:1rem;font-weight:700;margin:1em 0 .5em">$1</h5>');
    text = text.replace(/^#### (.*$)/gm, '<h4 style="font-size:1.125rem;font-weight:700;margin:1em 0 .5em">$1</h4>');
    text = text.replace(/^### (.*$)/gm, '<h3 style="font-size:1.25rem;font-weight:700;margin:1em 0 .5em">$1</h3>');
    text = text.replace(/^## (.*$)/gm, '<h2 style="font-size:1.5rem;font-weight:700;margin:1em 0 .5em">$1</h2>');
    text = text.replace(/^# (.*$)/gm, '<h1 style="font-size:1.875rem;font-weight:800;margin:1em 0 .5em">$1</h1>');
    text = text.replace(/^(\s*)[-*] (.*$)/gm, function (_, ind, item) {
      return '<div style="display:flex;gap:8px;padding-left:' + (Math.floor(ind.length / 2) * 16) + 'px;margin:4px 0"><span>•</span><span>' + item + '</span></div>';
    });
    text = text.replace(/^&gt; (.*$)/gm, '<blockquote style="border-left:4px solid #d1d5db;padding-left:12px;color:#6b7280;margin:8px 0">$1</blockquote>');
    text = text.replace(/\n\n/g, '</p><p style="margin:1em 0">');
    text = '<p style="margin:1em 0">' + text + '</p>';
    text = text.replace(/<p[^>]*><\/p>/g, '');
    return text;
  }

  modules.markdown = function (text, opts) {
    opts = opts || {};
    var n = create('div');
    n.style = 'text-gray-800 dark:text-gray-200 ' + (opts.classes || '');
    n.el.innerHTML = mdToHtml(text);
    return n;
  };

  // ===== SWIPE ROW =====
  modules.swipeRow = function (content, actions) {
    var wrap = create('div');
    wrap.style = 'relative overflow-hidden rounded-2xl';
    var bar = create('div');
    bar.style = 'absolute inset-y-0 right-0 flex flex-row';
    var totalW = 0;
    actions.forEach(function (a) {
      var w = a.width || 80;
      totalW += w;
      var btn = create('button', a.label || '');
      btn.style = 'h-full flex flex-col items-center justify-center text-white font-bold text-sm ' +
        (a.color === 'danger' ? 'bg-red-500' :
         a.color === 'success' ? 'bg-green-500' :
         a.color === 'warning' ? 'bg-yellow-500' : 'bg-blue-500');
      btn.el.style.width = w + 'px';
      btn.onClick = function () { vibrate(20); if (a.onClick) a.onClick(); reset(); };
      bar.push(btn);
    });

    var surface = create('div');
    surface.style = 'relative bg-white dark:bg-gray-800 transition-transform duration-200';
    surface.push(content);
    wrap.push(bar, surface);

    var startX = 0, startY = 0, open = false, dragging = false;
    function reset() { surface.el.style.transform = 'translateX(0)'; open = false; }

    surface.el.addEventListener('touchstart', function (e) {
      startX = e.touches[0].clientX;
      startY = e.touches[0].clientY;
      dragging = true;
      surface.el.style.transition = 'none';
    }, { passive: true });

    surface.el.addEventListener('touchmove', function (e) {
      if (!dragging) return;
      var dx = e.touches[0].clientX - startX;
      var dy = e.touches[0].clientY - startY;
      if (Math.abs(dy) > Math.abs(dx)) return;
      var base = open ? -totalW : 0;
      var shift = Math.max(-totalW, Math.min(0, base + dx));
      surface.el.style.transform = 'translateX(' + shift + 'px)';
    }, { passive: true });

    surface.el.addEventListener('touchend', function () {
      dragging = false;
      surface.el.style.transition = 'transform .2s';
      var cur = parseInt((surface.el.style.transform.match(/-?\d+/) || ['0'])[0], 10);
      if (cur < -totalW / 2) { surface.el.style.transform = 'translateX(-' + totalW + 'px)'; open = true; }
      else reset();
    }, { passive: true });

    wrap.reset = reset;
    return wrap;
  };

  // ===== VIRTUAL LIST =====
  modules.virtualList = function (items, render, opts) {
    opts = opts || {};
    var rowH = opts.rowHeight || 64;
    var buffer = opts.buffer || 5;
    var wrap = create('div');
    wrap.style = 'flex-1 overflow-y-auto';
    var sizer = create('div');
    sizer.style = 'position:relative';
    sizer.el.style.height = (items.length * rowH) + 'px';
    var viewport = create('div');
    viewport.style = 'position:absolute;left:0;right:0;top:0';
    sizer.push(viewport);
    wrap.push(sizer);

    function paint() {
      var st = wrap.el.scrollTop;
      var vh = wrap.el.clientHeight;
      var start = Math.max(0, Math.floor(st / rowH) - buffer);
      var end = Math.min(items.length, Math.ceil((st + vh) / rowH) + buffer);
      viewport.el.style.transform = 'translateY(' + (start * rowH) + 'px)';
      viewport.clear();
      for (var i = start; i < end; i++) {
        var row = render(items[i], i);
        row.style = 'height:' + rowH + 'px;' + (row.style || '');
        viewport.push(row);
      }
    }

    wrap.el.addEventListener('scroll', paint, { passive: true });
    setTimeout(paint, 50);
    wrap.refresh = paint;
    return wrap;
  };

  // ===== IDB =====
  modules.idb = function (name, storeName) {
    storeName = storeName || 'items';
    var dbp = new Promise(function (resolve, reject) {
      var req = indexedDB.open(name, 1);
      req.onupgradeneeded = function (e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains(storeName)) db.createObjectStore(storeName, { keyPath: 'id' });
      };
      req.onsuccess = function (e) { resolve(e.target.result); };
      req.onerror = function (e) { reject(e.target.error); };
    });
    function tx(mode) {
      return dbp.then(function (db) { return db.transaction(storeName, mode).objectStore(storeName); });
    }
    return {
      put: function (obj) { return tx('readwrite').then(function (s) { return new Promise(function (res, rej) { var r = s.put(obj); r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }); },
      get: function (id) { return tx('readonly').then(function (s) { return new Promise(function (res, rej) { var r = s.get(id); r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }); },
      all: function () { return tx('readonly').then(function (s) { return new Promise(function (res, rej) { var r = s.getAll(); r.onsuccess = function () { res(r.result || []); }; r.onerror = function () { rej(r.error); }; }); }); },
      remove: function (id) { return tx('readwrite').then(function (s) { return new Promise(function (res, rej) { var r = s.delete(id); r.onsuccess = function () { res(); }; r.onerror = function () { rej(r.error); }; }); }); },
      clear: function () { return tx('readwrite').then(function (s) { return new Promise(function (res, rej) { var r = s.clear(); r.onsuccess = function () { res(); }; r.onerror = function () { rej(r.error); }; }); }); }
    };
  };

  // ===== SIGNATURE =====
  modules.signature = function (opts) {
    opts = opts || {};
    var wrap = create('div');
    wrap.style = 'bg-white rounded-2xl overflow-hidden border border-gray-200';
    var canvas = document.createElement('canvas');
    canvas.width = opts.width || 600;
    canvas.height = opts.height || 300;
    canvas.style.cssText = 'width:100%;height:auto;display:block;touch-action:none;background:#fff';
    wrap.el.appendChild(canvas);
    var ctx = canvas.getContext('2d');
    ctx.lineWidth = opts.thickness || 2;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.strokeStyle = opts.color || '#111827';
    var drawing = false, dirty = false, lastX = 0, lastY = 0;

    function pos(e) {
      var rect = canvas.getBoundingClientRect();
      var t = e.touches ? e.touches[0] : e;
      return {
        x: (t.clientX - rect.left) * (canvas.width / rect.width),
        y: (t.clientY - rect.top) * (canvas.height / rect.height)
      };
    }
    function start(e) { e.preventDefault(); drawing = true; dirty = true; var p = pos(e); lastX = p.x; lastY = p.y; }
    function move(e) {
      if (!drawing) return;
      e.preventDefault();
      var p = pos(e);
      ctx.beginPath(); ctx.moveTo(lastX, lastY); ctx.lineTo(p.x, p.y); ctx.stroke();
      lastX = p.x; lastY = p.y;
    }
    function end() { drawing = false; }

    canvas.addEventListener('touchstart', start, { passive: false });
    canvas.addEventListener('touchmove', move, { passive: false });
    canvas.addEventListener('touchend', end, { passive: true });
    canvas.addEventListener('mousedown', start);
    canvas.addEventListener('mousemove', move);
    canvas.addEventListener('mouseup', end);
    canvas.addEventListener('mouseleave', end);

    var bar = create('div');
    bar.style = 'flex flex-row gap-2 p-3 bg-gray-50 border-t border-gray-200';
    var clear = create('button', 'Clear');
    clear.style = 'flex-1 p-2 rounded-lg bg-gray-200 text-gray-700 text-sm font-bold';
    var save = create('button', 'Save');
    save.style = 'flex-1 p-2 rounded-lg bg-blue-600 text-white text-sm font-bold';
    bar.push(clear, save);
    wrap.push(bar);

    clear.onClick = function () { ctx.clearRect(0, 0, canvas.width, canvas.height); dirty = false; };
    save.onClick = function () {
      if (!dirty) { toast('Nothing to save', 'warning'); return; }
      if (opts.onSave) opts.onSave(canvas.toDataURL('image/png'));
    };
    wrap.toDataURL = function () { return canvas.toDataURL('image/png'); };
    return wrap;
  };

  // ===== CHARTS =====
  function chartBox(title) {
    var n = create('div');
    n.style = 'bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm flex flex-col gap-3';
    if (title) {
      var t = create('div', title);
      t.style = 'text-sm font-bold text-gray-700 dark:text-gray-200';
      n.push(t);
    }
    return n;
  }
  function svgCanvas(w, h) {
    var el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('viewBox', '0 0 ' + w + ' ' + h);
    el.setAttribute('width', '100%');
    el.setAttribute('height', h);
    return el;
  }

  modules.barChart = function (data, opts) {
    opts = opts || {};
    var w = 320, h = opts.height || 180, pad = 24;
    var max = Math.max.apply(null, data.map(function (d) { return d.value; }));
    var barW = (w - pad * 2) / data.length * 0.7;
    var gap = (w - pad * 2) / data.length * 0.3;
    var box = chartBox(opts.title);
    var el = svgCanvas(w, h);
    data.forEach(function (d, i) {
      var barH = max ? (d.value / max) * (h - pad * 2) : 0;
      var x = pad + i * (barW + gap) + gap / 2;
      var y = h - pad - barH;
      var rect = document.createElementNS('http://www.w3.org/2000/svg', 'rect');
      rect.setAttribute('x', x); rect.setAttribute('y', y);
      rect.setAttribute('width', barW); rect.setAttribute('height', barH);
      rect.setAttribute('rx', 6);
      rect.setAttribute('fill', d.color || opts.color || '#3b82f6');
      el.appendChild(rect);
      var lb = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      lb.setAttribute('x', x + barW / 2); lb.setAttribute('y', h - 6);
      lb.setAttribute('text-anchor', 'middle'); lb.setAttribute('font-size', '10');
      lb.setAttribute('fill', '#6b7280'); lb.textContent = d.label;
      el.appendChild(lb);
      var vl = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      vl.setAttribute('x', x + barW / 2); vl.setAttribute('y', y - 4);
      vl.setAttribute('text-anchor', 'middle'); vl.setAttribute('font-size', '10');
      vl.setAttribute('font-weight', 'bold'); vl.setAttribute('fill', '#111827');
      vl.textContent = d.value;
      el.appendChild(vl);
    });
    box.el.appendChild(el);
    return box;
  };

  modules.lineChart = function (data, opts) {
    opts = opts || {};
    var w = 320, h = opts.height || 180, pad = 24;
    var max = Math.max.apply(null, data.map(function (d) { return d.value; }));
    var step = (w - pad * 2) / Math.max(1, data.length - 1);
    var box = chartBox(opts.title);
    var el = svgCanvas(w, h);
    var pts = data.map(function (d, i) {
      return { x: pad + i * step, y: h - pad - (max ? (d.value / max) * (h - pad * 2) : 0) };
    });
    var dPath = pts.map(function (p, i) { return (i === 0 ? 'M' : 'L') + p.x + ' ' + p.y; }).join(' ');
    var area = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    area.setAttribute('d', dPath + ' L' + (w - pad) + ' ' + (h - pad) + ' L' + pad + ' ' + (h - pad) + ' Z');
    area.setAttribute('fill', opts.color || '#3b82f6');
    area.setAttribute('opacity', '0.1');
    el.appendChild(area);
    var line = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    line.setAttribute('d', dPath);
    line.setAttribute('fill', 'none');
    line.setAttribute('stroke', opts.color || '#3b82f6');
    line.setAttribute('stroke-width', '2.5');
    line.setAttribute('stroke-linejoin', 'round');
    line.setAttribute('stroke-linecap', 'round');
    el.appendChild(line);
    pts.forEach(function (p, i) {
      var c = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      c.setAttribute('cx', p.x); c.setAttribute('cy', p.y);
      c.setAttribute('r', 4);
      c.setAttribute('fill', '#fff');
      c.setAttribute('stroke', opts.color || '#3b82f6');
      c.setAttribute('stroke-width', '2');
      el.appendChild(c);
      var lb = document.createElementNS('http://www.w3.org/2000/svg', 'text');
      lb.setAttribute('x', p.x); lb.setAttribute('y', h - 6);
      lb.setAttribute('text-anchor', 'middle');
      lb.setAttribute('font-size', '10');
      lb.setAttribute('fill', '#6b7280');
      lb.textContent = data[i].label;
      el.appendChild(lb);
    });
    box.el.appendChild(el);
    return box;
  };

  modules.pieChart = function (data, opts) {
    opts = opts || {};
    var size = 200, r = 80, cx = 100, cy = 100;
    var total = data.reduce(function (s, d) { return s + d.value; }, 0) || 1;
    var colors = opts.colors || ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4', '#ec4899'];
    var box = chartBox(opts.title);
    var el = svgCanvas(size, size);
    var sa = -Math.PI / 2;
    data.forEach(function (d, i) {
      var sl = (d.value / total) * Math.PI * 2;
      var ea = sa + sl;
      var x1 = cx + r * Math.cos(sa), y1 = cy + r * Math.sin(sa);
      var x2 = cx + r * Math.cos(ea), y2 = cy + r * Math.sin(ea);
      var lg = sl > Math.PI ? 1 : 0;
      var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M' + cx + ' ' + cy + ' L' + x1 + ' ' + y1 + ' A' + r + ' ' + r + ' 0 ' + lg + ' 1 ' + x2 + ' ' + y2 + ' Z');
      path.setAttribute('fill', d.color || colors[i % colors.length]);
      el.appendChild(path);
      sa = ea;
    });
    box.el.appendChild(el);
    var legend = create('div');
    legend.style = 'flex flex-col gap-1 mt-3';
    data.forEach(function (d, i) {
      var row = create('div');
      row.style = 'flex items-center gap-2 text-xs';
      var dot = create('div');
      dot.style = 'w-3 h-3 rounded-full';
      dot.el.style.background = d.color || colors[i % colors.length];
      row.push(dot, create('span', d.label + ' — ' + d.value));
      legend.push(row);
    });
    box.push(legend);
    return box;
  };

  modules.donutChart = function (data, opts) {
    opts = opts || {};
    var size = 200, r = 80, inner = 55, cx = 100, cy = 100;
    var total = data.reduce(function (s, d) { return s + d.value; }, 0) || 1;
    var colors = opts.colors || ['#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];
    var box = chartBox(opts.title);
    var el = svgCanvas(size, size);
    var sa = -Math.PI / 2;
    data.forEach(function (d, i) {
      var sl = (d.value / total) * Math.PI * 2;
      var ea = sa + sl;
      var x1 = cx + r * Math.cos(sa), y1 = cy + r * Math.sin(sa);
      var x2 = cx + r * Math.cos(ea), y2 = cy + r * Math.sin(ea);
      var xi1 = cx + inner * Math.cos(ea), yi1 = cy + inner * Math.sin(ea);
      var xi2 = cx + inner * Math.cos(sa), yi2 = cy + inner * Math.sin(sa);
      var lg = sl > Math.PI ? 1 : 0;
      var path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', 'M' + x1 + ' ' + y1 + ' A' + r + ' ' + r + ' 0 ' + lg + ' 1 ' + x2 + ' ' + y2 + ' L' + xi1 + ' ' + yi1 + ' A' + inner + ' ' + inner + ' 0 ' + lg + ' 0 ' + xi2 + ' ' + yi2 + ' Z');
      path.setAttribute('fill', d.color || colors[i % colors.length]);
      el.appendChild(path);
      sa = ea;
    });
    var ct = document.createElementNS('http://www.w3.org/2000/svg', 'text');
    ct.setAttribute('x', cx); ct.setAttribute('y', cy + 5);
    ct.setAttribute('text-anchor', 'middle'); ct.setAttribute('font-size', '18');
    ct.setAttribute('font-weight', 'bold'); ct.setAttribute('fill', '#111827');
    ct.textContent = opts.centerText || total;
    el.appendChild(ct);
    box.el.appendChild(el);
    return box;
  };

  // ===== DRAWER =====
  modules.drawer = function (opts) {
    opts = opts || {};
    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9998;opacity:0;transition:opacity .2s';
    var panel = document.createElement('div');
    panel.style.cssText = 'position:absolute;top:0;bottom:0;left:0;width:280px;max-width:80vw;background:#fff;display:flex;flex-direction:column;transform:translateX(-100%);transition:transform .3s cubic-bezier(.2,.9,.3,1);box-shadow:2px 0 20px rgba(0,0,0,.15)';
    var header = document.createElement('div');
    header.style.cssText = 'padding:24px 20px;border-bottom:1px solid #f3f4f6;display:flex;align-items:center;gap:12px';
    if (opts.avatar) {
      var av = document.createElement('img');
      av.src = opts.avatar;
      av.style.cssText = 'width:48px;height:48px;border-radius:50%;object-fit:cover';
      header.appendChild(av);
    }
    var info = document.createElement('div');
    info.innerHTML = '<div style="font-weight:700;font-size:15px;color:#111827">' + (opts.name || 'User') + '</div><div style="font-size:12px;color:#6b7280">' + (opts.email || '') + '</div>';
    header.appendChild(info);
    panel.appendChild(header);

    var body = document.createElement('div');
    body.style.cssText = 'flex:1;overflow-y:auto;padding:8px 0';
    (opts.items || []).forEach(function (item) {
      if (item.divider) {
        var d = document.createElement('div');
        d.style.cssText = 'height:1px;background:#f3f4f6;margin:8px 16px';
        body.appendChild(d);
        return;
      }
      var row = document.createElement('div');
      row.style.cssText = 'display:flex;align-items:center;gap:14px;padding:14px 20px;cursor:pointer;font-size:15px;color:#374151';
      row.onmouseenter = function () { row.style.background = '#f9fafb'; };
      row.onmouseleave = function () { row.style.background = ''; };
      var lbl = document.createElement('span');
      lbl.textContent = item.label;
      row.appendChild(lbl);
      row.onclick = function () { close(); if (item.onClick) setTimeout(item.onClick, 200); };
      body.appendChild(row);
    });
    panel.appendChild(body);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);
    requestAnimationFrame(function () {
      overlay.style.opacity = '1';
      panel.style.transform = 'translateX(0)';
    });
    overlay.addEventListener('click', function (e) { if (e.target === overlay) close(); });
    function close() {
      overlay.style.opacity = '0';
      panel.style.transform = 'translateX(-100%)';
      setTimeout(function () { overlay.remove(); }, 300);
    }
    return { close: close };
  };

  // ===== CAROUSEL =====
  modules.carousel = function (slides, opts) {
    opts = opts || {};
    var current = 0;
    var wrap = create('div');
    wrap.style = 'relative rounded-2xl overflow-hidden bg-gray-100';
    var track = create('div');
    track.style = 'flex flex-row transition-transform duration-300 ease-out';
    slides.forEach(function (s) {
      var slide = create('div');
      slide.style = 'w-full flex-shrink-0 relative';
      var src = typeof s === 'string' ? s : s.src;
      slide.push(img(src, '', 'w-full h-64 object-cover'));
      track.push(slide);
    });
    wrap.push(track);

    var dotEls = [];
    if (slides.length > 1) {
      var dots = create('div');
      dots.style = 'absolute bottom-3 left-0 right-0 flex flex-row justify-center gap-2';
      slides.forEach(function (_, i) {
        var d = create('div');
        d.style = 'h-2 rounded-full transition-all ' + (i === 0 ? 'bg-white w-6' : 'bg-white/50 w-2');
        d.onClick = function () { go(i); };
        dotEls.push(d);
        dots.push(d);
      });
      wrap.push(dots);
    }
    function go(i) {
      current = (i + slides.length) % slides.length;
      track.el.style.transform = 'translateX(' + (-current * 100) + '%)';
      dotEls.forEach(function (d, idx) {
        d.style = 'h-2 rounded-full transition-all ' + (idx === current ? 'bg-white w-6' : 'bg-white/50 w-2');
      });
    }
    wrap.go = go;
    return wrap;
  };

  // ===== PULL TO REFRESH =====
  modules.pullToRefresh = function (scrollEl, onRefresh) {
    var el = scrollEl instanceof Node ? scrollEl.el : scrollEl;
    var startY = 0, pulling = false, refreshing = false;
    var indicator = document.createElement('div');
    indicator.style.cssText = 'height:0;overflow:hidden;display:flex;align-items:center;justify-content:center;transition:height .2s;color:#6b7280;font-size:13px';
    indicator.innerHTML = '<span>Pull to refresh</span>';
    el.insertBefore(indicator, el.firstChild);

    function start(e) { if (refreshing || el.scrollTop > 0) return; startY = e.touches[0].clientY; pulling = true; }
    function move(e) {
      if (!pulling) return;
      var dy = e.touches[0].clientY - startY;
      if (dy > 0) {
        e.preventDefault();
        var h = Math.min(dy * 0.5, 80);
        indicator.style.height = h + 'px';
        indicator.innerHTML = h > 50 ? '<span>Release to refresh</span>' : '<span>Pull to refresh</span>';
      }
    }
    function end() {
      if (!pulling) return;
      pulling = false;
      var h = parseInt(indicator.style.height) || 0;
      if (h > 50) {
        refreshing = true;
        indicator.style.height = '60px';
        indicator.innerHTML = '<span>Refreshing...</span>';
        Promise.resolve(onRefresh()).then(function () {
          indicator.style.height = '0';
          indicator.innerHTML = '<span>Pull to refresh</span>';
          refreshing = false;
          vibrate(15);
        }).catch(function () {
          indicator.style.height = '0';
          indicator.innerHTML = '<span>Pull to refresh</span>';
          refreshing = false;
        });
      } else {
        indicator.style.height = '0';
      }
    }
    el.addEventListener('touchstart', start, { passive: true });
    el.addEventListener('touchmove', move, { passive: false });
    el.addEventListener('touchend', end, { passive: true });
  };

  // ===== LIGHTBOX =====
  modules.lightbox = function (images, opts) {
    opts = opts || {};
    var index = opts.start || 0;
    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:#000;z-index:9999;display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .2s';
    var im = document.createElement('img');
    im.style.cssText = 'max-width:100%;max-height:100%;object-fit:contain';
    im.src = typeof images[index] === 'string' ? images[index] : images[index].src;
    overlay.appendChild(im);

    var close = document.createElement('button');
    close.innerHTML = '×';
    close.style.cssText = 'position:absolute;top:16px;right:16px;background:rgba(255,255,255,.2);color:#fff;border:none;width:40px;height:40px;border-radius:50%;font-size:24px;cursor:pointer';
    overlay.appendChild(close);

    var prev = document.createElement('button');
    prev.innerHTML = '‹';
    prev.style.cssText = 'position:absolute;left:16px;top:50%;transform:translateY(-50%);background:rgba(255,255,255,.2);color:#fff;border:none;width:44px;height:44px;border-radius:50%;font-size:28px;cursor:pointer';
    overlay.appendChild(prev);

    var next = document.createElement('button');
    next.innerHTML = '›';
    next.style.cssText = 'position:absolute;right:16px;top:50%;transform:translateY(-50%);background:rgba(255,255,255,.2);color:#fff;border:none;width:44px;height:44px;border-radius:50%;font-size:28px;cursor:pointer';
    overlay.appendChild(next);

    document.body.appendChild(overlay);
    requestAnimationFrame(function () { overlay.style.opacity = '1'; });

    function show(i) {
      index = (i + images.length) % images.length;
      var src = typeof images[index] === 'string' ? images[index] : images[index].src;
      im.src = src;
    }
    function closeFn() {
      overlay.style.opacity = '0';
      setTimeout(function () { overlay.remove(); }, 200);
    }

    close.onclick = closeFn;
    prev.onclick = function () { show(index - 1); };
    next.onclick = function () { show(index + 1); };
    overlay.onclick = function (e) { if (e.target === overlay) closeFn(); };

    return { close: closeFn, show: show };
  };

  // ===== STEPPER =====
  modules.stepper = function (steps, onFinish) {
    var current = 0;
    var values = {};
    var wrap = create('div');
    wrap.style = 'flex flex-col gap-4';

    var progress = create('div');
    progress.style = 'flex flex-row gap-2';
    var dots = [];
    steps.forEach(function () {
      var d = create('div');
      d.style = 'flex-1 h-1 rounded-full bg-gray-200 dark:bg-gray-700';
      dots.push(d);
      progress.push(d);
    });
    wrap.push(progress);

    var body = create('div');
    body.style = 'flex flex-col gap-4';
    wrap.push(body);

    var nav = create('div');
    nav.style = 'flex flex-row gap-2';
    var back = create('button', 'Back');
    back.style = 'flex-1 p-3 rounded-xl bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200 font-bold';
    var next = create('button', 'Next');
    next.style = 'flex-1 p-3 rounded-xl bg-blue-600 text-white font-bold';
    nav.push(back, next);
    wrap.push(nav);

    function paint() {
      dots.forEach(function (d, i) {
        d.style = 'flex-1 h-1 rounded-full ' + (i <= current ? 'bg-blue-600' : 'bg-gray-200 dark:bg-gray-700');
      });
      body.clear();
      var step = steps[current];
      var content = step.render ? step.render(values) : (step.body || create('div'));
      body.push(content);
      next.text = current === steps.length - 1 ? (step.finishLabel || 'Finish') : 'Next';
    }

    back.onClick = function () { if (current > 0) { current--; paint(); } };
    next.onClick = function () {
      var step = steps[current];
      if (step.onNext) {
        var r = step.onNext(values);
        if (r === false) return;
        if (r && typeof r === 'object') for (var k in r) values[k] = r[k];
      }
      if (current < steps.length - 1) { current++; paint(); }
      else if (onFinish) onFinish(values);
    };

    paint();
    wrap.get = function () { return values; };
    return wrap;
  };

  // ===== IMPORT / FROM =====
  modules.import = function (name) { return modules[name] || null; };
  modules.from = function () {
    var out = {};
    for (var i = 0; i < arguments.length; i++) out[arguments[i]] = modules[arguments[i]];
    return out;
  };
  modules.list = function () {
    return Object.keys(modules).filter(function (k) {
      return ['import', 'from', 'list'].indexOf(k) === -1;
    });
  };

  global.modules = modules;
  global.M = modules;
})(window);