(function (global) {

  'use strict';

  (function injectBase() {
    if (document.getElementById('__fw_base')) return;
    var st = document.createElement('style');
    st.id = '__fw_base';
    st.textContent = [
      '*{box-sizing:border-box}',
      'html,body{margin:0;padding:0;height:100%;font-family:system-ui,-apple-system,sans-serif}',
      'button{font-family:inherit}',
      'input,textarea,select{font-family:inherit}',
      '.no-scrollbar::-webkit-scrollbar{display:none}',
      '.no-scrollbar{-ms-overflow-style:none;scrollbar-width:none}',
      '@keyframes __fade-in{from{opacity:0}to{opacity:1}}',
      '@keyframes __fade-out{from{opacity:1}to{opacity:0}}',
      '@keyframes __slide-up{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}',
      '@keyframes __slide-down{from{opacity:0;transform:translateY(-24px)}to{opacity:1;transform:translateY(0)}}',
      '@keyframes __slide-left{from{opacity:0;transform:translateX(30px)}to{opacity:1;transform:translateX(0)}}',
      '@keyframes __slide-right{from{opacity:0;transform:translateX(-30px)}to{opacity:1;transform:translateX(0)}}',
      '@keyframes __scale-in{from{opacity:0;transform:scale(.92)}to{opacity:1;transform:scale(1)}}',
      '@keyframes __bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}',
      '@keyframes __shake{0%,100%{transform:translateX(0)}25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}',
      '@keyframes spin{from{transform:rotate(0)}to{transform:rotate(360deg)}}',
      '.animate-spin{animation:spin 1s linear infinite}',
      '@keyframes pulse{0%,100%{opacity:1}50%{opacity:.5}}',
      '.animate-pulse{animation:pulse 2s cubic-bezier(.4,0,.6,1) infinite}',
      '@keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}',
      '.animate-bounce{animation:bounce 1s infinite}',
      '@keyframes __ai-fade{from{opacity:0}to{opacity:1}}',
      '@keyframes __ai-slide-up{from{opacity:0;transform:translateY(40px)}to{opacity:1;transform:translateY(0)}}',
      '@keyframes __ai-slide-down{from{opacity:0;transform:translateY(-40px)}to{opacity:1;transform:translateY(0)}}',
      '@keyframes __ai-slide-left{from{opacity:0;transform:translateX(50px)}to{opacity:1;transform:translateX(0)}}',
      '@keyframes __ai-slide-right{from{opacity:0;transform:translateX(-50px)}to{opacity:1;transform:translateX(0)}}',
      '@keyframes __ai-pulse{0%,100%{opacity:1}50%{opacity:.4}}',
      '@keyframes __ai-bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-18px)}}',
      '@keyframes __ai-scale{from{opacity:0;transform:scale(.6)}to{opacity:1;transform:scale(1)}}',
      '@keyframes __ai-zoom{from{opacity:0;transform:scale(1.6)}to{opacity:1;transform:scale(1)}}',
      '@keyframes __ai-shake{0%,100%{transform:translateX(0)}20%{transform:translateX(-10px)}40%{transform:translateX(10px)}60%{transform:translateX(-6px)}80%{transform:translateX(6px)}}',
      '@keyframes __ai-flip{from{transform:rotateY(90deg);opacity:0}to{transform:rotateY(0);opacity:1}}',
      '@keyframes __ai-rotate{from{transform:rotate(-180deg);opacity:0}to{transform:rotate(0);opacity:1}}'
    ].join('');
    document.head.appendChild(st);
  })();

  function showError(title, detail) {
    var box = document.getElementById('__err');
    if (!box) {
      box = document.createElement('div');
      box.id = '__err';
      box.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#dc2626;color:#fff;padding:12px;font:12px monospace;max-height:60vh;overflow:auto;white-space:pre-wrap';
      document.body.appendChild(box);
    }
    box.textContent = 'ERROR: ' + title + '\n\n' + (detail || '');
  }
  global.addEventListener('error', function (e) {
    showError('JavaScript error', (e.message || '') + '\n' + (e.filename || '') + ':' + (e.lineno || ''));
  });
  global.addEventListener('unhandledrejection', function (e) {
    showError('Promise rejected', String(e.reason));
  });

  var _cssRules = {};
  function css(obj) {
    if (obj === undefined) return _cssRules;
    for (var sel in obj) if (obj.hasOwnProperty(sel)) _cssRules[sel] = obj[sel];
    _paintCSS();
  }
  function cssReset() {
    for (var k in _cssRules) if (_cssRules.hasOwnProperty(k)) delete _cssRules[k];
    _paintCSS();
  }
  function _cssKey(k) { return k.replace(/([A-Z])/g, '-$1').toLowerCase(); }
  function _cssRender(sel, props) {
    if (sel.charAt(0) === '@') {
      var isKf = sel.indexOf('keyframes') !== -1;
      var inner = [];
      for (var k in props) {
        if (!props.hasOwnProperty(k)) continue;
        if (isKf) {
          var step = [];
          for (var p in props[k]) if (props[k].hasOwnProperty(p)) step.push(_cssKey(p) + ':' + props[k][p]);
          inner.push(k + '{' + step.join(';') + '}');
        } else inner.push(_cssRender(k, props[k]));
      }
      return sel + '{' + inner.join('') + '}';
    }
    var body = [];
    for (var p2 in props) if (props.hasOwnProperty(p2)) body.push(_cssKey(p2) + ':' + props[p2]);
    return sel + '{' + body.join(';') + '}';
  }
  function _paintCSS() {
    var sheet = document.getElementById('__css_sheet');
    if (!sheet) {
      sheet = document.createElement('style');
      sheet.id = '__css_sheet';
      document.head.appendChild(sheet);
    }
    var out = [];
    for (var sel in _cssRules) if (_cssRules.hasOwnProperty(sel)) out.push(_cssRender(sel, _cssRules[sel]));
    sheet.textContent = out.join('');
  }

  function toast(message, type, duration) {
    type = type || 'info';
    duration = duration || 2500;
    var colors = {
      info: 'background:#111827;color:#fff',
      success: 'background:#22c55e;color:#fff',
      error: 'background:#ef4444;color:#fff',
      warning: 'background:#facc15;color:#000'
    };
    var c = document.getElementById('__toasts');
    if (!c) {
      c = document.createElement('div');
      c.id = '__toasts';
      c.style.cssText = 'position:fixed;top:16px;left:0;right:0;z-index:9998;display:flex;flex-direction:column;align-items:center;gap:8px;pointer-events:none';
      document.body.appendChild(c);
    }
    var t = document.createElement('div');
    t.style.cssText = 'padding:12px 20px;border-radius:12px;font-weight:600;font-size:14px;box-shadow:0 6px 20px rgba(0,0,0,.2);max-width:90vw;transform:translateY(-20px);opacity:0;transition:all .25s ease;' + (colors[type] || colors.info);
    t.textContent = message;
    c.appendChild(t);
    requestAnimationFrame(function () { t.style.transform = 'translateY(0)'; t.style.opacity = '1'; });
    setTimeout(function () {
      t.style.transform = 'translateY(-20px)'; t.style.opacity = '0';
      setTimeout(function () { t.remove(); }, 300);
    }, duration);
  }

  function notify(title, body, time) {
    time = time || 0;
    function fire() {
      if (global.Android && global.Android.toast) global.Android.toast(title + (body ? ' — ' + body : ''));
      toast(title + (body ? ' — ' + body : ''), 'info', 3000);
    }
    if (time > 0) setTimeout(fire, time * 1000); else fire();
  }

  var store = {
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
    get: function (k, fb) { try { var v = localStorage.getItem(k); return v == null ? fb : JSON.parse(v); } catch (e) { return fb; } },
    remove: function (k) { try { localStorage.removeItem(k); } catch (e) {} },
    clear: function () { try { localStorage.clear(); } catch (e) {} },
    keys: function () {
      var out = [];
      try { for (var i = 0; i < localStorage.length; i++) out.push(localStorage.key(i)); } catch (e) {}
      return out;
    }
  };

  var theme = {
    set: function (n) {
      if (n === 'dark') document.documentElement.classList.add('dark');
      else document.documentElement.classList.remove('dark');
      store.set('theme', n);
      return n;
    },
    get: function () { return document.documentElement.classList.contains('dark') ? 'dark' : 'light'; },
    toggle: function () { return this.set(this.get() === 'dark' ? 'light' : 'dark'); },
    init: function () { if (store.get('theme') === 'dark') document.documentElement.classList.add('dark'); }
  };

  function $(sel, ctx) { return (ctx || document).querySelector(sel); }
  function $$(sel, ctx) { return Array.prototype.slice.call((ctx || document).querySelectorAll(sel)); }
  function uid() { return 'id_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }
  function escape(str) {
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function once(fn) {
    var called = false;
    return function () { if (called) return; called = true; return fn.apply(this, arguments); };
  }
  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function debounce(fn, ms) {
    var t;
    return function () {
      var args = arguments, self = this;
      clearTimeout(t);
      t = setTimeout(function () { fn.apply(self, args); }, ms);
    };
  }
  function throttle(fn, ms) {
    var last = 0;
    return function () {
      var now = Date.now();
      if (now - last < ms) return;
      last = now;
      fn.apply(this, arguments);
    };
  }
  function onReady(fn) {
    if (document.readyState === 'complete' || document.readyState === 'interactive') setTimeout(fn, 0);
    else document.addEventListener('DOMContentLoaded', fn);
  }
  function isMobile() { return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent); }
  function isDark() { return document.documentElement.classList.contains('dark'); }
  function number(n) { return String(n == null ? 0 : n).replace(/\B(?=(\d{3})+(?!\d))/g, ','); }
  function money(n, currency) {
    currency = currency || '$';
    var parts = Number(n || 0).toFixed(2).split('.');
    parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    return currency + parts.join('.');
  }

  var ANIMS = ['fade-in','fade-out','slide-up','slide-down','slide-left','slide-right','scale-in','bounce','shake'];
  function applyAnim(el, name) {
    if (ANIMS.indexOf(name) === -1) return;
    var cls = '__anim-' + name;
    el.classList.remove(cls);
    void el.offsetWidth;
    el.classList.add(cls);
  }
  function animate(node, name) {
    var el = node instanceof FWNode ? node.el : node;
    if (el) applyAnim(el, name);
    return node;
  }

  function spinner(size) {
    size = size || 24;
    var n = create('div');
    n.style = 'inline-block rounded-full border-2 border-gray-300 border-t-blue-500 animate-spin';
    n.el.style.width = size + 'px';
    n.el.style.height = size + 'px';
    return n;
  }
  function skeleton(lines, opts) {
    lines = lines || 3;
    opts = opts || {};
    var n = create('div');
    n.style = opts.card ? 'bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm flex flex-col gap-3' : 'flex flex-col gap-3';
    for (var i = 0; i < lines; i++) {
      var line = create('div');
      line.style = 'h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse';
      if (i === lines - 1) line.el.style.width = '60%';
      n.push(line);
    }
    return n;
  }

  function copy(text) {
    text = String(text);
    var fb = function () {
      var t = document.createElement('textarea');
      t.value = text;
      t.style.cssText = 'position:fixed;top:-1000px';
      document.body.appendChild(t);
      t.select();
      try { document.execCommand('copy'); toast('Copied', 'success'); }
      catch (e) { toast('Could not copy', 'error'); }
      t.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { toast('Copied', 'success'); }).catch(fb);
      return;
    }
    fb();
  }

  function toDate(d) { return d instanceof Date ? d : new Date(d); }
  function formatTime(d) { return toDate(d).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
  function formatDate(d) { return toDate(d).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }); }
  function formatDateTime(d) { return formatDate(d) + ' · ' + formatTime(d); }
  function formatAgo(d) {
    var s = Math.floor((Date.now() - toDate(d).getTime()) / 1000);
    if (s < 60) return s + 's ago';
    if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    if (s < 2592000) return Math.floor(s / 86400) + 'd ago';
    if (s < 31536000) return Math.floor(s / 2592000) + 'mo ago';
    return Math.floor(s / 31536000) + 'y ago';
  }

  var _tagDefaults = {};
  var _namedStyles = {};
  function defaults(tag, classes) {
    if (classes === undefined) return _tagDefaults[tag] || '';
    _tagDefaults[tag] = classes;
    return classes;
  }
  function styles(obj) {
    if (obj === undefined) return _namedStyles;
    for (var k in obj) if (obj.hasOwnProperty(k)) _namedStyles[k] = obj[k];
    return _namedStyles;
  }

  var ICONS = {
    home:'<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    menu:'<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    grid:'<rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/>',
    list:'<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
    arrowLeft:'<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
    arrowRight:'<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
    arrowUp:'<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
    arrowDown:'<line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/>',
    chevronLeft:'<polyline points="15 18 9 12 15 6"/>',
    chevronRight:'<polyline points="9 18 15 12 9 6"/>',
    chevronUp:'<polyline points="18 15 12 9 6 15"/>',
    chevronDown:'<polyline points="6 9 12 15 18 9"/>',
    moreH:'<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    moreV:'<circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/>',
    search:'<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    plus:'<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    plusCircle:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/>',
    minus:'<line x1="5" y1="12" x2="19" y2="12"/>',
    minusCircle:'<circle cx="12" cy="12" r="10"/><line x1="8" y1="12" x2="16" y2="12"/>',
    x:'<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    xCircle:'<circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/>',
    check:'<polyline points="20 6 9 17 4 12"/>',
    checkCircle:'<path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><polyline points="22 4 12 14.01 9 11.01"/>',
    edit:'<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    trash:'<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    copy:'<rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
    save:'<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>',
    download:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
    refresh:'<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
    filter:'<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
    share:'<circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/>',
    send:'<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
    reply:'<polyline points="9 17 4 12 9 7"/><path d="M20 18v-2a4 4 0 0 0-4-4H4"/>',
    pin:'<line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24z"/>',
    lock:'<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    unlock:'<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
    key:'<path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4"/>',
    shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    shieldCheck:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><polyline points="9 12 11 14 15 10"/>',
    eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
    eyeOff:'<path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/>',
    user:'<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    users:'<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
    userPlus:'<path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/>',
    userCircle:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="10" r="3"/><path d="M6.168 18.849a4 4 0 0 1 3.832-2.849h4a4 4 0 0 1 3.834 2.855"/>',
    smile:'<circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
    frown:'<circle cx="12" cy="12" r="10"/><path d="M16 16s-1.5-2-4-2-4 2-4 2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/>',
    mail:'<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
    inbox:'<polyline points="22 12 16 12 14 15 10 15 8 12 2 12"/><path d="M5.45 5.11L2 12v6a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-6l-3.45-6.89A2 2 0 0 0 16.76 4H7.24a2 2 0 0 0-1.79 1.11z"/>',
    phone:'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    messageCircle:'<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
    messageSquare:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    bell:'<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    bellOff:'<path d="M13.73 21a2 2 0 0 1-3.46 0"/><path d="M18.63 13A17.89 17.89 0 0 1 18 8"/><path d="M6.26 6.26A5.86 5.86 0 0 0 6 8c0 7-3 9-3 9h14"/><path d="M18 8a6 6 0 0 0-9.33-5"/><line x1="1" y1="1" x2="23" y2="23"/>',
    atSign:'<circle cx="12" cy="12" r="4"/><path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94"/>',
    hash:'<line x1="4" y1="9" x2="20" y2="9"/><line x1="4" y1="15" x2="20" y2="15"/><line x1="10" y1="3" x2="8" y2="21"/><line x1="16" y1="3" x2="14" y2="21"/>',
    play:'<polygon points="5 3 19 12 5 21 5 3"/>',
    pause:'<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>',
    stop:'<rect x="5" y="5" width="14" height="14" rx="1"/>',
    volume:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"/>',
    volumeX:'<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/>',
    mic:'<path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/>',
    camera:'<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
    video:'<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2" ry="2"/>',
    image:'<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/>',
    headphones:'<path d="M3 18v-6a9 9 0 0 1 18 0v6"/><path d="M21 19a2 2 0 0 1-2 2h-1a2 2 0 0 1-2-2v-3a2 2 0 0 1 2-2h3zM3 19a2 2 0 0 0 2 2h1a2 2 0 0 0 2-2v-3a2 2 0 0 0-2-2H3z"/>',
    radio:'<circle cx="12" cy="12" r="2"/><path d="M16.24 7.76a6 6 0 0 1 0 8.49m-8.48-.01a6 6 0 0 1 0-8.49m11.31-2.82a10 10 0 0 1 0 14.14m-14.14 0a10 10 0 0 1 0-14.14"/>',
    rss:'<path d="M4 11a9 9 0 0 1 9 9"/><path d="M4 4a16 16 0 0 1 16 16"/><circle cx="5" cy="19" r="1"/>',
    cart:'<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
    bag:'<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
    creditCard:'<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
    wallet:'<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',
    dollarSign:'<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>',
    tag:'<path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><line x1="7" y1="7" x2="7.01" y2="7"/>',
    gift:'<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',
    file:'<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/>',
    fileText:'<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
    folder:'<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    folderOpen:'<path d="M6 14l1.45-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.55 6a2 2 0 0 1-1.94 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h5a2 2 0 0 1 2 2v1"/>',
    archive:'<polyline points="21 8 21 21 3 21 3 8"/><rect x="1" y="3" width="22" height="5"/><line x1="10" y1="12" x2="14" y2="12"/>',
    book:'<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
    bookOpen:'<path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/>',
    link:'<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    externalLink:'<path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"/><polyline points="15 3 21 3 21 9"/><line x1="10" y1="14" x2="21" y2="3"/>',
    calendar:'<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    clock:'<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    timer:'<line x1="10" y1="2" x2="14" y2="2"/><line x1="12" y1="14" x2="15" y2="11"/><circle cx="12" cy="14" r="8"/>',
    sun:'<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
    moon:'<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
    cloud:'<path d="M18 10h-1.26A8 8 0 1 0 9 20h9a5 5 0 0 0 0-10z"/>',
    droplet:'<path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>',
    umbrella:'<path d="M23 12a11.05 11.05 0 0 0-22 0zm-5 7a3 3 0 0 1-6 0v-7"/>',
    wind:'<path d="M9.59 4.59A2 2 0 1 1 11 8H2m10.59 11.41A2 2 0 1 0 14 16H2m15.73-8.27A2.5 2.5 0 1 1 19.5 12H2"/>',
    zap:'<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    flame:'<path d="M8.5 14.5A2.5 2.5 0 0 0 11 12c0-1.38-.5-2-1-3-1.072-2.143-.224-4.054 2-6 .5 2.5 2 4.9 4 6.5 2 1.6 3 3.5 3 5.5a7 7 0 1 1-14 0c0-1.153.433-2.294 1-3a2.5 2.5 0 0 0 2.5 2.5z"/>',
    leaf:'<path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10z"/><path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>',
    map:'<polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"/><line x1="8" y1="2" x2="8" y2="18"/><line x1="16" y1="6" x2="16" y2="22"/>',
    mapPin:'<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
    navigation:'<polygon points="3 11 22 2 13 21 11 13 3 11"/>',
    compass:'<circle cx="12" cy="12" r="10"/><polygon points="16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76"/>',
    globe:'<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    anchor:'<circle cx="12" cy="5" r="3"/><line x1="12" y1="22" x2="12" y2="8"/><path d="M5 12H2a10 10 0 0 0 20 0h-3"/>',
    plane:'<path d="M17.8 19.2L16 11l3.5-3.5C21 6 21.5 4 21 3c-1-.5-3 0-4.5 1.5L13 8 4.8 6.2c-.5-.1-.9.1-1.1.5l-.3.5c-.2.5-.1 1 .3 1.3L9 12l-2 3H4l-1 1 3 2 2 3 1-1v-3l3-2 3.5 5.3c.3.4.8.5 1.3.3l.5-.2c.4-.3.6-.7.5-1.2z"/>',
    smartphone:'<rect x="5" y="2" width="14" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>',
    tablet:'<rect x="4" y="2" width="16" height="20" rx="2" ry="2"/><line x1="12" y1="18" x2="12.01" y2="18"/>',
    laptop:'<path d="M20 16V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v10"/><rect x="1" y="16" width="22" height="4" rx="1"/>',
    monitor:'<rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>',
    tv:'<rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/>',
    speaker:'<rect x="4" y="2" width="16" height="20" rx="2"/><circle cx="12" cy="14" r="4"/><line x1="12" y1="6" x2="12.01" y2="6"/>',
    keyboard:'<rect x="2" y="6" width="20" height="12" rx="2"/><line x1="6" y1="10" x2="6.01" y2="10"/><line x1="10" y1="10" x2="10.01" y2="10"/><line x1="14" y1="10" x2="14.01" y2="10"/><line x1="18" y1="10" x2="18.01" y2="10"/><line x1="6" y1="14" x2="18" y2="14"/>',
    cpu:'<rect x="4" y="4" width="16" height="16" rx="2" ry="2"/><rect x="9" y="9" width="6" height="6"/><line x1="9" y1="1" x2="9" y2="4"/><line x1="15" y1="1" x2="15" y2="4"/><line x1="9" y1="20" x2="9" y2="23"/><line x1="15" y1="20" x2="15" y2="23"/><line x1="20" y1="9" x2="23" y2="9"/><line x1="20" y1="14" x2="23" y2="14"/><line x1="1" y1="9" x2="4" y2="9"/><line x1="1" y1="14" x2="4" y2="14"/>',
    server:'<rect x="2" y="2" width="20" height="8" rx="2" ry="2"/><rect x="2" y="14" width="20" height="8" rx="2" ry="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/>',
    database:'<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>',
    wifi:'<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
    battery:'<rect x="1" y="6" width="18" height="12" rx="2" ry="2"/><line x1="23" y1="13" x2="23" y2="11"/>',
    power:'<path d="M18.36 6.64a9 9 0 1 1-12.73 0"/><line x1="12" y1="2" x2="12" y2="12"/>',
    info:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
    alertCircle:'<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
    alertTriangle:'<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    helpCircle:'<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    heart:'<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
    star:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    bookmark:'<path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"/>',
    flag:'<path d="M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1z"/><line x1="4" y1="22" x2="4" y2="15"/>',
    award:'<circle cx="12" cy="8" r="7"/><polyline points="8.21 13.89 7 23 12 20 17 23 15.79 13.88"/>',
    trophy:'<path d="M6 9H4.5a2.5 2.5 0 0 1 0-5H6"/><path d="M18 9h1.5a2.5 2.5 0 0 0 0-5H18"/><path d="M4 22h16"/><path d="M10 14.66V17c0 .55-.47.98-.97 1.21C7.85 18.75 7 20.24 7 22"/><path d="M14 14.66V17c0 .55.47.98.97 1.21C16.15 18.75 17 20.24 17 22"/><path d="M18 2H6v7a6 6 0 0 0 12 0V2z"/>',
    gem:'<polygon points="6 3 18 3 22 9 12 22 2 9 6 3"/><polyline points="2 9 22 9"/><polyline points="12 22 6 3"/><polyline points="12 22 18 3"/>',
    rocket:'<path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"/><path d="M12 15l-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"/><path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"/><path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"/>',
    sparkles:'<path d="M12 3l1.5 4.5L18 9l-4.5 1.5L12 15l-1.5-4.5L6 9l4.5-1.5L12 3z"/><path d="M19 15l.7 2.1L22 18l-2.3.7L19 21l-.7-2.3L16 18l2.3-.9L19 15z"/><path d="M5 3l.5 1.5L7 5l-1.5.5L5 7l-.5-1.5L3 5l1.5-.5L5 3z"/>',
    barChart:'<line x1="12" y1="20" x2="12" y2="10"/><line x1="18" y1="20" x2="18" y2="4"/><line x1="6" y1="20" x2="6" y2="16"/>',
    pieChart:'<path d="M21.21 15.89A10 10 0 1 1 8 2.83"/><path d="M22 12A10 10 0 0 0 12 2v10z"/>',
    lineChart:'<path d="M3 3v18h18"/><path d="M18.7 8l-5.1 5.2-2.8-2.7L7 14.3"/>',
    trendingUp:'<polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/>',
    trendingDown:'<polyline points="23 18 13.5 8.5 8.5 13.5 1 6"/><polyline points="17 18 23 18 23 12"/>',
    activity:'<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    target:'<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
    layers:'<polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/>',
    layout:'<rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>',
    sliders:'<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    toggle:'<rect x="1" y="5" width="22" height="14" rx="7"/><circle cx="16" cy="12" r="3"/>',
    settings:'<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    code:'<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
    terminal:'<polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>',
    scissors:'<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>',
    clipboard:'<path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><rect x="8" y="2" width="8" height="4" rx="1" ry="1"/>',
    coffee:'<path d="M18 8h1a4 4 0 0 1 0 8h-1"/><path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"/><line x1="6" y1="1" x2="6" y2="4"/><line x1="10" y1="1" x2="10" y2="4"/><line x1="14" y1="1" x2="14" y2="4"/>',
    ghost:'<path d="M9 10h.01M15 10h.01M12 2a8 8 0 0 0-8 8v12l3-3 2.5 2.5L12 19l2.5 2.5L17 19l3 3V10a8 8 0 0 0-8-8z"/>'
  };
  if (global.__ICONS) {
    for (var ik in global.__ICONS) if (global.__ICONS.hasOwnProperty(ik)) ICONS[ik] = global.__ICONS[ik];
  }

  function FWNode(tag, content) {
    this.el = document.createElement(tag);
    if (content != null) {
      if (content instanceof FWNode) this.el.appendChild(content.el);
      else if (content.nodeType === 1 || content.nodeType === 3) this.el.appendChild(content);
      else this.el.textContent = String(content);
    }
    var d = _tagDefaults[tag];
    if (d) this.el.className = d;
    this._listeners = {};
  }
  Object.defineProperty(FWNode.prototype, 'style', {
    get: function () { return this.el.className; },
    set: function (c) { this.el.className = c; }
  });
  Object.defineProperty(FWNode.prototype, 'text', {
    get: function () { return this.el.textContent; },
    set: function (v) { this.el.textContent = v; }
  });
  Object.defineProperty(FWNode.prototype, 'value', {
    get: function () { return this.el.value; },
    set: function (v) { this.el.value = v; }
  });
  Object.defineProperty(FWNode.prototype, 'id', {
    get: function () { return this.el.id; },
    set: function (v) { this.el.id = v; }
  });
  Object.defineProperty(FWNode.prototype, 'src', {
    get: function () { return this.el.src; },
    set: function (v) { this.el.src = v; }
  });
  Object.defineProperty(FWNode.prototype, 'alt', {
    get: function () { return this.el.alt; },
    set: function (v) { this.el.alt = v; }
  });
  Object.defineProperty(FWNode.prototype, 'placeholder', {
    get: function () { return this.el.placeholder; },
    set: function (v) { this.el.placeholder = v; }
  });
  Object.defineProperty(FWNode.prototype, 'href', {
    get: function () { return this.el.href; },
    set: function (v) { this.el.href = v; }
  });
  Object.defineProperty(FWNode.prototype, 'onClick', {
    set: function (fn) {
      if (this._listeners.click) this.el.removeEventListener('click', this._listeners.click);
      this._listeners.click = fn;
      if (fn) this.el.addEventListener('click', fn);
    },
    get: function () { return this._listeners.click; }
  });
  FWNode.prototype.addClass = function () {
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j]) this.el.classList.add(parts[j]);
    }
    return this;
  };
  FWNode.prototype.removeClass = function () {
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j]) this.el.classList.remove(parts[j]);
    }
    return this;
  };
  FWNode.prototype.toggleClass = function () {
    var last = false;
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j]) last = this.el.classList.toggle(parts[j]);
    }
    return last;
  };
  FWNode.prototype.hasClass = function () {
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j] && !this.el.classList.contains(parts[j])) return false;
    }
    return true;
  };
  FWNode.prototype.use = function () {
    for (var i = 0; i < arguments.length; i++) {
      var s = _namedStyles[arguments[i]];
      if (s) this.addClass(s);
    }
    return this;
  };
  FWNode.prototype.animate = function (name) { applyAnim(this.el, name); return this; };
  FWNode.prototype.on = function (ev, fn) { this.el.addEventListener(ev, fn); return this; };
  FWNode.prototype.onHover = function (fn) { this.el.addEventListener('mouseenter', fn); return this; };
  FWNode.prototype.onLeave = function (fn) { this.el.addEventListener('mouseleave', fn); return this; };
  FWNode.prototype.clear = function () {
    while (this.el.firstChild) this.el.removeChild(this.el.firstChild);
    return this;
  };
  FWNode.prototype.push = function () {
    for (var i = 0; i < arguments.length; i++) {
      var c = arguments[i];
      this.el.append(c instanceof FWNode ? c.el : c);
    }
    return this;
  };

  function create(tag, content) { return new FWNode(tag, content); }
  function app(id) {
    var root = new FWNode('div');
    (document.getElementById(id || 'root') || document.body).append(root.el);
    return root;
  }
  function render(target, node) {
    if (!target) return;
    var t = target instanceof FWNode ? target.el : target;
    t.innerHTML = '';
    if (node) t.appendChild(node instanceof FWNode ? node.el : node);
  }

  function row() { var n = create('div'); n.style = 'flex flex-row items-center'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function col() { var n = create('div'); n.style = 'flex flex-col'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function spacer() { var n = create('div'); n.style = 'flex-1'; return n; }
  function screen() {
    var n = create('div');
    n.style = 'min-h-screen p-4 flex flex-col gap-4';
    if (arguments.length) n.push.apply(n, arguments);
    return n;
  }
  function bottomBar() {
    var n = create('div');
    n.style = 'fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 p-4';
    if (arguments.length) n.push.apply(n, arguments);
    return n;
  }

  function badge(count) {
    var n = create('span', String(count));
    n.style = 'absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold';
    return n;
  }
  function iconBtn(name) {
    var btn = create('button');
    var extra = Array.prototype.slice.call(arguments, 1).join(' ');
    btn.style = ('relative p-2 rounded-full flex items-center justify-center ' + extra).trim();
    btn.push(svg(name, 'w-6 h-6'));
    return btn;
  }
  function rating(value, reviews) {
    var n = create('div');
    n.style = 'flex items-center gap-1 text-sm';
    var full = Math.floor(value);
    for (var i = 0; i < full; i++) n.push(svg('star', 'w-4 h-4 text-yellow-400'));
    if (value - full >= 0.5) n.push(svg('star', 'w-4 h-4 text-yellow-400'));
    var t = create('span', value + (reviews != null ? '  (' + reviews + ')' : ''));
    t.style = 'text-gray-600 dark:text-gray-300 ml-1';
    n.push(t);
    return n;
  }
  function chip(text, active) {
    var n = create('button', text);
    function paint(on) {
      n.style = 'px-4 py-2 rounded-full text-sm font-medium border transition ' +
        (on ? 'bg-black text-white border-black'
            : 'bg-white text-gray-700 border-gray-300 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600');
    }
    paint(!!active);
    n.setActive = function (on) { paint(on); return n; };
    return n;
  }
  function progressBar(value, max) {
    max = max || 100;
    var n = create('div');
    n.style = 'w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden';
    var fill = create('div');
    fill.style = 'h-full bg-blue-500 transition-all duration-300';
    fill.el.style.width = clamp((value / max) * 100, 0, 100) + '%';
    n.push(fill);
    n.set = function (v) {
      fill.el.style.width = clamp((v / max) * 100, 0, 100) + '%';
      return n;
    };
    return n;
  }
  function switchToggle(initial, onChange) {
    var on = !!initial;
    var n = create('button');
    var knob = create('div');
    knob.style = 'absolute top-0.5 w-6 h-6 bg-white rounded-full shadow transition-all';
    n.push(knob);
    function paint() {
      n.style = 'w-12 h-7 rounded-full transition relative ' + (on ? 'bg-blue-500' : 'bg-gray-300');
      knob.el.style.left = on ? '22px' : '2px';
    }
    paint();
    n.onClick = function () {
      on = !on;
      paint();
      vibrate(15);
      if (onChange) onChange(on);
    };
    n.get = function () { return on; };
    n.set = function (v) { on = !!v; paint(); return n; };
    return n;
  }
  function emptyState(icon, title, sub) {
    var n = create('div');
    n.style = 'flex flex-col items-center justify-center gap-3 py-16 text-center';
    var ic = create('div');
    ic.style = 'w-20 h-20 rounded-full bg-gray-100 dark:bg-gray-800 flex items-center justify-center';
    ic.push(svg(icon || 'info', 'w-10 h-10 text-gray-400'));
    n.push(ic);
    if (title) {
      var t = create('div', title);
      t.style = 'text-lg font-bold text-gray-700 dark:text-gray-200';
      n.push(t);
    }
    if (sub) {
      var s = create('div', sub);
      s.style = 'text-sm text-gray-500 max-w-xs';
      n.push(s);
    }
    return n;
  }
  function avatarGroup(srcs, max) {
    max = max || 3;
    var n = create('div');
    n.style = 'flex flex-row items-center';
    var show = srcs.slice(0, max);
    var rest = srcs.length - show.length;
    show.forEach(function (src, i) {
      var a = avatar(src);
      a.addClass('border-2 border-white dark:border-gray-900');
      if (i > 0) a.el.style.marginLeft = '-10px';
      n.push(a);
    });
    if (rest > 0) {
      var more = create('div', '+' + rest);
      more.style = 'w-12 h-12 rounded-full bg-gray-200 dark:bg-gray-700 flex items-center justify-center text-xs font-bold text-gray-600 dark:text-gray-200 border-2 border-white dark:border-gray-900';
      more.el.style.marginLeft = '-10px';
      n.push(more);
    }
    return n;
  }

  function scrollX() { var n = create('div'); n.style = 'flex flex-row gap-2 overflow-x-auto no-scrollbar'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function scrollY() { var n = create('div'); n.style = 'flex flex-col gap-2 overflow-y-auto no-scrollbar'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function hideScroll(node) { node.addClass('no-scrollbar'); return node; }

  function img(src, alt) {
    var n = create('img');
    n.src = src;
    n.alt = alt || '';
    n.style = Array.prototype.slice.call(arguments, 2).join(' ');
    return n;
  }
  function avatar(src) {
    var extra = Array.prototype.slice.call(arguments, 1).join(' ');
    return img(src, 'avatar', ('w-12 h-12 rounded-full object-cover ' + extra).trim());
  }
  function swatch(color) {
    var extra = Array.prototype.slice.call(arguments, 1).join(' ');
    var n = create('button');
    n.style = ('w-10 h-10 rounded-xl border-2 border-gray-200 dark:border-gray-700 flex items-center justify-center ' + extra).trim();
    var dot = create('div');
    dot.style = 'w-5 h-5 rounded-full';
    dot.el.style.background = color;
    n.push(dot);
    return n;
  }

  function svg(name) {
    var cs = Array.prototype.slice.call(arguments, 1).filter(Boolean).join(' ');
    var hasW = /\bw-/.test(cs), hasH = /\bh-/.test(cs);
    var cls = (hasW ? '' : 'w-6 ') + (hasH ? '' : 'h-6 ') + cs;
    var wrap = new FWNode('span');
    wrap.style = cls.trim();
    wrap.el.style.display = 'inline-block';
    var el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('viewBox', '0 0 24 24');
    el.setAttribute('fill', 'none');
    el.setAttribute('stroke', 'currentColor');
    el.setAttribute('stroke-width', '2');
    el.setAttribute('stroke-linecap', 'round');
    el.setAttribute('stroke-linejoin', 'round');
    el.setAttribute('width', '100%');
    el.setAttribute('height', '100%');
    el.innerHTML = ICONS[name] || '';
    wrap.el.append(el);
    return wrap;
  }
  function iconList() { return Object.keys(ICONS); }

  function dic(k, v, o) { o = o || {}; o[k] = v; return o; }
  function findDK(o, v) { if (!o) return undefined; for (var k in o) if (o.hasOwnProperty(k) && o[k] === v) return k; return undefined; }
  function findDV(o, k) { if (!o) return undefined; return o[k]; }

  function state(initial) {
    var _value = initial;
    var _subs = [];
    var api = {
      get: function () { return _value; },
      set: function (v) {
        if (v === _value) return v;
        _value = v;
        for (var i = 0; i < _subs.length; i++) {
          try { _subs[i](_value); } catch (e) {}
        }
        return _value;
      },
      update: function (fn) { return api.set(fn(_value)); },
      subscribe: function (fn) {
        _subs.push(fn);
        try { fn(_value); } catch (e) {}
        return function () {
          var i = _subs.indexOf(fn);
          if (i >= 0) _subs.splice(i, 1);
        };
      },
      bind: function (el, formatter) {
        api.subscribe(function (v) { el.text = formatter ? formatter(v) : v; });
        return el;
      }
    };
    return api;
  }

  function list(initial) {
    var _items = Array.isArray(initial) ? initial.slice() : [];
    var _renderer = null;
    var _container = null;
    function repaint() {
      if (!_container || !_renderer) return;
      _container.clear();
      for (var i = 0; i < _items.length; i++) {
        var node = _renderer(_items[i], i, api);
        if (node) _container.push(node);
      }
    }
    var api = {
      get: function () { return _items.slice(); },
      length: function () { return _items.length; },
      set: function (arr) { _items = Array.isArray(arr) ? arr.slice() : []; repaint(); return api; },
      push: function (item) { _items.push(item); repaint(); return api; },
      unshift: function (item) { _items.unshift(item); repaint(); return api; },
      pop: function () { var v = _items.pop(); repaint(); return v; },
      remove: function (i) { _items.splice(i, 1); repaint(); return api; },
      removeWhere: function (fn) {
        for (var i = _items.length - 1; i >= 0; i--) if (fn(_items[i])) _items.splice(i, 1);
        repaint(); return api;
      },
      update: function (i, item) { _items[i] = item; repaint(); return api; },
      clear: function () { _items = []; repaint(); return api; },
      render: function (fn) { _renderer = fn; repaint(); return api; },
      mount: function (container) { _container = container; repaint(); return api; }
    };
    return api;
  }

  function modal(opts) {
    opts = opts || {};
    var overlay = create('div');
    overlay.style = 'fixed inset-0 z-[9999] flex items-center justify-center p-4 bg-black/50';
    overlay.el.style.transition = 'opacity .2s ease';
    overlay.el.style.opacity = '0';

    var box = create('div');
    box.style = 'bg-white dark:bg-gray-800 rounded-3xl p-5 shadow-2xl w-full max-w-sm flex flex-col gap-4';
    box.el.style.transform = 'scale(.95)';
    box.el.style.transition = 'transform .25s ease';

    if (opts.title) {
      var t = create('div', opts.title);
      t.style = 'text-xl font-bold text-gray-900 dark:text-white';
      box.push(t);
    }
    if (opts.body) {
      if (typeof opts.body === 'string') {
        var b = create('div', opts.body);
        b.style = 'text-gray-600 dark:text-gray-300 leading-relaxed';
        box.push(b);
      } else box.push(opts.body);
    }

    var btnRow = create('div');
    btnRow.style = 'flex flex-row gap-2 mt-2';

    function close() {
      overlay.el.style.opacity = '0';
      box.el.style.transform = 'scale(.95)';
      setTimeout(function () { overlay.el.remove(); }, 200);
    }

    var buttons = opts.buttons || [{ label: 'OK', primary: true }];
    for (var i = 0; i < buttons.length; i++) {
      (function (b) {
        var btn = create('button', b.label);
        btn.style = 'flex-1 p-3 rounded-xl font-bold transition ' +
          (b.primary ? 'bg-blue-600 text-white'
           : b.danger ? 'bg-red-500 text-white'
           : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200');
        btn.onClick = function () {
          if (b.onClick) b.onClick();
          close();
        };
        btnRow.push(btn);
      })(buttons[i]);
    }

    box.push(btnRow);
    overlay.push(box);
    document.body.appendChild(overlay.el);

    requestAnimationFrame(function () {
      overlay.el.style.opacity = '1';
      box.el.style.transform = 'scale(1)';
    });

    overlay.el.addEventListener('click', function (e) {
      if (e.target === overlay.el) close();
    });

    return { close: close, el: box };
  }

  function confirm(msg, onYes, onNo) {
    return modal({
      body: msg,
      buttons: [
        { label: 'Cancel', onClick: onNo || function () {} },
        { label: 'Confirm', primary: true, onClick: onYes || function () {} }
      ]
    });
  }
  function alertBox(title, msg) {
    return modal({
      title: title,
      body: msg,
      buttons: [{ label: 'OK', primary: true }]
    });
  }

  function sheet(opts) {
    opts = opts || {};
    var overlay = create('div');
    overlay.style = 'fixed inset-0 z-[9999] flex items-end bg-black/50';
    overlay.el.style.transition = 'opacity .2s ease';
    overlay.el.style.opacity = '0';

    var panel = create('div');
    panel.style = 'bg-white dark:bg-gray-800 rounded-t-3xl w-full p-5 flex flex-col gap-1 max-h-[80vh] overflow-y-auto';
    panel.el.style.transform = 'translateY(100%)';
    panel.el.style.transition = 'transform .3s cubic-bezier(.2,.9,.3,1)';

    var handle = create('div');
    handle.style = 'w-12 h-1 bg-gray-300 dark:bg-gray-600 rounded-full mx-auto mb-3';
    panel.push(handle);

    if (opts.title) {
      var t = create('div', opts.title);
      t.style = 'text-lg font-bold text-center mb-2 text-gray-900 dark:text-white';
      panel.push(t);
    }

    function close() {
      overlay.el.style.opacity = '0';
      panel.el.style.transform = 'translateY(100%)';
      setTimeout(function () { overlay.el.remove(); }, 300);
    }

    if (opts.body) panel.push(opts.body);

    (opts.items || []).forEach(function (item) {
      var r = create('div');
      r.style = 'flex flex-row items-center gap-3 p-4 rounded-2xl active:bg-gray-100 dark:active:bg-gray-700';
      if (item.icon) r.push(svg(item.icon, 'w-5 h-5 text-gray-600 dark:text-gray-300'));
      var lbl = create('div', item.label);
      lbl.style = 'flex-1 text-base ' + (item.danger ? 'text-red-500' : 'text-gray-800 dark:text-gray-100');
      r.push(lbl);
      if (item.badge) r.push(badge(item.badge));
      r.onClick = function () {
        if (item.onClick) item.onClick();
        close();
      };
      panel.push(r);
    });

    overlay.push(panel);
    document.body.appendChild(overlay.el);

    requestAnimationFrame(function () {
      overlay.el.style.opacity = '1';
      panel.el.style.transform = 'translateY(0)';
    });

    overlay.el.addEventListener('click', function (e) {
      if (e.target === overlay.el) close();
    });

    return { close: close, el: panel };
  }

  function tabs(names) {
    var wrap = create('div');
    wrap.style = 'flex flex-row gap-2 p-1.5 bg-gray-100 dark:bg-gray-800 rounded-2xl';
    var current = names[0];
    var elMap = {};
    var _onChange = null;
    function paint() {
      for (var i = 0; i < names.length; i++) {
        var n = names[i];
        var on = n === current;
        elMap[n].style = 'flex-1 py-2 px-4 rounded-xl text-sm font-bold text-center transition ' +
          (on ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm'
              : 'text-gray-500 dark:text-gray-400');
      }
    }
    names.forEach(function (name) {
      var b = create('button', name);
      b.onClick = function () {
        if (name === current) return;
        current = name;
        paint();
        if (_onChange) _onChange(name);
      };
      elMap[name] = b;
      wrap.push(b);
    });
    paint();
    wrap.get = function () { return current; };
    wrap.select = function (n) {
      if (!elMap[n]) return wrap;
      current = n; paint();
      if (_onChange) _onChange(n);
      return wrap;
    };
    wrap.onChange = function (fn) { _onChange = fn; return wrap; };
    return wrap;
  }

  function chipGroup(options, onSelect, initial) {
    var selected = initial != null ? initial : (typeof options[0] === 'string' ? options[0] : options[0].value);
    var map = {};
    var wrap = create('div');
    wrap.style = 'flex flex-row gap-2 flex-wrap';
    function paint() {
      for (var k in map) {
        if (!map.hasOwnProperty(k)) continue;
        var on = k === selected;
        map[k].style = 'px-4 py-2 rounded-full text-sm font-medium border transition ' +
          (on ? 'bg-black text-white border-black'
              : 'bg-white text-gray-700 border-gray-300 dark:bg-gray-800 dark:text-gray-200 dark:border-gray-600');
      }
    }
    options.forEach(function (o) {
      var label = typeof o === 'string' ? o : o.label;
      var value = typeof o === 'string' ? o : o.value;
      var c = create('button', label);
      c.onClick = function () {
        selected = value; paint();
        if (onSelect) onSelect(selected);
      };
      map[value] = c;
      wrap.push(c);
    });
    paint();
    wrap.get = function () { return selected; };
    wrap.select = function (v) { selected = v; paint(); if (onSelect) onSelect(v); return wrap; };
    return wrap;
  }

  function page(opts) {
    opts = opts || {};
    var s = create('div');
    s.style = 'min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900';
    var header = create('div');
    header.style = 'flex flex-row items-center gap-3 p-4 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 sticky top-0 z-10';
    if (opts.onBack !== false) {
      var back = iconBtn('arrowLeft', 'text-gray-800 dark:text-white');
      back.onClick = function () {
        if (typeof opts.onBack === 'function') opts.onBack();
        else route('home');
      };
      header.push(back);
    }
    var title = create('div', opts.title || '');
    title.style = 'text-xl font-bold text-gray-900 dark:text-white flex-1 truncate';
    header.push(title);
    if (opts.right) header.push(opts.right);
    var body = create('div');
    body.style = 'flex-1 p-4 flex flex-col gap-4';
    if (opts.body) body.push(opts.body);
    s.push(header, body);
    return s;
  }

  function longPress(el, fn, ms) {
    ms = ms || 600;
    var target = el instanceof FWNode ? el.el : el;
    var timer = null;
    function start() { timer = setTimeout(function () { vibrate(30); fn(); }, ms); }
    function cancel() { clearTimeout(timer); }
    target.addEventListener('touchstart', start, { passive: true });
    target.addEventListener('touchend', cancel, { passive: true });
    target.addEventListener('touchmove', cancel, { passive: true });
    target.addEventListener('mousedown', start);
    target.addEventListener('mouseup', cancel);
    target.addEventListener('mouseleave', cancel);
    return el;
  }
  function onSwipe(el, dir, fn) {
    var target = el instanceof FWNode ? el.el : el;
    var x0 = 0, y0 = 0, t0 = 0;
    target.addEventListener('touchstart', function (e) {
      var t = e.touches[0];
      x0 = t.clientX; y0 = t.clientY; t0 = Date.now();
    }, { passive: true });
    target.addEventListener('touchend', function (e) {
      var t = e.changedTouches[0];
      var dx = t.clientX - x0, dy = t.clientY - y0, dt = Date.now() - t0;
      if (dt > 1000) return;
      var ax = Math.abs(dx), ay = Math.abs(dy);
      var min = 40;
      if (ax > ay && ax > min) {
        if (dx > 0 && dir === 'right') fn();
        if (dx < 0 && dir === 'left') fn();
      } else if (ay > ax && ay > min) {
        if (dy > 0 && dir === 'down') fn();
        if (dy < 0 && dir === 'up') fn();
      }
    }, { passive: true });
    return el;
  }

  function vibrate(ms) {
    ms = ms || 50;
    if (global.Android && global.Android.vibrate) { global.Android.vibrate(ms); return; }
    if (navigator.vibrate) navigator.vibrate(ms);
  }
  function share(title, text, url) {
    var data = { title: title || '', text: text || '', url: url || '' };
    if (global.Android && global.Android.share) { global.Android.share(data.title, data.text); return; }
    if (navigator.share) { navigator.share(data).catch(function () {}); return; }
    var combined = [title, text, url].filter(Boolean).join(' — ');
    if (combined) copy(combined);
  }

  var __AI_ANIM_MAP = {
    fade: '__ai-fade .5s ease both',
    slide: '__ai-slide-up .5s ease both',
    slideup: '__ai-slide-up .5s ease both',
    slidedown: '__ai-slide-down .5s ease both',
    slideleft: '__ai-slide-left .5s ease both',
    slideright: '__ai-slide-right .5s ease both',
    pulse: '__ai-pulse 1.2s ease-in-out infinite',
    bounce: '__ai-bounce .8s ease-in-out infinite',
    scale: '__ai-scale .5s ease both',
    zoom: '__ai-zoom .5s ease both',
    shake: '__ai-shake .6s ease both',
    flip: '__ai-flip .6s ease both',
    rotate: '__ai-rotate .6s ease both'
  };

  function animateItem(items, animation, type, sec, hideItem, repeat) {
    if (!Array.isArray(items)) items = [items];
    items = items.filter(function (x) { return x && x.el; });
    if (!items.length) return null;

    animation = (animation || 'fade').toLowerCase().replace(/[_-]/g, '');
    type = (type || 'overlay').toLowerCase();
    sec = Number(sec);
    if (!isFinite(sec) || sec <= 0) sec = 2;
    hideItem = hideItem !== false;

    var container = create('div');
    container.el.style.cssText = type === 'lined'
      ? 'display:flex;flex-direction:row;align-items:center;gap:10px;flex-wrap:nowrap'
      : 'display:grid;grid-template-areas:"a";grid-template-columns:1fr;grid-template-rows:1fr';

    items.forEach(function (item) {
      if (type === 'lined') {
        item.el.style.flexShrink = '0';
      } else {
        item.el.style.gridArea = 'a';
        item.el.style.minWidth = '0';
      }
      item.el.style.opacity = '0';
      item.el.style.visibility = 'hidden';
      item.el.style.willChange = 'opacity, transform';
      container.push(item);
    });

    var maxCycles;
    if (repeat === true) maxCycles = Infinity;
    else if (typeof repeat === 'number' && repeat > 0) maxCycles = Math.floor(repeat);
    else maxCycles = 1;

    var currentIndex = -1;
    var cyclesDone = 0;
    var stopped = false;
    var timer = null;

    function applyEnterAnim(el) {
      el.style.animation = 'none';
      void el.offsetWidth;
      el.style.animation = __AI_ANIM_MAP[animation] || __AI_ANIM_MAP.fade;
    }

    function hideEl(el) {
      el.style.animation = 'none';
      el.style.opacity = '0';
      el.style.visibility = 'hidden';
    }

    function showEl(el) {
      el.style.visibility = 'visible';
      el.style.opacity = '1';
      applyEnterAnim(el);
    }

    function resetAll() {
      items.forEach(function (item) { hideEl(item.el); });
    }

    function step() {
      if (stopped) return;
      currentIndex++;

      if (currentIndex >= items.length) {
        cyclesDone++;
        if (cyclesDone >= maxCycles) {
          stopped = true;
          return;
        }
        currentIndex = 0;
        if (hideItem) resetAll();
      }

      var current = items[currentIndex];

      if (hideItem) {
        for (var i = 0; i < items.length; i++) {
          if (i !== currentIndex && items[i].el.style.visibility !== 'hidden') hideEl(items[i].el);
        }
      }

      showEl(current.el);

      timer = setTimeout(step, sec * 1000);
    }

    timer = setTimeout(step, 0);

    container.stop = function () {
      stopped = true;
      if (timer) clearTimeout(timer);
    };
    container.restart = function () {
      stopped = false;
      cyclesDone = 0;
      currentIndex = -1;
      resetAll();
      if (timer) clearTimeout(timer);
      timer = setTimeout(step, 0);
    };
    container.items = items;

    return container;
  }

  function apiFactory(baseUrl, headers) {
    headers = headers || {};
    function request(method, url, body) {
      var opts = { method: method, headers: {} };
      for (var h in headers) if (headers.hasOwnProperty(h)) opts.headers[h] = headers[h];
      if (!opts.headers['Content-Type']) opts.headers['Content-Type'] = 'application/json';
      if (body !== undefined) opts.body = JSON.stringify(body);
      var full = url;
      if (baseUrl && url.indexOf('http') !== 0) full = baseUrl.replace(/\/$/, '') + '/' + url.replace(/^\//, '');
      return fetch(full, opts).then(function (r) {
        if (!r.ok) throw new Error('HTTP ' + r.status);
        var ct = r.headers.get('content-type') || '';
        if (ct.indexOf('application/json') !== -1) return r.json();
        return r.text();
      });
    }
    return {
      get: function (u) { return request('GET', u); },
      post: function (u, d) { return request('POST', u, d); },
      put: function (u, d) { return request('PUT', u, d); },
      patch: function (u, d) { return request('PATCH', u, d); },
      del: function (u) { return request('DELETE', u); }
    };
  }

  function idb(name, storeName) {
    storeName = storeName || 'items';
    var dbp = new Promise(function (resolve, reject) {
      var req = indexedDB.open(name, 1);
      req.onupgradeneeded = function (e) {
        var db = e.target.result;
        if (!db.objectStoreNames.contains(storeName)) db.createObjectStore(storeName, { keyPath: 'id' });
      };
      req.onsuccess = function (e) { resolve(e.target.result); };
      req.onerror = function (e) { reject(e.target.error); };
    });
    function tx(mode) {
      return dbp.then(function (db) { return db.transaction(storeName, mode).objectStore(storeName); });
    }
    return {
      put: function (obj) { return tx('readwrite').then(function (s) { return new Promise(function (res, rej) { var r = s.put(obj); r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }); },
      get: function (id) { return tx('readonly').then(function (s) { return new Promise(function (res, rej) { var r = s.get(id); r.onsuccess = function () { res(r.result); }; r.onerror = function () { rej(r.error); }; }); }); },
      all: function () { return tx('readonly').then(function (s) { return new Promise(function (res, rej) { var r = s.getAll(); r.onsuccess = function () { res(r.result || []); }; r.onerror = function () { rej(r.error); }; }); }); },
      remove: function (id) { return tx('readwrite').then(function (s) { return new Promise(function (res, rej) { var r = s.delete(id); r.onsuccess = function () { res(); }; r.onerror = function () { rej(r.error); }; }); }); },
      clear: function () { return tx('readwrite').then(function (s) { return new Promise(function (res, rej) { var r = s.clear(); r.onsuccess = function () { res(); }; r.onerror = function () { rej(r.error); }; }); }); }
    };
  }

  function route() {
    var args = Array.prototype.slice.call(arguments);
    var opts = {};
    if (args.length && typeof args[args.length - 1] === 'object' && !(args[args.length - 1] instanceof FWNode)) opts = args.pop();
    var ids = args;
    if (!ids.length) return;
    var targets = [];
    for (var k = 0; k < ids.length; k++) {
      var el = document.getElementById(ids[k]);
      if (el) targets.push(el);
    }
    if (!targets.length) { showError('route("' + ids.join(', ') + '") — no elements found', ''); return; }
    var parent = targets[0].parentElement || document.body;
    var anim = opts.animate;
    for (var i = 0; i < parent.children.length; i++) {
      var child = parent.children[i];
      if (!child.id) continue;
      if (targets.indexOf(child) !== -1) {
        child.style.display = '';
        if (anim) applyAnim(child, anim);
      } else child.style.display = 'none';
    }
    return targets.length === 1 ? targets[0] : targets;
  }

  global.$ = $;
  global.$$ = $$;
  global.uid = uid;
  global.clamp = clamp;
  global.escape = escape;
  global.once = once;
  global.sleep = sleep;
  global.debounce = debounce;
  global.throttle = throttle;
  global.onReady = onReady;
  global.isMobile = isMobile;
  global.isDark = isDark;
  global.number = number;
  global.money = money;

  global.FWNode = FWNode;
  global.create = create;
  global.app = app;
  global.render = render;
  global.text = function (t) { return create('span', t); };
  global.button = function (t) { return create('button', t); };
  global.view = function () { return create('div'); };

  global.row = row;
  global.col = col;
  global.spacer = spacer;
  global.screen = screen;
  global.bottomBar = bottomBar;

  global.badge = badge;
  global.iconBtn = iconBtn;
  global.rating = rating;
  global.chip = chip;
  global.progressBar = progressBar;
  global.switchToggle = switchToggle;
  global.emptyState = emptyState;
  global.avatarGroup = avatarGroup;

  global.scrollX = scrollX;
  global.scrollY = scrollY;
  global.hideScroll = hideScroll;

  global.img = img;
  global.avatar = avatar;
  global.swatch = swatch;
  global.svg = svg;
  global.icons = iconList;

  global.dic = dic;
  global.findDK = findDK;
  global.findDV = findDV;

  global.state = state;
  global.list = list;

  global.modal = modal;
  global.confirm = confirm;
  global.alertBox = alertBox;
  global.sheet = sheet;
  global.tabs = tabs;
  global.chipGroup = chipGroup;
  global.page = page;

  global.longPress = longPress;
  global.onSwipe = onSwipe;

  global.animateItem = animateItem;

  global.apiFactory = apiFactory;
  global.idb = idb;

  global.route = route;

  global.defaults = defaults;
  global.styles = styles;

  global.css = css;
  global.cssReset = cssReset;

  global.toast = toast;
  global.notify = notify;
  global.store = store;
  global.theme = theme;
  global.spinner = spinner;
  global.skeleton = skeleton;
  global.copy = copy;
  global.vibrate = vibrate;
  global.share = share;
  global.animate = animate;

  global.formatTime = formatTime;
  global.formatDate = formatDate;
  global.formatDateTime = formatDateTime;
  global.formatAgo = formatAgo;

  theme.init();
})(window);