
var root = app()

function home(){
  var root = col()
  root.addClass('w-full gap-0 m-1')

  var topBadge = create('div','open to work')
  topBadge.addClass('p-3 m-1 rounded-full bg-black text-white text-center font-bold uppercase tracking-widest')

  var dot = create('div','')
  dot.addClass('w-1.5 h-1.5 bg-green-400 rounded-full')

  var topRow = row(dot, topBadge)
  topRow.addClass('gap-2 items-center')

  var h1 = create('h1','Emat')
  h1.addClass('text- font-black tracking-tight text-black leading-none mt-4')

  var h1b = create('h1','Portfolio')
  h1b.addClass('text- font-black tracking-tight text-zinc-300 leading-none ')

  var small = create('p','I am a self taught dev. I made my own js framework called Next.js Pro. I been coding for 2 years now.')
  small.addClass('text- text-zinc-600 leading-6 mt-4 max-w-')

  var btnWork = create('button','My Work')
  btnWork.addClass('px-5 py-3 bg-black text-white rounded-xl text-sm font-semibold')
  btnWork.onClick = function(){ route('project') }

  var btnAbout = create('button','About')
  btnAbout.addClass('px-5 py-3 bg-zinc-100 text-black rounded-xl text-sm font-semibold border border-zinc-200')
  btnAbout.onClick = function(){ route('overview') }

  var btnRow = row(btnWork, btnAbout)
  btnRow.addClass('gap-3 mt-5')

  var hero = col(topRow, h1, h1b, small, btnRow)
  hero.addClass('p-5')

  var line = create('div','')
  line.addClass('h-[1px] bg-zinc-200 mx-5 mt-2')

  var aboutLabel = create('div','// ABOUT')
  aboutLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-6')

  var aboutTitle = create('h2','I build beta ui that feels real.')
  aboutTitle.addClass('text- font-bold leading-8 tracking-tight px-5 mt-2 max-w-')

  var aboutText = create('p','Not that ai clean dribbble stuff. I like stuff that feels used, touched. My language lets me do app() and create() super fast. I hate boilerplate. I just want to ship.')
  aboutText.addClass('text- text-zinc-600 leading-5 px-5 mt-3 max-w-')

  var box1Num = create('div','02')
  box1Num.addClass('text- font-bold text-zinc-400')
  var box1Title = create('div','Years')
  box1Title.addClass('text- font-bold text-black mt-1')
  var box1Sub = create('div','coding non stop')
  box1Sub.addClass('text- text-zinc-500 mt-1')
  var box1 = col(box1Num, box1Title, box1Sub)
  box1.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var box2Num = create('div','30+')
  box2Num.addClass('text- font-bold text-zinc-400')
  var box2Title = create('div','Projects')
  box2Title.addClass('text- font-bold text-black mt-1')
  var box2Sub = create('div','small to big')
  box2Sub.addClass('text- text-zinc-500 mt-1')
  var box2 = col(box2Num, box2Title, box2Sub)
  box2.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var aboutBoxes = row(box1, box2)
  aboutBoxes.addClass('gap-3 px-5 mt-5')

  var skillLabel = create('div','// SKILLS')
  skillLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var skill1 = create('div','Next.js Pro - my lang')
  skill1.addClass('px-3 py-2 rounded-full bg-zinc-900 text-white text- font-medium')
  var skill2 = create('div','Tailwind')
  skill2.addClass('px-3 py-2 rounded-full bg-white border border-zinc-200 text- font-medium')
  var skill3 = create('div','JS')
  skill3.addClass('px-3 py-2 rounded-full bg-white border border-zinc-200 text- font-medium')
  var skill4 = create('div','UI Design')
  skill4.addClass('px-3 py-2 rounded-full bg-white border border-zinc-200 text- font-medium')
  var skill5 = create('div','Figma to Code')
  skill5.addClass('px-3 py-2 rounded-full bg-white border border-zinc-200 text- font-medium')
  var skill6 = create('div','Mobile First')
  skill6.addClass('px-3 py-2 rounded-full bg-white border border-zinc-200 text- font-medium')

  var skillRow1 = row(skill1, skill2, skill3)
  skillRow1.addClass('gap-2 flex-wrap')
  var skillRow2 = row(skill4, skill5, skill6)
  skillRow2.addClass('gap-2 flex-wrap mt-2')
  var skills = col(skillRow1, skillRow2)
  skills.addClass('px-5 mt-3')

  var workLabel = create('div','// SELECTED WORK')
  workLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var proj1Title = create('div','Emat OS - Portfolio Engine')
  proj1Title.addClass('text- font-bold text-black')
  var proj1Desc = create('div','My own framework landing page')
  proj1Desc.addClass('text- text-zinc-500 mt-1')
  var proj1Tag = create('div','2024')
  proj1Tag.addClass('text- font-bold text-zinc-400 mt-3')
  var proj1 = col(proj1Title, proj1Desc, proj1Tag)
  proj1.addClass('p-4 rounded-2xl bg-white border border-zinc-200')

  var proj2Title = create('div','Header + Bottom Nav')
  proj2Title.addClass('text- font-bold text-black')
  var proj2Desc = create('div','Beta navigation system')
  proj2Desc.addClass('text- text-zinc-500 mt-1')
  var proj2Tag = create('div','2025')
  proj2Tag.addClass('text- font-bold text-zinc-400 mt-3')
  var proj2 = col(proj2Title, proj2Desc, proj2Tag)
  proj2.addClass('p-4 rounded-2xl bg-zinc-900 text-white')

  var proj3Title = create('div','Route System')
  proj3Title.addClass('text- font-bold text-black')
  var proj3Desc = create('div','SPA routing like next.js')
  proj3Desc.addClass('text- text-zinc-500 mt-1')
  var proj3Tag = create('div','2025')
  proj3Tag.addClass('text- font-bold text-zinc-400 mt-3')
  var proj3 = col(proj3Title, proj3Desc, proj3Tag)
  proj3.addClass('p-4 rounded-2xl bg-white border border-zinc-200')

  var projCol = col(proj1, proj2, proj3)
  projCol.addClass('gap-3 px-5 mt-3')

  var moreBtn = create('button','See all projects ->')
  moreBtn.addClass('mx-5 mt-4 py-3 rounded-xl border border-zinc-900 text-sm font-bold')
  moreBtn.onClick = function(){ route('project') }

  var quote = create('p','"Emat code like he mad at css. But it works. It always works."')
  quote.addClass('text- font-medium italic leading-6 px-5 mt-8 text-zinc-700')

  var quoteName = create('div','// my friend')
  quoteName.addClass('text- text-zinc-400 px-5 mt-2')

  var contactBoxTitle = create('div','Need a website?')
  contactBoxTitle.addClass('text- font-black text-white')
  var contactBoxSub = create('div','I can build it in my language in like 1 day. Fast and cheap but beta quality.')
  contactBoxSub.addClass('text- text-zinc-300 mt-2 leading-5')
  var contactBtn = create('button','Contact me')
  contactBtn.addClass('mt-4 px-5 py-2.5 bg-white text-black rounded-xl text-sm font-bold')
  contactBtn.onClick = function(){ route('user') }
  var contactBox = col(contactBoxTitle, contactBoxSub, contactBtn)
  contactBox.addClass('m-5 p-5 rounded- bg-black')

  var bottomSpace = create('div','')
  bottomSpace.addClass('h-[120px]')

  root.push(topBadge)
  root.push(topRow)
  root.push(h1)
  root.push(h1b)
  root.push(small)
  root.push(btnRow)
  root.push(line)
  root.push(aboutLabel)
  root.push(aboutTitle)
  root.push(aboutText)
  root.push(aboutBoxes)
  root.push(skillLabel)
  root.push(skills)
  root.push(workLabel)
  root.push(projCol)
  root.push(moreBtn)
  root.push(quote)
  root.push(quoteName)
  root.push(contactBox)
  root.push(bottomSpace)

  var d = col(root)
  d.id = 'home'
  d.addClass('w-full bg-[#fcfcfc]')
  return d
}


function overview(){
  var wrap = col()
  wrap.addClass('w-full gap-0 bg-[#fcfcfc]')

  var label1 = create('div','// ABOUT ME')
  label1.addClass('text- font-bold tracking-widest text-zinc-400 px-5 pt-6')

  var title1 = create('h1','I am not a senior.')
  title1.addClass('text- font-black leading-[0.95] tracking-tight px-5 mt-3')

  var title1b = create('h1','I just ship.')
  title1b.addClass('text- font-black leading-[0.95] tracking-tight px-5 text-zinc-300')

  var p1 = create('p','My name is Emmanuel Omidiora. I am 15. I started coding because I wanted to make my own language. Not to get a job just kidding 😂. I just wanted to see if I can do app() and it actually works.')
  p1.addClass('text- leading-6 text-zinc-600 px-5 mt-5 max-w-')

  var p2 = create('p','I failed like 4 times before. My first framework was trash. Second was okay. This one Next-js Pro is the one that finally feels right. It is like react but simpler for me.')
  p2.addClass('text- leading-6 text-zinc-600 px-5 mt-4 max-w-')

  var imgBox = create('div','[ image here ]')
  imgBox.addClass('mx-5 mt-6 h-[220px] rounded- bg-zinc-900 text-white flex items-center justify-center text- font-bold tracking-widest')

  var info1k = create('div','LOCATION')
  info1k.addClass('text- font-bold tracking-widest text-zinc-400')
  var info1v = create('div','Nigeria, remote')
  info1v.addClass('text- font-semibold text-black mt-1')
  var info1 = col(info1k, info1v)
  info1.addClass('w-[50%]')

  var info2k = create('div','EXPERIENCE')
  info2k.addClass('text- font-bold tracking-widest text-zinc-400')
  var info2v = create('div','2 years self taught')
  info2v.addClass('text- font-semibold text-black mt-1')
  var info2 = col(info2k, info2v)
  info2.addClass('w-[50%]')

  var infoRow1 = row(info1, info2)
  infoRow1.addClass('px-5 mt-6 gap-3')

  var info3k = create('div','FOCUS')
  info3k.addClass('text- font-bold tracking-widest text-zinc-400')
  var info3v = create('div','Frontend + Language Design')
  info3v.addClass('text- font-semibold text-black mt-1')
  var info3 = col(info3k, info3v)
  info3.addClass('w-[50%]')

  var info4k = create('div','CURRENT')
  info4k.addClass('text- font-bold tracking-widest text-zinc-400')
  var info4v = create('div','Building Emat OS v2')
  info4v.addClass('text- font-semibold text-black mt-1')
  var info4 = col(info4k, info4v)
  info4.addClass('w-[50%]')

  var infoRow2 = row(info3, info4)
  infoRow2.addClass('px-5 mt-4 gap-3')

  var divi = create('div','')
  divi.addClass('h-[1px] bg-zinc-200 mx-5 mt-8')

  var label2 = create('div','// HOW I WORK')
  label2.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var step1n = create('div','01')
  step1n.addClass('text- font-black text-zinc-300')
  var step1t = create('div','Idea in head')
  step1t.addClass('text- font-bold text-black mt-1')
  var step1d = create('div','I dont use figma much. I just think of the layout and open code. Sometimes I sketch on paper with pen.')
  step1d.addClass('text- text-zinc-500 leading-5 mt-2')
  var step1 = col(step1n, step1t, step1d)
  step1.addClass('p-4 rounded-2xl bg-white border border-zinc-200')

  var step2n = create('div','02')
  step2n.addClass('text- font-black text-zinc-300')
  var step2t = create('div','Code fast')
  step2t.addClass('text- font-bold text-black mt-1')
  var step2d = create('div','I write html structure with create() and col() row(). Then I add class. I dont perfect it first time.')
  step2d.addClass('text- text-zinc-500 leading-5 mt-2')
  var step2 = col(step2n, step2t, step2d)
  step2.addClass('p-4 rounded-2xl bg-white border border-zinc-200')

  var step3n = create('div','03')
  step3n.addClass('text- font-black text-zinc-300')
  var step3t = create('div','Break and fix')
  step3t.addClass('text- font-bold text-black mt-1')
  var step3d = create('div','I test on my phone. If it breaks I fix. I dont use devtools that much, just my phone browser.')
  step3d.addClass('text- text-zinc-500 leading-5 mt-2')
  var step3 = col(step3n, step3t, step3d)
  step3.addClass('p-4 rounded-2xl bg-white border border-zinc-200')

  var steps = col(step1, step2, step3)
  steps.addClass('gap-3 px-5 mt-4')

  var label3 = create('div','// TOOLS I ACTUALLY USE')
  label3.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var tool1 = create('div','VS Code')
  tool1.addClass('px-3 py-2 rounded-xl bg-black text-white text- font-bold')
  var tool2 = create('div','My Phone')
  tool2.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text- font-bold')
  var tool3 = create('div','Chrome')
  tool3.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text- font-bold')
  var tool4 = create('div','Pen + Paper')
  tool4.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text- font-bold')
  var tool5 = create('div','Tailwind CDN')
  tool5.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text- font-bold')
  var tool6 = create('div','GitHub')
  tool6.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text- font-bold')

  var toolR1 = row(tool1, tool2, tool3)
  toolR1.addClass('gap-2 flex-wrap')
  var toolR2 = row(tool4, tool5, tool6)
  toolR2.addClass('gap-2 flex-wrap mt-2')
  var tools = col(toolR1, toolR2)
  tools.addClass('px-5 mt-3')

  var label4 = create('div','// RANDOM FACTS')
  label4.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var fact1 = create('div','- I type with 2 fingers mostly')
  fact1.addClass('text- text-zinc-600 px-5 mt-2')
  var fact2 = create('div','- I learned css from copying instagram')
  fact2.addClass('text- text-zinc-600 px-5 mt-2')
  var fact3 = create('div','- I hate semicolons but I use them')
  fact3.addClass('text- text-zinc-600 px-5 mt-2')
  var fact4 = create('div','- I want to build a phone OS one day')
  fact4.addClass('text- text-zinc-600 px-5 mt-2')
  var fact5 = create('div','- My code is messy but it works')
  fact5.addClass('text- text-zinc-600 px-5 mt-2')

  var facts = col(fact1, fact2, fact3, fact4, fact5)
  facts.addClass('gap-1')

  var ctaTitle = create('div','Lets work together?')
  ctaTitle.addClass('text- font-black text-white')
  var ctaSub = create('div','I am free most times after 5pm. Just dm.')
  ctaSub.addClass('text- text-zinc-400 mt-2')
  var ctaBtn = create('button','Go to Projects')
  ctaBtn.addClass('mt-4 px-5 py-3 bg-white text-black rounded-xl text-sm font-bold w-fit')
  ctaBtn.onClick = function(){ route('project') }
  var ctaBox = col(ctaTitle, ctaSub, ctaBtn)
  ctaBox.addClass('m-5 p-6 rounded- bg-zinc-900 mt-8')

  var space = create('div','')
  space.addClass('h-[120px]')

  wrap.push(label1)
  wrap.push(title1)
  wrap.push(title1b)
  wrap.push(p1)
  wrap.push(p2)
  wrap.push(imgBox)
  wrap.push(infoRow1)
  wrap.push(infoRow2)
  wrap.push(divi)
  wrap.push(label2)
  wrap.push(steps)
  wrap.push(label3)
  wrap.push(tools)
  wrap.push(label4)
  wrap.push(facts)
  wrap.push(ctaBox)
  wrap.push(space)

  var d = col(wrap)
  d.id = 'overview'
  return d
}

function project(){
  var links = [
    { label: 'GitHub', url: 'https://github.com/emat' },
    { label: 'Live Demo', url: 'https://emat.dev' },
    { label: 'Docs', url: 'https://docs.emat.dev' },
    { label: 'Figma', url: 'https://figma.com/@emat' },
    { label: 'Twitter', url: 'https://x.com/emat_dev' },
    { label: 'Email', url: 'mailto:emat@pro.dev' }
  ]

  var demos = [
    { title: 'Portfolio Engine', desc: 'My own framework landing page', url: '#', tag: 'FRAMEWORK' },
    { title: 'Header + Bottom Nav', desc: 'Beta navigation system', url: '#', tag: 'UI SYSTEM' },
    { title: 'Route System', desc: 'SPA routing like next.js', url: '#', tag: 'ROUTER' },
    { title: 'Game Engine', desc: '2D game framework in JS', url: '#', tag: 'GAMES' },
    { title: 'AI NPC', desc: 'NPCs that learn from play', url: '#', tag: 'AI' },
    { title: 'Coffee Shop', desc: 'Small store page', url: '#', tag: 'COMMERCE' }
  ]

  var wrap = col()
  wrap.addClass('w-full bg-[#fcfcfc] gap-0')

  var label = create('div','// PROJECTS')
  label.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 pt-6')

  var title = create('h1','Things I built')
  title.addClass('text-5xl font-black leading-[0.9] tracking-tight px-5 mt-3')

  var titleB = create('h1','with my own hands.')
  titleB.addClass('text-5xl font-black leading-[0.9] tracking-tight px-5 text-zinc-300')

  var sub = create('p','Everything here I built from scratch. No react, no next.js, no vue. My own framework. My own rules. Each one taught me something I could not learn from tutorials.')
  sub.addClass('text-base leading-6 text-zinc-600 px-5 mt-5 max-w-md')

  var statsRow = row(
    col(
      create('div','34').addClass('text-3xl font-black text-black'),
      create('div','PROJECTS').addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-1')
    ).addClass('items-start w-1/3'),
    col(
      create('div','12k').addClass('text-3xl font-black text-black'),
      create('div','LINES').addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-1')
    ).addClass('items-start w-1/3'),
    col(
      create('div','2y').addClass('text-3xl font-black text-black'),
      create('div','CODING').addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-1')
    ).addClass('items-start w-1/3')
  )
  statsRow.addClass('px-5 mt-8')

  var linksLabel = create('div','// MY LINKS')
  linksLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var linksList = col()
  linksList.addClass('gap-2 px-5 mt-3')
  for (var i = 0; i < links.length; i++){
    let lk = links[i]
    let lkName = create('div', lk.label)
    lkName.addClass('text-base font-semibold text-black')
    let lkUrl = create('div', lk.url)
    lkUrl.addClass('text-xs text-zinc-500 mt-1')
    let lkLeft = col(lkName, lkUrl)
    let lkArrow = create('div','↗')
    lkArrow.addClass('text-xl text-zinc-400')
    let lkRow = row(lkLeft, spacer(), lkArrow)
    lkRow.addClass('p-4 rounded-2xl bg-white border border-zinc-200 items-center active:scale-[0.99] transition')
    lkRow.onClick = function(){
      if (typeof window !== 'undefined') window.open(lk.url, '_blank')
    }
    linksList.push(lkRow)
  }

  var featuredLabel = create('div','// FEATURED')
  featuredLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var featureTag = create('div','BEST WORK')
  featureTag.addClass('inline-block px-3 py-1 rounded-full bg-black text-white text-xs font-bold tracking-widest mt-3 mx-5')

  var featureTitle = create('h2','Emat OS')
  featureTitle.addClass('text-4xl font-black leading-none tracking-tight px-5 mt-3')

  var featureSub = create('div','Portfolio Engine + Framework')
  featureSub.addClass('text-sm font-bold tracking-widest text-violet-600 px-5 mt-2 uppercase')

  var featureDesc = create('p','My own framework running on my own app. Everything you see on this portfolio is built with it. app(), create(), col(), row() - no react. It ships faster than anything I have used. I wrote it in 4 failed attempts before it finally clicked.')
  featureDesc.addClass('text-base leading-6 text-zinc-600 px-5 mt-4 max-w-md')

  var featureImg = create('div')
  featureImg.addClass('mx-5 mt-6 h-56 rounded-3xl bg-zinc-900 overflow-hidden flex items-center justify-center relative')
  var featureImgText = create('div','EMAT OS v2')
  featureImgText.addClass('text-white text-2xl font-black tracking-widest opacity-30')
  var featureImgBadge = create('div','LIVE')
  featureImgBadge.addClass('absolute top-4 right-4 px-3 py-1 rounded-full bg-green-500 text-white text-xs font-black tracking-widest')
  featureImg.push(featureImgText, featureImgBadge)

  var feat1 = create('div','4 attempts')
  feat1.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text-sm font-bold')
  var feat2 = create('div','JS only')
  feat2.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text-sm font-bold')
  var feat3 = create('div','60fps')
  feat3.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text-sm font-bold')
  var feat4 = create('div','12kb core')
  feat4.addClass('px-3 py-2 rounded-xl bg-white border border-zinc-200 text-sm font-bold')
  var featRow = row(feat1, feat2, feat3, feat4)
  featRow.addClass('gap-2 px-5 mt-4 flex-wrap')

  var featureBtn = create('button','Open Live Demo ->')
  featureBtn.addClass('mx-5 mt-5 py-3.5 rounded-xl bg-black text-white text-sm font-bold w-[calc(100%-40px)]')
  featureBtn.onClick = function(){ toast('Opening demo...', 'success') }

  var featureBtn2 = create('button','View Source')
  featureBtn2.addClass('mx-5 mt-2 py-3.5 rounded-xl bg-white border border-zinc-200 text-black text-sm font-bold w-[calc(100%-40px)]')

  var gridLabel = create('div','// ALL PROJECTS')
  gridLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var gridTitle = create('h2','Every build counts.')
  gridTitle.addClass('text-2xl font-black tracking-tight px-5 mt-2')

  var gridSub = create('p','Small or big. Ugly or clean. Each one made me better.')
  gridSub.addClass('text-sm text-zinc-500 px-5 mt-2')

  var filters = ['All','Framework','UI','Games','AI']
  var filterRow = row()
  filterRow.addClass('gap-2 px-5 mt-4 flex-wrap')
  for (var f = 0; f < filters.length; f++){
    let chip = create('div', filters[f])
    chip.addClass('px-4 py-2 rounded-full bg-white border border-zinc-200 text-xs font-bold tracking-wide uppercase')
    filterRow.push(chip)
  }

  var projectList = col()
  projectList.addClass('gap-3 px-5 mt-5')

  for (var p = 0; p < demos.length; p++){
    let dm = demos[p]
    let pCard = col()
    pCard.addClass('p-5 rounded-3xl bg-white border border-zinc-200')

    let pTop = row()
    pTop.addClass('items-center justify-between')

    let pIndex = create('div', (p + 1 < 10 ? '0' : '') + (p + 1))
    pIndex.addClass('text-4xl font-black text-zinc-200 leading-none')

    let pTag = create('div', dm.tag)
    pTag.addClass('px-3 py-1 rounded-full bg-zinc-100 border border-zinc-200 text-xs font-black tracking-widest text-zinc-600')

    pTop.push(pIndex, pTag)

    let pTitle = create('div', dm.title)
    pTitle.addClass('text-xl font-black text-black mt-4 tracking-tight')

    let pDesc = create('div', dm.desc)
    pDesc.addClass('text-sm text-zinc-500 mt-2 leading-5')

    let pStack = row()
    pStack.addClass('gap-2 mt-4 flex-wrap')
    let stk = ['JS','CSS','Framework']
    for (var s = 0; s < stk.length; s++){
      let sTag = create('div', stk[s])
      sTag.addClass('px-2 py-1 rounded-md bg-zinc-100 text-xs font-bold text-zinc-600')
      pStack.push(sTag)
    }

    let pBtn = create('button','View ->')
    pBtn.addClass('mt-4 px-4 py-2.5 rounded-xl bg-black text-white text-xs font-bold w-fit')
    pBtn.onClick = function(){ toast('Opening ' + dm.title, 'success') }

    pCard.push(pTop, pTitle, pDesc, pStack, pBtn)
    projectList.push(pCard)
  }

  var demoLabel = create('div','// LIVE DEMOS')
  demoLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var demoTitle = create('h2','Try them now')
  demoTitle.addClass('text-2xl font-black tracking-tight px-5 mt-2')

  var demoSub = create('p','Real code, running right here.')
  demoSub.addClass('text-sm text-zinc-500 px-5 mt-2')

  var demoBox = create('div')
  demoBox.addClass('mx-5 mt-5 p-4 rounded-3xl bg-zinc-900 border border-zinc-800 relative overflow-hidden')
  demoBox.el.style.minHeight = '280px'

  var demoHeader = row()
  demoHeader.addClass('items-center gap-2')

  var demoDot1 = create('div','')
  demoDot1.addClass('w-3 h-3 rounded-full bg-red-500')
  var demoDot2 = create('div','')
  demoDot2.addClass('w-3 h-3 rounded-full bg-amber-400')
  var demoDot3 = create('div','')
  demoDot3.addClass('w-3 h-3 rounded-full bg-green-500')

  var demoUrl = create('div','emat://demo/portfolio')
  demoUrl.addClass('ml-3 text-xs text-zinc-500 font-mono')

  demoHeader.push(demoDot1, demoDot2, demoDot3, demoUrl)

  var demoPreview = col()
  demoPreview.addClass('mt-5 gap-2')

  var dPreviewBar1 = create('div','')
  dPreviewBar1.addClass('h-3 w-32 rounded-full bg-zinc-700')
  var dPreviewBar2 = create('div','')
  dPreviewBar2.addClass('h-2 w-48 rounded-full bg-zinc-800')
  var dPreviewBar3 = create('div','')
  dPreviewBar3.addClass('h-2 w-40 rounded-full bg-zinc-800')

  var dPreviewCard = create('div','')
  dPreviewCard.addClass('mt-3 h-24 rounded-2xl bg-zinc-800 border border-zinc-700')

  demoPreview.push(dPreviewBar1, dPreviewBar2, dPreviewBar3, dPreviewCard)

  var demoRunBtn = create('button','Run Demo')
  demoRunBtn.addClass('mt-4 px-4 py-2 rounded-lg bg-green-500 text-white text-xs font-bold')

  demoBox.push(demoHeader, demoPreview, demoRunBtn)

  var codeLabel = create('div','// SAMPLE CODE')
  codeLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var codeTitle = create('h2','How it looks')
  codeTitle.addClass('text-2xl font-black tracking-tight px-5 mt-2')

  var codeBlock = create('div','app()\n  .col()\n  .style("p-5 gap-3")\n  .push(\n    create("h1", "Hello"),\n    create("p", "Built with my own tools"),\n    create("button", "Click me")\n  )\n  .done()')
  codeBlock.addClass('mx-5 mt-4 p-4 rounded-2xl bg-zinc-900 text-zinc-100 text-xs leading-5 font-mono whitespace-pre-line')

  var codeBlock2 = create('div','var root = app()\nvar card = col()\ncard.addClass("p-5 bg-white rounded-2xl")\ncard.push(create("h1", "Emat"))\nroot.push(card)')
  codeBlock2.addClass('mx-5 mt-3 p-4 rounded-2xl bg-zinc-900 text-zinc-100 text-xs leading-5 font-mono whitespace-pre-line')

  var codeBlock3 = create('div','route("home")\nroute("user")\nroute("shop")')
  codeBlock3.addClass('mx-5 mt-3 p-4 rounded-2xl bg-zinc-900 text-zinc-100 text-xs leading-5 font-mono whitespace-pre-line')

  var processLabel = create('div','// PROCESS')
  processLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var processTitle = create('h2','How I ship')
  processTitle.addClass('text-2xl font-black tracking-tight px-5 mt-2')

  var s1n = create('div','01')
  s1n.addClass('text-3xl font-black text-zinc-200 leading-none')
  var s1t = create('div','Think')
  s1t.addClass('text-lg font-bold text-black mt-2')
  var s1d = create('div','I picture the whole screen in my head before touching code. Layout first. Colors after.')
  s1d.addClass('text-sm text-zinc-500 leading-5 mt-2')
  var s1 = col(s1n, s1t, s1d)
  s1.addClass('p-5 rounded-2xl bg-white border border-zinc-200')

  var s2n = create('div','02')
  s2n.addClass('text-3xl font-black text-zinc-200 leading-none')
  var s2t = create('div','Build')
  s2t.addClass('text-lg font-bold text-black mt-2')
  var s2d = create('div','app() and go. col() then row(). I do not design in figma. I design in the browser.')
  s2d.addClass('text-sm text-zinc-500 leading-5 mt-2')
  var s2 = col(s2n, s2t, s2d)
  s2.addClass('p-5 rounded-2xl bg-white border border-zinc-200')

  var s3n = create('div','03')
  s3n.addClass('text-3xl font-black text-zinc-200 leading-none')
  var s3t = create('div','Break')
  s3t.addClass('text-lg font-bold text-black mt-2')
  var s3d = create('div','I test on my phone. Everything breaks. I fix. I test again. Until it feels real.')
  s3d.addClass('text-sm text-zinc-500 leading-5 mt-2')
  var s3 = col(s3n, s3t, s3d)
  s3.addClass('p-5 rounded-2xl bg-white border border-zinc-200')

  var s4n = create('div','04')
  s4n.addClass('text-3xl font-black text-zinc-200 leading-none')
  var s4t = create('div','Ship')
  s4t.addClass('text-lg font-bold text-black mt-2')
  var s4d = create('div','Push to github. Export apk. Send to friends. Read the chaos. Repeat.')
  s4d.addClass('text-sm text-zinc-500 leading-5 mt-2')
  var s4 = col(s4n, s4t, s4d)
  s4.addClass('p-5 rounded-2xl bg-white border border-zinc-200')

  var processCol = col(s1, s2, s3, s4)
  processCol.addClass('gap-3 px-5 mt-4')

  var numbersLabel = create('div','// BY THE NUMBERS')
  numbersLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var n1v = create('div','34')
  n1v.addClass('text-4xl font-black text-black leading-none')
  var n1l = create('div','Projects shipped')
  n1l.addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-2')
  var n1 = col(n1v, n1l)
  n1.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var n2v = create('div','4')
  n2v.addClass('text-4xl font-black text-black leading-none')
  var n2l = create('div','Failed attempts')
  n2l.addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-2')
  var n2 = col(n2v, n2l)
  n2.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var nRow1 = row(n1, n2)
  nRow1.addClass('gap-3 px-5 mt-3')

  var n3v = create('div','2y')
  n3v.addClass('text-4xl font-black text-black leading-none')
  var n3l = create('div','Non stop coding')
  n3l.addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-2')
  var n3 = col(n3v, n3l)
  n3.addClass('p-4 rounded-2xl bg-black w-[48%]')
  n3.children
  var n3val = n3.el.firstChild
  if (n3val) n3val.style.color = '#fff'
  var n3lbl = n3.el.children[1]
  if (n3lbl) n3lbl.style.color = '#a1a1aa'

  var n4v = create('div','12k')
  n4v.addClass('text-4xl font-black text-black leading-none')
  var n4l = create('div','Lines of code')
  n4l.addClass('text-xs text-zinc-400 font-bold uppercase tracking-widest mt-2')
  var n4 = col(n4v, n4l)
  n4.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var nRow2 = row(n3, n4)
  nRow2.addClass('gap-3 px-5 mt-3')

  var stackLabel = create('div','// TOOLS & TECH')
  stackLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var tools = ['Next.js Pro','Tailwind','JavaScript','HTML','CSS','Git','GitHub','VS Code','Chrome DevTools','Figma','CapCut','Termux']
  var toolsWrap = row()
  toolsWrap.addClass('gap-2 px-5 mt-3 flex-wrap')
  for (var t = 0; t < tools.length; t++){
    let tt = create('div', tools[t])
    tt.addClass('px-3 py-2 rounded-full bg-white border border-zinc-200 text-xs font-bold text-zinc-700')
    toolsWrap.push(tt)
  }

  var quoteLabel = create('div','// WHAT I LEARNED')
  quoteLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var q1 = create('p','"Nobody is coming to save your project. If it is broken, you open it, look, and fix. Google is free. Time is not."')
  q1.addClass('text-base italic leading-6 text-zinc-700 px-5 mt-3 max-w-md')

  var q2 = create('p','"Tutorials teach you how. Only shipping teaches you why."')
  q2.addClass('text-base italic leading-6 text-zinc-700 px-5 mt-4 max-w-md')

  var q3 = create('p','"If you cannot explain your code to your grandma, you do not understand it yet."')
  q3.addClass('text-base italic leading-6 text-zinc-700 px-5 mt-4 max-w-md')

  var ctaLabel = create('div','// WANT ONE?')
  ctaLabel.addClass('text-sm font-bold tracking-widest text-zinc-500 px-6 mt-10')

  var ctaTitle = create('div','I build fast.')
  ctaTitle.addClass('text-3xl font-black text-white leading-none mt-3')
  var ctaTitleB = create('div','Real fast.')
  ctaTitleB.addClass('text-3xl font-black text-white leading-none text-violet-300')

  var ctaSub = create('div','Simple landing, portfolio, small app. 1 day. My language. My tools. Cheap and beta quality but it works.')
  ctaSub.addClass('text-sm text-zinc-400 mt-3 leading-5')

  var ctaBtn = create('button','Start a project')
  ctaBtn.addClass('mt-5 px-5 py-3 bg-white text-black rounded-xl text-sm font-bold w-fit')
  ctaBtn.onClick = function(){ route('user') }

  var ctaBtn2 = create('button','See pricing')
  ctaBtn2.addClass('mt-2 px-5 py-3 border border-zinc-700 text-white rounded-xl text-sm font-bold w-fit')
  ctaBtn2.onClick = function(){ route('shop') }

  var ctaBox = col(ctaLabel, ctaTitle, ctaTitleB, ctaSub, ctaBtn, ctaBtn2)
  ctaBox.addClass('m-5 p-6 rounded-3xl bg-zinc-900 mt-8')

  var openSourceLabel = create('div','// OPEN SOURCE')
  openSourceLabel.addClass('text-sm font-bold tracking-widest text-zinc-400 px-5 mt-10')

  var osTitle = create('h2','Free. Forever.')
  osTitle.addClass('text-2xl font-black tracking-tight px-5 mt-2')

  var osDesc = create('p','Every framework I build is open source. No ads, no tracking, no paywall. If you learn something, pass it on.')
  osDesc.addClass('text-sm leading-5 text-zinc-600 px-5 mt-3')

  var osList = col()
  osList.addClass('gap-2 px-5 mt-4')
  var osItems = ['Next.js Pro - UI framework','Emat2D - Game engine','Route System','Icon Pack']
  for (var o = 0; o < osItems.length; o++){
    let oi = create('div', osItems[o])
    oi.addClass('p-3 rounded-xl bg-white border border-zinc-200 text-sm font-semibold text-black')
    osList.push(oi)
  }

  var foot = create('div','Built with Next.js Pro. No react. No next.js. All hand made.')
  foot.addClass('text-xs text-zinc-400 text-center px-5 mt-10 leading-5')

  var space = create('div','')
  space.addClass('h-[140px]')

  wrap.push(label)
  wrap.push(title)
  wrap.push(titleB)
  wrap.push(sub)
  wrap.push(statsRow)
  wrap.push(linksLabel)
  wrap.push(linksList)
  wrap.push(featuredLabel)
  wrap.push(featureTag)
  wrap.push(featureTitle)
  wrap.push(featureSub)
  wrap.push(featureDesc)
  wrap.push(featureImg)
  wrap.push(featRow)
  wrap.push(featureBtn)
  wrap.push(featureBtn2)
  wrap.push(gridLabel)
  wrap.push(gridTitle)
  wrap.push(gridSub)
  wrap.push(filterRow)
  wrap.push(projectList)
  wrap.push(demoLabel)
  wrap.push(demoTitle)
  wrap.push(demoSub)
  wrap.push(demoBox)
  wrap.push(codeLabel)
  wrap.push(codeTitle)
  wrap.push(codeBlock)
  wrap.push(codeBlock2)
  wrap.push(codeBlock3)
  wrap.push(processLabel)
  wrap.push(processTitle)
  wrap.push(processCol)
  wrap.push(numbersLabel)
  wrap.push(nRow1)
  wrap.push(nRow2)
  wrap.push(stackLabel)
  wrap.push(toolsWrap)
  wrap.push(quoteLabel)
  wrap.push(q1)
  wrap.push(q2)
  wrap.push(q3)
  wrap.push(ctaBox)
  wrap.push(openSourceLabel)
  wrap.push(osTitle)
  wrap.push(osDesc)
  wrap.push(osList)
  wrap.push(foot)
  wrap.push(space)

  var d = col(wrap)
  d.id = 'project'
  return d
}


function shop(){
  var wrap = col()
  wrap.addClass('w-full bg-[#fcfcfc] gap-0')

  var label = create('div','// SUPPORT ME')
  label.addClass('text- font-bold tracking-widest text-zinc-400 px-5 pt-6')

  var title = create('h1','Buy me a coffee')
  title.addClass('text- font-black tracking-tight leading-[0.9] px-5 mt-3')

  var sub = create('p','I build free stuff. Framework, game engine, all free. If you like my work you can support me. Even small helps me buy data and keep building.')
  sub.addClass('text- leading-5 text-zinc-600 px-5 mt-4 max-w-')

  var coffeeIcon = create('div','☕')
  coffeeIcon.addClass('text-')

  var coffeeTitle = create('div','Buy me a coffee')
  coffeeTitle.addClass('text- font-black text-black mt-2')

  var coffeeDesc = create('div','One coffee = one night of coding')
  coffeeDesc.addClass('text- text-zinc-500 mt-1')

  var coffeeBtn1 = create('button','₦1000 - Coffee')
  coffeeBtn1.addClass('w-full py-3 rounded-xl bg-white border border-zinc-200 text- font-bold mt-3')

  var coffeeBtn2 = create('button','₦3000 - Lunch + Data')
  coffeeBtn2.addClass('w-full py-3 rounded-xl bg-black text-white text- font-bold mt-2')

  var coffeeBtn3 = create('button','₦10000 - Big Support ❤️')
  coffeeBtn3.addClass('w-full py-3 rounded-xl bg-violet-600 text-white text- font-bold mt-2')

  var coffeeBox = col(coffeeIcon, coffeeTitle, coffeeDesc, coffeeBtn1, coffeeBtn2, coffeeBtn3)
  coffeeBox.addClass('p-5 rounded- bg-white border border-zinc-200 mx-5 mt-6')

  var accLabel = create('div','// DIRECT TRANSFER')
  accLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var accBoxTitle = create('div','SmartCash Account')
  accBoxTitle.addClass('text- font-bold tracking-widest text-zinc-400 uppercase')

  var accNum = create('div','09126396856')
  accNum.addClass('text- font-black tracking-tight text-black mt-2')

  var accNameLabel = create('div','Account Name')
  accNameLabel.addClass('text- font-bold text-zinc-400 uppercase mt-4 tracking-wide')

  var accName = create('div','Omidiora Rachel')
  accName.addClass('text- font-bold text-black mt-1')

  var accBank = create('div','SmartCash • by Airtel')
  accBank.addClass('text- text-zinc-500 mt-1')

  var copyBtn = create('button','Copy Number')
  copyBtn.addClass('w-full py-3 rounded-xl bg-black text-white text- font-bold mt-5')
  copyBtn.onClick = function(){
    navigator.clipboard.writeText('09126396856')
    copyBtn.textContent = 'Copied!'
  }

  var accBox = col(accBoxTitle, accNum, accNameLabel, accName, accBank, copyBtn)
  accBox.addClass('p-6 rounded- bg-[#fffbeb] border border-amber-200 mx-5 mt-3')

  var otherLabel = create('div','// OTHER WAYS')
  otherLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var other1Title = create('div','PayPal')
  other1Title.addClass('text- font-bold text-black')
  var other1Desc = create('div','emat@pro.dev (coming soon)')
  other1Desc.addClass('text- text-zinc-500 mt-1')
  var other1 = col(other1Title, other1Desc)
  other1.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var other2Title = create('div','Crypto')
  other2Title.addClass('text- font-bold text-black')
  var other2Desc = create('div','USDT BEP20 soon')
  other2Desc.addClass('text- text-zinc-500 mt-1')
  var other2 = col(other2Title, other2Desc)
  other2.addClass('p-4 rounded-2xl bg-white border border-zinc-200 w-[48%]')

  var otherRow = row(other1, other2)
  otherRow.addClass('gap-2 px-5 mt-3')

  var whyLabel = create('div','// WHY SUPPORT?')
  whyLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var why1 = create('div','- Data is expensive in NG, I use like 100gb per month')
  why1.addClass('text- text-zinc-600 px-5 mt-2')
  var why2 = create('div','- I want to buy a better phone to test games')
  why2.addClass('text- text-zinc-600 px-5 mt-2')
  var why3 = create('div','- I build open source, no ads, no tracking')
  why3.addClass('text- text-zinc-600 px-5 mt-2')
  var why4 = create('div','- Your name will be in my game credits')
  why4.addClass('text- text-zinc-600 px-5 mt-2')

  var whyCol = col(why1, why2, why3, why4)
  whyCol.addClass('gap-1')

  var thanksBox = create('div','Thanks for reading ❤️\nEven if you dont pay, just sharing my portfolio helps a lot.')
  thanksBox.addClass('mx-5 mt-8 p-5 rounded-2xl bg-zinc-900 text-white text- leading-5 whitespace-pre-line')

  var space = create('div','')
  space.addClass('h-[130px]')

  wrap.push(label)
  wrap.push(title)
  wrap.push(sub)
  wrap.push(coffeeBox)
  wrap.push(accLabel)
  wrap.push(accBox)
  wrap.push(otherLabel)
  wrap.push(otherRow)
  wrap.push(whyLabel)
  wrap.push(whyCol)
  wrap.push(thanksBox)
  wrap.push(space)

  var d = col(wrap)
  d.id = 'shop'
  return d
}

function fav(){
  var wrap = col()
  wrap.addClass('w-full bg-[#fcfcfc] gap-0')

  var label = create('div','// FAVORITES & ME')
  label.addClass('text- font-bold tracking-widest text-zinc-400 px-5 pt-6')

  var title = create('h1','What I love to do')
  title.addClass('text- font-black leading-[0.9] tracking-tight px-5 mt-3 max-w-')

  var sub = create('p','Outside coding I am just a normal guy. I scroll, I play, I think about future. Here are my fav things.')
  sub.addClass('text- leading-5 text-zinc-600 px-5 mt-3 max-w-')

  var card1Icon = create('div','fb')
  card1Icon.addClass('w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text- font-black')
  var card1Title = create('div','Scrolling Facebook')
  card1Title.addClass('text- font-bold text-black mt-3')
  var card1Desc = create('p','I can scroll Facebook for hours. I just watch videos, memes, tech pages, sci-fi groups. I learn a lot from random posts. Thats how I found many UI ideas. I dont post much, I just consume.')
  card1Desc.addClass('text- leading-5 text-zinc-600 mt-2')
  var card1Tag = create('div','Daily • 2-3 hours')
  card1Tag.addClass('text- font-bold tracking-wide text-zinc-400 mt-4 uppercase')
  var card1 = col(card1Icon, card1Title, card1Desc, card1Tag)
  card1.addClass('p-5 rounded- bg-white border border-zinc-200 mx-5 mt-6')

  var card2Icon = create('div','FF')
  card2Icon.addClass('w-10 h-10 rounded-full bg-black text-white flex items-center justify-center text- font-black')
  var card2Title = create('div','Free Fire')
  card2Title.addClass('text- font-bold text-white mt-3')
  var card2Desc = create('p','I am actually good at Free Fire. Not pro but my friends know I clutch. I play aggressive, close range. I love the movement. It taught me about timing and fast decision. Like coding.')
  card2Desc.addClass('text- leading-5 text-zinc-300 mt-2')
  var card2Row1 = create('div','KD: 3.2')
  card2Row1.addClass('px-2 py-1 rounded-full bg-white/10 text- font-bold text-white')
  var card2Row2 = create('div','Role: Rusher')
  card2Row2.addClass('px-2 py-1 rounded-full bg-white/10 text- font-bold text-white')
  var card2Row3 = create('div','Rank: Heroic')
  card2Row3.addClass('px-2 py-1 rounded-full bg-white/10 text- font-bold text-white')
  var card2Stats = row(card2Row1, card2Row2, card2Row3)
  card2Stats.addClass('gap-2 mt-4 flex-wrap')
  var card2 = col(card2Icon, card2Title, card2Desc, card2Stats)
  card2.addClass('p-5 rounded- bg-zinc-900 mx-5 mt-3')

  var card3Icon = create('div','AI')
  card3Icon.addClass('w-10 h-10 rounded-full bg-violet-600 text-white flex items-center justify-center text- font-black')
  var card3Title = create('div','AI Engineer mindset')
  card3Title.addClass('text- font-bold text-black mt-3')
  var card3Desc = create('p','I want to be AI engineer. Not just using chatgpt. I want to build small models that run in browser. I am learning how llm work, tokens, vectors. My dream is to make AI that can write my framework code for me.')
  card3Desc.addClass('text- leading-5 text-zinc-600 mt-2')
  var card3List1 = create('div','• Trying to build tiny transformer')
  card3List1.addClass('text- text-zinc-600 mt-1')
  var card3List2 = create('div','• Learning python for AI side')
  card3List2.addClass('text- text-zinc-600 mt-1')
  var card3List3 = create('div','• Want to make AI game NPCs')
  card3List3.addClass('text- text-zinc-600 mt-1')
  var card3List = col(card3List1, card3List2, card3List3)
  card3List.addClass('mt-3')
  var card3 = col(card3Icon, card3Title, card3Desc, card3List)
  card3.addClass('p-5 rounded- bg-white border border-zinc-200 mx-5 mt-3')

  var card4Icon = create('div','SCI')
  card4Icon.addClass('w-10 h-10 rounded-full bg-cyan-500 text-white flex items-center justify-center text- font-black')
  var card4Title = create('div','Sci-Fi & Science')
  card4Title.addClass('text- font-bold text-black mt-3')
  var card4Desc = create('p','I love sci-fi movies, books, anything about space, time travel, parallel worlds. Interstellar is my top. I also love real science, black holes, quantum stuff. It makes me think bigger than just divs and css.')
  card4Desc.addClass('text- leading-5 text-zinc-600 mt-2')
  var card4Mov1 = create('div','Interstellar')
  card4Mov1.addClass('px-2 py-1 rounded-full bg-zinc-100 border border-zinc-200 text- font-bold')
  var card4Mov2 = create('div','Dune')
  card4Mov2.addClass('px-2 py-1 rounded-full bg-zinc-100 border border-zinc-200 text- font-bold')
  var card4Mov3 = create('div','Black Mirror')
  card4Mov3.addClass('px-2 py-1 rounded-full bg-zinc-100 border border-zinc-200 text- font-bold')
  var card4Mov4 = create('div','Cosmos')
  card4Mov4.addClass('px-2 py-1 rounded-full bg-zinc-100 border border-zinc-200 text- font-bold')
  var card4Row = row(card4Mov1, card4Mov2, card4Mov3, card4Mov4)
  card4Row.addClass('gap-2 mt-4 flex-wrap')
  var card4 = col(card4Icon, card4Title, card4Desc, card4Row)
  card4.addClass('p-5 rounded- bg-white border border-zinc-200 mx-5 mt-3')

  var bestLabel = create('div','// BEST PROJECT')
  bestLabel.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var bestTitle = create('h2','Game Maker Framework')
  bestTitle.addClass('text- font-black tracking-tight px-5 mt-3 leading-8')

  var bestSub = create('div','My proudest work')
  bestSub.addClass('text- font-bold tracking-widest text-violet-600 px-5 mt-2 uppercase')

  var bestDesc = create('p','This is my best project ever. Its not just a game, its a framework to make games. Like you write game.create() and player.move() and it builds a game for you. I made it because I was tired of Unity being heavy. I wanted something light that runs in browser with my language.')
  bestDesc.addClass('text- leading-5 text-zinc-600 px-5 mt-4 max-w-')

  var feat1T = create('div','No install')
  feat1T.addClass('text- font-bold text-black')
  var feat1D = create('div','Runs in browser, just code')
  feat1D.addClass('text- text-zinc-500 mt-1')
  var feat1 = col(feat1T, feat1D)
  feat1.addClass('p-3 rounded-xl bg-white border border-zinc-200 w-[48%]')

  var feat2T = create('div','Fast render')
  feat2T.addClass('text- font-bold text-black')
  var feat2D = create('div','60fps on my phone')
  feat2D.addClass('text- text-zinc-500 mt-1')
  var feat2 = col(feat2T, feat2D)
  feat2.addClass('p-3 rounded-xl bg-white border border-zinc-200 w-[48%]')

  var featRow1 = row(feat1, feat2)
  featRow1.addClass('gap-2 px-5 mt-4')

  var feat3T = create('div','AI NPCs')
  feat3T.addClass('text- font-bold text-black')
  var feat3D = create('div','NPCs learn from you')
  feat3D.addClass('text- text-zinc-500 mt-1')
  var feat3 = col(feat3T, feat3D)
  feat3.addClass('p-3 rounded-xl bg-white border border-zinc-200 w-[48%]')

  var feat4T = create('div','Export')
  feat4T.addClass('text- font-bold text-black')
  var feat4D = create('div','Export to apk one click')
  feat4D.addClass('text- text-zinc-500 mt-1')
  var feat4 = col(feat4T, feat4D)
  feat4.addClass('p-3 rounded-xl bg-white border border-zinc-200 w-[48%]')

  var featRow2 = row(feat3, feat4)
  featRow2.addClass('gap-2 px-5 mt-2')

  
  var codeBox = create('div','const game = Emat2d({\n canvas: \'#game\',\n width: CW,\n height: CH,\n background: \'#0a0a12\',\n imagePath: \'assets/img/\',\n soundPath: \'assets/sounds/\',\n gravity: 1400,\n debug: false\n})\n\nconst player = game.createPlayer({\n x: 100,\n y: 100,\n sprite: \'freefire_player.png\'\n})\n\ngame.start()')
codeBox.addClass('mx-5 mt-5 p-4 rounded-2xl bg-zinc-900 text-zinc-100 text- leading-5 font-mono whitespace-pre-line')
  codeBox.addClass('mx-5 mt-5 p-4 rounded-2xl bg-zinc-900 text-zinc-100 text- leading-5 font-mono whitespace-pre-line')

  var btnPlay = create('button','Try Demo (coming soon)')
  btnPlay.addClass('mx-5 mt-4 py-3.5 rounded-xl bg-black text-white text- font-bold')

  var btnCode = create('button','View Source ->')
  btnCode.addClass('mx-5 mt-2 py-3.5 rounded-xl bg-white border border-zinc-200 text-black text- font-bold')

  var thought = create('p','"I want people to make games like they post on Facebook. Fast, easy, no overthinking. Thats why I built this."')
  thought.addClass('text- italic leading-6 text-zinc-600 px-5 mt-8')

  var space = create('div','')
  space.addClass('h-[130px]')

  wrap.push(label)
  wrap.push(title)
  wrap.push(sub)
  wrap.push(card1)
  wrap.push(card2)
  wrap.push(card3)
  wrap.push(card4)
  wrap.push(bestLabel)
  wrap.push(bestTitle)
  wrap.push(bestSub)
  wrap.push(bestDesc)
  wrap.push(featRow1)
  wrap.push(featRow2)
  wrap.push(codeBox)
  wrap.push(btnPlay)
  wrap.push(btnCode)
  wrap.push(thought)
  wrap.push(space)

  var d = col(wrap)
  d.id = 'fav'
  return d
}


function profile(){
  var wrap = col()
  wrap.addClass('w-full bg-[#fcfcfc] gap-0')

  var cover = img("1790749030146.jpg", "1790749030146.jpg", "w-full rounded-[50%]")

  var avatar = create('div','E')
  avatar.addClass('w- h- rounded-full bg-white border-4 border-[#fcfcfc] text-black text- font-black flex items-center justify-center -mt-8 ml-8')

  var name = create('div','Emat')
  name.addClass('text- font-black tracking-tight px-5 mt-3')

  var handle = create('div','@emat.dev • Next.js Pro creator')
  handle.addClass('text- text-zinc-500 px-5 mt-1')

  var bio = create('p','I build my own tools. If it doesnt exist I make it. Simple as that. Currently in Nigeria building cool stuff for web.')
  bio.addClass('text- leading-5 text-zinc-600 px-5 mt-4 max-w-')

  var followBtn = create('button','Follow')
  followBtn.addClass('px-5 py-2.5 bg-black text-white rounded-xl text- font-bold')

  var msgBtn = create('button','Message')
  msgBtn.addClass('px-5 py-2.5 bg-white border border-zinc-200 text-black rounded-xl text- font-bold')

  var btnRow = row(followBtn, msgBtn)
  btnRow.addClass('gap-2 px-5 mt-4')

  var stats1n = create('div','34')
  stats1n.addClass('text- font-black text-black')
  var stats1l = create('div','projects')
  stats1l.addClass('text- text-zinc-400 font-bold uppercase tracking-wide')
  var stats1 = col(stats1n, stats1l)
  stats1.addClass('items-center')

  var stats2n = create('div','2y')
  stats2n.addClass('text- font-black text-black')
  var stats2l = create('div','coding')
  stats2l.addClass('text- text-zinc-400 font-bold uppercase tracking-wide')
  var stats2 = col(stats2n, stats2l)
  stats2.addClass('items-center')

  var stats3n = create('div','100%')
  stats3n.addClass('text- font-black text-black')
  var stats3l = create('div','self taught')
  stats3l.addClass('text- text-zinc-400 font-bold uppercase tracking-wide')
  var stats3 = col(stats3n, stats3l)
  stats3.addClass('items-center')

  var statsRow = row(stats1, stats2, stats3)
  statsRow.addClass('justify-between px-8 mt-6 py-4 rounded-2xl bg-white border border-zinc-200 mx-5')

  var labelLinks = create('div','// LINKS')
  labelLinks.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var link1Name = create('div','GitHub')
  link1Name.addClass('text- font-semibold text-black')
  var link1Url = create('div','github.com/emat')
  link1Url.addClass('text- text-zinc-500')
  var link1Arrow = create('div','↗')
  link1Arrow.addClass('text- text-zinc-400')
  var link1Left = col(link1Name, link1Url)
  var link1 = row(link1Left, spacer(), link1Arrow)
  link1.addClass('p-4 rounded-2xl bg-white border border-zinc-200 items-center')

  var link2Name = create('div','Twitter / X')
  link2Name.addClass('text- font-semibold text-black')
  var link2Url = create('div','@emat_dev')
  link2Url.addClass('text- text-zinc-500')
  var link2Arrow = create('div','↗')
  link2Arrow.addClass('text- text-zinc-400')
  var link2Left = col(link2Name, link2Url)
  var link2 = row(link2Left, spacer(), link2Arrow)
  link2.addClass('p-4 rounded-2xl bg-white border border-zinc-200 items-center')

  var link3Name = create('div','Email')
  link3Name.addClass('text- font-semibold text-black')
  var link3Url = create('div','emat@pro.dev')
  link3Url.addClass('text- text-zinc-500')
  var link3Arrow = create('div','↗')
  link3Arrow.addClass('text- text-zinc-400')
  var link3Left = col(link3Name, link3Url)
  var link3 = row(link3Left, spacer(), link3Arrow)
  link3.addClass('p-4 rounded-2xl bg-white border border-zinc-200 items-center')

  var linksCol = col(link1, link2, link3)
  linksCol.addClass('gap-2 px-5 mt-3')

  var labelStack = create('div','// MY STACK TODAY')
  labelStack.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var st1 = create('div','Next.js Pro 60%')
  st1.addClass('text- font-bold text-white p-3 rounded-xl bg-black w-full')
  var st2 = create('div','Tailwind 80%')
  st2.addClass('text- font-bold text-black p-3 rounded-xl bg-zinc-200 w-[80%] mt-2')
  var st3 = create('div','JS 70%')
  st3.addClass('text- font-bold text-black p-3 rounded-xl bg-zinc-200 w-[70%] mt-2')
  var st4 = create('div','CSS 80% (I try)')
  st4.addClass('text- font-bold text-black p-3 rounded-xl bg-zinc-200 w-[80%] mt-2')
  var stackCol = col(st1, st2, st3, st4)
  stackCol.addClass('px-5 mt-3')

  var labelNow = create('div','// NOW')
  labelNow.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var nowText = create('div','- Learning how to make route() more fast\n- Fixing bottom nav touch bug\n- Trying to make header not overlay\n- Building new project page')
  nowText.addClass('text- leading-6 text-zinc-600 px-5 mt-2 whitespace-pre-line')

  var labelContact = create('div','// CONTACT')
  labelContact.addClass('text- font-bold tracking-widest text-zinc-400 px-5 mt-8')

  var input1 = create('input','')
  input1.addClass('w-full p-4 rounded-xl bg-white border border-zinc-200 text- outline-none')
  input1.placeholder = 'Your name'

  var input2 = create('input','')
  input2.addClass('w-full p-4 rounded-xl bg-white border border-zinc-200 text- outline-none mt-2')
  input2.placeholder = 'Your email'

  var input3 = create('textarea','')
  input3.addClass('w-full p-4 rounded-xl bg-white border border-zinc-200 text- outline-none mt-2 h-')
  input3.placeholder = 'Message'

  var sendBtn = create('button','Send Message')
  sendBtn.addClass('w-full py-3.5 rounded-xl bg-black text-white text- font-bold mt-3')

  var form = col(input1, input2, input3, sendBtn)
  form.addClass('px-5 mt-3')

  var foot = create('div','© 2025 Emat. Built with Next.js Pro - no react.')
  foot.addClass('text- text-zinc-400 text-center mt-8 px-5')

  var space = create('div','')
  space.addClass('h-[130px]')

  wrap.push(cover)
  wrap.push(avatar)
  wrap.push(name)
  wrap.push(handle)
  wrap.push(bio)
  wrap.push(btnRow)
  wrap.push(statsRow)
  wrap.push(labelLinks)
  wrap.push(linksCol)
  wrap.push(labelStack)
  wrap.push(stackCol)
  wrap.push(labelNow)
  wrap.push(nowText)
  wrap.push(labelContact)
  wrap.push(form)
  wrap.push(foot)
  wrap.push(space)

  var d = col(wrap)
  d.id = 'user'
  return d
}

var txt = create('div','Emat portfolio')
txt.addClass('text-xl font-black tracking-tight text-slate-900')

var menu = iconBtn('menu')
menu.addClass('p-2.5 rounded-xl bg-slate-900 text-white active:scale-95')

var list = ['home','overview','project']
var nm = create('ul')
for (var i = 0; i < 3; i++){
  let li = create('li', list[i])
  li.addClass('px-4 py-3 rounded-xl text-sm font-semibold capitalize text-slate-600')
  let target = list[i]
  li.onClick = function(){
    route(target)
    nm.addClass('hidden')
    nm.removeClass('flex')
    open = false
  }
  nm.push(li)
}
nm.addClass('hidden absolute left-4 right-4 top-full mt-2 flex flex-col gap-1 p-2 rounded-2xl bg-white border border-slate-200 shadow-xl z-[90]')

var header = row(txt, spacer(), menu)
header.addClass('p-4 bg-white border-b border-slate-100 sticky top-0 z-[100]')

var fh = col(header, nm)
fh.addClass('relative w-full z-[100]')

var b1 = iconBtn('home')
var b2 = iconBtn('bag')
var b3 = iconBtn('star')
var b4 = iconBtn('user')

b1.addClass('p-3.5 rounded-2xl bg-slate-900 text-white shadow-lg')
b2.addClass('p-3.5 rounded-2xl text-slate-500 bg-transparent')
b3.addClass('p-3.5 rounded-2xl text-slate-500 bg-transparent')
b4.addClass('p-3.5 rounded-2xl text-slate-500 bg-transparent')

var downNav = row(b1, spacer(), b2, spacer(), b3, spacer(), b4)
downNav.addClass('fixed bottom-5 left-1/2 -translate-x-1/2 w-[90%] max-w-[360px] p-2 bg-white border border-slate-200 rounded-3xl shadow-[0_20px_50px_-15px_rgba(0,0,0,0.3)] z-[300]')

var open = false
menu.onClick = function(){
  open =!open
  if(open){
    nm.removeClass('hidden')
    nm.addClass('flex')
  } else {
    nm.addClass('hidden')
    nm.removeClass('flex')
  }
}

function setActive(a){
  var all = [b1,b2,b3,b4]
  for(var i=0;i<all.length;i++){
    all[i].removeClass('bg-slate-900 text-white shadow-lg')
    all[i].addClass('text-slate-500 bg-transparent')
  }
  a.removeClass('text-slate-500 bg-transparent')
  a.addClass('bg-slate-900 text-white shadow-lg')
}

b1.onClick = function(){ setActive(b1); route('home') }
b2.onClick = function(){ setActive(b2); route('shop') }
b3.onClick = function(){ setActive(b3); route('fav') }
b4.onClick = function(){ setActive(b4); route('user') }

root.addClass('min-h-screen bg-slate-50')
root.push(fh, home(), overview(), project(), shop(), fav(), profile(), downNav)
route('home')