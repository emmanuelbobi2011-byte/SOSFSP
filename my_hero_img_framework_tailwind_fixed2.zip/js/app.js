var root = app();
root.addClass(' h-screen bg-black')
var div = img("IMG-20261006-WA0014.jpg", "IMG-20261006-WA0014.jpg", "w-full h-[605px] absolute inset-0 z-0 ")
var div2 = img("IMG-20261006-WA0012.jpg", "IMG-20261006-WA0012.jpg", "w-full absolute inset-0 z-0 h-[605px]")
var i = animateItem([div2,div],'slide-right','overlay',2,true,true)
var gap = create('div')
gap.addClass('w-100 h-5')
var gap2 = create('div',svg('user','w-80 h-40 text-white'))
gap2.addClass('w-100 h-40')
var gap3 = create('div')
gap3.addClass('w-100 h-7')
var text = create('div','LOGIN')
var text2 = create('div','We sow u Rock')
var input = create('input')
input.placeholder = `Name  / Email / Phone No.`
var btn = create('button','Submit')
var tet = col(gap2,text,text2,input,gap,btn)
tet.addClass('absolute z-10 inset-1 flex items-center justify-center')
text.addClass('text-white text-6xl')
text2.addClass('text-white')
text.el.style.letterSpacing = '20px'
btn.addClass('border w-80 h-10 border-white rounded-2xl hover:scale-105 bg-[#102040] text-white text-xl')
input.addClass('border w-80 h-10 border-white rounded-2xl p-2 ')
root.push(i,tet);
