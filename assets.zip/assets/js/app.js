(function injectStyles() {
  if (document.getElementById('__app_styles')) return;
  var st = document.createElement('style');
  st.id = '__app_styles';
  st.textContent = [
    ':root{--bg:#fff;--bg-soft:#f7f7f7;--bg-card:#fff;--border:#e5e5e5;--text:#3c3c3c;--text-light:#777;--green:#58cc02;--green-dark:#48a502;--blue:#1cb0f6;--blue-dark:#1899d6;--red:#ff4b4b;--red-dark:#d33d3d;--purple:#ce82ff;--purple-dark:#a568cc;--orange:#ff9600;--gray:#e5e5e5;--gray-dark:#afafaf}',
    'html.dark{--bg:#0d1117;--bg-soft:#161b22;--bg-card:#161b22;--border:#30363d;--text:#e6edf3;--text-light:#8b949e;--gray:#21262d;--gray-dark:#6e7681}',
    '*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}',
    'html,body{margin:0;padding:0;height:100%;font-family:system-ui,-apple-system,sans-serif;background:var(--bg);color:var(--text);overflow:hidden;transition:background .2s,color .2s}',
    'button{font-family:inherit;border:none;cursor:pointer;background:none;color:inherit}',
    'input,textarea,select{font-family:inherit}',
    '.no-scrollbar::-webkit-scrollbar{display:none}',
    '.no-scrollbar{-ms-overflow-style:none;scrollbar-width:none}',
    '.CodeMirror{height:100%;font-family:ui-monospace,Menlo,Consolas,monospace;font-size:13px;line-height:1.5;background:var(--bg);color:var(--text)}',
    '.CodeMirror-gutters{background:var(--bg-soft);border-right:1px solid var(--border)}',
    '.CodeMirror-linenumber{color:var(--text-light)}',
    '.CodeMirror-cursor{border-left:2px solid var(--green)}',
    '.CodeMirror-selected{background:#ddf4d0!important}',
    'html.dark .CodeMirror-selected{background:#264f78!important}',
    '.CodeMirror-hints{z-index:99999!important;font-family:ui-monospace,monospace;font-size:13px;max-height:40vh;background:var(--bg-card);border:2px solid var(--border);border-radius:12px;color:var(--text);box-shadow:0 8px 24px rgba(0,0,0,.08)}',
    '.CodeMirror-hint{padding:8px 14px;border-radius:8px}',
    '.CodeMirror-hint-active{background:var(--green)!important;color:#fff!important}'
  ].join('');
  document.head.appendChild(st);
})();

var root = app();
root.el.style.cssText = 'width:100vw;height:100vh;display:flex;flex-direction:column;background:var(--bg);color:var(--text);overflow:hidden';

var GREEN = '#58cc02';
var GREEN_DARK = '#48a502';
var BLUE = '#1cb0f6';
var BLUE_DARK = '#1899d6';
var RED = '#ff4b4b';
var RED_DARK = '#d33d3d';
var PURPLE = '#ce82ff';
var PURPLE_DARK = '#a568cc';
var ORANGE = '#ff9600';
var ORANGE_DARK = '#e08600';

var STORAGE_KEY = 'emat_editor_v7';
var OPEN_KEY = 'emat_editor_open_v7';
var SETTINGS_KEY = 'emat_editor_settings_v7';

var state = {
  files: {},
  fileList: [],
  openFile: null,
  projectName: 'Untitled',
  screen: 'home',
  media: {},
  settings: {
    theme: 'light',
    fontSize: 13,
    tabSize: 2,
    lineWrap: true,
    lineNumbers: true,
    autoClose: true,
    autocorrect: true
  }
};

var _db = null;
function openMediaDB() {
  return new Promise(function (resolve, reject) {
    if (_db) return resolve(_db);
    var req = indexedDB.open('emat_media_v1', 1);
    req.onupgradeneeded = function (e) {
      var db = e.target.result;
      if (!db.objectStoreNames.contains('media')) {
        db.createObjectStore('media', { keyPath: 'name' });
      }
    };
    req.onsuccess = function (e) { _db = e.target.result; resolve(_db); };
    req.onerror = function (e) { reject(e.target.error); };
  });
}

function dbPutMedia(rec) {
  return openMediaDB().then(function (db) {
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('media', 'readwrite');
      tx.objectStore('media').put(rec);
      tx.oncomplete = resolve;
      tx.onerror = function (e) { reject(e.target.error); };
    });
  });
}

function dbAllMedia() {
  return openMediaDB().then(function (db) {
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('media', 'readonly');
      var req = tx.objectStore('media').getAll();
      req.onsuccess = function () { resolve(req.result || []); };
      req.onerror = function (e) { reject(e.target.error); };
    });
  });
}

function dbDeleteMedia(name) {
  return openMediaDB().then(function (db) {
    return new Promise(function (resolve, reject) {
      var tx = db.transaction('media', 'readwrite');
      tx.objectStore('media').delete(name);
      tx.oncomplete = resolve;
      tx.onerror = function (e) { reject(e.target.error); };
    });
  });
}

function loadMediaIntoState() {
  return dbAllMedia().then(function (list) {
    state.media = {};
    list.forEach(function (m) { state.media[m.name] = m; });
    return state.media;
  }).catch(function () { return {}; });
}

function isMediaName(name) {
  return state.media && state.media[name];
}

function fileExt(name) {
  var i = name.lastIndexOf('.');
  return i === -1 ? '' : name.slice(i + 1).toLowerCase();
}

function fileCategory(name) {
  if (isMediaName(name)) {
    var t = state.media[name].type || '';
    if (t.indexOf('image/') === 0) return 'image';
    if (t.indexOf('video/') === 0) return 'video';
    if (t.indexOf('audio/') === 0) return 'audio';
    return 'binary';
  }
  var ext = fileExt(name);
  if (ext === 'js' || ext === 'ts' || ext === 'json' || ext === 'html' || ext === 'css' || ext === 'txt' || ext === 'md') return 'code';
  return 'text';
}

function load() {
  try {
    var raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      var p = JSON.parse(raw);
      if (p && p.files) {
        state.files = p.files;
        state.fileList = p.fileList || Object.keys(p.files);
        state.projectName = p.projectName || 'Untitled';
      }
    }
    var open = localStorage.getItem(OPEN_KEY);
    if (open) state.openFile = open;
    var setg = localStorage.getItem(SETTINGS_KEY);
    if (setg) {
      var sp = JSON.parse(setg);
      for (var k in sp) if (sp.hasOwnProperty(k)) state.settings[k] = sp[k];
    }
  } catch (e) {}
  if (state.settings.theme === 'dark') document.documentElement.classList.add('dark');
}

function save() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify({
      files: state.files,
      fileList: state.fileList,
      projectName: state.projectName
    }));
    if (state.openFile) localStorage.setItem(OPEN_KEY, state.openFile);
  } catch (e) {}
}

function saveSettings() {
  try { localStorage.setItem(SETTINGS_KEY, JSON.stringify(state.settings)); } catch (e) {}
}

function hasProject() {
  return state.fileList.length > 0 && state.openFile;
}

function uniqueName(base, ext) {
  if (!state.files[base + ext] && !state.media[base + ext]) return base + ext;
  var i = 1;
  while (state.files[base + '_' + i + ext] || state.media[base + '_' + i + ext]) i++;
  return base + '_' + i + ext;
}

function refreshTheme() {
  document.documentElement.classList.toggle('dark', state.settings.theme === 'dark');
}

var TEMPLATES = {
  blank: {
    name: 'Blank', icon: 'file', color: '#afafaf',
    files: { 'main.js': 'var root = app();\nroot.style = "p-6 flex flex-col gap-4";\n\nvar t = create("h1", "Hello world");\nt.style = "text-2xl font-bold";\n\nvar b = create("button", "Tap me");\nb.style = "bg-blue-500 text-white p-3 rounded";\nb.onClick = function () {\n  vibrate(30);\n  toast("You clicked");\n};\n\nroot.push(t, b);\n' }
  },
  gallery: {
    name: 'Gallery', icon: 'image', color: PURPLE,
    files: { 'main.js': 'var root = app();\nroot.style = "p-4 flex flex-col gap-3";\n\nvar title = create("h1", "My Gallery");\ntitle.style = "text-3xl font-bold";\nroot.push(title);\n\nvar grid = create("div");\ngrid.style = "grid grid-cols-2 gap-3";\n\nfor (var i = 1; i <= 6; i++) {\n  var im = img("https://picsum.photos/400/400?random=" + i, "pic", "w-full rounded-2xl shadow");\n  grid.push(im);\n}\n\nroot.push(grid);\n' }
  },
  todo: {
    name: 'Todo List', icon: 'check', color: GREEN,
    files: { 'main.js': 'var root = app();\nroot.style = "p-6 flex flex-col gap-4 bg-gray-50 min-h-screen";\n\nvar title = create("h1", "My Todos");\ntitle.style = "text-3xl font-bold";\n\nvar list = store.get("todos", []);\nvar listEl = create("div");\nlistEl.style = "flex flex-col gap-2";\n\nfunction render() {\n  listEl.clear();\n  list.forEach(function (t, i) {\n    var row = create("div");\n    row.style = "flex items-center gap-3 bg-white p-4 rounded-2xl shadow-sm";\n    var label = create("div", t.text);\n    label.style = "flex-1";\n    var del = create("button", "x");\n    del.style = "text-red-500 text-xl";\n    del.onClick = function () { list.splice(i, 1); store.set("todos", list); render(); };\n    row.push(label, del);\n    listEl.push(row);\n  });\n}\n\nvar input = create("input");\ninput.placeholder = "Add a task...";\ninput.style = "p-4 rounded-2xl border-2 border-gray-200 outline-none";\n\nvar addBtn = create("button", "Add");\naddBtn.style = "bg-green-500 text-white p-4 rounded-2xl font-bold";\naddBtn.onClick = function () {\n  if (!input.value.trim()) return;\n  list.push({ text: input.value.trim(), done: false });\n  store.set("todos", list);\n  input.value = "";\n  render();\n};\n\nrender();\nroot.push(title, listEl, input, addBtn);\n' }
  }
};

function iconSvg(name, size, color) {
  size = size || 20;
  var ic = svg(name, 'w-5 h-5');
  ic.el.style.cssText = 'width:' + size + 'px;height:' + size + 'px;color:' + (color || 'currentColor') + ';display:inline-block;flex-shrink:0';
  return ic;
}

function makeBtn(text, color, darkColor, onClick) {
  var b = create('button');
  b.el.style.cssText = 'padding:14px 20px;border-radius:16px;background:' + color + ';color:#fff;font-weight:800;font-size:16px;letter-spacing:.3px;box-shadow:0 4px 0 ' + darkColor + ';transition:transform .1s,box-shadow .1s;display:flex;align-items:center;justify-content:center;gap:8px';
  if (text) {
    var lbl = create('span', text);
    lbl.el.style.cssText = 'color:#fff;font-weight:800';
    b.push(lbl);
  }
  b.onClick = function () {
    b.el.style.transform = 'translateY(3px)';
    b.el.style.boxShadow = '0 1px 0 ' + darkColor;
    setTimeout(function () {
      b.el.style.transform = '';
      b.el.style.boxShadow = '0 4px 0 ' + darkColor;
    }, 100);
    vibrate(15);
    onClick();
  };
  return b;
}

function makeGhostBtn(text, onClick) {
  var b = create('button');
  b.el.style.cssText = 'padding:14px 20px;border-radius:16px;background:var(--bg-card);color:var(--text);font-weight:800;font-size:16px;border:2px solid var(--border);box-shadow:0 4px 0 var(--border);display:flex;align-items:center;justify-content:center;gap:8px';
  if (text) {
    var lbl = create('span', text);
    lbl.el.style.cssText = 'color:var(--text);font-weight:800';
    b.push(lbl);
  }
  b.onClick = function () {
    b.el.style.transform = 'translateY(3px)';
    b.el.style.boxShadow = '0 1px 0 var(--border)';
    setTimeout(function () {
      b.el.style.transform = '';
      b.el.style.boxShadow = '0 4px 0 var(--border)';
    }, 100);
    vibrate(15);
    if (onClick) onClick();
  };
  return b;
}

function makeCard(iconName, title, subtitle, color, onClick) {
  var card = create('div');
  card.el.style.cssText = 'background:var(--bg-card);border:2px solid var(--border);border-radius:20px;padding:16px;display:flex;flex-direction:row;align-items:center;gap:14px;cursor:pointer';
  var iconBox = create('div');
  iconBox.el.style.cssText = 'width:52px;height:52px;border-radius:16px;background:' + color + '22;display:flex;align-items:center;justify-content:center;flex-shrink:0';
  iconBox.push(iconSvg(iconName, 26, color));
  var body = create('div');
  body.el.style.cssText = 'flex:1;min-width:0';
  var t1 = create('div', title);
  t1.el.style.cssText = 'font-weight:800;font-size:16px;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
  var s1 = create('div', subtitle || '');
  s1.el.style.cssText = 'font-size:12px;color:var(--text-light);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;margin-top:2px';
  body.push(t1, s1);
  var arrow = iconSvg('chevronRight', 22, '#afafaf');
  card.push(iconBox, body, arrow);
  card.onClick = function () { vibrate(15); onClick(); };
  return card;
}

function askName(label, defaultValue, onDone) {
  var input = create('input');
  input.value = defaultValue || '';
  input.el.style.cssText = 'width:100%;padding:16px;border-radius:16px;border:2px solid var(--border);font-size:16px;font-weight:600;color:var(--text);outline:none;background:var(--bg-card)';
  input.el.onfocus = function () { input.el.style.borderColor = BLUE; };
  input.el.onblur = function () { input.el.style.borderColor = 'var(--border)'; };
  modal({
    title: label,
    body: input,
    buttons: [
      { label: 'Cancel' },
      { label: 'OK', primary: true, onClick: function () {
        var v = input.value.trim();
        onDone(v || defaultValue || 'Untitled');
      }}
    ]
  });
  setTimeout(function () { input.el.focus(); }, 100);
}

var screens = {};
var editor = null;

function buildHome() {
  var s = create('div');
  s.id = 'screen_home';
  s.el.style.cssText = 'flex:1;display:flex;flex-direction:column;background:var(--bg);overflow:hidden';

  var scroll = create('div');
  scroll.el.style.cssText = 'flex:1;overflow-y:auto;padding:20px 20px 32px';

  var header = create('div');
  header.el.style.cssText = 'display:flex;flex-direction:row;align-items:center;justify-content:space-between;margin-bottom:24px';

  var greet = create('div');
  var g1 = create('div','Welcome back');
  g1.el.style.cssText = 'font-size:13px;color:var(--text-light);font-weight:600';
  var g2 = create('div','Emat Studio');
  g2.el.style.cssText = 'font-size:28px;font-weight:900;color:var(--text);letter-spacing:-.5px';
  greet.push(g1, g2);

  var right = create('div');
  right.el.style.cssText = 'display:flex;gap:8px;align-items:center';

  var importBtnTop = create('button');
  importBtnTop.el.style.cssText = 'width:44px;height:44px;border-radius:50%;background:var(--bg-soft);border:2px solid var(--border);display:flex;align-items:center;justify-content:center';
  importBtnTop.push(iconSvg('upload', 20, 'var(--text)'));
  importBtnTop.onClick = function () { vibrate(15); importAnyFile(); };

  var settingsBtn = create('button');
  settingsBtn.el.style.cssText = 'width:44px;height:44px;border-radius:50%;background:var(--bg-soft);border:2px solid var(--border);display:flex;align-items:center;justify-content:center';
  settingsBtn.push(iconSvg('settings', 20, 'var(--text)'));
  settingsBtn.onClick = function () { vibrate(15); openSettings(); };

  var avatar = create('div','E');
  avatar.el.style.cssText = 'width:44px;height:44px;border-radius:50%;background:' + GREEN + ';color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900;font-size:18px';

  right.push(importBtnTop, settingsBtn, avatar);
  header.push(greet, right);
  scroll.push(header);

  var recentHolder = create('div');
  scroll.push(recentHolder);

  function paintRecent() {
    recentHolder.clear();
    if (!hasProject()) return;
    var recentTitle = create('div','Continue working');
    recentTitle.el.style.cssText = 'font-size:16px;font-weight:800;color:var(--text);margin-bottom:12px';
    recentHolder.push(recentTitle);
    var recentCard = create('div');
    recentCard.el.style.cssText = 'background:linear-gradient(135deg,' + GREEN + ' 0%,' + GREEN_DARK + ' 100%);border-radius:24px;padding:20px;color:#fff;display:flex;flex-direction:column;gap:10px;box-shadow:0 8px 0 ' + GREEN_DARK + ';cursor:pointer;margin-bottom:28px';
    var r1 = create('div');
    r1.el.style.cssText = 'display:flex;align-items:center;gap:8px;font-size:12px;font-weight:700;opacity:.9;color:#fff';
    r1.push(iconSvg('code', 14, '#fff'), create('span','Recent Project'));
    var r2 = create('div', state.projectName);
    r2.el.style.cssText = 'font-size:22px;font-weight:900;letter-spacing:-.3px;color:#fff';
    var total = state.fileList.length + Object.keys(state.media).length;
    var r3 = create('div', total + ' item' + (total === 1 ? '' : 's') + ' · ' + (state.openFile || ''));
    r3.el.style.cssText = 'font-size:12px;opacity:.9;color:#fff';
    var r4 = create('div');
    r4.el.style.cssText = 'margin-top:6px;font-size:14px;font-weight:800;background:rgba(255,255,255,.25);padding:10px 16px;border-radius:12px;align-self:flex-start;display:flex;align-items:center;gap:6px;color:#fff';
    r4.push(iconSvg('play', 14, '#fff'), create('span','Open editor'));
    recentCard.push(r1, r2, r3, r4);
    recentCard.onClick = function () { vibrate(15); openEditor(); };
    recentHolder.push(recentCard);
  }
  paintRecent();
  s.paintRecent = paintRecent;

  var newTitle = create('div','Start new project');
  newTitle.el.style.cssText = 'font-size:16px;font-weight:800;color:var(--text);margin-bottom:12px';
  scroll.push(newTitle);

  var newRow = create('div');
  newRow.el.style.cssText = 'display:flex;flex-direction:row;gap:10px;margin-bottom:28px';

  var newBtn = makeBtn('', GREEN, GREEN_DARK, function () {
    askName('Project name', 'Untitled', function (name) {
      state.projectName = name;
      state.files = { 'main.js': 'var root = app();\nroot.style = "p-6 flex flex-col gap-4";\n\nvar t = create("h1", "Hello world");\nt.style = "text-2xl font-bold";\n\nvar b = create("button", "Tap me");\nb.style = "bg-blue-500 text-white p-3 rounded";\nb.onClick = function () {\n  vibrate(30);\n  toast("You clicked");\n};\n\nroot.push(t, b);\n' };
      state.fileList = ['main.js'];
      state.openFile = 'main.js';
      save();
      openEditor();
    });
  });
  newBtn.push(iconSvg('plus', 18, '#fff'), create('span','New Project'));
  newBtn.el.style.flex = '1';
  newBtn.el.style.padding = '16px 12px';
  newBtn.el.style.fontSize = '15px';

  var importBtn = makeGhostBtn('', function () { importProject(); });
  importBtn.push(iconSvg('upload', 18, 'var(--text)'), create('span','Import ZIP'));
  importBtn.el.style.flex = '1';
  importBtn.el.style.padding = '16px 12px';
  importBtn.el.style.fontSize = '15px';

  newRow.push(newBtn, importBtn);
  scroll.push(newRow);

  var tplTitle = create('div','Templates');
  tplTitle.el.style.cssText = 'font-size:16px;font-weight:800;color:var(--text);margin-bottom:12px';
  scroll.push(tplTitle);

  var tplList = create('div');
  tplList.el.style.cssText = 'display:flex;flex-direction:column;gap:10px';

  Object.keys(TEMPLATES).forEach(function (key) {
    var tpl = TEMPLATES[key];
    var card = makeCard(tpl.icon, tpl.name, 'Tap to create', tpl.color, function () {
      askName('Project name', tpl.name, function (name) {
        state.projectName = name;
        state.files = {};
        state.fileList = [];
        for (var f in tpl.files) {
          if (tpl.files.hasOwnProperty(f)) {
            state.files[f] = tpl.files[f];
            state.fileList.push(f);
          }
        }
        state.openFile = state.fileList[0];
        save();
        openEditor();
      });
    });
    tplList.push(card);
  });

  scroll.push(tplList);

  var foot = create('div','Emat Studio v7');
  foot.el.style.cssText = 'text-align:center;font-size:11px;color:var(--text-light);margin-top:32px;font-weight:600';
  scroll.push(foot);

  s.push(scroll);
  return s;
}

function openSettings() {
  var body = create('div');
  body.el.style.cssText = 'display:flex;flex-direction:column;gap:14px;max-height:60vh;overflow-y:auto';

  function row(label, control) {
    var r = create('div');
    r.el.style.cssText = 'display:flex;flex-direction:row;align-items:center;justify-content:space-between;gap:12px;padding:8px 0';
    var l = create('div', label);
    l.el.style.cssText = 'font-size:14px;font-weight:700;color:var(--text)';
    r.push(l, control);
    return r;
  }

  // FIX: accept explicit initial state (was reading state.settings[key] directly,
  // which for 'theme' is a string and always truthy).
  function toggleRow(key, onChange, initialState) {
    var b = create('button');
    var on = (initialState !== undefined) ? !!initialState : !!state.settings[key];
    b.el.style.cssText = 'width:50px;height:28px;border-radius:14px;background:' + (on ? GREEN : 'var(--gray)') + ';position:relative;transition:background .15s';
    var knob = create('div');
    knob.el.style.cssText = 'width:22px;height:22px;background:#fff;border-radius:50%;position:absolute;top:3px;left:' + (on ? '25px' : '3px') + ';transition:left .15s;box-shadow:0 1px 3px rgba(0,0,0,.2)';
    b.push(knob);
    b.onClick = function () {
      on = !on;
      state.settings[key] = on;
      b.el.style.background = on ? GREEN : 'var(--gray)';
      knob.el.style.left = on ? '25px' : '3px';
      saveSettings();
      vibrate(15);
      if (onChange) onChange(on);
    };
    return b;
  }

  function numberRow(key, min, max) {
    var wrap = create('div');
    wrap.el.style.cssText = 'display:flex;align-items:center;gap:8px';
    var dec = create('button','-');
    dec.el.style.cssText = 'width:32px;height:32px;border-radius:10px;background:var(--bg-soft);border:2px solid var(--border);font-size:18px;font-weight:800;color:var(--text);display:flex;align-items:center;justify-content:center';
    var val = create('div', String(state.settings[key]));
    val.el.style.cssText = 'min-width:32px;text-align:center;font-weight:800;color:var(--text);font-size:15px';
    var inc = create('button','+');
    inc.el.style.cssText = 'width:32px;height:32px;border-radius:10px;background:var(--bg-soft);border:2px solid var(--border);font-size:18px;font-weight:800;color:var(--text);display:flex;align-items:center;justify-content:center';
    dec.onClick = function () {
      state.settings[key] = Math.max(min, state.settings[key] - 1);
      val.text = String(state.settings[key]);
      saveSettings(); applySettings(); vibrate(10);
    };
    inc.onClick = function () {
      state.settings[key] = Math.min(max, state.settings[key] + 1);
      val.text = String(state.settings[key]);
      saveSettings(); applySettings(); vibrate(10);
    };
    wrap.push(dec, val, inc);
    return wrap;
  }

  body.push(
    row('Dark mode', toggleRow('theme', function (on) {
      state.settings.theme = on ? 'dark' : 'light';
      saveSettings(); refreshTheme();
    }, state.settings.theme === 'dark')),
    row('Font size', numberRow('fontSize', 10, 22)),
    row('Tab size', numberRow('tabSize', 1, 8)),
    row('Line numbers', toggleRow('lineNumbers', applySettings)),
    row('Line wrap', toggleRow('lineWrap', applySettings)),
    row('Auto close brackets', toggleRow('autoClose', applySettings)),
    row('Autocorrect', toggleRow('autocorrect'))
  );

  var resetBtn = create('button','Reset current project');
  resetBtn.el.style.cssText = 'width:100%;padding:14px;border-radius:14px;background:' + RED + ';color:#fff;font-weight:800;font-size:14px;margin-top:8px;box-shadow:0 4px 0 ' + RED_DARK;
  resetBtn.onClick = function () {
    confirm('Delete current project?', function () {
      state.files = {};
      state.fileList = [];
      state.media = {};
      state.openFile = null;
      state.projectName = 'Untitled';
      save();
      if (screens.home && screens.home.paintRecent) screens.home.paintRecent();
      paintFileList();
      if (editor) editor.setValue('');
      toast('Project deleted', 'success');
    });
  };
  body.push(resetBtn);

  modal({
    title: 'Settings',
    body: body,
    buttons: [{ label: 'Done', primary: true }]
  });
}

function applySettings() {
  if (!editor) return;
  editor.setOption('tabSize', state.settings.tabSize);
  editor.setOption('indentUnit', state.settings.tabSize);
  editor.setOption('lineNumbers', state.settings.lineNumbers);
  editor.setOption('lineWrapping', state.settings.lineWrap);
  editor.setOption('autoCloseBrackets', state.settings.autoClose);
  editor.getWrapperElement().style.fontSize = state.settings.fontSize + 'px';
}

function buildEditor() {
  var s = create('div');
  s.id = 'screen_editor';
  s.el.style.cssText = 'flex:1;display:none;flex-direction:column;background:var(--bg);overflow:hidden';

  var toolbar = create('div');
  toolbar.el.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:6px;padding:10px 12px;border-bottom:2px solid var(--border);flex-shrink:0;background:var(--bg)';

  var backBtn = create('button');
  backBtn.el.style.cssText = 'width:36px;height:36px;border-radius:10px;background:var(--bg-soft);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;flex-shrink:0';
  backBtn.push(iconSvg('arrowLeft', 18, 'var(--text)'));
  backBtn.onClick = function () { vibrate(15); goHome(); };

  var filesBtn = create('button');
  filesBtn.el.style.cssText = 'width:36px;height:36px;border-radius:10px;background:' + PURPLE + ';display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 2px 0 ' + PURPLE_DARK;
  filesBtn.push(iconSvg('folder', 18, '#fff'));
  filesBtn.onClick = function () { vibrate(15); if (s.openSheet) s.openSheet(); };

  var info = create('div');
  info.el.style.cssText = 'flex:1;min-width:0;text-align:center;padding:0 4px';

  var projectNameEl = create('div', state.projectName);
  projectNameEl.el.style.cssText = 'font-size:14px;font-weight:800;color:var(--text);overflow:hidden;text-overflow:ellipsis;white-space:nowrap';

  var fileNameEl = create('div','no file');
  fileNameEl.el.style.cssText = 'font-size:10px;color:var(--text-light);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600';

  info.push(projectNameEl, fileNameEl);

  var importTop = create('button');
  importTop.el.style.cssText = 'width:36px;height:36px;border-radius:10px;background:var(--bg-soft);border:2px solid var(--border);display:flex;align-items:center;justify-content:center;flex-shrink:0';
  importTop.push(iconSvg('upload', 16, 'var(--text)'));
  importTop.onClick = function () { vibrate(15); importAnyFile(); };

  var exportBtn = create('button');
  exportBtn.el.style.cssText = 'width:36px;height:36px;border-radius:10px;background:' + BLUE + ';display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 2px 0 ' + BLUE_DARK;
  exportBtn.push(iconSvg('download', 16, '#fff'));
  exportBtn.onClick = function () { vibrate(15); exportProject(); };

  var runBtn = create('button');
  runBtn.el.style.cssText = 'width:36px;height:36px;border-radius:10px;background:' + GREEN + ';display:flex;align-items:center;justify-content:center;flex-shrink:0;box-shadow:0 2px 0 ' + GREEN_DARK;
  runBtn.push(iconSvg('play', 14, '#fff'));
  runBtn.onClick = function () { vibrate(15); runCode(); };

  toolbar.push(backBtn, filesBtn, info, importTop, exportBtn, runBtn);

  var editorPane = create('div');
  editorPane.el.style.cssText = 'flex:1;position:relative;overflow:hidden';

  var previewPane = create('div');
  previewPane.el.style.cssText = 'display:none;flex:1;position:relative;overflow:hidden;background:#fff';

  var consolePane = create('div');
  consolePane.el.style.cssText = 'display:none;flex:1;overflow:auto;background:#111;color:#4ade80;padding:12px;font-family:ui-monospace,monospace;font-size:12px';

  var iframe = create('iframe');
  iframe.el.style.cssText = 'width:100%;height:100%;border:none;background:#fff;display:block';
  previewPane.push(iframe);

  var editBar = create('div');
  editBar.el.style.cssText = 'display:flex;flex-direction:row;gap:0;border-top:2px solid var(--border);background:var(--bg-soft);flex-shrink:0;overflow-x:auto';

  var editTools = [
    { icon: 'arrowLeft', label: 'Undo', action: function () { editor.undo(); } },
    { icon: 'arrowRight', label: 'Redo', action: function () { editor.redo(); } },
    { icon: 'check', label: 'All', action: function () { editor.execCommand('selectAll'); } },
    { icon: 'copy', label: 'Copy', action: function () { cmdCopy(); } },
    { icon: 'scissors', label: 'Cut', action: function () { cmdCut(); } },
    { icon: 'clipboard', label: 'Paste', action: function () { cmdPaste(); } },
    { icon: 'code', label: 'Indent', action: function () { editor.execCommand('indentMore'); } },
    { icon: 'terminal', label: 'Outdent', action: function () { editor.execCommand('indentLess'); } },
    { icon: 'save', label: 'Save', action: function () { save(); toast('Saved', 'success'); } },
    { icon: 'trash', label: 'Clear', action: function () { cmdClear(); } }
  ];

  editTools.forEach(function (t) {
    var btn = create('button');
    btn.el.style.cssText = 'flex-shrink:0;display:flex;flex-direction:column;align-items:center;gap:2px;padding:8px 12px;background:transparent;color:var(--text-light);font-size:9px;font-weight:800;border:none';
    btn.push(iconSvg(t.icon, 18, 'currentColor'));
    var lbl = create('div', t.label);
    lbl.el.style.cssText = 'font-size:9px;color:inherit;font-weight:800;letter-spacing:.3px';
    btn.push(lbl);
    btn.onClick = function () {
      vibrate(10);
      try { t.action(); } catch (e) { toast('Error: ' + e.message, 'error'); }
      if (editor) editor.focus();
    };
    editBar.push(btn);
  });

  var bottomBar = create('div');
  bottomBar.el.style.cssText = 'display:flex;flex-direction:row;border-top:2px solid var(--border);flex-shrink:0;background:var(--bg)';

  var TABS = [
    { id: 'editor', label: 'Code', icon: 'code' },
    { id: 'preview', label: 'Preview', icon: 'play' },
    { id: 'console', label: 'Console', icon: 'terminal' }
  ];
  var tabButtons = {};

  function setTab(id) {
    state.screen = id;
    for (var k in tabButtons) {
      if (!tabButtons.hasOwnProperty(k)) continue;
      var on = k === id;
      tabButtons[k].el.style.color = on ? GREEN : 'var(--text-light)';
      tabButtons[k].el.style.borderTop = '3px solid ' + (on ? GREEN : 'transparent');
    }
    editorPane.el.style.display = id === 'editor' ? 'block' : 'none';
    previewPane.el.style.display = id === 'preview' ? 'block' : 'none';
    consolePane.el.style.display = id === 'console' ? 'block' : 'none';
    // FIX: editBar is a Node — must use .el.style, not .style
    editBar.el.style.display = id === 'editor' ? 'flex' : 'none';
  }
  s.setTab = setTab;

  TABS.forEach(function (tb) {
    var btn = create('button');
    btn.el.style.cssText = 'flex:1;display:flex;flex-direction:column;align-items:center;padding:10px 0 8px;gap:2px;background:transparent;color:var(--text-light);border-top:3px solid transparent;font-weight:700';
    btn.push(iconSvg(tb.icon, 18, 'currentColor'));
    var lbl = create('div', tb.label);
    lbl.el.style.cssText = 'font-size:10px;font-weight:800;color:inherit;letter-spacing:.3px';
    btn.push(lbl);
    btn.onClick = function () { vibrate(10); setTab(tb.id); };
    tabButtons[tb.id] = btn;
    bottomBar.push(btn);
  });

  var sheetOverlay = create('div');
  sheetOverlay.el.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:9998;display:none';
  var sheetPanel = create('div');
  sheetPanel.el.style.cssText = 'position:absolute;top:0;bottom:0;left:0;width:82vw;max-width:340px;background:var(--bg);display:flex;flex-direction:column;transform:translateX(-100%);transition:transform .25s cubic-bezier(.2,.9,.3,1);border-right:2px solid var(--border)';
  sheetOverlay.push(sheetPanel);
  document.body.appendChild(sheetOverlay.el);

  var sheetHeader = create('div');
  sheetHeader.el.style.cssText = 'display:flex;flex-direction:row;align-items:center;justify-content:space-between;padding:18px;border-bottom:2px solid var(--border)';

  var sheetTitle = create('div','Files');
  sheetTitle.el.style.cssText = 'font-size:20px;font-weight:900;color:var(--text)';

  var sheetClose = create('button');
  sheetClose.el.style.cssText = 'width:34px;height:34px;border-radius:10px;background:var(--bg-soft);border:2px solid var(--border);display:flex;align-items:center;justify-content:center';
  sheetClose.push(iconSvg('x', 18, 'var(--text)'));

  sheetHeader.push(sheetTitle, sheetClose);

  var sheetBody = create('div');
  sheetBody.el.style.cssText = 'flex:1;overflow-y:auto;padding:8px';

  var sheetFooter = create('div');
  sheetFooter.el.style.cssText = 'padding:12px;border-top:2px solid var(--border);display:flex;flex-direction:column;gap:8px';

  var newFileBtn = makeBtn('', GREEN, GREEN_DARK, function () {
    askName('File name', 'main.js', function (name) {
      var nv = name.indexOf('.') === -1 ? name + '.js' : name;
      if (state.files[nv] || state.media[nv]) { toast('Already exists', 'error'); return; }
      state.files[nv] = '';
      state.fileList.push(nv);
      state.openFile = nv;
      if (editor) { editor.setValue(''); editor.clearHistory(); }
      fileNameEl.text = nv;
      save();
      paintFileList();
      closeSheet();
    });
  });
  newFileBtn.push(iconSvg('plus', 18, '#fff'), create('span','New File'));
  newFileBtn.el.style.padding = '12px';
  newFileBtn.el.style.fontSize = '14px';

  var importBtn2 = makeGhostBtn('', function () { importAnyFile(); });
  importBtn2.push(iconSvg('upload', 18, 'var(--text)'), create('span','Import File (any)'));
  importBtn2.el.style.padding = '12px';
  importBtn2.el.style.fontSize = '14px';

  var importZipBtn = makeGhostBtn('', function () { importProject(); });
  importZipBtn.push(iconSvg('folderOpen', 18, 'var(--text)'), create('span','Import ZIP'));
  importZipBtn.el.style.padding = '12px';
  importZipBtn.el.style.fontSize = '14px';

  var modulesBtn = makeBtn('', BLUE, BLUE_DARK, function () { openModules(); });
  modulesBtn.push(iconSvg('grid', 18, '#fff'), create('span','Insert Module'));
  modulesBtn.el.style.padding = '12px';
  modulesBtn.el.style.fontSize = '14px';

  // FIX: pass the real handler straight into makeGhostBtn — no second onClick.
  var clearAllBtn = makeGhostBtn('', function () {
    confirm('Delete all files in this project?', function () {
      var mediaNames = Object.keys(state.media);
      var del = mediaNames.map(function (n) { return dbDeleteMedia(n); });
      Promise.all(del).then(function () {
        state.media = {};
        state.files = {};
        state.fileList = [];
        state.openFile = null;
        if (editor) { editor.setValue(''); editor.clearHistory(); }
        fileNameEl.text = 'untitled';
        save();
        paintFileList();
        closeSheet();
        toast('All files deleted', 'error');
      });
    });
  });
  clearAllBtn.push(iconSvg('trash', 18, RED), create('span','Clear All Files'));
  // Color the label red
  var clearLabel = clearAllBtn.el.lastChild;
  if (clearLabel) clearLabel.style.color = RED;
  clearAllBtn.el.style.borderColor = RED;
  clearAllBtn.el.style.boxShadow = '0 4px 0 ' + RED_DARK;
  clearAllBtn.el.style.padding = '12px';
  clearAllBtn.el.style.fontSize = '14px';

  sheetFooter.push(newFileBtn, importBtn2, importZipBtn, modulesBtn, clearAllBtn);
  sheetPanel.push(sheetHeader, sheetBody, sheetFooter);

  function openSheet() {
    sheetOverlay.el.style.display = 'block';
    paintFileList();
    requestAnimationFrame(function () { sheetPanel.el.style.transform = 'translateX(0)'; });
  }
  function closeSheet() {
    sheetPanel.el.style.transform = 'translateX(-100%)';
    setTimeout(function () { sheetOverlay.el.style.display = 'none'; }, 250);
  }

  sheetClose.onClick = closeSheet;
  sheetOverlay.onClick = function (e) { if (e.target === sheetOverlay.el) closeSheet(); };

  s.openSheet = openSheet;
  s.closeSheet = closeSheet;
  s.sheetBody = sheetBody;

  setTimeout(function () {
    editor = CodeMirror(editorPane.el, {
      value: state.openFile && state.files[state.openFile] ? state.files[state.openFile] : '',
      mode: 'javascript',
      lineNumbers: state.settings.lineNumbers,
      lineWrapping: state.settings.lineWrap,
      autofocus: false,
      indentUnit: state.settings.tabSize,
      tabSize: state.settings.tabSize,
      indentWithTabs: false,
      autoCloseBrackets: state.settings.autoClose,
      matchBrackets: true,
      autoCloseTags: true,
      viewportMargin: 20,
      extraKeys: {
        'Ctrl-Z': function (cm) { cm.undo(); },
        'Cmd-Z': function (cm) { cm.undo(); },
        'Ctrl-Y': function (cm) { cm.redo(); },
        'Cmd-Y': function (cm) { cm.redo(); },
        'Shift-Ctrl-Z': function (cm) { cm.redo(); },
        'Shift-Cmd-Z': function (cm) { cm.redo(); },
        'Ctrl-A': function (cm) { cm.execCommand('selectAll'); },
        'Cmd-A': function (cm) { cm.execCommand('selectAll'); },
        'Ctrl-C': function (cm) { cmdCopy(); },
        'Cmd-C': function (cm) { cmdCopy(); },
        'Ctrl-X': function (cm) { cmdCut(); },
        'Cmd-X': function (cm) { cmdCut(); },
        'Ctrl-V': function (cm) { cmdPaste(); },
        'Cmd-V': function (cm) { cmdPaste(); },
        'Ctrl-S': function (cm) { save(); toast('Saved', 'success'); },
        'Cmd-S': function (cm) { save(); toast('Saved', 'success'); },
        'Ctrl-Space': 'autocomplete',
        'Tab': function (cm) {
          if (cm.somethingSelected()) cm.indentSelection('add');
          else cm.replaceSelection('  ', 'end');
        },
        'Shift-Tab': function (cm) { cm.indentSelection('subtract'); },
        'Enter': 'newlineAndIndent'
      },
      hintOptions: { completeSingle: false, alignWithWord: true }
    });

    editor.getWrapperElement().style.fontSize = state.settings.fontSize + 'px';

    editor.on('inputRead', function (cm, change) {
      if (!change.text) return;
      if (!/[a-zA-Z_.$]/.test(change.text[0])) return;
      if (cm.state.completionActive) return;
      setTimeout(function () { cm.showHint({ hint: customHint, completeSingle: false }); }, 40);
    });

    function customHint(cm) {
      var cur = cm.getCursor();
      var tok = cm.getTokenAt(cur);
      var word = tok.string.slice(0, cur.ch - tok.start);
      if (!word) return null;
      var pool = FRAMEWORK_API.concat(JS_KEYWORDS);
      var seen = {}, list = [];
      for (var i = 0; i < pool.length; i++) {
        var n = pool[i];
        if (seen[n]) continue;
        if (n.toLowerCase().indexOf(word.toLowerCase()) !== 0) continue;
        seen[n] = 1;
        list.push({ text: n, displayText: n });
      }
      if (!list.length) return null;
      return { list: list, from: CodeMirror.Pos(cur.line, tok.start), to: CodeMirror.Pos(cur.line, tok.ch) };
    }
    CodeMirror.commands.autocomplete = function (cm) { cm.showHint({ hint: customHint }); };

    function autocorrect(cm) {
      if (!state.settings.autocorrect) return;
      var cur = cm.getCursor();
      var line = cm.getLine(cur.line);
      var before = line.slice(0, cur.ch);
      var m = before.match(/([A-Za-z_][A-Za-z0-9_]*)$/);
      if (!m) return;
      var fixed = CORRECTIONS[m[1]];
      if (!fixed) return;
      cm.replaceRange(fixed, { line: cur.line, ch: cur.ch - m[1].length }, cur);
    }
    editor.addKeyMap({
      'Space': function (cm) { autocorrect(cm); cm.replaceSelection(' ', 'end'); },
      'Enter': function (cm) { autocorrect(cm); cm.execCommand('newlineAndIndent'); },
      ';': function (cm) { autocorrect(cm); cm.replaceSelection(';', 'end'); },
      '.': function (cm) { autocorrect(cm); cm.replaceSelection('.', 'end'); },
      ',': function (cm) { autocorrect(cm); cm.replaceSelection(',', 'end'); }
    });

    editor.on('change', function () {
      if (!state.openFile) return;
      if (isMediaName(state.openFile)) return;
      state.files[state.openFile] = editor.getValue();
      save();
    });

    fileNameEl.text = state.openFile || 'untitled';
  }, 100);

  s.getEditor = function () { return editor; };
  s.iframe = iframe;
  s.consolePane = consolePane;
  s.projectNameEl = projectNameEl;
  s.fileNameEl = fileNameEl;

  s.push(toolbar, editorPane, previewPane, consolePane, editBar, bottomBar);
  return s;
}

function cmdCopy() {
  if (!editor) return;
  var sel = editor.getSelection();
  if (!sel) { toast('Nothing selected', 'warning'); return; }
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(sel).then(function () { toast('Copied', 'success'); }).catch(function () { fallbackCopy(sel); });
  } else { fallbackCopy(sel); }
}

function fallbackCopy(text) {
  var ta = document.createElement('textarea');
  ta.value = text;
  ta.style.cssText = 'position:fixed;left:-9999px;top:-9999px';
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); toast('Copied', 'success'); }
  catch (e) { toast('Copy failed', 'error'); }
  ta.remove();
}

function cmdCut() {
  if (!editor) return;
  var sel = editor.getSelection();
  if (!sel) { toast('Nothing selected', 'warning'); return; }
  fallbackCopy(sel);
  editor.replaceSelection('');
  toast('Cut', 'success');
}

function cmdPaste() {
  if (!editor) return;
  if (navigator.clipboard && navigator.clipboard.readText) {
    navigator.clipboard.readText().then(function (text) {
      if (!text) { toast('Clipboard empty', 'warning'); return; }
      editor.replaceSelection(text);
      toast('Pasted', 'success');
    }).catch(function () { toast('Paste blocked. Long-press editor.', 'warning'); });
  } else { toast('Paste not supported', 'warning'); }
}

function cmdClear() {
  if (!editor) return;
  if (!editor.getValue().trim()) { toast('Already empty', 'warning'); return; }
  confirm('Clear current file?', function () {
    editor.setValue('');
    editor.clearHistory();
    if (state.openFile && !isMediaName(state.openFile)) {
      state.files[state.openFile] = '';
      save();
    }
    toast('Cleared', 'success');
  });
}

var FRAMEWORK_API = ['create','app','text','button','view','row','col','spacer','screen','bottomBar','badge','iconBtn','scrollX','scrollY','img','avatar','svg','icons','dic','findDK','findDV','route','defaults','styles','toast','store','theme','spinner','skeleton','copy','formatTime','formatDate','formatAgo','animate','vibrate','notify','modal','confirm','alertBox','sheet','tabs','chip','chipGroup','page','emptyState','progressBar','switchToggle','avatarGroup','state','list','idb','apiFactory','longPress','onSwipe','render','$','$$','uid','clamp','escape','once','sleep','debounce','throttle','onReady','isMobile','isDark','number','money','modules','M','css','cssReset'];
var JS_KEYWORDS = ['const','let','var','function','return','if','else','for','while','do','break','continue','switch','case','default','try','catch','finally','throw','new','this','class','extends','super','import','export','from','async','await','yield','typeof','instanceof','delete','in','of','void','null','undefined','true','false','console','document','window','Math','JSON','Array','Object','String','Number','Boolean','Promise','log','warn','error','alert','setTimeout','setInterval','fetch','then','map','filter','reduce','forEach','push','pop','shift','unshift','splice','slice','length','indexOf','includes','join','split','replace','toUpperCase','toLowerCase','trim','parseInt','parseFloat'];
var CORRECTIONS = {'functon':'function','funciton':'function','fucntion':'function','retrun':'return','reutrn':'return','retunr':'return','consle':'console','consoel':'console','cnosole':'console','documnet':'document','docuemnt':'document','wndow':'window','windwo':'window','lenght':'length','legnth':'length','pritn':'print','elese':'else','ture':'true','flase':'false','nul':'null','udnefined':'undefined','undefiend':'undefined','Aray':'Array','Obejct':'Object','Stirng':'String','Nubmer':'Number','Booean':'Boolean','Proimse':'Promise','asycn':'async','awiat':'await','improt':'import','exprt':'export'};

function openModules() {
  sheet({
    title: 'Insert Module',
    items: [
      { icon: 'barChart', label: 'Bar Chart', onClick: function () { insertModule('barChart'); } },
      { icon: 'pieChart', label: 'Pie Chart', onClick: function () { insertModule('pieChart'); } },
      { icon: 'lineChart', label: 'Line Chart', onClick: function () { insertModule('lineChart'); } },
      { icon: 'image', label: 'QR Code', onClick: function () { insertModule('qrcode'); } },
      { icon: 'calendar', label: 'Date Picker', onClick: function () { insertModule('datePicker'); } },
      { icon: 'edit', label: 'Signature Pad', onClick: function () { insertModule('signature'); } },
      { icon: 'fileText', label: 'Markdown', onClick: function () { insertModule('markdown'); } },
      { icon: 'list', label: 'Virtual List', onClick: function () { insertModule('virtualList'); } }
    ]
  });
}

function paintFileList() {
  if (!screens.editor || !screens.editor.sheetBody) return;
  var body = screens.editor.sheetBody;
  body.clear();

  var allNames = state.fileList.slice();
  Object.keys(state.media).forEach(function (n) {
    if (allNames.indexOf(n) === -1) allNames.push(n);
  });

  if (!allNames.length) {
    var empty = create('div');
    empty.el.style.cssText = 'padding:32px 16px;text-align:center;color:var(--text-light);font-size:13px;font-weight:600';
    empty.push(iconSvg('file', 36, 'var(--gray-dark)'));
    var txt = create('div','No files yet');
    txt.el.style.cssText = 'margin-top:12px';
    empty.push(txt);
    var hint = create('div','Tap "New File" or "Import File" below');
    hint.el.style.cssText = 'font-size:11px;margin-top:4px;color:var(--gray-dark)';
    empty.push(hint);
    body.push(empty);
    return;
  }

  allNames.forEach(function (name) {
    var isMedia = isMediaName(name);
    var cat = fileCategory(name);
    var row = create('div');
    row.el.style.cssText = 'display:flex;flex-direction:row;align-items:center;gap:10px;padding:12px;border-radius:12px;margin-bottom:4px;cursor:pointer';
    if (state.openFile === name) row.el.style.background = GREEN + '22';

    var ic = create('div');
    ic.el.style.cssText = 'width:36px;height:36px;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0;overflow:hidden;background:' + (state.openFile === name ? GREEN : 'var(--bg-soft)');

    if (isMedia && cat === 'image') {
      var im = document.createElement('img');
      im.src = state.media[name].dataUrl;
      im.style.cssText = 'width:100%;height:100%;object-fit:cover';
      ic.el.appendChild(im);
    } else {
      var iconName = cat === 'video' ? 'video' : cat === 'audio' ? 'volume' : cat === 'code' ? 'code' : isMedia ? 'file' : 'fileText';
      ic.push(iconSvg(iconName, 18, state.openFile === name ? '#fff' : 'var(--text)'));
    }

    var mid = create('div');
    mid.el.style.cssText = 'flex:1;min-width:0';

    var label = create('div', name);
    label.el.style.cssText = 'font-size:14px;color:var(--text);font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
    if (state.openFile === name) label.el.style.color = GREEN_DARK;

    var meta = create('div', cat.toUpperCase() + (isMedia ? ' · ' + fmtSize(state.media[name].size) : ''));
    meta.el.style.cssText = 'font-size:10px;color:var(--text-light);font-weight:600;margin-top:2px';

    mid.push(label, meta);

    var dots = create('button');
    dots.el.style.cssText = 'width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center';
    dots.push(iconSvg('moreV', 16, 'var(--text-light)'));
    dots.onClick = function (e) { e.stopPropagation(); fileActions(name); };

    row.push(ic, mid, dots);
    row.onClick = function () {
      if (isMedia) {
        previewFile(name);
        return;
      }
      state.openFile = name;
      if (editor) {
        editor.setValue(state.files[name] || '');
        editor.clearHistory();
        editor.refresh();
      }
      if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = name;
      paintFileList();
      save();
      if (screens.editor && screens.editor.closeSheet) screens.editor.closeSheet();
      if (screens.editor) screens.editor.setTab('editor');
    };
    body.push(row);
  });
}

function fmtSize(n) {
  if (n == null) return '';
  if (n < 1024) return n + ' B';
  if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
  return (n / 1024 / 1024).toFixed(2) + ' MB';
}

function fileActions(name) {
  var isMedia = isMediaName(name);
  var items = [];
  items.push({ icon: 'eye', label: 'Preview', onClick: function () { previewFile(name); } });
  if (!isMedia) {
    items.push({ icon: 'edit', label: 'Rename', onClick: function () { renameFile(name); } });
    items.push({ icon: 'copy', label: 'Duplicate', onClick: function () { duplicateFile(name); } });
  }
  items.push({ icon: 'download', label: 'Download to device', onClick: function () { downloadFile(name); } });
  if (isMedia) {
    items.push({ icon: 'code', label: 'Insert into code', onClick: function () { insertMediaRef(name); } });
  }
  items.push({ icon: 'trash', label: 'Delete', danger: true, onClick: function () { deleteFile(name); } });
  sheet({ title: name, items: items });
}

function previewFile(name) {
  var isMedia = isMediaName(name);
  var cat = fileCategory(name);

  var body = create('div');
  body.el.style.cssText = 'display:flex;flex-direction:column;gap:12px;max-height:70vh;overflow:hidden';

  if (isMedia && cat === 'image') {
    var im = document.createElement('img');
    im.src = state.media[name].dataUrl;
    im.style.cssText = 'width:100%;max-height:55vh;object-fit:contain;border-radius:16px;background:#111';
    body.el.appendChild(im);
  } else if (isMedia && cat === 'video') {
    var vd = document.createElement('video');
    vd.src = state.media[name].dataUrl;
    vd.controls = true;
    vd.style.cssText = 'width:100%;max-height:55vh;border-radius:16px;background:#000';
    body.el.appendChild(vd);
  } else if (isMedia && cat === 'audio') {
    var au = document.createElement('audio');
    au.src = state.media[name].dataUrl;
    au.controls = true;
    au.style.cssText = 'width:100%';
    body.el.appendChild(au);
  } else {
    var pre = document.createElement('pre');
    pre.style.cssText = 'background:var(--bg-soft);padding:12px;border-radius:12px;font-size:12px;max-height:55vh;overflow:auto;white-space:pre-wrap;word-break:break-all;margin:0;color:var(--text)';
    pre.textContent = isMedia ? '[binary ' + fmtSize(state.media[name].size) + ']' : (state.files[name] || '');
    body.el.appendChild(pre);
  }

  var meta = create('div');
  meta.el.style.cssText = 'font-size:11px;color:var(--text-light);font-weight:600;text-align:center';
  meta.text = isMedia ? cat.toUpperCase() + ' · ' + fmtSize(state.media[name].size) : fileCategory(name).toUpperCase() + ' · ' + (state.files[name] || '').length + ' chars';

  var actions = create('div');
  actions.el.style.cssText = 'display:flex;flex-direction:row;gap:8px';

  if (!isMedia) {
    var editBtn = makeBtn('Edit', GREEN, GREEN_DARK, function () {
      state.openFile = name;
      if (editor) {
        editor.setValue(state.files[name] || '');
        editor.clearHistory();
        editor.refresh();
      }
      if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = name;
      paintFileList();
      save();
      if (screens.editor && screens.editor.setTab) screens.editor.setTab('editor');
    });
    editBtn.el.style.flex = '1';
    actions.push(editBtn);
  }

  if (isMedia && cat === 'image') {
    var insertBtn = makeBtn('Insert img()', BLUE, BLUE_DARK, function () { insertMediaRef(name); });
    insertBtn.el.style.flex = '1';
    actions.push(insertBtn);
  }

  var dlBtn = makeGhostBtn('Save', function () { downloadFile(name); });
  dlBtn.el.style.flex = '1';
  actions.push(dlBtn);

  body.push(meta, actions);

  modal({
    title: name,
    body: body,
    buttons: [{ label: 'Close', primary: true }]
  });
}

function insertMediaRef(name) {
  if (!editor) { toast('Open a code file first', 'warning'); return; }
  if (!state.openFile || isMediaName(state.openFile)) {
    var codeFile = state.fileList.filter(function (n) { return !isMediaName(n); })[0];
    if (codeFile) {
      state.openFile = codeFile;
      editor.setValue(state.files[codeFile] || '');
      editor.clearHistory();
      if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = codeFile;
    }
  }
  var cat = fileCategory(name);
  var snippet;
  if (cat === 'image') {
    snippet = 'img("' + name + '", "' + name + '", "w-full rounded-2xl")';
  } else if (cat === 'video') {
    snippet = 'var v = create("video");\nv.src = window.__FILES["' + name + '"];\nv.el.controls = true;\nv.style = "w-full rounded-2xl";\nroot.push(v);';
  } else if (cat === 'audio') {
    snippet = 'var a = create("audio");\na.src = window.__FILES["' + name + '"];\na.el.controls = true;\nroot.push(a);';
  } else {
    snippet = '"' + name + '"';
  }
  editor.replaceSelection(snippet);
  if (screens.editor && screens.editor.setTab) screens.editor.setTab('editor');
  toast('Inserted ' + name, 'success');
}

function renameFile(name) {
  askName('New name', name, function (nv) {
    if (!nv || nv === name) return;
    state.files[nv] = state.files[name];
    delete state.files[name];
    var idx = state.fileList.indexOf(name);
    if (idx !== -1) state.fileList[idx] = nv;
    if (state.openFile === name) state.openFile = nv;
    save();
    paintFileList();
    if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = state.openFile || '';
  });
}

function duplicateFile(name) {
  var dot = name.lastIndexOf('.');
  var base = dot === -1 ? name : name.slice(0, dot);
  var ext = dot === -1 ? '' : name.slice(dot);
  var copy = uniqueName(base + '_copy', ext);
  state.files[copy] = state.files[name];
  state.fileList.push(copy);
  save();
  paintFileList();
}

function deleteFile(name) {
  confirm('Delete ' + name + '?', function () {
    if (isMediaName(name)) {
      dbDeleteMedia(name).then(function () {
        delete state.media[name];
        paintFileList();
        if (screens.home && screens.home.paintRecent) screens.home.paintRecent();
        toast('Deleted ' + name, 'error');
      });
      return;
    }
    delete state.files[name];
    var idx = state.fileList.indexOf(name);
    if (idx !== -1) state.fileList.splice(idx, 1);
    if (state.openFile === name) {
      state.openFile = state.fileList[0] || null;
      if (editor) editor.setValue(state.openFile ? state.files[state.openFile] : '');
      if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = state.openFile || 'untitled';
    }
    save();
    paintFileList();
    if (screens.home && screens.home.paintRecent) screens.home.paintRecent();
  });
}

function downloadFile(name) {
  if (isMediaName(name)) {
    var m = state.media[name];
    if (window.Android && Android.saveToDownloads) {
      var b64 = m.dataUrl.split(',')[1] || '';
      Android.saveToDownloads(name, b64);
      toast('Saved: Downloads/' + name, 'success');
      return;
    }
    var a = document.createElement('a');
    a.href = m.dataUrl;
    a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    toast('Downloaded: ' + name, 'success');
    return;
  }
  var content = state.files[name] || '';
  if (window.Android && Android.saveToDownloads) {
    Android.saveToDownloads(name, content);
    toast('Saved: Downloads/' + name, 'success');
    return;
  }
  var blob = new Blob([content], { type: 'text/plain' });
  var u = URL.createObjectURL(blob);
  var a2 = document.createElement('a');
  a2.href = u; a2.download = name;
  document.body.appendChild(a2); a2.click(); a2.remove();
  setTimeout(function () { URL.revokeObjectURL(u); }, 1000);
  toast('Downloaded: ' + name, 'success');
}

function insertModule(name) {
  if (!editor) return;
  var snippets = {
    barChart: 'var chart = modules.barChart([\n  { label: "Mon", value: 12 },\n  { label: "Tue", value: 19 },\n  { label: "Wed", value: 8 }\n], { title: "Sales" });\nroot.push(chart);\n',
    pieChart: 'var pie = modules.pieChart([\n  { label: "A", value: 45 },\n  { label: "B", value: 30 },\n  { label: "C", value: 25 }\n], { title: "Split" });\nroot.push(pie);\n',
    lineChart: 'var line = modules.lineChart([\n  { label: "W1", value: 20 },\n  { label: "W2", value: 45 },\n  { label: "W3", value: 60 }\n], { title: "Growth" });\nroot.push(line);\n',
    qrcode: 'var qr = modules.qrcode("https://example.com", { size: 200 });\nroot.push(qr);\n',
    datePicker: 'var dp = modules.datePicker({\n  onChange: function (val) { toast("Picked: " + val); }\n});\nroot.push(dp);\n',
    signature: 'var sig = modules.signature({\n  height: 200,\n  onSave: function (dataUrl) { console.log("Saved"); }\n});\nroot.push(sig);\n',
    markdown: 'var md = modules.markdown("# Hello\\n\\nThis is **bold**.");\nroot.push(md);\n',
    virtualList: 'var items = [];\nfor (var i = 0; i < 1000; i++) items.push({ id: i, name: "Item " + i });\nvar v = modules.virtualList(items, function (it) {\n  var r = create("div", it.name);\n  r.style = "p-3 border-b border-gray-200";\n  return r;\n}, { rowHeight: 50 });\nroot.push(v);\n'
  };
  editor.replaceSelection(snippets[name] || '');
  screens.editor.setTab('editor');
}

function b64Encode(str) {
  var bytes = new TextEncoder().encode(String(str));
  var bin = '';
  var chunk = 0x8000;
  for (var i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

function bytesToBase64(bytes) {
  var bin = '';
  var chunk = 0x8000;
  for (var i = 0; i < bytes.length; i += chunk) {
    bin += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(bin);
}

function guessMime(name) {
  var ext = fileExt(name);
  var m = {
    png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif',
    webp: 'image/webp', bmp: 'image/bmp', svg: 'image/svg+xml',
    mp4: 'video/mp4', webm: 'video/webm', mov: 'video/quicktime',
    mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', m4a: 'audio/mp4'
  };
  return m[ext] || 'application/octet-stream';
}

function mediaFileMapScript() {
  var obj = {};
  Object.keys(state.media).forEach(function (n) {
    obj[n] = state.media[n].dataUrl;
  });
  return 'window.__FILES = ' + JSON.stringify(obj) + ';';
}

function buildHTML(userCode) {
  var base = window.location.href.replace(/[^\/]*$/, '');
  var encoded = b64Encode(userCode);
  var fmScript = mediaFileMapScript();
  return [
    '<!DOCTYPE html>',
    '<html>',
    '<head>',
    '<base href="' + base + '">',
    '<meta charset="utf-8">',
    '<meta name="viewport" content="width=device-width,initial-scale=1">',
    '<script src="tailwind.js"><\/script>',
    '<script>try{tailwind.config={darkMode:"class"}}catch(e){}<\/script>',
    '<script src="icons.js"><\/script>',
    '<script>' + fmScript + '<\/script>',
    '<script src="framework/framework.js"><\/script>',
    '<script src="modules.js"><\/script>',
    '<\/head>',
    '<body>',
    '<div id="root"><\/div>',
    '<script>',
    '(function(){',
    'function __log(level,args){',
    'try{var m=[];for(var i=0;i<args.length;i++){var a=args[i];m.push(typeof a==="object"?JSON.stringify(a):String(a));}',
    'parent.postMessage({type:"log",level:level,message:m.join(" ")},"*");}catch(e){}',
    '}',
    'console.log=function(){__log("log",arguments);};',
    'console.warn=function(){__log("warn",arguments);};',
    'console.error=function(){__log("error",arguments);};',
    'window.addEventListener("error",function(e){__log("error",[e.message+" (line "+e.lineno+")"]);});',
    'window.vibrate=function(ms){try{parent.postMessage({type:"vibrate",ms:ms||50},"*");}catch(e){}};',
    'var __origImg=window.img;',
    'window.img=function(src,alt){',
    'if(window.__FILES&&window.__FILES[src])src=window.__FILES[src];',
    'var args=Array.prototype.slice.call(arguments);',
    'args[0]=src;',
    'return __origImg.apply(null,args);',
    '};',
    'function __decode(b64){',
    'var bin=atob(b64);',
    'var bytes=new Uint8Array(bin.length);',
    'for(var i=0;i<bin.length;i++)bytes[i]=bin.charCodeAt(i);',
    'return new TextDecoder().decode(bytes);',
    '}',
    'function __ready(){',
    'if(typeof window.app!=="function"){setTimeout(__ready,50);return;}',
    'try{',
    'var __code=__decode("' + encoded + '");',
    '(new Function(__code))();',
    '}catch(e){__log("error",[e.message]);}',
    '}',
    'window.addEventListener("load",__ready);',
    '})();',
    '<\/script>',
    '<\/body>',
    '<\/html>'
  ].join('\n');
}

function runCode() {
  var code = '';
  if (state.openFile && !isMediaName(state.openFile)) {
    code = editor ? editor.getValue() : '';
  } else {
    var firstCode = state.fileList.filter(function (n) { return !isMediaName(n); })[0];
    if (firstCode) code = state.files[firstCode] || '';
  }
  if (screens.editor && screens.editor.consolePane) screens.editor.consolePane.clear();
  if (!screens.editor || !screens.editor.iframe) return;
  var iframeEl = screens.editor.iframe.el;
  var html = buildHTML(code);
  // FIX: srcdoc has a size limit — fall back to a Blob URL for very large code.
  if (html.length < 1500000) {
    iframeEl.removeAttribute('src');
    iframeEl.srcdoc = html;
  } else {
    iframeEl.removeAttribute('srcdoc');
    var blob = new Blob([html], { type: 'text/html' });
    var url = URL.createObjectURL(blob);
    iframeEl.src = url;
    iframeEl.onload = function () {
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    };
  }
  setTimeout(function () { if (screens.editor) screens.editor.setTab('preview'); }, 80);
}

function exportProject() {
  askName('App name', state.projectName, function (name) {
    state.projectName = name;
    save();
    if (screens.editor && screens.editor.projectNameEl) screens.editor.projectNameEl.text = name;

    if (!window.Android || !Android.readAsset || !Android.saveZipToDownloads) {
      toast('Export needs the Android app.', 'error');
      return;
    }

    var tailwindJs = Android.readAsset('tailwind.js');
    var iconsJs = Android.readAsset('icons.js');
    var frameworkJs = Android.readAsset('framework/framework.js');
    var modulesJs = Android.readAsset('modules.js');

    var missing = [];
    if (!tailwindJs) missing.push('tailwind.js');
    if (!iconsJs) missing.push('icons.js');
    if (!frameworkJs) missing.push('framework/framework.js');
    if (!modulesJs) missing.push('modules.js');
    if (missing.length) {
      toast('Missing in assets/: ' + missing.join(', '), 'error', 5000);
      return;
    }

    var allCode = state.fileList.filter(function (n) { return !isMediaName(n); });
    var mainCode = state.openFile && !isMediaName(state.openFile) && editor
      ? editor.getValue()
      : (allCode.length ? state.files[allCode[0]] : '');

    if (!mainCode.trim()) { toast('No code to export', 'warning'); return; }

    var safeName = name.replace(/[^A-Za-z0-9_-]/g, '_');
    var zipName = safeName + '.zip';

    var mediaMap = {};
    Object.keys(state.media).forEach(function (n) {
      mediaMap[n] = state.media[n].dataUrl;
    });
    var filesJs = 'window.__FILES = ' + JSON.stringify(mediaMap) + ';';

    var indexHtml = [
      '<!DOCTYPE html>',
      '<html>',
      '<head>',
      '<meta charset="utf-8">',
      '<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">',
      '<title>' + name + '</title>',
      '<script src="tailwind.js"><\/script>',
      '<script>try{tailwind.config={darkMode:"class"}}catch(e){}<\/script>',
      '<script src="icons.js"><\/script>',
      '<script src="files.js"><\/script>',
      '<script src="framework/framework.js"><\/script>',
      '<script src="modules.js"><\/script>',
      '<\/head>',
      '<body>',
      '<div id="root"><\/div>',
      '<script>',
      '(function(){',
      'var __origImg=window.img;',
      'window.img=function(src,alt){',
      'if(window.__FILES&&window.__FILES[src])src=window.__FILES[src];',
      'var args=Array.prototype.slice.call(arguments);',
      'args[0]=src;',
      'return __origImg.apply(null,args);',
      '};',
      '})();',
      '<\/script>',
      '<script src="js/app.js"><\/script>',
      '<\/body>',
      '<\/html>'
    ].join('\n');

    var zipFiles = [
      { name: 'index.html', content: indexHtml },
      { name: 'tailwind.js', content: tailwindJs },
      { name: 'icons.js', content: iconsJs },
      { name: 'modules.js', content: modulesJs },
      { name: 'files.js', content: filesJs },
      { name: 'framework/framework.js', content: frameworkJs },
      { name: 'js/app.js', content: mainCode }
    ];

    Object.keys(state.media).forEach(function (n) {
      var m = state.media[n];
      var b64 = m.dataUrl.split(',')[1] || '';
      zipFiles.push({ name: 'assets/' + n, content: b64, base64: true });
    });

    try {
      Android.saveZipToDownloads(zipName, JSON.stringify(zipFiles));
      toast('Saved to Downloads/' + zipName, 'success', 4000);
    } catch (e) {
      toast('Export failed: ' + e.message, 'error');
    }
  });
}

function importAnyFile() {
  var input = document.createElement('input');
  input.type = 'file';
  input.multiple = true;
  input.accept = '*/*';
  input.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0';
  document.body.appendChild(input);
  input.onchange = function () {
    var files = input.files;
    if (!files || !files.length) { input.remove(); return; }
    var arr = Array.prototype.slice.call(files);
    var i = 0;

    function next() {
      if (i >= arr.length) {
        save();
        paintFileList();
        if (screens.editor && screens.editor.closeSheet) screens.editor.closeSheet();
        toast('Imported ' + arr.length + ' file(s)', 'success');
        input.remove();
        return;
      }
      var f = arr[i++];
      processFile(f, next);
    }
    next();
  };
  input.click();
}

function processFile(file, done) {
  var name = file.name || 'file';
  var type = file.type || '';
  var isMedia = type.indexOf('image/') === 0 ||
                type.indexOf('video/') === 0 ||
                type.indexOf('audio/') === 0 ||
                /\.(png|jpg|jpeg|gif|webp|bmp|svg|mp4|webm|mov|mp3|wav|ogg|m4a)$/i.test(name);

  var reader = new FileReader();

  if (isMedia) {
    reader.onload = function () {
      var dataUrl = reader.result;
      if (state.media[name]) {
        var dot = name.lastIndexOf('.');
        var base = dot === -1 ? name : name.slice(0, dot);
        var ext = dot === -1 ? '' : name.slice(dot);
        name = uniqueName(base, ext);
      }
      dbPutMedia({
        name: name,
        dataUrl: dataUrl,
        type: type || 'application/octet-stream',
        size: file.size,
        time: Date.now()
      }).then(function () {
        state.media[name] = {
          name: name,
          dataUrl: dataUrl,
          type: type,
          size: file.size,
          time: Date.now()
        };
        done();
      }).catch(function () { done(); });
    };
    reader.onerror = function () { done(); };
    reader.readAsDataURL(file);
  } else {
    reader.onload = function () {
      var text = reader.result;
      if (state.files[name]) {
        var dot = name.lastIndexOf('.');
        var base = dot === -1 ? name : name.slice(0, dot);
        var ext = dot === -1 ? '' : name.slice(dot);
        name = uniqueName(base, ext);
      }
      state.files[name] = text;
      state.fileList.push(name);
      state.openFile = name;
      if (editor) {
        editor.setValue(text);
        editor.clearHistory();
        editor.refresh();
      }
      if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = name;
      if (screens.editor && screens.editor.setTab) screens.editor.setTab('editor');
      done();
    };
    reader.onerror = function () { done(); };
    reader.readAsText(file);
  }
}

// FIX: proper ZIP import via Java bridge. Requires Android.unzipToJson(b64String)
// which returns a JSON array like:
//   [{"name":"js/app.js","content":"...","base64":false}, ...]
// The Java side must decode b64 -> byte[], open ZipInputStream, and return UTF-8
// for text entries and base64 for binary entries.
function importProject() {
  var input = document.createElement('input');
  input.type = 'file';
  input.accept = '.zip,application/zip';
  input.style.cssText = 'position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0';
  document.body.appendChild(input);
  input.onchange = function () {
    var f = input.files && input.files[0];
    if (!f) { input.remove(); return; }

    if (!window.Android || !Android.unzipToJson) {
      toast('ZIP import needs updated Android bridge (unzipToJson)', 'error', 4000);
      input.remove();
      return;
    }

    var reader = new FileReader();
    reader.onload = function () {
      try {
        var bytes = new Uint8Array(reader.result);
        var b64 = bytesToBase64(bytes);
        var json = Android.unzipToJson(b64);
        var entries = JSON.parse(json);
        if (!entries || !entries.length) {
          toast('Empty ZIP', 'error');
          input.remove();
          return;
        }

        var appJs = null;
        var pname = 'Imported';
        var mediaEntries = [];

        for (var i = 0; i < entries.length; i++) {
          var e = entries[i];
          if (e.name === 'js/app.js') {
            appJs = e.base64 ? atob(e.content) : e.content;
          } else if (e.name === 'index.html') {
            var m = String(e.content).match(/<title>([^<]*)<\/title>/);
            if (m) pname = m[1];
          } else if (e.name.indexOf('assets/') === 0) {
            mediaEntries.push(e);
          }
        }

        if (appJs == null) {
          toast('No js/app.js in ZIP', 'error');
          input.remove();
          return;
        }

        state.projectName = pname;
        state.files = { 'main.js': appJs };
        state.fileList = ['main.js'];
        state.openFile = 'main.js';

        // restore media
        var pending = [];
        state.media = {};
        mediaEntries.forEach(function (e) {
          var name = e.name.slice(7); // strip "assets/"
          var mime = guessMime(name);
          var b64data = e.base64 ? e.content : b64Encode(e.content);
          var dataUrl = 'data:' + mime + ';base64,' + b64data;
          var size = e.base64 ? Math.floor(e.content.length * 0.75) : e.content.length;
          var rec = { name: name, dataUrl: dataUrl, type: mime, size: size, time: Date.now() };
          state.media[name] = rec;
          pending.push(dbPutMedia(rec).catch(function () {}));
        });

        Promise.all(pending).then(function () {
          save();
          toast('Imported: ' + pname, 'success');
          openEditor();
        });
      } catch (err) {
        toast('Import failed: ' + err.message, 'error');
      }
      input.remove();
    };
    reader.onerror = function () {
      toast('Read failed', 'error');
      input.remove();
    };
    reader.readAsArrayBuffer(f);
  };
  input.click();
}

function goHome() {
  state.screen = 'home';
  if (screens.home) screens.home.el.style.display = 'flex';
  if (screens.editor) screens.editor.el.style.display = 'none';
  if (screens.home && screens.home.paintRecent) screens.home.paintRecent();
}

function openEditor() {
  state.screen = 'editor';
  if (screens.home) screens.home.el.style.display = 'none';
  if (screens.editor) screens.editor.el.style.display = 'flex';
  if (editor && state.openFile && !isMediaName(state.openFile)) {
    editor.setValue(state.files[state.openFile] || '');
    editor.clearHistory();
    editor.refresh();
    editor.focus();
  }
  if (screens.editor && screens.editor.fileNameEl) screens.editor.fileNameEl.text = state.openFile || 'untitled';
  if (screens.editor && screens.editor.projectNameEl) screens.editor.projectNameEl.text = state.projectName;
  if (screens.editor) screens.editor.setTab('editor');
  applySettings();
}

window.addEventListener('message', function (e) {
  if (!e.data) return;
  if (e.data.type === 'log') {
    var level = e.data.level || 'log';
    var color = level === 'error' ? '#f87171' : level === 'warn' ? '#fbbf24' : '#4ade80';
    var row = create('div','[' + level + '] ' + e.data.message);
    row.el.style.cssText = 'color:' + color + ';padding:3px 0;border-bottom:1px solid #333;white-space:pre-wrap;word-break:break-word';
    if (screens.editor && screens.editor.consolePane) {
      screens.editor.consolePane.push(row);
      screens.editor.consolePane.el.scrollTop = screens.editor.consolePane.el.scrollHeight;
    }
  }
  if (e.data.type === 'vibrate') {
    try {
      if (window.Android && Android.vibrate) {
        Android.vibrate(Math.round(Number(e.data.ms) || 50));
      }
    } catch (err) {}
  }
});

load();
loadMediaIntoState().then(function () {
  screens.home = buildHome();
  screens.editor = buildEditor();
  root.push(screens.home, screens.editor);
  goHome();
});