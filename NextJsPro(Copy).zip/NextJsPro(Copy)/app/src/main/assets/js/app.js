var root = app();
root.style = 'h-screen w-screen flex flex-col bg-gray-900 text-white overflow-hidden';

var toolbar = create('div');
toolbar.style = 'flex flex-row items-center gap-2 p-2 bg-gray-800 border-b border-gray-700';

var title = create('div', 'editor.js');
title.style = 'font-bold text-sm';

var clearBtn = create('button', 'Clear');
clearBtn.style = 'bg-gray-700 px-3 py-1 rounded text-sm';

var runBtn = create('button', 'Run');
runBtn.style = 'bg-green-500 px-3 py-1 rounded text-sm font-bold';

toolbar.push(title, spacer(), clearBtn, runBtn);

var editorPane = create('div');
editorPane.style = 'flex-1 overflow-hidden relative';

var previewPane = create('div');
previewPane.style = 'hidden';

var consolePane = create('div');
consolePane.style = 'hidden';

var tabBar = create('div');
tabBar.style = 'flex flex-row bg-gray-800 border-t border-gray-700';

root.push(toolbar, editorPane, previewPane, consolePane, tabBar);

var iframe = create('iframe');
iframe.el.style.cssText = 'width:100%;height:100%;border:none;background:#fff;display:block';
previewPane.push(iframe);

var TABS = [
  { id: 'editor',  label: 'Editor',  icon: 'code' },
  { id: 'preview', label: 'Preview', icon: 'play' },
  { id: 'console', label: 'Console', icon: 'terminal' }
];

var tabButtons = {};
var currentTab = 'editor';

function setTab(id) {
  currentTab = id;
  for (var k in tabButtons) {
    if (!tabButtons.hasOwnProperty(k)) continue;
    var on = k === id;
    tabButtons[k].style = 'flex-1 flex flex-col items-center py-2 gap-1 ' +
      (on ? 'text-blue-400 border-t-2 border-blue-400'
          : 'text-gray-400 border-t-2 border-transparent');
  }
  editorPane.style  = id === 'editor'  ? 'flex-1 overflow-hidden relative' : 'hidden';
  previewPane.style = id === 'preview' ? 'flex-1 overflow-hidden relative bg-white' : 'hidden';
  consolePane.style = id === 'console'
    ? 'flex-1 overflow-auto bg-black text-green-400 p-3 font-mono text-xs'
    : 'hidden';
}

for (var ti = 0; ti < TABS.length; ti++) {
  (function (t) {
    var btn = create('button');
    var lbl = create('div', t.label);
    lbl.style = 'text-[10px] font-bold';
    btn.push(svg(t.icon, 'w-5 h-5'), lbl);
    btn.onClick = function () { setTab(t.id); };
    tabButtons[t.id] = btn;
    tabBar.push(btn);
  })(TABS[ti]);
}

var FRAMEWORK_API = [
  'create', 'app', 'text', 'button', 'view',
  'row', 'col', 'spacer', 'screen', 'bottomBar',
  'badge', 'iconBtn', 'scrollX', 'scrollY',
  'img', 'avatar', 'svg', 'icons',
  'dic', 'findDK', 'findDV',
  'route', 'defaults', 'styles',
  'toast', 'store', 'theme',
  'spinner', 'skeleton', 'copy',
  'formatTime', 'formatDate', 'formatAgo',
  'animate'
];

var JS_KEYWORDS = [
  'const', 'let', 'var', 'function', 'return', 'if', 'else',
  'for', 'while', 'do', 'break', 'continue', 'switch', 'case',
  'default', 'try', 'catch', 'finally', 'throw', 'new', 'this',
  'class', 'extends', 'super', 'import', 'export', 'from',
  'async', 'await', 'yield', 'typeof', 'instanceof', 'delete',
  'in', 'of', 'void', 'null', 'undefined', 'true', 'false',
  'console', 'document', 'window', 'Math', 'JSON',
  'Array', 'Object', 'String', 'Number', 'Boolean', 'Promise',
  'log', 'warn', 'error', 'alert', 'setTimeout', 'setInterval',
  'fetch', 'then', 'map', 'filter', 'reduce', 'forEach',
  'push', 'pop', 'shift', 'unshift', 'splice', 'slice',
  'length', 'indexOf', 'includes', 'join', 'split', 'replace',
  'toUpperCase', 'toLowerCase', 'trim', 'parseInt', 'parseFloat'
];

var CORRECTIONS = {
  'functon': 'function', 'funciton': 'function', 'fucntion': 'function',
  'retrun': 'return', 'reutrn': 'return', 'retunr': 'return',
  'consle': 'console', 'consoel': 'console', 'cnosole': 'console',
  'documnet': 'document', 'docuemnt': 'document',
  'wndow': 'window', 'windwo': 'window',
  'lenght': 'length', 'legnth': 'length',
  'pritn': 'print', 'elese': 'else',
  'ture': 'true', 'flase': 'false', 'nul': 'null',
  'udnefined': 'undefined', 'undefiend': 'undefined',
  'Aray': 'Array', 'Obejct': 'Object', 'Stirng': 'String',
  'Nubmer': 'Number', 'Booean': 'Boolean', 'Proimse': 'Promise',
  'asycn': 'async', 'awiat': 'await',
  'improt': 'import', 'exprt': 'export'
};

var editor;

setTimeout(function () {
  editor = CodeMirror(editorPane.el, {
    value:
      '// Write your app code here.\n' +
      '// Tap Run to render it in the Preview tab.\n\n' +
      'var root = app();\n' +
      'root.style = "p-6 flex flex-col gap-4";\n\n' +
      'var t = create("h1", "Hello world");\n' +
      't.style = "text-2xl font-bold";\n\n' +
      'var b = create("button", "Tap me");\n' +
      'b.style = "bg-blue-500 text-white p-3 rounded";\n' +
      'b.onClick = function () {\n' +
      '  console.log("clicked!");\n' +
      '  toast("You clicked");\n' +
      '};\n\n' +
      'root.push(t, b);\n',

    mode: 'javascript',
    lineNumbers: true,
    lineWrapping: true,
    autofocus: true,
    indentUnit: 2,
    tabSize: 2,
    indentWithTabs: false,
    autoCloseBrackets: true,
    matchBrackets: true,
    autoCloseTags: true,
    viewportMargin: 20,

    extraKeys: {
      'Ctrl-Space': 'autocomplete',
      'Tab': function (cm) {
        if (cm.somethingSelected()) cm.indentSelection('add');
        else cm.replaceSelection('  ', 'end');
      },
      'Shift-Tab': function (cm) { cm.indentSelection('subtract'); },
      'Enter': 'newlineAndIndent'
    },
    hintOptions: { completeSingle: false, alignWithWord: true }
  });

  editor.on('inputRead', function (cm, change) {
    if (!change.text) return;
    if (!/[a-zA-Z_.$]/.test(change.text[0])) return;
    if (cm.state.completionActive) return;
    setTimeout(function () {
      cm.showHint({ hint: customHint, completeSingle: false });
    }, 40);
  });

  function customHint(cm) {
    var cur = cm.getCursor();
    var tok = cm.getTokenAt(cur);
    var word = tok.string.slice(0, cur.ch - tok.start);
    if (!word) return null;
    var pool = FRAMEWORK_API.concat(JS_KEYWORDS);
    var seen = {}, list = [];
    for (var i = 0; i < pool.length; i++) {
      var n = pool[i];
      if (seen[n]) continue;
      if (n.toLowerCase().indexOf(word.toLowerCase()) !== 0) continue;
      seen[n] = 1;
      list.push({ text: n, displayText: n });
    }
    if (!list.length) return null;
    return {
      list: list,
      from: CodeMirror.Pos(cur.line, tok.start),
      to: CodeMirror.Pos(cur.line, cur.ch)
    };
  }
  CodeMirror.commands.autocomplete = function (cm) {
    cm.showHint({ hint: customHint });
  };

  function autocorrect(cm) {
    var cur = cm.getCursor();
    var line = cm.getLine(cur.line);
    var before = line.slice(0, cur.ch);
    var m = before.match(/([A-Za-z_][A-Za-z0-9_]*)$/);
    if (!m) return;
    var fixed = CORRECTIONS[m[1]];
    if (!fixed) return;
    cm.replaceRange(fixed, { line: cur.line, ch: cur.ch - m[1].length }, cur);
  }
  editor.addKeyMap({
    'Space': function (cm) { autocorrect(cm); cm.replaceSelection(' ', 'end'); },
    'Enter': function (cm) { autocorrect(cm); cm.execCommand('newlineAndIndent'); },
    ';': function (cm) { autocorrect(cm); cm.replaceSelection(';', 'end'); },
    '.': function (cm) { autocorrect(cm); cm.replaceSelection('.', 'end'); },
    ',': function (cm) { autocorrect(cm); cm.replaceSelection(',', 'end'); }
  });

  editor.on('change', function () {
    try { localStorage.setItem('editor_content', editor.getValue()); } catch (e) {}
  });
  try {
    var saved = localStorage.getItem('editor_content');
    if (saved) editor.setValue(saved);
  } catch (e) {}

  setTab('editor');
}, 100);

window.addEventListener('message', function (e) {
  if (!e.data || e.data.type !== 'log') return;
  var level = e.data.level || 'log';
  var color =
    level === 'error' ? '#f87171' :
    level === 'warn'  ? '#fbbf24' :
    '#4ade80';
  var row = create('div', '[' + level + '] ' + e.data.message);
  row.style = 'color:' + color + ';padding:3px 0;border-bottom:1px solid #1f2937;white-space:pre-wrap;word-break:break-word';
  consolePane.push(row);
  consolePane.el.scrollTop = consolePane.el.scrollHeight;
});

function buildHTML(userCode) {
  var base = window.location.href.replace(/[^\/]*$/, '');

  return [
    '<!DOCTYPE html>',
    '<html>',
    '<head>',
    '  <base href="' + base + '">',
    '  <meta charset="utf-8">',
    '  <meta name="viewport" content="width=device-width,initial-scale=1">',
    '  <script src="tailwind.js"><\/script>',
    '  <script>try{tailwind.config={darkMode:"class"}}catch(e){}<\/script>',
    '  <script src="icons.js"><\/script>',
    '  <script src="framework/framework.js"><\/script>',
    '  <style>html,body{margin:0;min-height:100%;font-family:system-ui,sans-serif;}<\/style>',
    '  <script>',
    '    function __log(level, args){',
    '      try{',
    '        var msg=[];',
    '        for(var i=0;i<args.length;i++){',
    '          var a=args[i];',
    '          msg.push(typeof a==="object"?JSON.stringify(a):String(a));',
    '        }',
    '        parent.postMessage({type:"log",level:level,message:msg.join(" ")},"*");',
    '      }catch(e){}',
    '    }',
    '    console.log   = function(){ __log("log",   arguments); };',
    '    console.warn  = function(){ __log("warn",  arguments); };',
    '    console.error = function(){ __log("error", arguments); };',
    '    window.addEventListener("error", function(e){',
    '      __log("error", [e.message + " (line " + e.lineno + ")" ]);',
    '    });',
    '    function __runWhenReady(){',
    '      if(typeof window.app !== "function"){',
    '        setTimeout(__runWhenReady, 50);',
    '        return;',
    '      }',
    '      try {',
    userCode,
    '      } catch (e) { __log("error", [e.message]); }',
    '    }',
    '    window.addEventListener("load", __runWhenReady);',
    '  <\/script>',
    '<\/head>',
    '<body>',
    '  <div id="root"></div>',
    '<\/body>',
    '<\/html>'
  ].join('\n');
}

runBtn.onClick = function () {
  consolePane.el.replaceChildren();
  var code = editor.getValue();
  iframe.el.srcdoc = buildHTML(code);
  setTimeout(function () { setTab('preview'); }, 80);
};

clearBtn.onClick = function () {
  editor.setValue('');
  consolePane.el.replaceChildren();
  iframe.el.srcdoc = '';
};