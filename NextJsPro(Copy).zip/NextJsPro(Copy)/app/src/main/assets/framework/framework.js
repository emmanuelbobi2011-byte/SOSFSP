(function (global) {

  function showError(title, detail) {
    var box = document.getElementById('__err');
    if (!box) {
      box = document.createElement('div');
      box.id = '__err';
      box.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:99999;background:#dc2626;color:#fff;padding:12px;font:12px monospace;max-height:60vh;overflow:auto;white-space:pre-wrap';
      document.body.appendChild(box);
    }
    box.textContent = 'ERROR: ' + title + '\n\n' + (detail || '');
  }
  global.addEventListener('error', function (e) {
    showError('JavaScript error', (e.message || '') + '\n' + (e.filename || '') + ':' + (e.lineno || ''));
  });

  function toast(message, type, duration) {
    type = type || 'info';
    duration = duration || 2500;
    var colors = {
      info: 'background:#111827;color:#fff',
      success: 'background:#22c55e;color:#fff',
      error: 'background:#ef4444;color:#fff',
      warning: 'background:#facc15;color:#000'
    };
    var c = document.getElementById('__toasts');
    if (!c) {
      c = document.createElement('div');
      c.id = '__toasts';
      c.style.cssText = 'position:fixed;top:16px;left:0;right:0;z-index:9998;display:flex;flex-direction:column;align-items:center;gap:8px;pointer-events:none';
      document.body.appendChild(c);
    }
    var t = document.createElement('div');
    t.style.cssText = 'padding:12px 20px;border-radius:12px;font-weight:600;font-size:14px;box-shadow:0 6px 20px rgba(0,0,0,.2);max-width:90vw;transform:translateY(-20px);opacity:0;transition:all .25s ease;' + (colors[type] || colors.info);
    t.textContent = message;
    c.appendChild(t);
    requestAnimationFrame(function () {
      t.style.transform = 'translateY(0)';
      t.style.opacity = '1';
    });
    setTimeout(function () {
      t.style.transform = 'translateY(-20px)';
      t.style.opacity = '0';
      setTimeout(function () { t.remove(); }, 300);
    }, duration);
  }

  var store = {
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} },
    get: function (k, fb) { try { var v = localStorage.getItem(k); return v == null ? fb : JSON.parse(v); } catch (e) { return fb; } },
    remove: function (k) { try { localStorage.removeItem(k); } catch (e) {} },
    clear: function () { try { localStorage.clear(); } catch (e) {} }
  };

  var theme = {
    set: function (n) {
      if (n === 'dark') document.documentElement.classList.add('dark');
      else document.documentElement.classList.remove('dark');
      store.set('theme', n);
      return n;
    },
    get: function () { return document.documentElement.classList.contains('dark') ? 'dark' : 'light'; },
    toggle: function () { return this.set(this.get() === 'dark' ? 'light' : 'dark'); },
    init: function () { if (store.get('theme') === 'dark') document.documentElement.classList.add('dark'); }
  };

  var ANIMS = ['fade-in','fade-out','slide-up','slide-down','slide-left','slide-right','scale-in','bounce','shake'];
  function applyAnim(el, name) {
    if (ANIMS.indexOf(name) === -1) return;
    var cls = '__anim-' + name;
    el.classList.remove(cls);
    void el.offsetWidth;
    el.classList.add(cls);
  }

  function spinner(size) {
    size = size || 24;
    var n = create('div');
    n.style = 'inline-block rounded-full border-2 border-gray-300 border-t-blue-500 animate-spin';
    n.el.style.width = size + 'px';
    n.el.style.height = size + 'px';
    return n;
  }

  function skeleton(lines, opts) {
    lines = lines || 3;
    opts = opts || {};
    var n = create('div');
    n.style = opts.card ? 'bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm flex flex-col gap-3' : 'flex flex-col gap-3';
    for (var i = 0; i < lines; i++) {
      var line = create('div');
      line.style = 'h-4 bg-gray-200 dark:bg-gray-700 rounded animate-pulse';
      if (i === lines - 1) line.el.style.width = '60%';
      n.push(line);
    }
    return n;
  }

  function copy(text) {
    text = String(text);
    var fb = function () {
      var t = document.createElement('textarea');
      t.value = text;
      t.style.cssText = 'position:fixed;top:-1000px';
      document.body.appendChild(t);
      t.select();
      try { document.execCommand('copy'); toast('Copied', 'success'); }
      catch (e) { toast('Could not copy', 'error'); }
      t.remove();
    };
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { toast('Copied', 'success'); }).catch(fb);
      return;
    }
    fb();
  }

  function toDate(d) { return d instanceof Date ? d : new Date(d); }
  function formatTime(d) { return toDate(d).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' }); }
  function formatDate(d) { return toDate(d).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' }); }
  function formatAgo(d) {
    var s = Math.floor((Date.now() - toDate(d).getTime()) / 1000);
    if (s < 60) return s + 's ago';
    if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago';
    return Math.floor(s / 86400) + 'd ago';
  }

  var _tagDefaults = {};
  var _namedStyles = {};
  function defaults(tag, classes) {
    if (classes === undefined) return _tagDefaults[tag] || '';
    _tagDefaults[tag] = classes;
    return classes;
  }
  function styles(obj) {
    if (obj === undefined) return _namedStyles;
    for (var k in obj) if (obj.hasOwnProperty(k)) _namedStyles[k] = obj[k];
    return _namedStyles;
  }

  var ICONS = {
    home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    menu: '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
    minus: '<line x1="5" y1="12" x2="19" y2="12"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    check: '<polyline points="20 6 9 17 4 12"/>',
    arrowLeft: '<line x1="19" y1="12" x2="5" y2="12"/><polyline points="12 19 5 12 12 5"/>',
    arrowRight: '<line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/>',
    chevronLeft: '<polyline points="15 18 9 12 15 6"/>',
    chevronRight: '<polyline points="9 18 15 12 9 6"/>',
    edit: '<path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    heart: '<path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>',
    star: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
    user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
    bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
    mail: '<path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/>',
    phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
    messageCircle: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
    send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
    cart: '<circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>',
    bag: '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/><line x1="3" y1="6" x2="21" y2="6"/><path d="M16 10a4 4 0 0 1-8 0"/>',
    creditCard: '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
    wallet: '<path d="M21 12V7H5a2 2 0 0 1 0-4h14v4"/><path d="M3 5v14a2 2 0 0 0 2 2h16v-5"/><path d="M18 12a2 2 0 0 0 0 4h4v-4z"/>',
    gift: '<polyline points="20 12 20 22 4 22 4 12"/><rect x="2" y="7" width="20" height="5"/><line x1="12" y1="22" x2="12" y2="7"/><path d="M12 7H7.5a2.5 2.5 0 0 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h4.5a2.5 2.5 0 0 0 0-5C13 2 12 7 12 7z"/>',
    file: '<path d="M13 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><polyline points="13 2 13 9 20 9"/>',
    folder: '<path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
    sun: '<circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>',
    moon: '<path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>',
    wifi: '<path d="M5 12.55a11 11 0 0 1 14.08 0"/><path d="M1.42 9a16 16 0 0 1 21.16 0"/><path d="M8.53 16.11a6 6 0 0 1 6.95 0"/><line x1="12" y1="20" x2="12.01" y2="20"/>',
    zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
    droplet: '<path d="M12 2.69l5.66 5.66a8 8 0 1 1-11.31 0z"/>',
    tv: '<rect x="2" y="7" width="20" height="15" rx="2" ry="2"/><polyline points="17 2 12 7 7 2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    code: '<polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/>',
    terminal: '<polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/>',
    play: '<polygon points="5 3 19 12 5 21 5 3"/>',
    info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
    alertCircle: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>',
    helpCircle: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    moreH: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>'
  };

  function Node(tag, text) {
    this.el = document.createElement(tag);
    if (text != null) this.el.textContent = text;
    var d = _tagDefaults[tag];
    if (d) this.el.className = d;
  }
  Object.defineProperty(Node.prototype, 'style', {
    get: function () { return this.el.className; },
    set: function (c) { this.el.className = c; }
  });
  Object.defineProperty(Node.prototype, 'text', {
    get: function () { return this.el.textContent; },
    set: function (v) { this.el.textContent = v; }
  });
  Object.defineProperty(Node.prototype, 'value', {
    get: function () { return this.el.value; },
    set: function (v) { this.el.value = v; }
  });
  Object.defineProperty(Node.prototype, 'id', {
    get: function () { return this.el.id; },
    set: function (v) { this.el.id = v; }
  });
  Object.defineProperty(Node.prototype, 'src', {
    get: function () { return this.el.src; },
    set: function (v) { this.el.src = v; }
  });
  Object.defineProperty(Node.prototype, 'alt', {
    get: function () { return this.el.alt; },
    set: function (v) { this.el.alt = v; }
  });
  Object.defineProperty(Node.prototype, 'placeholder', {
    get: function () { return this.el.placeholder; },
    set: function (v) { this.el.placeholder = v; }
  });
  Object.defineProperty(Node.prototype, 'href', {
    get: function () { return this.el.href; },
    set: function (v) { this.el.href = v; }
  });
  Object.defineProperty(Node.prototype, 'onClick', {
    set: function (fn) { this.el.addEventListener('click', fn); }
  });
  Node.prototype.addClass = function () {
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j]) this.el.classList.add(parts[j]);
    }
    return this;
  };
  Node.prototype.removeClass = function () {
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j]) this.el.classList.remove(parts[j]);
    }
    return this;
  };
  Node.prototype.toggleClass = function () {
    var last = false;
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j]) last = this.el.classList.toggle(parts[j]);
    }
    return last;
  };
  Node.prototype.hasClass = function () {
    for (var i = 0; i < arguments.length; i++) {
      var parts = String(arguments[i]).split(/\s+/);
      for (var j = 0; j < parts.length; j++) if (parts[j] && !this.el.classList.contains(parts[j])) return false;
    }
    return true;
  };
  Node.prototype.use = function () {
    for (var i = 0; i < arguments.length; i++) {
      var s = _namedStyles[arguments[i]];
      if (s) this.addClass(s);
    }
    return this;
  };
  Node.prototype.animate = function (name) { applyAnim(this.el, name); return this; };
  Node.prototype.on = function (ev, fn) { this.el.addEventListener(ev, fn); return this; };
  Node.prototype.onHover = function (fn) { this.el.addEventListener('mouseenter', fn); return this; };
  Node.prototype.onLeave = function (fn) { this.el.addEventListener('mouseleave', fn); return this; };
  Node.prototype.push = function () {
    for (var i = 0; i < arguments.length; i++) {
      var c = arguments[i];
      this.el.append(c instanceof Node ? c.el : c);
    }
    return this;
  };

  function create(tag, text) { return new Node(tag, text); }
  function app(id) {
    var root = new Node('div');
    (document.getElementById(id || 'root') || document.body).append(root.el);
    return root;
  }
  function animate(node, name) {
    var el = node instanceof Node ? node.el : node;
    if (el) applyAnim(el, name);
    return node;
  }

  function row() { var n = create('div'); n.style = 'flex flex-row items-center'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function col() { var n = create('div'); n.style = 'flex flex-col'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function spacer() { var n = create('div'); n.style = 'flex-1'; return n; }
  function screen() {
    var n = create('div');
    n.style = 'min-h-screen p-4 flex flex-col gap-4';
    if (arguments.length) n.push.apply(n, arguments);
    return n;
  }
  function bottomBar() {
    var n = create('div');
    n.style = 'fixed bottom-0 left-0 right-0 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-700 p-4';
    if (arguments.length) n.push.apply(n, arguments);
    return n;
  }
  function badge(count) {
    var n = create('span', String(count));
    n.style = 'absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold';
    return n;
  }
  function iconBtn(name) {
    var btn = create('button');
    var extra = Array.prototype.slice.call(arguments, 1).join(' ');
    btn.style = ('relative p-2 rounded-full flex items-center justify-center ' + extra).trim();
    btn.push(svg(name, 'w-6 h-6'));
    return btn;
  }
  function scrollX() { var n = create('div'); n.style = 'flex flex-row gap-2 overflow-x-auto no-scrollbar'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function scrollY() { var n = create('div'); n.style = 'flex flex-col gap-2 overflow-y-auto no-scrollbar'; if (arguments.length) n.push.apply(n, arguments); return n; }
  function img(src, alt) {
    var n = create('img');
    n.src = src;
    n.alt = alt || '';
    n.style = Array.prototype.slice.call(arguments, 2).join(' ');
    return n;
  }
  function avatar(src) {
    var extra = Array.prototype.slice.call(arguments, 1).join(' ');
    return img(src, 'avatar', ('w-12 h-12 rounded-full object-cover ' + extra).trim());
  }
  function svg(name) {
    var cs = Array.prototype.slice.call(arguments, 1).filter(Boolean).join(' ');
    var hasW = /\bw-/.test(cs), hasH = /\bh-/.test(cs);
    var cls = (hasW ? '' : 'w-6 ') + (hasH ? '' : 'h-6 ') + cs;
    var wrap = new Node('span');
    wrap.style = cls.trim();
    wrap.el.style.display = 'inline-block';
    var el = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    el.setAttribute('viewBox', '0 0 24 24');
    el.setAttribute('fill', 'none');
    el.setAttribute('stroke', 'currentColor');
    el.setAttribute('stroke-width', '2');
    el.setAttribute('stroke-linecap', 'round');
    el.setAttribute('stroke-linejoin', 'round');
    el.setAttribute('width', '100%');
    el.setAttribute('height', '100%');
    el.innerHTML = ICONS[name] || '';
    wrap.el.append(el);
    return wrap;
  }
  function iconList() { return Object.keys(ICONS); }

  function dic(k, v, o) { o = o || {}; o[k] = v; return o; }
  function findDK(o, v) { if (!o) return undefined; for (var k in o) if (o.hasOwnProperty(k) && o[k] === v) return k; return undefined; }
  function findDV(o, k) { if (!o) return undefined; return o[k]; }

  function route(id, opts) {
    opts = opts || {};
    var target = document.getElementById(id);
    if (!target) { showError('route("' + id + '") no element', ''); return; }
    var parent = target.parentElement || document.body;
    var anim = opts.animate;
    for (var i = 0; i < parent.children.length; i++) {
      var child = parent.children[i];
      if (!child.id) continue;
      if (child === target) {
        child.style.display = '';
        if (anim) applyAnim(child, anim);
      } else {
        child.style.display = 'none';
      }
    }
    return target;
  }

  global.Node = Node;
  global.create = create;
  global.app = app;
  global.text = function (t) { return create('span', t); };
  global.button = function (t) { return create('button', t); };
  global.view = function () { return create('div'); };
  global.row = row;
  global.col = col;
  global.spacer = spacer;
  global.screen = screen;
  global.bottomBar = bottomBar;
  global.badge = badge;
  global.iconBtn = iconBtn;
  global.scrollX = scrollX;
  global.scrollY = scrollY;
  global.img = img;
  global.avatar = avatar;
  global.svg = svg;
  global.icons = iconList;
  global.dic = dic;
  global.findDK = findDK;
  global.findDV = findDV;
  global.route = route;
  global.defaults = defaults;
  global.styles = styles;
  global.toast = toast;
  global.store = store;
  global.theme = theme;
  global.spinner = spinner;
  global.skeleton = skeleton;
  global.copy = copy;
  global.formatTime = formatTime;
  global.formatDate = formatDate;
  global.formatAgo = formatAgo;
  global.animate = animate;

  theme.init();
})(window);